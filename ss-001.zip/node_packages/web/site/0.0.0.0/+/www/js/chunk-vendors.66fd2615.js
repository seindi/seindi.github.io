(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-vendors"],{"0299":function(t,e,n){"use strict";var r,i="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_".split(""),s=64,o={},a=0,c=0;function u(t){var e="";do{e=i[t%s]+e,t=Math.floor(t/s)}while(t>0);return e}function l(t){var e=0;for(c=0;c<t.length;c++)e=e*s+o[t.charAt(c)];return e}function h(){var t=u(+new Date);return t!==r?(a=0,r=t):t+"."+u(a++)}for(;c<s;c++)o[i[c]]=c;h.encode=u,h.decode=l,t.exports=h},"0829":function(t,e,n){"use strict";(function(t){n.d(e,"a",(function(){return Cu})),n.d(e,"b",(function(){return Sc})),n.d(e,"c",(function(){return dc})),n.d(e,"d",(function(){return ec})),n.d(e,"e",(function(){return ou})),n.d(e,"f",(function(){return kc})),n.d(e,"g",(function(){return E})),n.d(e,"h",(function(){return jc})),n.d(e,"i",(function(){return au})),n.d(e,"j",(function(){return cu})),n.d(e,"k",(function(){return L})),n.d(e,"l",(function(){return Du})),n.d(e,"m",(function(){return za})),n.d(e,"n",(function(){return st})),n.d(e,"o",(function(){return K})),n.d(e,"p",(function(){return Qa})),n.d(e,"q",(function(){return w})),n.d(e,"r",(function(){return G})),n.d(e,"s",(function(){return g})),n.d(e,"t",(function(){return $a})),n.d(e,"u",(function(){return $u})),n.d(e,"v",(function(){return nl})),n.d(e,"w",(function(){return el})),n.d(e,"x",(function(){return vc})),n.d(e,"y",(function(){return ic})),n.d(e,"z",(function(){return sc})),n.d(e,"A",(function(){return tc})),n.d(e,"B",(function(){return Ku})),n.d(e,"C",(function(){return Zu})),n.d(e,"D",(function(){return Ic})),n.d(e,"E",(function(){return oc})),n.d(e,"F",(function(){return gc})),n.d(e,"G",(function(){return yc})),n.d(e,"H",(function(){return _c})),n.d(e,"I",(function(){return ku})),n.d(e,"J",(function(){return Tu})),n.d(e,"K",(function(){return pc})),n.d(e,"L",(function(){return Yu})),n.d(e,"M",(function(){return Fu})),n.d(e,"N",(function(){return Mu})),n.d(e,"O",(function(){return Uu})),n.d(e,"P",(function(){return Bu})),n.d(e,"Q",(function(){return qu})),n.d(e,"R",(function(){return Vu})),n.d(e,"S",(function(){return rl})),n.d(e,"T",(function(){return vu})),n.d(e,"U",(function(){return wu})),n.d(e,"V",(function(){return Ec})),n.d(e,"W",(function(){return Oc})),n.d(e,"X",(function(){return Gu})),n.d(e,"Y",(function(){return Wu})),n.d(e,"Z",(function(){return yu})),n.d(e,"ab",(function(){return fu})),n.d(e,"bb",(function(){return cc})),n.d(e,"cb",(function(){return ac})),n.d(e,"db",(function(){return Xu})),n.d(e,"eb",(function(){return tl})),n.d(e,"fb",(function(){return zu})),n.d(e,"gb",(function(){return f})),n.d(e,"hb",(function(){return lu})),n.d(e,"ib",(function(){return Eu})),n.d(e,"jb",(function(){return Iu})),n.d(e,"kb",(function(){return Hu})),n.d(e,"lb",(function(){return wc})),n.d(e,"mb",(function(){return mu}));var r=n("589b"),i=n("22e5"),s=n("e691"),o=n("1fd5"),a=n("8f6b");const c="@firebase/firestore";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u{constructor(t){this.uid=t}isAuthenticated(){return null!=this.uid}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}u.UNAUTHENTICATED=new u(null),u.GOOGLE_CREDENTIALS=new u("google-credentials-uid"),u.FIRST_PARTY=new u("first-party-uid"),u.MOCK_USER=new u("mock-user");
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let l="9.5.0";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const h=new s["b"]("@firebase/firestore");function d(){return h.logLevel}function f(t){h.setLogLevel(t)}function p(t,...e){if(h.logLevel<=s["a"].DEBUG){const n=e.map(y);h.debug(`Firestore (${l}): ${t}`,...n)}}function m(t,...e){if(h.logLevel<=s["a"].ERROR){const n=e.map(y);h.error(`Firestore (${l}): ${t}`,...n)}}function g(t,...e){if(h.logLevel<=s["a"].WARN){const n=e.map(y);h.warn(`Firestore (${l}): ${t}`,...n)}}function y(t){if("string"==typeof t)return t;try{return e=t,JSON.stringify(e)}catch(e){return t}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function b(t="Unexpected state"){const e=`FIRESTORE (${l}) INTERNAL ASSERTION FAILED: `+t;throw m(e),new Error(e)}function v(t,e){t||b()}function w(t,e){t||b()}function _(t,e){return t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const I={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class E extends Error{constructor(t,e){super(e),this.code=t,this.message=e,this.name="FirebaseError",this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O{constructor(){this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T{constructor(t,e){this.user=e,this.type="OAuth",this.authHeaders={},this.authHeaders.Authorization="Bearer "+t}}class k{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable(()=>e(u.UNAUTHENTICATED))}shutdown(){}}class S{constructor(t){this.token=t,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(t,e){this.changeListener=e,t.enqueueRetryable(()=>e(this.token.user))}shutdown(){this.changeListener=null}}class A{constructor(t){this.t=t,this.currentUser=u.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(t,e){let n=this.i;const r=t=>this.i!==n?(n=this.i,e(t)):Promise.resolve();let i=new O;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new O,t.enqueueRetryable(()=>r(this.currentUser))};const s=()=>{const e=i;t.enqueueRetryable(async()=>{await e.promise,await r(this.currentUser)})},o=t=>{p("FirebaseCredentialsProvider","Auth detected"),this.auth=t,this.auth.addAuthTokenListener(this.o),s()};this.t.onInit(t=>o(t)),setTimeout(()=>{if(!this.auth){const t=this.t.getImmediate({optional:!0});t?o(t):(p("FirebaseCredentialsProvider","Auth not yet detected"),i.resolve(),i=new O)}},0),s()}getToken(){const t=this.i,e=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(e).then(e=>this.i!==t?(p("FirebaseCredentialsProvider","getToken aborted due to token change."),this.getToken()):e?(v("string"==typeof e.accessToken),new T(e.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){const t=this.auth&&this.auth.getUid();return v(null===t||"string"==typeof t),new u(t)}}class j{constructor(t,e,n){this.h=t,this.l=e,this.m=n,this.type="FirstParty",this.user=u.FIRST_PARTY}get authHeaders(){const t={"X-Goog-AuthUser":this.l},e=this.h.auth.getAuthHeaderValueForFirstParty([]);return e&&(t.Authorization=e),this.m&&(t["X-Goog-Iam-Authorization-Token"]=this.m),t}}class N{constructor(t,e,n){this.h=t,this.l=e,this.m=n}getToken(){return Promise.resolve(new j(this.h,this.l,this.m))}start(t,e){t.enqueueRetryable(()=>e(u.FIRST_PARTY))}shutdown(){}invalidateToken(){}}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C{constructor(t,e){this.previousValue=t,e&&(e.sequenceNumberHandler=t=>this.g(t),this.p=t=>e.writeSequenceNumber(t))}g(t){return this.previousValue=Math.max(t,this.previousValue),this.previousValue}next(){const t=++this.previousValue;return this.p&&this.p(t),t}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function R(t){const e="undefined"!=typeof self&&(self.crypto||self.msCrypto),n=new Uint8Array(t);if(e&&"function"==typeof e.getRandomValues)e.getRandomValues(n);else for(let r=0;r<t;r++)n[r]=Math.floor(256*Math.random());return n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */C.T=-1;class x{static I(){const t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",e=Math.floor(256/t.length)*t.length;let n="";for(;n.length<20;){const r=R(40);for(let i=0;i<r.length;++i)n.length<20&&r[i]<e&&(n+=t.charAt(r[i]%t.length))}return n}}function D(t,e){return t<e?-1:t>e?1:0}function P(t,e,n){return t.length===e.length&&t.every((t,r)=>n(t,e[r]))}function F(t){return t+"\0"}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L{constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new E(I.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new E(I.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<-62135596800)throw new E(I.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new E(I.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}static now(){return L.fromMillis(Date.now())}static fromDate(t){return L.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),n=Math.floor(1e6*(t-1e3*e));return new L(e,n)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(t){return this.seconds===t.seconds?D(this.nanoseconds,t.nanoseconds):D(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const t=this.seconds- -62135596800;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M{constructor(t){this.timestamp=t}static fromTimestamp(t){return new M(t)}static min(){return new M(new L(0,0))}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U(t){let e=0;for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e++;return e}function B(t,e){for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e(n,t[n])}function q(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V{constructor(t,e,n){void 0===e?e=0:e>t.length&&b(),void 0===n?n=t.length-e:n>t.length-e&&b(),this.segments=t,this.offset=e,this.len=n}get length(){return this.len}isEqual(t){return 0===V.comparator(this,t)}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof V?t.forEach(t=>{e.push(t)}):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=void 0===t?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return 0===this.length}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,n=this.limit();e<n;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const n=Math.min(t.length,e.length);for(let r=0;r<n;r++){const n=t.get(r),i=e.get(r);if(n<i)return-1;if(n>i)return 1}return t.length<e.length?-1:t.length>e.length?1:0}}class z extends V{construct(t,e,n){return new z(t,e,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}static fromString(...t){const e=[];for(const n of t){if(n.indexOf("//")>=0)throw new E(I.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);e.push(...n.split("/").filter(t=>t.length>0))}return new z(e)}static emptyPath(){return new z([])}}const H=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class K extends V{construct(t,e,n){return new K(t,e,n)}static isValidIdentifier(t){return H.test(t)}canonicalString(){return this.toArray().map(t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),K.isValidIdentifier(t)||(t="`"+t+"`"),t)).join(".")}toString(){return this.canonicalString()}isKeyField(){return 1===this.length&&"__name__"===this.get(0)}static keyField(){return new K(["__name__"])}static fromServerFormat(t){const e=[];let n="",r=0;const i=()=>{if(0===n.length)throw new E(I.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(n),n=""};let s=!1;for(;r<t.length;){const e=t[r];if("\\"===e){if(r+1===t.length)throw new E(I.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const e=t[r+1];if("\\"!==e&&"."!==e&&"`"!==e)throw new E(I.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);n+=e,r+=2}else"`"===e?(s=!s,r++):"."!==e||s?(n+=e,r++):(i(),r++)}if(i(),s)throw new E(I.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new K(e)}static emptyPath(){return new K([])}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ${constructor(t){this.fields=t,t.sort(K.comparator)}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return P(this.fields,t.fields,(t,e)=>t.isEqual(e))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function G(){return"undefined"!=typeof atob}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(t){this.binaryString=t}static fromBase64String(t){const e=atob(t);return new W(e)}static fromUint8Array(t){const e=function(t){let e="";for(let n=0;n<t.length;++n)e+=String.fromCharCode(t[n]);return e}(t);return new W(e)}toBase64(){return t=this.binaryString,btoa(t);var t}toUint8Array(){return function(t){const e=new Uint8Array(t.length);for(let n=0;n<t.length;n++)e[n]=t.charCodeAt(n);return e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return D(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}W.EMPTY_BYTE_STRING=new W("");const Y=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Q(t){if(v(!!t),"string"==typeof t){let e=0;const n=Y.exec(t);if(v(!!n),n[1]){let t=n[1];t=(t+"000000000").substr(0,9),e=Number(t)}const r=new Date(t);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:J(t.seconds),nanos:J(t.nanos)}}function J(t){return"number"==typeof t?t:"string"==typeof t?Number(t):0}function X(t){return"string"==typeof t?W.fromBase64String(t):W.fromUint8Array(t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Z(t){var e,n;return"server_timestamp"===(null===(n=((null===(e=null==t?void 0:t.mapValue)||void 0===e?void 0:e.fields)||{}).__type__)||void 0===n?void 0:n.stringValue)}function tt(t){const e=t.mapValue.fields.__previous_value__;return Z(e)?tt(e):e}function et(t){const e=Q(t.mapValue.fields.__local_write_time__.timestampValue);return new L(e.seconds,e.nanos)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nt(t){return null==t}function rt(t){return 0===t&&1/t==-1/0}function it(t){return"number"==typeof t&&Number.isInteger(t)&&!rt(t)&&t<=Number.MAX_SAFE_INTEGER&&t>=Number.MIN_SAFE_INTEGER}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class st{constructor(t){this.path=t}static fromPath(t){return new st(z.fromString(t))}static fromName(t){return new st(z.fromString(t).popFirst(5))}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}isEqual(t){return null!==t&&0===z.comparator(this.path,t.path)}toString(){return this.path.toString()}static comparator(t,e){return z.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new st(new z(t.slice()))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ot(t){return"nullValue"in t?0:"booleanValue"in t?1:"integerValue"in t||"doubleValue"in t?2:"timestampValue"in t?3:"stringValue"in t?5:"bytesValue"in t?6:"referenceValue"in t?7:"geoPointValue"in t?8:"arrayValue"in t?9:"mapValue"in t?Z(t)?4:10:b()}function at(t,e){const n=ot(t);if(n!==ot(e))return!1;switch(n){case 0:return!0;case 1:return t.booleanValue===e.booleanValue;case 4:return et(t).isEqual(et(e));case 3:return function(t,e){if("string"==typeof t.timestampValue&&"string"==typeof e.timestampValue&&t.timestampValue.length===e.timestampValue.length)return t.timestampValue===e.timestampValue;const n=Q(t.timestampValue),r=Q(e.timestampValue);return n.seconds===r.seconds&&n.nanos===r.nanos}(t,e);case 5:return t.stringValue===e.stringValue;case 6:return function(t,e){return X(t.bytesValue).isEqual(X(e.bytesValue))}(t,e);case 7:return t.referenceValue===e.referenceValue;case 8:return function(t,e){return J(t.geoPointValue.latitude)===J(e.geoPointValue.latitude)&&J(t.geoPointValue.longitude)===J(e.geoPointValue.longitude)}(t,e);case 2:return function(t,e){if("integerValue"in t&&"integerValue"in e)return J(t.integerValue)===J(e.integerValue);if("doubleValue"in t&&"doubleValue"in e){const n=J(t.doubleValue),r=J(e.doubleValue);return n===r?rt(n)===rt(r):isNaN(n)&&isNaN(r)}return!1}(t,e);case 9:return P(t.arrayValue.values||[],e.arrayValue.values||[],at);case 10:return function(t,e){const n=t.mapValue.fields||{},r=e.mapValue.fields||{};if(U(n)!==U(r))return!1;for(const i in n)if(n.hasOwnProperty(i)&&(void 0===r[i]||!at(n[i],r[i])))return!1;return!0}(t,e);default:return b()}}function ct(t,e){return void 0!==(t.values||[]).find(t=>at(t,e))}function ut(t,e){const n=ot(t),r=ot(e);if(n!==r)return D(n,r);switch(n){case 0:return 0;case 1:return D(t.booleanValue,e.booleanValue);case 2:return function(t,e){const n=J(t.integerValue||t.doubleValue),r=J(e.integerValue||e.doubleValue);return n<r?-1:n>r?1:n===r?0:isNaN(n)?isNaN(r)?0:-1:1}(t,e);case 3:return lt(t.timestampValue,e.timestampValue);case 4:return lt(et(t),et(e));case 5:return D(t.stringValue,e.stringValue);case 6:return function(t,e){const n=X(t),r=X(e);return n.compareTo(r)}(t.bytesValue,e.bytesValue);case 7:return function(t,e){const n=t.split("/"),r=e.split("/");for(let i=0;i<n.length&&i<r.length;i++){const t=D(n[i],r[i]);if(0!==t)return t}return D(n.length,r.length)}(t.referenceValue,e.referenceValue);case 8:return function(t,e){const n=D(J(t.latitude),J(e.latitude));return 0!==n?n:D(J(t.longitude),J(e.longitude))}(t.geoPointValue,e.geoPointValue);case 9:return function(t,e){const n=t.values||[],r=e.values||[];for(let i=0;i<n.length&&i<r.length;++i){const t=ut(n[i],r[i]);if(t)return t}return D(n.length,r.length)}(t.arrayValue,e.arrayValue);case 10:return function(t,e){const n=t.fields||{},r=Object.keys(n),i=e.fields||{},s=Object.keys(i);r.sort(),s.sort();for(let o=0;o<r.length&&o<s.length;++o){const t=D(r[o],s[o]);if(0!==t)return t;const e=ut(n[r[o]],i[s[o]]);if(0!==e)return e}return D(r.length,s.length)}(t.mapValue,e.mapValue);default:throw b()}}function lt(t,e){if("string"==typeof t&&"string"==typeof e&&t.length===e.length)return D(t,e);const n=Q(t),r=Q(e),i=D(n.seconds,r.seconds);return 0!==i?i:D(n.nanos,r.nanos)}function ht(t){return dt(t)}function dt(t){return"nullValue"in t?"null":"booleanValue"in t?""+t.booleanValue:"integerValue"in t?""+t.integerValue:"doubleValue"in t?""+t.doubleValue:"timestampValue"in t?function(t){const e=Q(t);return`time(${e.seconds},${e.nanos})`}(t.timestampValue):"stringValue"in t?t.stringValue:"bytesValue"in t?X(t.bytesValue).toBase64():"referenceValue"in t?(n=t.referenceValue,st.fromName(n).toString()):"geoPointValue"in t?`geo(${(e=t.geoPointValue).latitude},${e.longitude})`:"arrayValue"in t?function(t){let e="[",n=!0;for(const r of t.values||[])n?n=!1:e+=",",e+=dt(r);return e+"]"}(t.arrayValue):"mapValue"in t?function(t){const e=Object.keys(t.fields||{}).sort();let n="{",r=!0;for(const i of e)r?r=!1:n+=",",n+=`${i}:${dt(t.fields[i])}`;return n+"}"}(t.mapValue):b();var e,n}function ft(t,e){return{referenceValue:`projects/${t.projectId}/databases/${t.database}/documents/${e.path.canonicalString()}`}}function pt(t){return!!t&&"integerValue"in t}function mt(t){return!!t&&"arrayValue"in t}function gt(t){return!!t&&"nullValue"in t}function yt(t){return!!t&&"doubleValue"in t&&isNaN(Number(t.doubleValue))}function bt(t){return!!t&&"mapValue"in t}function vt(t){if(t.geoPointValue)return{geoPointValue:Object.assign({},t.geoPointValue)};if(t.timestampValue&&"object"==typeof t.timestampValue)return{timestampValue:Object.assign({},t.timestampValue)};if(t.mapValue){const e={mapValue:{fields:{}}};return B(t.mapValue.fields,(t,n)=>e.mapValue.fields[t]=vt(n)),e}if(t.arrayValue){const e={arrayValue:{values:[]}};for(let n=0;n<(t.arrayValue.values||[]).length;++n)e.arrayValue.values[n]=vt(t.arrayValue.values[n]);return e}return Object.assign({},t)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(t){this.value=t}static empty(){return new wt({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let n=0;n<t.length-1;++n)if(e=(e.mapValue.fields||{})[t.get(n)],!bt(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=vt(e)}setAll(t){let e=K.emptyPath(),n={},r=[];t.forEach((t,i)=>{if(!e.isImmediateParentOf(i)){const t=this.getFieldsMap(e);this.applyChanges(t,n,r),n={},r=[],e=i.popLast()}t?n[i.lastSegment()]=vt(t):r.push(i.lastSegment())});const i=this.getFieldsMap(e);this.applyChanges(i,n,r)}delete(t){const e=this.field(t.popLast());bt(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return at(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let n=0;n<t.length;++n){let r=e.mapValue.fields[t.get(n)];bt(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},e.mapValue.fields[t.get(n)]=r),e=r}return e.mapValue.fields}applyChanges(t,e,n){B(e,(e,n)=>t[e]=n);for(const r of n)delete t[r]}clone(){return new wt(vt(this.value))}}function _t(t){const e=[];return B(t.fields,(t,n)=>{const r=new K([t]);if(bt(n)){const t=_t(n.mapValue).fields;if(0===t.length)e.push(r);else for(const n of t)e.push(r.child(n))}else e.push(r)}),new $(e)
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class It{constructor(t,e,n,r,i){this.key=t,this.documentType=e,this.version=n,this.data=r,this.documentState=i}static newInvalidDocument(t){return new It(t,0,M.min(),wt.empty(),0)}static newFoundDocument(t,e,n){return new It(t,1,e,n,0)}static newNoDocument(t,e){return new It(t,2,e,wt.empty(),0)}static newUnknownDocument(t,e){return new It(t,3,e,wt.empty(),2)}convertToFoundDocument(t,e){return this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=wt.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=wt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this}get hasLocalMutations(){return 1===this.documentState}get hasCommittedMutations(){return 2===this.documentState}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return 0!==this.documentType}isFoundDocument(){return 1===this.documentType}isNoDocument(){return 2===this.documentType}isUnknownDocument(){return 3===this.documentType}isEqual(t){return t instanceof It&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}clone(){return new It(this.key,this.documentType,this.version,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{constructor(t,e=null,n=[],r=[],i=null,s=null,o=null){this.path=t,this.collectionGroup=e,this.orderBy=n,this.filters=r,this.limit=i,this.startAt=s,this.endAt=o,this.A=null}}function Ot(t,e=null,n=[],r=[],i=null,s=null,o=null){return new Et(t,e,n,r,i,s,o)}function Tt(t){const e=_(t);if(null===e.A){let t=e.path.canonicalString();null!==e.collectionGroup&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(t=>Nt(t)).join(","),t+="|ob:",t+=e.orderBy.map(t=>function(t){return t.field.canonicalString()+t.dir}(t)).join(","),nt(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=Bt(e.startAt)),e.endAt&&(t+="|ub:",t+=Bt(e.endAt)),e.A=t}return e.A}function kt(t){let e=t.path.canonicalString();return null!==t.collectionGroup&&(e+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(e+=`, filters: [${t.filters.map(t=>{return`${(e=t).field.canonicalString()} ${e.op} ${ht(e.value)}`;var e}).join(", ")}]`),nt(t.limit)||(e+=", limit: "+t.limit),t.orderBy.length>0&&(e+=`, orderBy: [${t.orderBy.map(t=>function(t){return`${t.field.canonicalString()} (${t.dir})`}(t)).join(", ")}]`),t.startAt&&(e+=", startAt: "+Bt(t.startAt)),t.endAt&&(e+=", endAt: "+Bt(t.endAt)),`Target(${e})`}function St(t,e){if(t.limit!==e.limit)return!1;if(t.orderBy.length!==e.orderBy.length)return!1;for(let i=0;i<t.orderBy.length;i++)if(!Vt(t.orderBy[i],e.orderBy[i]))return!1;if(t.filters.length!==e.filters.length)return!1;for(let i=0;i<t.filters.length;i++)if(n=t.filters[i],r=e.filters[i],n.op!==r.op||!n.field.isEqual(r.field)||!at(n.value,r.value))return!1;var n,r;return t.collectionGroup===e.collectionGroup&&!!t.path.isEqual(e.path)&&!!Ht(t.startAt,e.startAt)&&Ht(t.endAt,e.endAt)}function At(t){return st.isDocumentKey(t.path)&&null===t.collectionGroup&&0===t.filters.length}class jt extends class{}{constructor(t,e,n){super(),this.field=t,this.op=e,this.value=n}static create(t,e,n){return t.isKeyField()?"in"===e||"not-in"===e?this.R(t,e,n):new Ct(t,e,n):"array-contains"===e?new Pt(t,n):"in"===e?new Ft(t,n):"not-in"===e?new Lt(t,n):"array-contains-any"===e?new Mt(t,n):new jt(t,e,n)}static R(t,e,n){return"in"===e?new Rt(t,n):new xt(t,n)}matches(t){const e=t.data.field(this.field);return"!="===this.op?null!==e&&this.P(ut(e,this.value)):null!==e&&ot(this.value)===ot(e)&&this.P(ut(e,this.value))}P(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return 0===t;case"!=":return 0!==t;case">":return t>0;case">=":return t>=0;default:return b()}}v(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}}function Nt(t){return t.field.canonicalString()+t.op.toString()+ht(t.value)}class Ct extends jt{constructor(t,e,n){super(t,e,n),this.key=st.fromName(n.referenceValue)}matches(t){const e=st.comparator(t.key,this.key);return this.P(e)}}class Rt extends jt{constructor(t,e){super(t,"in",e),this.keys=Dt("in",e)}matches(t){return this.keys.some(e=>e.isEqual(t.key))}}class xt extends jt{constructor(t,e){super(t,"not-in",e),this.keys=Dt("not-in",e)}matches(t){return!this.keys.some(e=>e.isEqual(t.key))}}function Dt(t,e){var n;return((null===(n=e.arrayValue)||void 0===n?void 0:n.values)||[]).map(t=>st.fromName(t.referenceValue))}class Pt extends jt{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return mt(e)&&ct(e.arrayValue,this.value)}}class Ft extends jt{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return null!==e&&ct(this.value.arrayValue,e)}}class Lt extends jt{constructor(t,e){super(t,"not-in",e)}matches(t){if(ct(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return null!==e&&!ct(this.value.arrayValue,e)}}class Mt extends jt{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!mt(e)||!e.arrayValue.values)&&e.arrayValue.values.some(t=>ct(this.value.arrayValue,t))}}class Ut{constructor(t,e){this.position=t,this.before=e}}function Bt(t){return`${t.before?"b":"a"}:${t.position.map(t=>ht(t)).join(",")}`}class qt{constructor(t,e="asc"){this.field=t,this.dir=e}}function Vt(t,e){return t.dir===e.dir&&t.field.isEqual(e.field)}function zt(t,e,n){let r=0;for(let i=0;i<t.position.length;i++){const s=e[i],o=t.position[i];if(r=s.field.isKeyField()?st.comparator(st.fromName(o.referenceValue),n.key):ut(o,n.data.field(s.field)),"desc"===s.dir&&(r*=-1),0!==r)break}return t.before?r<=0:r<0}function Ht(t,e){if(null===t)return null===e;if(null===e)return!1;if(t.before!==e.before||t.position.length!==e.position.length)return!1;for(let n=0;n<t.position.length;n++)if(!at(t.position[n],e.position[n]))return!1;return!0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kt{constructor(t,e=null,n=[],r=[],i=null,s="F",o=null,a=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=n,this.filters=r,this.limit=i,this.limitType=s,this.startAt=o,this.endAt=a,this.V=null,this.S=null,this.startAt,this.endAt}}function $t(t,e,n,r,i,s,o,a){return new Kt(t,e,n,r,i,s,o,a)}function Gt(t){return new Kt(t)}function Wt(t){return!nt(t.limit)&&"F"===t.limitType}function Yt(t){return!nt(t.limit)&&"L"===t.limitType}function Qt(t){return t.explicitOrderBy.length>0?t.explicitOrderBy[0].field:null}function Jt(t){for(const e of t.filters)if(e.v())return e.field;return null}function Xt(t){return null!==t.collectionGroup}function Zt(t){const e=_(t);if(null===e.V){e.V=[];const t=Jt(e),n=Qt(e);if(null!==t&&null===n)t.isKeyField()||e.V.push(new qt(t)),e.V.push(new qt(K.keyField(),"asc"));else{let t=!1;for(const n of e.explicitOrderBy)e.V.push(n),n.field.isKeyField()&&(t=!0);if(!t){const t=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";e.V.push(new qt(K.keyField(),t))}}}return e.V}function te(t){const e=_(t);if(!e.S)if("F"===e.limitType)e.S=Ot(e.path,e.collectionGroup,Zt(e),e.filters,e.limit,e.startAt,e.endAt);else{const t=[];for(const i of Zt(e)){const e="desc"===i.dir?"asc":"desc";t.push(new qt(i.field,e))}const n=e.endAt?new Ut(e.endAt.position,!e.endAt.before):null,r=e.startAt?new Ut(e.startAt.position,!e.startAt.before):null;e.S=Ot(e.path,e.collectionGroup,t,e.filters,e.limit,n,r)}return e.S}function ee(t,e,n){return new Kt(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),e,n,t.startAt,t.endAt)}function ne(t,e){return St(te(t),te(e))&&t.limitType===e.limitType}function re(t){return`${Tt(te(t))}|lt:${t.limitType}`}function ie(t){return`Query(target=${kt(te(t))}; limitType=${t.limitType})`}function se(t,e){return e.isFoundDocument()&&function(t,e){const n=e.key.path;return null!==t.collectionGroup?e.key.hasCollectionId(t.collectionGroup)&&t.path.isPrefixOf(n):st.isDocumentKey(t.path)?t.path.isEqual(n):t.path.isImmediateParentOf(n)}(t,e)&&function(t,e){for(const n of t.explicitOrderBy)if(!n.field.isKeyField()&&null===e.data.field(n.field))return!1;return!0}(t,e)&&function(t,e){for(const n of t.filters)if(!n.matches(e))return!1;return!0}(t,e)&&function(t,e){return!(t.startAt&&!zt(t.startAt,Zt(t),e))&&(!t.endAt||!zt(t.endAt,Zt(t),e))}(t,e)}function oe(t){return(e,n)=>{let r=!1;for(const i of Zt(t)){const t=ae(i,e,n);if(0!==t)return t;r=r||i.field.isKeyField()}return 0}}function ae(t,e,n){const r=t.field.isKeyField()?st.comparator(e.key,n.key):function(t,e,n){const r=e.data.field(t),i=n.data.field(t);return null!==r&&null!==i?ut(r,i):b()}(t.field,e,n);switch(t.dir){case"asc":return r;case"desc":return-1*r;default:return b()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ce(t,e){if(t.D){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:rt(e)?"-0":e}}function ue(t){return{integerValue:""+t}}function le(t,e){return it(e)?ue(e):ce(t,e)}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class he{constructor(){this._=void 0}}function de(t,e,n){return t instanceof me?function(t,e){const n={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:t.seconds,nanos:t.nanoseconds}}}};return e&&(n.fields.__previous_value__=e),{mapValue:n}}(n,e):t instanceof ge?ye(t,e):t instanceof be?ve(t,e):function(t,e){const n=pe(t,e),r=_e(n)+_e(t.C);return pt(n)&&pt(t.C)?ue(r):ce(t.N,r)}(t,e)}function fe(t,e,n){return t instanceof ge?ye(t,e):t instanceof be?ve(t,e):n}function pe(t,e){return t instanceof we?pt(n=e)||function(t){return!!t&&"doubleValue"in t}(n)?e:{integerValue:0}:null;var n}class me extends he{}class ge extends he{constructor(t){super(),this.elements=t}}function ye(t,e){const n=Ie(e);for(const r of t.elements)n.some(t=>at(t,r))||n.push(r);return{arrayValue:{values:n}}}class be extends he{constructor(t){super(),this.elements=t}}function ve(t,e){let n=Ie(e);for(const r of t.elements)n=n.filter(t=>!at(t,r));return{arrayValue:{values:n}}}class we extends he{constructor(t,e){super(),this.N=t,this.C=e}}function _e(t){return J(t.integerValue||t.doubleValue)}function Ie(t){return mt(t)&&t.arrayValue.values?t.arrayValue.values.slice():[]}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ee{constructor(t,e){this.field=t,this.transform=e}}function Oe(t,e){return t.field.isEqual(e.field)&&function(t,e){return t instanceof ge&&e instanceof ge||t instanceof be&&e instanceof be?P(t.elements,e.elements,at):t instanceof we&&e instanceof we?at(t.C,e.C):t instanceof me&&e instanceof me}(t.transform,e.transform)}class Te{constructor(t,e){this.version=t,this.transformResults=e}}class ke{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new ke}static exists(t){return new ke(void 0,t)}static updateTime(t){return new ke(t)}get isNone(){return void 0===this.updateTime&&void 0===this.exists}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}function Se(t,e){return void 0!==t.updateTime?e.isFoundDocument()&&e.version.isEqual(t.updateTime):void 0===t.exists||t.exists===e.isFoundDocument()}class Ae{}function je(t,e,n){t instanceof De?function(t,e,n){const r=t.value.clone(),i=Le(t.fieldTransforms,e,n.transformResults);r.setAll(i),e.convertToFoundDocument(n.version,r).setHasCommittedMutations()}(t,e,n):t instanceof Pe?function(t,e,n){if(!Se(t.precondition,e))return void e.convertToUnknownDocument(n.version);const r=Le(t.fieldTransforms,e,n.transformResults),i=e.data;i.setAll(Fe(t)),i.setAll(r),e.convertToFoundDocument(n.version,i).setHasCommittedMutations()}(t,e,n):function(t,e,n){e.convertToNoDocument(n.version).setHasCommittedMutations()}(0,e,n)}function Ne(t,e,n){t instanceof De?function(t,e,n){if(!Se(t.precondition,e))return;const r=t.value.clone(),i=Me(t.fieldTransforms,n,e);r.setAll(i),e.convertToFoundDocument(xe(e),r).setHasLocalMutations()}(t,e,n):t instanceof Pe?function(t,e,n){if(!Se(t.precondition,e))return;const r=Me(t.fieldTransforms,n,e),i=e.data;i.setAll(Fe(t)),i.setAll(r),e.convertToFoundDocument(xe(e),i).setHasLocalMutations()}(t,e,n):function(t,e){Se(t.precondition,e)&&e.convertToNoDocument(M.min())}(t,e)}function Ce(t,e){let n=null;for(const r of t.fieldTransforms){const t=e.data.field(r.field),i=pe(r.transform,t||null);null!=i&&(null==n&&(n=wt.empty()),n.set(r.field,i))}return n||null}function Re(t,e){return t.type===e.type&&!!t.key.isEqual(e.key)&&!!t.precondition.isEqual(e.precondition)&&!!function(t,e){return void 0===t&&void 0===e||!(!t||!e)&&P(t,e,(t,e)=>Oe(t,e))}(t.fieldTransforms,e.fieldTransforms)&&(0===t.type?t.value.isEqual(e.value):1!==t.type||t.data.isEqual(e.data)&&t.fieldMask.isEqual(e.fieldMask))}function xe(t){return t.isFoundDocument()?t.version:M.min()}class De extends Ae{constructor(t,e,n,r=[]){super(),this.key=t,this.value=e,this.precondition=n,this.fieldTransforms=r,this.type=0}}class Pe extends Ae{constructor(t,e,n,r,i=[]){super(),this.key=t,this.data=e,this.fieldMask=n,this.precondition=r,this.fieldTransforms=i,this.type=1}}function Fe(t){const e=new Map;return t.fieldMask.fields.forEach(n=>{if(!n.isEmpty()){const r=t.data.field(n);e.set(n,r)}}),e}function Le(t,e,n){const r=new Map;v(t.length===n.length);for(let i=0;i<n.length;i++){const s=t[i],o=s.transform,a=e.data.field(s.field);r.set(s.field,fe(o,a,n[i]))}return r}function Me(t,e,n){const r=new Map;for(const i of t){const t=i.transform,s=n.data.field(i.field);r.set(i.field,de(t,s,e))}return r}class Ue extends Ae{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}}class Be extends Ae{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qe{constructor(t){this.count=t}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ve,ze;function He(t){switch(t){default:return b();case I.CANCELLED:case I.UNKNOWN:case I.DEADLINE_EXCEEDED:case I.RESOURCE_EXHAUSTED:case I.INTERNAL:case I.UNAVAILABLE:case I.UNAUTHENTICATED:return!1;case I.INVALID_ARGUMENT:case I.NOT_FOUND:case I.ALREADY_EXISTS:case I.PERMISSION_DENIED:case I.FAILED_PRECONDITION:case I.ABORTED:case I.OUT_OF_RANGE:case I.UNIMPLEMENTED:case I.DATA_LOSS:return!0}}function Ke(t){if(void 0===t)return m("GRPC error has no .code"),I.UNKNOWN;switch(t){case Ve.OK:return I.OK;case Ve.CANCELLED:return I.CANCELLED;case Ve.UNKNOWN:return I.UNKNOWN;case Ve.DEADLINE_EXCEEDED:return I.DEADLINE_EXCEEDED;case Ve.RESOURCE_EXHAUSTED:return I.RESOURCE_EXHAUSTED;case Ve.INTERNAL:return I.INTERNAL;case Ve.UNAVAILABLE:return I.UNAVAILABLE;case Ve.UNAUTHENTICATED:return I.UNAUTHENTICATED;case Ve.INVALID_ARGUMENT:return I.INVALID_ARGUMENT;case Ve.NOT_FOUND:return I.NOT_FOUND;case Ve.ALREADY_EXISTS:return I.ALREADY_EXISTS;case Ve.PERMISSION_DENIED:return I.PERMISSION_DENIED;case Ve.FAILED_PRECONDITION:return I.FAILED_PRECONDITION;case Ve.ABORTED:return I.ABORTED;case Ve.OUT_OF_RANGE:return I.OUT_OF_RANGE;case Ve.UNIMPLEMENTED:return I.UNIMPLEMENTED;case Ve.DATA_LOSS:return I.DATA_LOSS;default:return b()}}(ze=Ve||(Ve={}))[ze.OK=0]="OK",ze[ze.CANCELLED=1]="CANCELLED",ze[ze.UNKNOWN=2]="UNKNOWN",ze[ze.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ze[ze.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ze[ze.NOT_FOUND=5]="NOT_FOUND",ze[ze.ALREADY_EXISTS=6]="ALREADY_EXISTS",ze[ze.PERMISSION_DENIED=7]="PERMISSION_DENIED",ze[ze.UNAUTHENTICATED=16]="UNAUTHENTICATED",ze[ze.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ze[ze.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ze[ze.ABORTED=10]="ABORTED",ze[ze.OUT_OF_RANGE=11]="OUT_OF_RANGE",ze[ze.UNIMPLEMENTED=12]="UNIMPLEMENTED",ze[ze.INTERNAL=13]="INTERNAL",ze[ze.UNAVAILABLE=14]="UNAVAILABLE",ze[ze.DATA_LOSS=15]="DATA_LOSS";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(t,e){this.comparator=t,this.root=e||We.EMPTY}insert(t,e){return new $e(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,We.BLACK,null,null))}remove(t){return new $e(this.comparator,this.root.remove(t,this.comparator).copy(null,null,We.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const n=this.comparator(t,e.key);if(0===n)return e.value;n<0?e=e.left:n>0&&(e=e.right)}return null}indexOf(t){let e=0,n=this.root;for(;!n.isEmpty();){const r=this.comparator(t,n.key);if(0===r)return e+n.left.size;r<0?n=n.left:(e+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal((e,n)=>(t(e,n),!1))}toString(){const t=[];return this.inorderTraversal((e,n)=>(t.push(`${e}:${n}`),!1)),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new Ge(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new Ge(this.root,t,this.comparator,!1)}getReverseIterator(){return new Ge(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new Ge(this.root,t,this.comparator,!0)}}class Ge{constructor(t,e,n,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!t.isEmpty();)if(i=e?n(t.key,e):1,r&&(i*=-1),i<0)t=this.isReverse?t.left:t.right;else{if(0===i){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(0===this.nodeStack.length)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class We{constructor(t,e,n,r,i){this.key=t,this.value=e,this.color=null!=n?n:We.RED,this.left=null!=r?r:We.EMPTY,this.right=null!=i?i:We.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,n,r,i){return new We(null!=t?t:this.key,null!=e?e:this.value,null!=n?n:this.color,null!=r?r:this.left,null!=i?i:this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,n){let r=this;const i=n(t,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(t,e,n),null):0===i?r.copy(null,e,null,null,null):r.copy(null,null,null,null,r.right.insert(t,e,n)),r.fixUp()}removeMin(){if(this.left.isEmpty())return We.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let n,r=this;if(e(t,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(t,e),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),0===e(t,r.key)){if(r.right.isEmpty())return We.EMPTY;n=r.right.min(),r=r.copy(n.key,n.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(t,e))}return r.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,We.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,We.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw b();if(this.right.isRed())throw b();const t=this.left.check();if(t!==this.right.check())throw b();return t+(this.isRed()?0:1)}}We.EMPTY=null,We.RED=!0,We.BLACK=!1,We.EMPTY=new class{constructor(){this.size=0}get key(){throw b()}get value(){throw b()}get color(){throw b()}get left(){throw b()}get right(){throw b()}copy(t,e,n,r,i){return this}insert(t,e,n){return new We(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ye{constructor(t){this.comparator=t,this.data=new $e(this.comparator)}has(t){return null!==this.data.get(t)}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal((e,n)=>(t(e),!1))}forEachInRange(t,e){const n=this.data.getIteratorFrom(t[0]);for(;n.hasNext();){const r=n.getNext();if(this.comparator(r.key,t[1])>=0)return;e(r.key)}}forEachWhile(t,e){let n;for(n=void 0!==e?this.data.getIteratorFrom(e):this.data.getIterator();n.hasNext();)if(!t(n.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new Qe(this.data.getIterator())}getIteratorFrom(t){return new Qe(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach(t=>{e=e.add(t)}),e}isEqual(t){if(!(t instanceof Ye))return!1;if(this.size!==t.size)return!1;const e=this.data.getIterator(),n=t.data.getIterator();for(;e.hasNext();){const t=e.getNext().key,r=n.getNext().key;if(0!==this.comparator(t,r))return!1}return!0}toArray(){const t=[];return this.forEach(e=>{t.push(e)}),t}toString(){const t=[];return this.forEach(e=>t.push(e)),"SortedSet("+t.toString()+")"}copy(t){const e=new Ye(this.comparator);return e.data=t,e}}class Qe{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Je=new $e(st.comparator);function Xe(){return Je}const Ze=new $e(st.comparator);function tn(){return Ze}const en=new $e(st.comparator);function nn(){return en}const rn=new Ye(st.comparator);function sn(...t){let e=rn;for(const n of t)e=e.add(n);return e}const on=new Ye(D);function an(){return on}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cn{constructor(t,e,n,r,i){this.snapshotVersion=t,this.targetChanges=e,this.targetMismatches=n,this.documentUpdates=r,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(t,e){const n=new Map;return n.set(t,un.createSynthesizedTargetChangeForCurrentChange(t,e)),new cn(M.min(),n,an(),Xe(),sn())}}class un{constructor(t,e,n,r,i){this.resumeToken=t,this.current=e,this.addedDocuments=n,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(t,e){return new un(W.EMPTY_BYTE_STRING,e,sn(),sn(),sn())}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(t,e,n,r){this.k=t,this.removedTargetIds=e,this.key=n,this.$=r}}class hn{constructor(t,e){this.targetId=t,this.O=e}}class dn{constructor(t,e,n=W.EMPTY_BYTE_STRING,r=null){this.state=t,this.targetIds=e,this.resumeToken=n,this.cause=r}}class fn{constructor(){this.F=0,this.M=gn(),this.L=W.EMPTY_BYTE_STRING,this.B=!1,this.U=!0}get current(){return this.B}get resumeToken(){return this.L}get q(){return 0!==this.F}get K(){return this.U}j(t){t.approximateByteSize()>0&&(this.U=!0,this.L=t)}W(){let t=sn(),e=sn(),n=sn();return this.M.forEach((r,i)=>{switch(i){case 0:t=t.add(r);break;case 2:e=e.add(r);break;case 1:n=n.add(r);break;default:b()}}),new un(this.L,this.B,t,e,n)}G(){this.U=!1,this.M=gn()}H(t,e){this.U=!0,this.M=this.M.insert(t,e)}J(t){this.U=!0,this.M=this.M.remove(t)}Y(){this.F+=1}X(){this.F-=1}Z(){this.U=!0,this.B=!0}}class pn{constructor(t){this.tt=t,this.et=new Map,this.nt=Xe(),this.st=mn(),this.it=new Ye(D)}rt(t){for(const e of t.k)t.$&&t.$.isFoundDocument()?this.ot(e,t.$):this.ct(e,t.key,t.$);for(const e of t.removedTargetIds)this.ct(e,t.key,t.$)}at(t){this.forEachTarget(t,e=>{const n=this.ut(e);switch(t.state){case 0:this.ht(e)&&n.j(t.resumeToken);break;case 1:n.X(),n.q||n.G(),n.j(t.resumeToken);break;case 2:n.X(),n.q||this.removeTarget(e);break;case 3:this.ht(e)&&(n.Z(),n.j(t.resumeToken));break;case 4:this.ht(e)&&(this.lt(e),n.j(t.resumeToken));break;default:b()}})}forEachTarget(t,e){t.targetIds.length>0?t.targetIds.forEach(e):this.et.forEach((t,n)=>{this.ht(n)&&e(n)})}ft(t){const e=t.targetId,n=t.O.count,r=this.dt(e);if(r){const t=r.target;if(At(t))if(0===n){const n=new st(t.path);this.ct(e,n,It.newNoDocument(n,M.min()))}else v(1===n);else this.wt(e)!==n&&(this.lt(e),this.it=this.it.add(e))}}_t(t){const e=new Map;this.et.forEach((n,r)=>{const i=this.dt(r);if(i){if(n.current&&At(i.target)){const e=new st(i.target.path);null!==this.nt.get(e)||this.gt(r,e)||this.ct(r,e,It.newNoDocument(e,t))}n.K&&(e.set(r,n.W()),n.G())}});let n=sn();this.st.forEach((t,e)=>{let r=!0;e.forEachWhile(t=>{const e=this.dt(t);return!e||2===e.purpose||(r=!1,!1)}),r&&(n=n.add(t))});const r=new cn(t,e,this.it,this.nt,n);return this.nt=Xe(),this.st=mn(),this.it=new Ye(D),r}ot(t,e){if(!this.ht(t))return;const n=this.gt(t,e.key)?2:0;this.ut(t).H(e.key,n),this.nt=this.nt.insert(e.key,e),this.st=this.st.insert(e.key,this.yt(e.key).add(t))}ct(t,e,n){if(!this.ht(t))return;const r=this.ut(t);this.gt(t,e)?r.H(e,1):r.J(e),this.st=this.st.insert(e,this.yt(e).delete(t)),n&&(this.nt=this.nt.insert(e,n))}removeTarget(t){this.et.delete(t)}wt(t){const e=this.ut(t).W();return this.tt.getRemoteKeysForTarget(t).size+e.addedDocuments.size-e.removedDocuments.size}Y(t){this.ut(t).Y()}ut(t){let e=this.et.get(t);return e||(e=new fn,this.et.set(t,e)),e}yt(t){let e=this.st.get(t);return e||(e=new Ye(D),this.st=this.st.insert(t,e)),e}ht(t){const e=null!==this.dt(t);return e||p("WatchChangeAggregator","Detected inactive target",t),e}dt(t){const e=this.et.get(t);return e&&e.q?null:this.tt.Tt(t)}lt(t){this.et.set(t,new fn),this.tt.getRemoteKeysForTarget(t).forEach(e=>{this.ct(t,e,null)})}gt(t,e){return this.tt.getRemoteKeysForTarget(t).has(e)}}function mn(){return new $e(st.comparator)}function gn(){return new $e(st.comparator)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yn=(()=>{const t={asc:"ASCENDING",desc:"DESCENDING"};return t})(),bn=(()=>{const t={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"};return t})();class vn{constructor(t,e){this.databaseId=t,this.D=e}}function wn(t,e){return t.D?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function _n(t,e){return t.D?e.toBase64():e.toUint8Array()}function In(t,e){return wn(t,e.toTimestamp())}function En(t){return v(!!t),M.fromTimestamp(function(t){const e=Q(t);return new L(e.seconds,e.nanos)}(t))}function On(t,e){return function(t){return new z(["projects",t.projectId,"databases",t.database])}(t).child("documents").child(e).canonicalString()}function Tn(t){const e=z.fromString(t);return v(Zn(e)),e}function kn(t,e){return On(t.databaseId,e.path)}function Sn(t,e){const n=Tn(e);if(n.get(1)!==t.databaseId.projectId)throw new E(I.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+t.databaseId.projectId);if(n.get(3)!==t.databaseId.database)throw new E(I.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+t.databaseId.database);return new st(Cn(n))}function An(t,e){return On(t.databaseId,e)}function jn(t){const e=Tn(t);return 4===e.length?z.emptyPath():Cn(e)}function Nn(t){return new z(["projects",t.databaseId.projectId,"databases",t.databaseId.database]).canonicalString()}function Cn(t){return v(t.length>4&&"documents"===t.get(4)),t.popFirst(5)}function Rn(t,e,n){return{name:kn(t,e),fields:n.value.mapValue.fields}}function xn(t,e,n){const r=Sn(t,e.name),i=En(e.updateTime),s=new wt({mapValue:{fields:e.fields}}),o=It.newFoundDocument(r,i,s);return n&&o.setHasCommittedMutations(),n?o.setHasCommittedMutations():o}function Dn(t,e){return"found"in e?function(t,e){v(!!e.found),e.found.name,e.found.updateTime;const n=Sn(t,e.found.name),r=En(e.found.updateTime),i=new wt({mapValue:{fields:e.found.fields}});return It.newFoundDocument(n,r,i)}(t,e):"missing"in e?function(t,e){v(!!e.missing),v(!!e.readTime);const n=Sn(t,e.missing),r=En(e.readTime);return It.newNoDocument(n,r)}(t,e):b()}function Pn(t,e){let n;if("targetChange"in e){e.targetChange;const r=function(t){return"NO_CHANGE"===t?0:"ADD"===t?1:"REMOVE"===t?2:"CURRENT"===t?3:"RESET"===t?4:b()}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],s=function(t,e){return t.D?(v(void 0===e||"string"==typeof e),W.fromBase64String(e||"")):(v(void 0===e||e instanceof Uint8Array),W.fromUint8Array(e||new Uint8Array))}(t,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(t){const e=void 0===t.code?I.UNKNOWN:Ke(t.code);return new E(e,t.message||"")}(o);n=new dn(r,i,s,a||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const i=Sn(t,r.document.name),s=En(r.document.updateTime),o=new wt({mapValue:{fields:r.document.fields}}),a=It.newFoundDocument(i,s,o),c=r.targetIds||[],u=r.removedTargetIds||[];n=new ln(c,u,a.key,a)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const i=Sn(t,r.document),s=r.readTime?En(r.readTime):M.min(),o=It.newNoDocument(i,s),a=r.removedTargetIds||[];n=new ln([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const i=Sn(t,r.document),s=r.removedTargetIds||[];n=new ln([],s,i,null)}else{if(!("filter"in e))return b();{e.filter;const t=e.filter;t.targetId;const r=t.count||0,i=new qe(r),s=t.targetId;n=new hn(s,i)}}return n}function Fn(t,e){let n;if(e instanceof De)n={update:Rn(t,e.key,e.value)};else if(e instanceof Ue)n={delete:kn(t,e.key)};else if(e instanceof Pe)n={update:Rn(t,e.key,e.data),updateMask:Xn(e.fieldMask)};else{if(!(e instanceof Be))return b();n={verify:kn(t,e.key)}}return e.fieldTransforms.length>0&&(n.updateTransforms=e.fieldTransforms.map(t=>function(t,e){const n=e.transform;if(n instanceof me)return{fieldPath:e.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(n instanceof ge)return{fieldPath:e.field.canonicalString(),appendMissingElements:{values:n.elements}};if(n instanceof be)return{fieldPath:e.field.canonicalString(),removeAllFromArray:{values:n.elements}};if(n instanceof we)return{fieldPath:e.field.canonicalString(),increment:n.C};throw b()}(0,t))),e.precondition.isNone||(n.currentDocument=function(t,e){return void 0!==e.updateTime?{updateTime:In(t,e.updateTime)}:void 0!==e.exists?{exists:e.exists}:b()}(t,e.precondition)),n}function Ln(t,e){const n=e.currentDocument?function(t){return void 0!==t.updateTime?ke.updateTime(En(t.updateTime)):void 0!==t.exists?ke.exists(t.exists):ke.none()}(e.currentDocument):ke.none(),r=e.updateTransforms?e.updateTransforms.map(e=>function(t,e){let n=null;if("setToServerValue"in e)v("REQUEST_TIME"===e.setToServerValue),n=new me;else if("appendMissingElements"in e){const t=e.appendMissingElements.values||[];n=new ge(t)}else if("removeAllFromArray"in e){const t=e.removeAllFromArray.values||[];n=new be(t)}else"increment"in e?n=new we(t,e.increment):b();const r=K.fromServerFormat(e.fieldPath);return new Ee(r,n)}(t,e)):[];if(e.update){e.update.name;const i=Sn(t,e.update.name),s=new wt({mapValue:{fields:e.update.fields}});if(e.updateMask){const t=function(t){const e=t.fieldPaths||[];return new $(e.map(t=>K.fromServerFormat(t)))}(e.updateMask);return new Pe(i,s,t,n,r)}return new De(i,s,n,r)}if(e.delete){const r=Sn(t,e.delete);return new Ue(r,n)}if(e.verify){const r=Sn(t,e.verify);return new Be(r,n)}return b()}function Mn(t,e){return t&&t.length>0?(v(void 0!==e),t.map(t=>function(t,e){let n=t.updateTime?En(t.updateTime):En(e);return n.isEqual(M.min())&&(n=En(e)),new Te(n,t.transformResults||[])}(t,e))):[]}function Un(t,e){return{documents:[An(t,e.path)]}}function Bn(t,e){const n={structuredQuery:{}},r=e.path;null!==e.collectionGroup?(n.parent=An(t,r),n.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(n.parent=An(t,r.popLast()),n.structuredQuery.from=[{collectionId:r.lastSegment()}]);const i=function(t){if(0===t.length)return;const e=t.map(t=>function(t){if("=="===t.op){if(yt(t.value))return{unaryFilter:{field:Wn(t.field),op:"IS_NAN"}};if(gt(t.value))return{unaryFilter:{field:Wn(t.field),op:"IS_NULL"}}}else if("!="===t.op){if(yt(t.value))return{unaryFilter:{field:Wn(t.field),op:"IS_NOT_NAN"}};if(gt(t.value))return{unaryFilter:{field:Wn(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Wn(t.field),op:Gn(t.op),value:t.value}}}(t));return 1===e.length?e[0]:{compositeFilter:{op:"AND",filters:e}}}(e.filters);i&&(n.structuredQuery.where=i);const s=function(t){if(0!==t.length)return t.map(t=>function(t){return{field:Wn(t.field),direction:$n(t.dir)}}(t))}(e.orderBy);s&&(n.structuredQuery.orderBy=s);const o=function(t,e){return t.D||nt(e)?e:{value:e}}(t,e.limit);return null!==o&&(n.structuredQuery.limit=o),e.startAt&&(n.structuredQuery.startAt=Hn(e.startAt)),e.endAt&&(n.structuredQuery.endAt=Hn(e.endAt)),n}function qn(t){let e=jn(t.parent);const n=t.structuredQuery,r=n.from?n.from.length:0;let i=null;if(r>0){v(1===r);const t=n.from[0];t.allDescendants?i=t.collectionId:e=e.child(t.collectionId)}let s=[];n.where&&(s=zn(n.where));let o=[];n.orderBy&&(o=n.orderBy.map(t=>function(t){return new qt(Yn(t.field),function(t){switch(t){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(t.direction))}(t)));let a=null;n.limit&&(a=function(t){let e;return e="object"==typeof t?t.value:t,nt(e)?null:e}(n.limit));let c=null;n.startAt&&(c=Kn(n.startAt));let u=null;return n.endAt&&(u=Kn(n.endAt)),$t(e,i,o,s,a,"F",c,u)}function Vn(t,e){const n=function(t,e){switch(e){case 0:return null;case 1:return"existence-filter-mismatch";case 2:return"limbo-document";default:return b()}}(0,e.purpose);return null==n?null:{"goog-listen-tags":n}}function zn(t){return t?void 0!==t.unaryFilter?[Jn(t)]:void 0!==t.fieldFilter?[Qn(t)]:void 0!==t.compositeFilter?t.compositeFilter.filters.map(t=>zn(t)).reduce((t,e)=>t.concat(e)):b():[]}function Hn(t){return{before:t.before,values:t.position}}function Kn(t){const e=!!t.before,n=t.values||[];return new Ut(n,e)}function $n(t){return yn[t]}function Gn(t){return bn[t]}function Wn(t){return{fieldPath:t.canonicalString()}}function Yn(t){return K.fromServerFormat(t.fieldPath)}function Qn(t){return jt.create(Yn(t.fieldFilter.field),function(t){switch(t){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return b()}}(t.fieldFilter.op),t.fieldFilter.value)}function Jn(t){switch(t.unaryFilter.op){case"IS_NAN":const e=Yn(t.unaryFilter.field);return jt.create(e,"==",{doubleValue:NaN});case"IS_NULL":const n=Yn(t.unaryFilter.field);return jt.create(n,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const r=Yn(t.unaryFilter.field);return jt.create(r,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const i=Yn(t.unaryFilter.field);return jt.create(i,"!=",{nullValue:"NULL_VALUE"});default:return b()}}function Xn(t){const e=[];return t.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Zn(t){return t.length>=4&&"projects"===t.get(0)&&"databases"===t.get(2)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tr(t){let e="";for(let n=0;n<t.length;n++)e.length>0&&(e=nr(e)),e=er(t.get(n),e);return nr(e)}function er(t,e){let n=e;const r=t.length;for(let i=0;i<r;i++){const e=t.charAt(i);switch(e){case"\0":n+="";break;case"":n+="";break;default:n+=e}}return n}function nr(t){return t+""}function rr(t){const e=t.length;if(v(e>=2),2===e)return v(""===t.charAt(0)&&""===t.charAt(1)),z.emptyPath();const n=e-2,r=[];let i="";for(let s=0;s<e;){const e=t.indexOf("",s);switch((e<0||e>n)&&b(),t.charAt(e+1)){case"":const n=t.substring(s,e);let o;0===i.length?o=n:(i+=n,o=i,i=""),r.push(o);break;case"":i+=t.substring(s,e),i+="\0";break;case"":i+=t.substring(s,e+1);break;default:b()}s=e+2}return new z(r)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ir{constructor(t,e){this.seconds=t,this.nanoseconds=e}}class sr{constructor(t,e,n){this.ownerId=t,this.allowTabSynchronization=e,this.leaseTimestampMs=n}}sr.store="owner",sr.key="owner";class or{constructor(t,e,n){this.userId=t,this.lastAcknowledgedBatchId=e,this.lastStreamToken=n}}or.store="mutationQueues",or.keyPath="userId";class ar{constructor(t,e,n,r,i){this.userId=t,this.batchId=e,this.localWriteTimeMs=n,this.baseMutations=r,this.mutations=i}}ar.store="mutations",ar.keyPath="batchId",ar.userMutationsIndex="userMutationsIndex",ar.userMutationsKeyPath=["userId","batchId"];class cr{constructor(){}static prefixForUser(t){return[t]}static prefixForPath(t,e){return[t,tr(e)]}static key(t,e,n){return[t,tr(e),n]}}cr.store="documentMutations",cr.PLACEHOLDER=new cr;class ur{constructor(t,e){this.path=t,this.readTime=e}}class lr{constructor(t,e){this.path=t,this.version=e}}class hr{constructor(t,e,n,r,i,s){this.unknownDocument=t,this.noDocument=e,this.document=n,this.hasCommittedMutations=r,this.readTime=i,this.parentPath=s}}hr.store="remoteDocuments",hr.readTimeIndex="readTimeIndex",hr.readTimeIndexPath="readTime",hr.collectionReadTimeIndex="collectionReadTimeIndex",hr.collectionReadTimeIndexPath=["parentPath","readTime"];class dr{constructor(t){this.byteSize=t}}dr.store="remoteDocumentGlobal",dr.key="remoteDocumentGlobalKey";class fr{constructor(t,e,n,r,i,s,o){this.targetId=t,this.canonicalId=e,this.readTime=n,this.resumeToken=r,this.lastListenSequenceNumber=i,this.lastLimboFreeSnapshotVersion=s,this.query=o}}fr.store="targets",fr.keyPath="targetId",fr.queryTargetsIndexName="queryTargetsIndex",fr.queryTargetsKeyPath=["canonicalId","targetId"];class pr{constructor(t,e,n){this.targetId=t,this.path=e,this.sequenceNumber=n}}pr.store="targetDocuments",pr.keyPath=["targetId","path"],pr.documentTargetsIndex="documentTargetsIndex",pr.documentTargetsKeyPath=["path","targetId"];class mr{constructor(t,e,n,r){this.highestTargetId=t,this.highestListenSequenceNumber=e,this.lastRemoteSnapshotVersion=n,this.targetCount=r}}mr.key="targetGlobalKey",mr.store="targetGlobal";class gr{constructor(t,e){this.collectionId=t,this.parent=e}}gr.store="collectionParents",gr.keyPath=["collectionId","parent"];class yr{constructor(t,e,n,r){this.clientId=t,this.updateTimeMs=e,this.networkEnabled=n,this.inForeground=r}}yr.store="clientMetadata",yr.keyPath="clientId";class br{constructor(t,e,n){this.bundleId=t,this.createTime=e,this.version=n}}br.store="bundles",br.keyPath="bundleId";class vr{constructor(t,e,n){this.name=t,this.readTime=e,this.bundledQuery=n}}vr.store="namedQueries",vr.keyPath="name";const wr=[or.store,ar.store,cr.store,hr.store,fr.store,sr.store,mr.store,pr.store,yr.store,dr.store,gr.store,br.store,vr.store],_r="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Ir{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(t){this.onCommittedListeners.push(t)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(t=>t())}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Er{constructor(t){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,t(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(t){return this.next(void 0,t)}next(t,e){return this.callbackAttached&&b(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(e,this.error):this.wrapSuccess(t,this.result):new Er((n,r)=>{this.nextCallback=e=>{this.wrapSuccess(t,e).next(n,r)},this.catchCallback=t=>{this.wrapFailure(e,t).next(n,r)}})}toPromise(){return new Promise((t,e)=>{this.next(t,e)})}wrapUserFunction(t){try{const e=t();return e instanceof Er?e:Er.resolve(e)}catch(t){return Er.reject(t)}}wrapSuccess(t,e){return t?this.wrapUserFunction(()=>t(e)):Er.resolve(e)}wrapFailure(t,e){return t?this.wrapUserFunction(()=>t(e)):Er.reject(e)}static resolve(t){return new Er((e,n)=>{e(t)})}static reject(t){return new Er((e,n)=>{n(t)})}static waitFor(t){return new Er((e,n)=>{let r=0,i=0,s=!1;t.forEach(t=>{++r,t.next(()=>{++i,s&&i===r&&e()},t=>n(t))}),s=!0,i===r&&e()})}static or(t){let e=Er.resolve(!1);for(const n of t)e=e.next(t=>t?Er.resolve(t):n());return e}static forEach(t,e){const n=[];return t.forEach((t,r)=>{n.push(e.call(this,t,r))}),this.waitFor(n)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Or{constructor(t,e){this.action=t,this.transaction=e,this.aborted=!1,this.Et=new O,this.transaction.oncomplete=()=>{this.Et.resolve()},this.transaction.onabort=()=>{e.error?this.Et.reject(new Sr(t,e.error)):this.Et.resolve()},this.transaction.onerror=e=>{const n=Rr(e.target.error);this.Et.reject(new Sr(t,n))}}static open(t,e,n,r){try{return new Or(e,t.transaction(r,n))}catch(t){throw new Sr(e,t)}}get It(){return this.Et.promise}abort(t){t&&this.Et.reject(t),this.aborted||(p("SimpleDb","Aborting transaction:",t?t.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}store(t){const e=this.transaction.objectStore(t);return new jr(e)}}class Tr{constructor(t,e,n){this.name=t,this.version=e,this.At=n,12.2===Tr.Rt(Object(o["l"])())&&m("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}static delete(t){return p("SimpleDb","Removing database:",t),Nr(window.indexedDB.deleteDatabase(t)).toPromise()}static bt(){if(!Object(o["r"])())return!1;if(Tr.Pt())return!0;const t=Object(o["l"])(),e=Tr.Rt(t),n=0<e&&e<10,r=Tr.vt(t),i=0<r&&r<4.5;return!(t.indexOf("MSIE ")>0||t.indexOf("Trident/")>0||t.indexOf("Edge/")>0||n||i)}static Pt(){var e;return"undefined"!=typeof t&&"YES"===(null===(e=Object({NODE_ENV:"production",BASE_URL:""}))||void 0===e?void 0:e.Vt)}static St(t,e){return t.store(e)}static Rt(t){const e=t.match(/i(?:phone|pad|pod) os ([\d_]+)/i),n=e?e[1].split("_").slice(0,2).join("."):"-1";return Number(n)}static vt(t){const e=t.match(/Android ([\d.]+)/i),n=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(n)}async Dt(t){return this.db||(p("SimpleDb","Opening database:",this.name),this.db=await new Promise((e,n)=>{const r=indexedDB.open(this.name,this.version);r.onsuccess=t=>{const n=t.target.result;e(n)},r.onblocked=()=>{n(new Sr(t,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},r.onerror=e=>{const r=e.target.error;"VersionError"===r.name?n(new E(I.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):"InvalidStateError"===r.name?n(new E(I.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+r)):n(new Sr(t,r))},r.onupgradeneeded=t=>{p("SimpleDb",'Database "'+this.name+'" requires upgrade from version:',t.oldVersion);const e=t.target.result;this.At.Ct(e,r.transaction,t.oldVersion,this.version).next(()=>{p("SimpleDb","Database upgrade to version "+this.version+" complete")})}})),this.Nt&&(this.db.onversionchange=t=>this.Nt(t)),this.db}xt(t){this.Nt=t,this.db&&(this.db.onversionchange=e=>t(e))}async runTransaction(t,e,n,r){const i="readonly"===e;let s=0;for(;;){++s;try{this.db=await this.Dt(t);const e=Or.open(this.db,t,i?"readonly":"readwrite",n),s=r(e).catch(t=>(e.abort(t),Er.reject(t))).toPromise();return s.catch(()=>{}),await e.It,s}catch(t){const e="FirebaseError"!==t.name&&s<3;if(p("SimpleDb","Transaction failed with error:",t.message,"Retrying:",e),this.close(),!e)return Promise.reject(t)}}}close(){this.db&&this.db.close(),this.db=void 0}}class kr{constructor(t){this.kt=t,this.$t=!1,this.Ot=null}get isDone(){return this.$t}get Ft(){return this.Ot}set cursor(t){this.kt=t}done(){this.$t=!0}Mt(t){this.Ot=t}delete(){return Nr(this.kt.delete())}}class Sr extends E{constructor(t,e){super(I.UNAVAILABLE,`IndexedDB transaction '${t}' failed: ${e}`),this.name="IndexedDbTransactionError"}}function Ar(t){return"IndexedDbTransactionError"===t.name}class jr{constructor(t){this.store=t}put(t,e){let n;return void 0!==e?(p("SimpleDb","PUT",this.store.name,t,e),n=this.store.put(e,t)):(p("SimpleDb","PUT",this.store.name,"<auto-key>",t),n=this.store.put(t)),Nr(n)}add(t){return p("SimpleDb","ADD",this.store.name,t,t),Nr(this.store.add(t))}get(t){return Nr(this.store.get(t)).next(e=>(void 0===e&&(e=null),p("SimpleDb","GET",this.store.name,t,e),e))}delete(t){return p("SimpleDb","DELETE",this.store.name,t),Nr(this.store.delete(t))}count(){return p("SimpleDb","COUNT",this.store.name),Nr(this.store.count())}Lt(t,e){const n=this.cursor(this.options(t,e)),r=[];return this.Bt(n,(t,e)=>{r.push(e)}).next(()=>r)}Ut(t,e){p("SimpleDb","DELETE ALL",this.store.name);const n=this.options(t,e);n.qt=!1;const r=this.cursor(n);return this.Bt(r,(t,e,n)=>n.delete())}Kt(t,e){let n;e?n=t:(n={},e=t);const r=this.cursor(n);return this.Bt(r,e)}jt(t){const e=this.cursor({});return new Er((n,r)=>{e.onerror=t=>{const e=Rr(t.target.error);r(e)},e.onsuccess=e=>{const r=e.target.result;r?t(r.primaryKey,r.value).next(t=>{t?r.continue():n()}):n()}})}Bt(t,e){const n=[];return new Er((r,i)=>{t.onerror=t=>{i(t.target.error)},t.onsuccess=t=>{const i=t.target.result;if(!i)return void r();const s=new kr(i),o=e(i.primaryKey,i.value,s);if(o instanceof Er){const t=o.catch(t=>(s.done(),Er.reject(t)));n.push(t)}s.isDone?r():null===s.Ft?i.continue():i.continue(s.Ft)}}).next(()=>Er.waitFor(n))}options(t,e){let n;return void 0!==t&&("string"==typeof t?n=t:e=t),{index:n,range:e}}cursor(t){let e="next";if(t.reverse&&(e="prev"),t.index){const n=this.store.index(t.index);return t.qt?n.openKeyCursor(t.range,e):n.openCursor(t.range,e)}return this.store.openCursor(t.range,e)}}function Nr(t){return new Er((e,n)=>{t.onsuccess=t=>{const n=t.target.result;e(n)},t.onerror=t=>{const e=Rr(t.target.error);n(e)}})}let Cr=!1;function Rr(t){const e=Tr.Rt(Object(o["l"])());if(e>=12.2&&e<13){const e="An internal error was encountered in the Indexed Database server";if(t.message.indexOf(e)>=0){const t=new E("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${e}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Cr||(Cr=!0,setTimeout(()=>{throw t},0)),t}}return t}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xr extends Ir{constructor(t,e){super(),this.Qt=t,this.currentSequenceNumber=e}}function Dr(t,e){const n=_(t);return Tr.St(n.Qt,e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pr{constructor(t,e,n,r){this.batchId=t,this.localWriteTime=e,this.baseMutations=n,this.mutations=r}applyToRemoteDocument(t,e){const n=e.mutationResults;for(let r=0;r<this.mutations.length;r++){const e=this.mutations[r];e.key.isEqual(t.key)&&je(e,t,n[r])}}applyToLocalView(t){for(const e of this.baseMutations)e.key.isEqual(t.key)&&Ne(e,t,this.localWriteTime);for(const e of this.mutations)e.key.isEqual(t.key)&&Ne(e,t,this.localWriteTime)}applyToLocalDocumentSet(t){this.mutations.forEach(e=>{const n=t.get(e.key),r=n;this.applyToLocalView(r),n.isValidDocument()||r.convertToNoDocument(M.min())})}keys(){return this.mutations.reduce((t,e)=>t.add(e.key),sn())}isEqual(t){return this.batchId===t.batchId&&P(this.mutations,t.mutations,(t,e)=>Re(t,e))&&P(this.baseMutations,t.baseMutations,(t,e)=>Re(t,e))}}class Fr{constructor(t,e,n,r){this.batch=t,this.commitVersion=e,this.mutationResults=n,this.docVersions=r}static from(t,e,n){v(t.mutations.length===n.length);let r=nn();const i=t.mutations;for(let s=0;s<i.length;s++)r=r.insert(i[s].key,n[s].version);return new Fr(t,e,n,r)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lr{constructor(t,e,n,r,i=M.min(),s=M.min(),o=W.EMPTY_BYTE_STRING){this.target=t,this.targetId=e,this.purpose=n,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=o}withSequenceNumber(t){return new Lr(this.target,this.targetId,this.purpose,t,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken)}withResumeToken(t,e){return new Lr(this.target,this.targetId,this.purpose,this.sequenceNumber,e,this.lastLimboFreeSnapshotVersion,t)}withLastLimboFreeSnapshotVersion(t){return new Lr(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,t,this.resumeToken)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr{constructor(t){this.Wt=t}}function Ur(t,e){if(e.document)return xn(t.Wt,e.document,!!e.hasCommittedMutations);if(e.noDocument){const t=st.fromSegments(e.noDocument.path),n=Hr(e.noDocument.readTime),r=It.newNoDocument(t,n);return e.hasCommittedMutations?r.setHasCommittedMutations():r}if(e.unknownDocument){const t=st.fromSegments(e.unknownDocument.path),n=Hr(e.unknownDocument.version);return It.newUnknownDocument(t,n)}return b()}function Br(t,e,n){const r=qr(n),i=e.key.path.popLast().toArray();if(e.isFoundDocument()){const n=function(t,e){return{name:kn(t,e.key),fields:e.data.value.mapValue.fields,updateTime:wn(t,e.version.toTimestamp())}}(t.Wt,e),s=e.hasCommittedMutations;return new hr(null,null,n,s,r,i)}if(e.isNoDocument()){const t=e.key.path.toArray(),n=zr(e.version),s=e.hasCommittedMutations;return new hr(null,new ur(t,n),null,s,r,i)}if(e.isUnknownDocument()){const t=e.key.path.toArray(),n=zr(e.version);return new hr(new lr(t,n),null,null,!0,r,i)}return b()}function qr(t){const e=t.toTimestamp();return[e.seconds,e.nanoseconds]}function Vr(t){const e=new L(t[0],t[1]);return M.fromTimestamp(e)}function zr(t){const e=t.toTimestamp();return new ir(e.seconds,e.nanoseconds)}function Hr(t){const e=new L(t.seconds,t.nanoseconds);return M.fromTimestamp(e)}function Kr(t,e){const n=(e.baseMutations||[]).map(e=>Ln(t.Wt,e));for(let s=0;s<e.mutations.length-1;++s){const t=e.mutations[s];if(s+1<e.mutations.length&&void 0!==e.mutations[s+1].transform){const n=e.mutations[s+1];t.updateTransforms=n.transform.fieldTransforms,e.mutations.splice(s+1,1),++s}}const r=e.mutations.map(e=>Ln(t.Wt,e)),i=L.fromMillis(e.localWriteTimeMs);return new Pr(e.batchId,i,n,r)}function $r(t){const e=Hr(t.readTime),n=void 0!==t.lastLimboFreeSnapshotVersion?Hr(t.lastLimboFreeSnapshotVersion):M.min();let r;var i;return void 0!==t.query.documents?(v(1===(i=t.query).documents.length),r=te(Gt(jn(i.documents[0])))):r=function(t){return te(qn(t))}(t.query),new Lr(r,t.targetId,0,t.lastListenSequenceNumber,e,n,W.fromBase64String(t.resumeToken))}function Gr(t,e){const n=zr(e.snapshotVersion),r=zr(e.lastLimboFreeSnapshotVersion);let i;i=At(e.target)?Un(t.Wt,e.target):Bn(t.Wt,e.target);const s=e.resumeToken.toBase64();return new fr(e.targetId,Tt(e.target),n,s,e.sequenceNumber,r,i)}function Wr(t){const e=qn({parent:t.parent,structuredQuery:t.structuredQuery});return"LAST"===t.limitType?ee(e,e.limit,"L"):e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yr{getBundleMetadata(t,e){return Qr(t).get(e).next(t=>{if(t)return{id:(e=t).bundleId,createTime:Hr(e.createTime),version:e.version};var e})}saveBundleMetadata(t,e){return Qr(t).put({bundleId:(n=e).id,createTime:zr(En(n.createTime)),version:n.version});var n}getNamedQuery(t,e){return Jr(t).get(e).next(t=>{if(t)return{name:(e=t).name,query:Wr(e.bundledQuery),readTime:Hr(e.readTime)};var e})}saveNamedQuery(t,e){return Jr(t).put(function(t){return{name:t.name,readTime:zr(En(t.readTime)),bundledQuery:t.bundledQuery}}(e))}}function Qr(t){return Dr(t,br.store)}function Jr(t){return Dr(t,vr.store)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xr{constructor(){this.Gt=new Zr}addToCollectionParentIndex(t,e){return this.Gt.add(e),Er.resolve()}getCollectionParents(t,e){return Er.resolve(this.Gt.getEntries(e))}}class Zr{constructor(){this.index={}}add(t){const e=t.lastSegment(),n=t.popLast(),r=this.index[e]||new Ye(z.comparator),i=!r.has(n);return this.index[e]=r.add(n),i}has(t){const e=t.lastSegment(),n=t.popLast(),r=this.index[e];return r&&r.has(n)}getEntries(t){return(this.index[t]||new Ye(z.comparator)).toArray()}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ti{constructor(){this.zt=new Zr}addToCollectionParentIndex(t,e){if(!this.zt.has(e)){const n=e.lastSegment(),r=e.popLast();t.addOnCommittedListener(()=>{this.zt.add(e)});const i={collectionId:n,parent:tr(r)};return ei(t).put(i)}return Er.resolve()}getCollectionParents(t,e){const n=[],r=IDBKeyRange.bound([e,""],[F(e),""],!1,!0);return ei(t).Lt(r).next(t=>{for(const r of t){if(r.collectionId!==e)break;n.push(rr(r.parent))}return n})}}function ei(t){return Dr(t,gr.store)}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ni={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0};class ri{constructor(t,e,n){this.cacheSizeCollectionThreshold=t,this.percentileToCollect=e,this.maximumSequenceNumbersToCollect=n}static withCacheSize(t){return new ri(t,ri.DEFAULT_COLLECTION_PERCENTILE,ri.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ii(t,e,n){const r=t.store(ar.store),i=t.store(cr.store),s=[],o=IDBKeyRange.only(n.batchId);let a=0;const c=r.Kt({range:o},(t,e,n)=>(a++,n.delete()));s.push(c.next(()=>{v(1===a)}));const u=[];for(const l of n.mutations){const t=cr.key(e,l.key.path,n.batchId);s.push(i.delete(t)),u.push(l.key)}return Er.waitFor(s).next(()=>u)}function si(t){if(!t)return 0;let e;if(t.document)e=t.document;else if(t.unknownDocument)e=t.unknownDocument;else{if(!t.noDocument)throw b();e=t.noDocument}return JSON.stringify(e).length}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ri.DEFAULT_COLLECTION_PERCENTILE=10,ri.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ri.DEFAULT=new ri(41943040,ri.DEFAULT_COLLECTION_PERCENTILE,ri.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ri.DISABLED=new ri(-1,0,0);class oi{constructor(t,e,n,r){this.userId=t,this.N=e,this.Ht=n,this.referenceDelegate=r,this.Jt={}}static Yt(t,e,n,r){v(""!==t.uid);const i=t.isAuthenticated()?t.uid:"";return new oi(i,e,n,r)}checkEmpty(t){let e=!0;const n=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return ci(t).Kt({index:ar.userMutationsIndex,range:n},(t,n,r)=>{e=!1,r.done()}).next(()=>e)}addMutationBatch(t,e,n,r){const i=ui(t),s=ci(t);return s.add({}).next(o=>{v("number"==typeof o);const a=new Pr(o,e,n,r),c=function(t,e,n){const r=n.baseMutations.map(e=>Fn(t.Wt,e)),i=n.mutations.map(e=>Fn(t.Wt,e));return new ar(e,n.batchId,n.localWriteTime.toMillis(),r,i)}(this.N,this.userId,a),u=[];let l=new Ye((t,e)=>D(t.canonicalString(),e.canonicalString()));for(const t of r){const e=cr.key(this.userId,t.key.path,o);l=l.add(t.key.path.popLast()),u.push(s.put(c)),u.push(i.put(e,cr.PLACEHOLDER))}return l.forEach(e=>{u.push(this.Ht.addToCollectionParentIndex(t,e))}),t.addOnCommittedListener(()=>{this.Jt[o]=a.keys()}),Er.waitFor(u).next(()=>a)})}lookupMutationBatch(t,e){return ci(t).get(e).next(t=>t?(v(t.userId===this.userId),Kr(this.N,t)):null)}Xt(t,e){return this.Jt[e]?Er.resolve(this.Jt[e]):this.lookupMutationBatch(t,e).next(t=>{if(t){const n=t.keys();return this.Jt[e]=n,n}return null})}getNextMutationBatchAfterBatchId(t,e){const n=e+1,r=IDBKeyRange.lowerBound([this.userId,n]);let i=null;return ci(t).Kt({index:ar.userMutationsIndex,range:r},(t,e,r)=>{e.userId===this.userId&&(v(e.batchId>=n),i=Kr(this.N,e)),r.done()}).next(()=>i)}getHighestUnacknowledgedBatchId(t){const e=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let n=-1;return ci(t).Kt({index:ar.userMutationsIndex,range:e,reverse:!0},(t,e,r)=>{n=e.batchId,r.done()}).next(()=>n)}getAllMutationBatches(t){const e=IDBKeyRange.bound([this.userId,-1],[this.userId,Number.POSITIVE_INFINITY]);return ci(t).Lt(ar.userMutationsIndex,e).next(t=>t.map(t=>Kr(this.N,t)))}getAllMutationBatchesAffectingDocumentKey(t,e){const n=cr.prefixForPath(this.userId,e.path),r=IDBKeyRange.lowerBound(n),i=[];return ui(t).Kt({range:r},(n,r,s)=>{const[o,a,c]=n,u=rr(a);if(o===this.userId&&e.path.isEqual(u))return ci(t).get(c).next(t=>{if(!t)throw b();v(t.userId===this.userId),i.push(Kr(this.N,t))});s.done()}).next(()=>i)}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new Ye(D);const r=[];return e.forEach(e=>{const i=cr.prefixForPath(this.userId,e.path),s=IDBKeyRange.lowerBound(i),o=ui(t).Kt({range:s},(t,r,i)=>{const[s,o,a]=t,c=rr(o);s===this.userId&&e.path.isEqual(c)?n=n.add(a):i.done()});r.push(o)}),Er.waitFor(r).next(()=>this.Zt(t,n))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,r=n.length+1,i=cr.prefixForPath(this.userId,n),s=IDBKeyRange.lowerBound(i);let o=new Ye(D);return ui(t).Kt({range:s},(t,e,i)=>{const[s,a,c]=t,u=rr(a);s===this.userId&&n.isPrefixOf(u)?u.length===r&&(o=o.add(c)):i.done()}).next(()=>this.Zt(t,o))}Zt(t,e){const n=[],r=[];return e.forEach(e=>{r.push(ci(t).get(e).next(t=>{if(null===t)throw b();v(t.userId===this.userId),n.push(Kr(this.N,t))}))}),Er.waitFor(r).next(()=>n)}removeMutationBatch(t,e){return ii(t.Qt,this.userId,e).next(n=>(t.addOnCommittedListener(()=>{this.te(e.batchId)}),Er.forEach(n,e=>this.referenceDelegate.markPotentiallyOrphaned(t,e))))}te(t){delete this.Jt[t]}performConsistencyCheck(t){return this.checkEmpty(t).next(e=>{if(!e)return Er.resolve();const n=IDBKeyRange.lowerBound(cr.prefixForUser(this.userId)),r=[];return ui(t).Kt({range:n},(t,e,n)=>{if(t[0]===this.userId){const e=rr(t[1]);r.push(e)}else n.done()}).next(()=>{v(0===r.length)})})}containsKey(t,e){return ai(t,this.userId,e)}ee(t){return li(t).get(this.userId).next(t=>t||new or(this.userId,-1,""))}}function ai(t,e,n){const r=cr.prefixForPath(e,n.path),i=r[1],s=IDBKeyRange.lowerBound(r);let o=!1;return ui(t).Kt({range:s,qt:!0},(t,n,r)=>{const[s,a,c]=t;s===e&&a===i&&(o=!0),r.done()}).next(()=>o)}function ci(t){return Dr(t,ar.store)}function ui(t){return Dr(t,cr.store)}function li(t){return Dr(t,or.store)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi{constructor(t){this.ne=t}next(){return this.ne+=2,this.ne}static se(){return new hi(0)}static ie(){return new hi(-1)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class di{constructor(t,e){this.referenceDelegate=t,this.N=e}allocateTargetId(t){return this.re(t).next(e=>{const n=new hi(e.highestTargetId);return e.highestTargetId=n.next(),this.oe(t,e).next(()=>e.highestTargetId)})}getLastRemoteSnapshotVersion(t){return this.re(t).next(t=>M.fromTimestamp(new L(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(t){return this.re(t).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(t,e,n){return this.re(t).next(r=>(r.highestListenSequenceNumber=e,n&&(r.lastRemoteSnapshotVersion=n.toTimestamp()),e>r.highestListenSequenceNumber&&(r.highestListenSequenceNumber=e),this.oe(t,r)))}addTargetData(t,e){return this.ce(t,e).next(()=>this.re(t).next(n=>(n.targetCount+=1,this.ae(e,n),this.oe(t,n))))}updateTargetData(t,e){return this.ce(t,e)}removeTargetData(t,e){return this.removeMatchingKeysForTargetId(t,e.targetId).next(()=>fi(t).delete(e.targetId)).next(()=>this.re(t)).next(e=>(v(e.targetCount>0),e.targetCount-=1,this.oe(t,e)))}removeTargets(t,e,n){let r=0;const i=[];return fi(t).Kt((s,o)=>{const a=$r(o);a.sequenceNumber<=e&&null===n.get(a.targetId)&&(r++,i.push(this.removeTargetData(t,a)))}).next(()=>Er.waitFor(i)).next(()=>r)}forEachTarget(t,e){return fi(t).Kt((t,n)=>{const r=$r(n);e(r)})}re(t){return pi(t).get(mr.key).next(t=>(v(null!==t),t))}oe(t,e){return pi(t).put(mr.key,e)}ce(t,e){return fi(t).put(Gr(this.N,e))}ae(t,e){let n=!1;return t.targetId>e.highestTargetId&&(e.highestTargetId=t.targetId,n=!0),t.sequenceNumber>e.highestListenSequenceNumber&&(e.highestListenSequenceNumber=t.sequenceNumber,n=!0),n}getTargetCount(t){return this.re(t).next(t=>t.targetCount)}getTargetData(t,e){const n=Tt(e),r=IDBKeyRange.bound([n,Number.NEGATIVE_INFINITY],[n,Number.POSITIVE_INFINITY]);let i=null;return fi(t).Kt({range:r,index:fr.queryTargetsIndexName},(t,n,r)=>{const s=$r(n);St(e,s.target)&&(i=s,r.done())}).next(()=>i)}addMatchingKeys(t,e,n){const r=[],i=mi(t);return e.forEach(e=>{const s=tr(e.path);r.push(i.put(new pr(n,s))),r.push(this.referenceDelegate.addReference(t,n,e))}),Er.waitFor(r)}removeMatchingKeys(t,e,n){const r=mi(t);return Er.forEach(e,e=>{const i=tr(e.path);return Er.waitFor([r.delete([n,i]),this.referenceDelegate.removeReference(t,n,e)])})}removeMatchingKeysForTargetId(t,e){const n=mi(t),r=IDBKeyRange.bound([e],[e+1],!1,!0);return n.delete(r)}getMatchingKeysForTargetId(t,e){const n=IDBKeyRange.bound([e],[e+1],!1,!0),r=mi(t);let i=sn();return r.Kt({range:n,qt:!0},(t,e,n)=>{const r=rr(t[1]),s=new st(r);i=i.add(s)}).next(()=>i)}containsKey(t,e){const n=tr(e.path),r=IDBKeyRange.bound([n],[F(n)],!1,!0);let i=0;return mi(t).Kt({index:pr.documentTargetsIndex,qt:!0,range:r},([t,e],n,r)=>{0!==t&&(i++,r.done())}).next(()=>i>0)}Tt(t,e){return fi(t).get(e).next(t=>t?$r(t):null)}}function fi(t){return Dr(t,fr.store)}function pi(t){return Dr(t,mr.store)}function mi(t){return Dr(t,pr.store)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function gi(t){if(t.code!==I.FAILED_PRECONDITION||t.message!==_r)throw t;p("LocalStore","Unexpectedly lost primary lease")}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yi([t,e],[n,r]){const i=D(t,n);return 0===i?D(e,r):i}class bi{constructor(t){this.ue=t,this.buffer=new Ye(yi),this.he=0}le(){return++this.he}fe(t){const e=[t,this.le()];if(this.buffer.size<this.ue)this.buffer=this.buffer.add(e);else{const t=this.buffer.last();yi(e,t)<0&&(this.buffer=this.buffer.delete(t).add(e))}}get maxValue(){return this.buffer.last()[0]}}class vi{constructor(t,e){this.garbageCollector=t,this.asyncQueue=e,this.de=!1,this.we=null}start(t){-1!==this.garbageCollector.params.cacheSizeCollectionThreshold&&this._e(t)}stop(){this.we&&(this.we.cancel(),this.we=null)}get started(){return null!==this.we}_e(t){const e=this.de?3e5:6e4;p("LruGarbageCollector",`Garbage collection scheduled in ${e}ms`),this.we=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.we=null,this.de=!0;try{await t.collectGarbage(this.garbageCollector)}catch(t){Ar(t)?p("LruGarbageCollector","Ignoring IndexedDB error during garbage collection: ",t):await gi(t)}await this._e(t)})}}class wi{constructor(t,e){this.me=t,this.params=e}calculateTargetCount(t,e){return this.me.ge(t).next(t=>Math.floor(e/100*t))}nthSequenceNumber(t,e){if(0===e)return Er.resolve(C.T);const n=new bi(e);return this.me.forEachTarget(t,t=>n.fe(t.sequenceNumber)).next(()=>this.me.ye(t,t=>n.fe(t))).next(()=>n.maxValue)}removeTargets(t,e,n){return this.me.removeTargets(t,e,n)}removeOrphanedDocuments(t,e){return this.me.removeOrphanedDocuments(t,e)}collect(t,e){return-1===this.params.cacheSizeCollectionThreshold?(p("LruGarbageCollector","Garbage collection skipped; disabled"),Er.resolve(ni)):this.getCacheSize(t).next(n=>n<this.params.cacheSizeCollectionThreshold?(p("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),ni):this.pe(t,e))}getCacheSize(t){return this.me.getCacheSize(t)}pe(t,e){let n,r,i,o,a,c,u;const l=Date.now();return this.calculateTargetCount(t,this.params.percentileToCollect).next(e=>(e>this.params.maximumSequenceNumbersToCollect?(p("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${e}`),r=this.params.maximumSequenceNumbersToCollect):r=e,o=Date.now(),this.nthSequenceNumber(t,r))).next(r=>(n=r,a=Date.now(),this.removeTargets(t,n,e))).next(e=>(i=e,c=Date.now(),this.removeOrphanedDocuments(t,n))).next(t=>(u=Date.now(),d()<=s["a"].DEBUG&&p("LruGarbageCollector",`LRU Garbage Collection\n\tCounted targets in ${o-l}ms\n\tDetermined least recently used ${r} in `+(a-o)+"ms\n"+`\tRemoved ${i} targets in `+(c-a)+"ms\n"+`\tRemoved ${t} documents in `+(u-c)+"ms\n"+`Total Duration: ${u-l}ms`),Er.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:t})))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _i{constructor(t,e){this.db=t,this.garbageCollector=function(t,e){return new wi(t,e)}(this,e)}ge(t){const e=this.Te(t);return this.db.getTargetCache().getTargetCount(t).next(t=>e.next(e=>t+e))}Te(t){let e=0;return this.ye(t,t=>{e++}).next(()=>e)}forEachTarget(t,e){return this.db.getTargetCache().forEachTarget(t,e)}ye(t,e){return this.Ee(t,(t,n)=>e(n))}addReference(t,e,n){return Ii(t,n)}removeReference(t,e,n){return Ii(t,n)}removeTargets(t,e,n){return this.db.getTargetCache().removeTargets(t,e,n)}markPotentiallyOrphaned(t,e){return Ii(t,e)}Ie(t,e){return function(t,e){let n=!1;return li(t).jt(r=>ai(t,r,e).next(t=>(t&&(n=!0),Er.resolve(!t)))).next(()=>n)}(t,e)}removeOrphanedDocuments(t,e){const n=this.db.getRemoteDocumentCache().newChangeBuffer(),r=[];let i=0;return this.Ee(t,(s,o)=>{if(o<=e){const e=this.Ie(t,s).next(e=>{if(!e)return i++,n.getEntry(t,s).next(()=>(n.removeEntry(s),mi(t).delete([0,tr(s.path)])))});r.push(e)}}).next(()=>Er.waitFor(r)).next(()=>n.apply(t)).next(()=>i)}removeTarget(t,e){const n=e.withSequenceNumber(t.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(t,n)}updateLimboDocument(t,e){return Ii(t,e)}Ee(t,e){const n=mi(t);let r,i=C.T;return n.Kt({index:pr.documentTargetsIndex},([t,n],{path:s,sequenceNumber:o})=>{0===t?(i!==C.T&&e(new st(rr(r)),i),i=o,r=s):i=C.T}).next(()=>{i!==C.T&&e(new st(rr(r)),i)})}getCacheSize(t){return this.db.getRemoteDocumentCache().getSize(t)}}function Ii(t,e){return mi(t).put(function(t,e){return new pr(0,tr(t.path),e)}(e,t.currentSequenceNumber))}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ei{constructor(t,e){this.mapKeyFn=t,this.equalsFn=e,this.inner={}}get(t){const e=this.mapKeyFn(t),n=this.inner[e];if(void 0!==n)for(const[r,i]of n)if(this.equalsFn(r,t))return i}has(t){return void 0!==this.get(t)}set(t,e){const n=this.mapKeyFn(t),r=this.inner[n];if(void 0!==r){for(let n=0;n<r.length;n++)if(this.equalsFn(r[n][0],t))return void(r[n]=[t,e]);r.push([t,e])}else this.inner[n]=[[t,e]]}delete(t){const e=this.mapKeyFn(t),n=this.inner[e];if(void 0===n)return!1;for(let r=0;r<n.length;r++)if(this.equalsFn(n[r][0],t))return 1===n.length?delete this.inner[e]:n.splice(r,1),!0;return!1}forEach(t){B(this.inner,(e,n)=>{for(const[r,i]of n)t(r,i)})}isEmpty(){return q(this.inner)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oi{constructor(){this.changes=new Ei(t=>t.toString(),(t,e)=>t.isEqual(e)),this.changesApplied=!1}getReadTime(t){const e=this.changes.get(t);return e?e.readTime:M.min()}addEntry(t,e){this.assertNotApplied(),this.changes.set(t.key,{document:t,readTime:e})}removeEntry(t,e=null){this.assertNotApplied(),this.changes.set(t,{document:It.newInvalidDocument(t),readTime:e})}getEntry(t,e){this.assertNotApplied();const n=this.changes.get(e);return void 0!==n?Er.resolve(n.document):this.getFromCache(t,e)}getEntries(t,e){return this.getAllFromCache(t,e)}apply(t){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(t)}assertNotApplied(){}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{constructor(t,e){this.N=t,this.Ht=e}addEntry(t,e,n){return Ai(t).put(ji(e),n)}removeEntry(t,e){const n=Ai(t),r=ji(e);return n.delete(r)}updateMetadata(t,e){return this.getMetadata(t).next(n=>(n.byteSize+=e,this.Ae(t,n)))}getEntry(t,e){return Ai(t).get(ji(e)).next(t=>this.Re(e,t))}be(t,e){return Ai(t).get(ji(e)).next(t=>({document:this.Re(e,t),size:si(t)}))}getEntries(t,e){let n=Xe();return this.Pe(t,e,(t,e)=>{const r=this.Re(t,e);n=n.insert(t,r)}).next(()=>n)}ve(t,e){let n=Xe(),r=new $e(st.comparator);return this.Pe(t,e,(t,e)=>{const i=this.Re(t,e);n=n.insert(t,i),r=r.insert(t,si(e))}).next(()=>({documents:n,Ve:r}))}Pe(t,e,n){if(e.isEmpty())return Er.resolve();const r=IDBKeyRange.bound(e.first().path.toArray(),e.last().path.toArray()),i=e.getIterator();let s=i.getNext();return Ai(t).Kt({range:r},(t,e,r)=>{const o=st.fromSegments(t);for(;s&&st.comparator(s,o)<0;)n(s,null),s=i.getNext();s&&s.isEqual(o)&&(n(s,e),s=i.hasNext()?i.getNext():null),s?r.Mt(s.path.toArray()):r.done()}).next(()=>{for(;s;)n(s,null),s=i.hasNext()?i.getNext():null})}getDocumentsMatchingQuery(t,e,n){let r=Xe();const i=e.path.length+1,s={};if(n.isEqual(M.min())){const t=e.path.toArray();s.range=IDBKeyRange.lowerBound(t)}else{const t=e.path.toArray(),r=qr(n);s.range=IDBKeyRange.lowerBound([t,r],!0),s.index=hr.collectionReadTimeIndex}return Ai(t).Kt(s,(t,n,s)=>{if(t.length!==i)return;const o=Ur(this.N,n);e.path.isPrefixOf(o.key.path)?se(e,o)&&(r=r.insert(o.key,o)):s.done()}).next(()=>r)}newChangeBuffer(t){return new ki(this,!!t&&t.trackRemovals)}getSize(t){return this.getMetadata(t).next(t=>t.byteSize)}getMetadata(t){return Si(t).get(dr.key).next(t=>(v(!!t),t))}Ae(t,e){return Si(t).put(dr.key,e)}Re(t,e){if(e){const t=Ur(this.N,e);if(!t.isNoDocument()||!t.version.isEqual(M.min()))return t}return It.newInvalidDocument(t)}}class ki extends Oi{constructor(t,e){super(),this.Se=t,this.trackRemovals=e,this.De=new Ei(t=>t.toString(),(t,e)=>t.isEqual(e))}applyChanges(t){const e=[];let n=0,r=new Ye((t,e)=>D(t.canonicalString(),e.canonicalString()));return this.changes.forEach((i,s)=>{const o=this.De.get(i);if(s.document.isValidDocument()){const a=Br(this.Se.N,s.document,this.getReadTime(i));r=r.add(i.path.popLast());const c=si(a);n+=c-o,e.push(this.Se.addEntry(t,i,a))}else if(n-=o,this.trackRemovals){const n=Br(this.Se.N,It.newNoDocument(i,M.min()),this.getReadTime(i));e.push(this.Se.addEntry(t,i,n))}else e.push(this.Se.removeEntry(t,i))}),r.forEach(n=>{e.push(this.Se.Ht.addToCollectionParentIndex(t,n))}),e.push(this.Se.updateMetadata(t,n)),Er.waitFor(e)}getFromCache(t,e){return this.Se.be(t,e).next(t=>(this.De.set(e,t.size),t.document))}getAllFromCache(t,e){return this.Se.ve(t,e).next(({documents:t,Ve:e})=>(e.forEach((t,e)=>{this.De.set(t,e)}),t))}}function Si(t){return Dr(t,dr.store)}function Ai(t){return Dr(t,hr.store)}function ji(t){return t.path.toArray()}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ni{constructor(t){this.N=t}Ct(t,e,n,r){v(n<r&&n>=0&&r<=11);const i=new Or("createOrUpgrade",e);n<1&&r>=1&&(function(t){t.createObjectStore(sr.store)}(t),function(t){t.createObjectStore(or.store,{keyPath:or.keyPath}),t.createObjectStore(ar.store,{keyPath:ar.keyPath,autoIncrement:!0}).createIndex(ar.userMutationsIndex,ar.userMutationsKeyPath,{unique:!0}),t.createObjectStore(cr.store)}(t),Ci(t),function(t){t.createObjectStore(hr.store)}(t));let s=Er.resolve();return n<3&&r>=3&&(0!==n&&(function(t){t.deleteObjectStore(pr.store),t.deleteObjectStore(fr.store),t.deleteObjectStore(mr.store)}(t),Ci(t)),s=s.next(()=>function(t){const e=t.store(mr.store),n=new mr(0,0,M.min().toTimestamp(),0);return e.put(mr.key,n)}(i))),n<4&&r>=4&&(0!==n&&(s=s.next(()=>function(t,e){return e.store(ar.store).Lt().next(n=>{t.deleteObjectStore(ar.store),t.createObjectStore(ar.store,{keyPath:ar.keyPath,autoIncrement:!0}).createIndex(ar.userMutationsIndex,ar.userMutationsKeyPath,{unique:!0});const r=e.store(ar.store),i=n.map(t=>r.put(t));return Er.waitFor(i)})}(t,i))),s=s.next(()=>{!function(t){t.createObjectStore(yr.store,{keyPath:yr.keyPath})}(t)})),n<5&&r>=5&&(s=s.next(()=>this.Ce(i))),n<6&&r>=6&&(s=s.next(()=>(function(t){t.createObjectStore(dr.store)}(t),this.Ne(i)))),n<7&&r>=7&&(s=s.next(()=>this.xe(i))),n<8&&r>=8&&(s=s.next(()=>this.ke(t,i))),n<9&&r>=9&&(s=s.next(()=>{!function(t){t.objectStoreNames.contains("remoteDocumentChanges")&&t.deleteObjectStore("remoteDocumentChanges")}(t),function(t){const e=t.objectStore(hr.store);e.createIndex(hr.readTimeIndex,hr.readTimeIndexPath,{unique:!1}),e.createIndex(hr.collectionReadTimeIndex,hr.collectionReadTimeIndexPath,{unique:!1})}(e)})),n<10&&r>=10&&(s=s.next(()=>this.$e(i))),n<11&&r>=11&&(s=s.next(()=>{!function(t){t.createObjectStore(br.store,{keyPath:br.keyPath})}(t),function(t){t.createObjectStore(vr.store,{keyPath:vr.keyPath})}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(t)})),s}Ne(t){let e=0;return t.store(hr.store).Kt((t,n)=>{e+=si(n)}).next(()=>{const n=new dr(e);return t.store(dr.store).put(dr.key,n)})}Ce(t){const e=t.store(or.store),n=t.store(ar.store);return e.Lt().next(e=>Er.forEach(e,e=>{const r=IDBKeyRange.bound([e.userId,-1],[e.userId,e.lastAcknowledgedBatchId]);return n.Lt(ar.userMutationsIndex,r).next(n=>Er.forEach(n,n=>{v(n.userId===e.userId);const r=Kr(this.N,n);return ii(t,e.userId,r).next(()=>{})}))}))}xe(t){const e=t.store(pr.store),n=t.store(hr.store);return t.store(mr.store).get(mr.key).next(t=>{const r=[];return n.Kt((n,i)=>{const s=new z(n),o=function(t){return[0,tr(t)]}(s);r.push(e.get(o).next(n=>n?Er.resolve():(n=>e.put(new pr(0,tr(n),t.highestListenSequenceNumber)))(s)))}).next(()=>Er.waitFor(r))})}ke(t,e){t.createObjectStore(gr.store,{keyPath:gr.keyPath});const n=e.store(gr.store),r=new Zr,i=t=>{if(r.add(t)){const e=t.lastSegment(),r=t.popLast();return n.put({collectionId:e,parent:tr(r)})}};return e.store(hr.store).Kt({qt:!0},(t,e)=>{const n=new z(t);return i(n.popLast())}).next(()=>e.store(cr.store).Kt({qt:!0},([t,e,n],r)=>{const s=rr(e);return i(s.popLast())}))}$e(t){const e=t.store(fr.store);return e.Kt((t,n)=>{const r=$r(n),i=Gr(this.N,r);return e.put(i)})}}function Ci(t){t.createObjectStore(pr.store,{keyPath:pr.keyPath}).createIndex(pr.documentTargetsIndex,pr.documentTargetsKeyPath,{unique:!0}),t.createObjectStore(fr.store,{keyPath:fr.keyPath}).createIndex(fr.queryTargetsIndexName,fr.queryTargetsKeyPath,{unique:!0}),t.createObjectStore(mr.store)}const Ri="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class xi{constructor(t,e,n,r,i,s,o,a,c,u){if(this.allowTabSynchronization=t,this.persistenceKey=e,this.clientId=n,this.Oe=i,this.window=s,this.document=o,this.Fe=c,this.Me=u,this.Le=null,this.Be=!1,this.isPrimary=!1,this.networkEnabled=!0,this.Ue=null,this.inForeground=!1,this.qe=null,this.Ke=null,this.je=Number.NEGATIVE_INFINITY,this.Qe=t=>Promise.resolve(),!xi.bt())throw new E(I.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new _i(this,r),this.We=e+"main",this.N=new Mr(a),this.Ge=new Tr(this.We,11,new Ni(this.N)),this.ze=new di(this.referenceDelegate,this.N),this.Ht=new ti,this.He=function(t,e){return new Ti(t,e)}(this.N,this.Ht),this.Je=new Yr,this.window&&this.window.localStorage?this.Ye=this.window.localStorage:(this.Ye=null,!1===u&&m("IndexedDbPersistence","LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Xe().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new E(I.FAILED_PRECONDITION,Ri);return this.Ze(),this.tn(),this.en(),this.runTransaction("getHighestListenSequenceNumber","readonly",t=>this.ze.getHighestSequenceNumber(t))}).then(t=>{this.Le=new C(t,this.Fe)}).then(()=>{this.Be=!0}).catch(t=>(this.Ge&&this.Ge.close(),Promise.reject(t)))}nn(t){return this.Qe=async e=>{if(this.started)return t(e)},t(this.isPrimary)}setDatabaseDeletedListener(t){this.Ge.xt(async e=>{null===e.newVersion&&await t()})}setNetworkEnabled(t){this.networkEnabled!==t&&(this.networkEnabled=t,this.Oe.enqueueAndForget(async()=>{this.started&&await this.Xe()}))}Xe(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",t=>Pi(t).put(new yr(this.clientId,Date.now(),this.networkEnabled,this.inForeground)).next(()=>{if(this.isPrimary)return this.sn(t).next(t=>{t||(this.isPrimary=!1,this.Oe.enqueueRetryable(()=>this.Qe(!1)))})}).next(()=>this.rn(t)).next(e=>this.isPrimary&&!e?this.on(t).next(()=>!1):!!e&&this.cn(t).next(()=>!0))).catch(t=>{if(Ar(t))return p("IndexedDbPersistence","Failed to extend owner lease: ",t),this.isPrimary;if(!this.allowTabSynchronization)throw t;return p("IndexedDbPersistence","Releasing owner lease after error during lease refresh",t),!1}).then(t=>{this.isPrimary!==t&&this.Oe.enqueueRetryable(()=>this.Qe(t)),this.isPrimary=t})}sn(t){return Di(t).get(sr.key).next(t=>Er.resolve(this.an(t)))}un(t){return Pi(t).delete(this.clientId)}async hn(){if(this.isPrimary&&!this.ln(this.je,18e5)){this.je=Date.now();const t=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const e=Dr(t,yr.store);return e.Lt().next(t=>{const n=this.fn(t,18e5),r=t.filter(t=>-1===n.indexOf(t));return Er.forEach(r,t=>e.delete(t.clientId)).next(()=>r)})}).catch(()=>[]);if(this.Ye)for(const e of t)this.Ye.removeItem(this.dn(e.clientId))}}en(){this.Ke=this.Oe.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Xe().then(()=>this.hn()).then(()=>this.en()))}an(t){return!!t&&t.ownerId===this.clientId}rn(t){return this.Me?Er.resolve(!0):Di(t).get(sr.key).next(e=>{if(null!==e&&this.ln(e.leaseTimestampMs,5e3)&&!this.wn(e.ownerId)){if(this.an(e)&&this.networkEnabled)return!0;if(!this.an(e)){if(!e.allowTabSynchronization)throw new E(I.FAILED_PRECONDITION,Ri);return!1}}return!(!this.networkEnabled||!this.inForeground)||Pi(t).Lt().next(t=>void 0===this.fn(t,5e3).find(t=>{if(this.clientId!==t.clientId){const e=!this.networkEnabled&&t.networkEnabled,n=!this.inForeground&&t.inForeground,r=this.networkEnabled===t.networkEnabled;if(e||n&&r)return!0}return!1}))}).next(t=>(this.isPrimary!==t&&p("IndexedDbPersistence",`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.Be=!1,this._n(),this.Ke&&(this.Ke.cancel(),this.Ke=null),this.mn(),this.gn(),await this.Ge.runTransaction("shutdown","readwrite",[sr.store,yr.store],t=>{const e=new xr(t,C.T);return this.on(e).next(()=>this.un(e))}),this.Ge.close(),this.yn()}fn(t,e){return t.filter(t=>this.ln(t.updateTimeMs,e)&&!this.wn(t.clientId))}pn(){return this.runTransaction("getActiveClients","readonly",t=>Pi(t).Lt().next(t=>this.fn(t,18e5).map(t=>t.clientId)))}get started(){return this.Be}getMutationQueue(t){return oi.Yt(t,this.N,this.Ht,this.referenceDelegate)}getTargetCache(){return this.ze}getRemoteDocumentCache(){return this.He}getIndexManager(){return this.Ht}getBundleCache(){return this.Je}runTransaction(t,e,n){p("IndexedDbPersistence","Starting transaction:",t);const r="readonly"===e?"readonly":"readwrite";let i;return this.Ge.runTransaction(t,r,wr,r=>(i=new xr(r,this.Le?this.Le.next():C.T),"readwrite-primary"===e?this.sn(i).next(t=>!!t||this.rn(i)).next(e=>{if(!e)throw m(`Failed to obtain primary lease for action '${t}'.`),this.isPrimary=!1,this.Oe.enqueueRetryable(()=>this.Qe(!1)),new E(I.FAILED_PRECONDITION,_r);return n(i)}).next(t=>this.cn(i).next(()=>t)):this.Tn(i).next(()=>n(i)))).then(t=>(i.raiseOnCommittedEvent(),t))}Tn(t){return Di(t).get(sr.key).next(t=>{if(null!==t&&this.ln(t.leaseTimestampMs,5e3)&&!this.wn(t.ownerId)&&!this.an(t)&&!(this.Me||this.allowTabSynchronization&&t.allowTabSynchronization))throw new E(I.FAILED_PRECONDITION,Ri)})}cn(t){const e=new sr(this.clientId,this.allowTabSynchronization,Date.now());return Di(t).put(sr.key,e)}static bt(){return Tr.bt()}on(t){const e=Di(t);return e.get(sr.key).next(t=>this.an(t)?(p("IndexedDbPersistence","Releasing primary lease."),e.delete(sr.key)):Er.resolve())}ln(t,e){const n=Date.now();return!(t<n-e)&&(!(t>n)||(m(`Detected an update time that is in the future: ${t} > ${n}`),!1))}Ze(){null!==this.document&&"function"==typeof this.document.addEventListener&&(this.qe=()=>{this.Oe.enqueueAndForget(()=>(this.inForeground="visible"===this.document.visibilityState,this.Xe()))},this.document.addEventListener("visibilitychange",this.qe),this.inForeground="visible"===this.document.visibilityState)}mn(){this.qe&&(this.document.removeEventListener("visibilitychange",this.qe),this.qe=null)}tn(){var t;"function"==typeof(null===(t=this.window)||void 0===t?void 0:t.addEventListener)&&(this.Ue=()=>{this._n(),Object(o["v"])()&&navigator.appVersion.match(/Version\/1[45]/)&&this.Oe.enterRestrictedMode(!0),this.Oe.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.Ue))}gn(){this.Ue&&(this.window.removeEventListener("pagehide",this.Ue),this.Ue=null)}wn(t){var e;try{const n=null!==(null===(e=this.Ye)||void 0===e?void 0:e.getItem(this.dn(t)));return p("IndexedDbPersistence",`Client '${t}' ${n?"is":"is not"} zombied in LocalStorage`),n}catch(t){return m("IndexedDbPersistence","Failed to get zombied client id.",t),!1}}_n(){if(this.Ye)try{this.Ye.setItem(this.dn(this.clientId),String(Date.now()))}catch(t){m("Failed to set zombie client id.",t)}}yn(){if(this.Ye)try{this.Ye.removeItem(this.dn(this.clientId))}catch(t){}}dn(t){return`firestore_zombie_${this.persistenceKey}_${t}`}}function Di(t){return Dr(t,sr.store)}function Pi(t){return Dr(t,yr.store)}function Fi(t,e){let n=t.projectId;return t.isDefaultDatabase||(n+="."+t.database),"firestore/"+e+"/"+n+"/"
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class Li{constructor(t,e){this.progress=t,this.En=e}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mi{constructor(t,e,n){this.He=t,this.In=e,this.Ht=n}An(t,e){return this.In.getAllMutationBatchesAffectingDocumentKey(t,e).next(n=>this.Rn(t,e,n))}Rn(t,e,n){return this.He.getEntry(t,e).next(t=>{for(const e of n)e.applyToLocalView(t);return t})}bn(t,e){t.forEach((t,n)=>{for(const r of e)r.applyToLocalView(n)})}Pn(t,e){return this.He.getEntries(t,e).next(e=>this.vn(t,e).next(()=>e))}vn(t,e){return this.In.getAllMutationBatchesAffectingDocumentKeys(t,e).next(t=>this.bn(e,t))}getDocumentsMatchingQuery(t,e,n){return function(t){return st.isDocumentKey(t.path)&&null===t.collectionGroup&&0===t.filters.length}(e)?this.Vn(t,e.path):Xt(e)?this.Sn(t,e,n):this.Dn(t,e,n)}Vn(t,e){return this.An(t,new st(e)).next(t=>{let e=tn();return t.isFoundDocument()&&(e=e.insert(t.key,t)),e})}Sn(t,e,n){const r=e.collectionGroup;let i=tn();return this.Ht.getCollectionParents(t,r).next(s=>Er.forEach(s,s=>{const o=function(t,e){return new Kt(e,null,t.explicitOrderBy.slice(),t.filters.slice(),t.limit,t.limitType,t.startAt,t.endAt)}(e,s.child(r));return this.Dn(t,o,n).next(t=>{t.forEach((t,e)=>{i=i.insert(t,e)})})}).next(()=>i))}Dn(t,e,n){let r,i;return this.He.getDocumentsMatchingQuery(t,e,n).next(n=>(r=n,this.In.getAllMutationBatchesAffectingQuery(t,e))).next(e=>(i=e,this.Cn(t,i,r).next(t=>{r=t;for(const e of i)for(const t of e.mutations){const n=t.key;let i=r.get(n);null==i&&(i=It.newInvalidDocument(n),r=r.insert(n,i)),Ne(t,i,e.localWriteTime),i.isFoundDocument()||(r=r.remove(n))}}))).next(()=>(r.forEach((t,n)=>{se(e,n)||(r=r.remove(t))}),r))}Cn(t,e,n){let r=sn();for(const s of e)for(const t of s.mutations)t instanceof Pe&&null===n.get(t.key)&&(r=r.add(t.key));let i=n;return this.He.getEntries(t,r).next(t=>(t.forEach((t,e)=>{e.isFoundDocument()&&(i=i.insert(t,e))}),i))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ui{constructor(t,e,n,r){this.targetId=t,this.fromCache=e,this.Nn=n,this.xn=r}static kn(t,e){let n=sn(),r=sn();for(const i of e.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new Ui(t,e.fromCache,n,r)}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bi{$n(t){this.On=t}getDocumentsMatchingQuery(t,e,n,r){return function(t){return 0===t.filters.length&&null===t.limit&&null==t.startAt&&null==t.endAt&&(0===t.explicitOrderBy.length||1===t.explicitOrderBy.length&&t.explicitOrderBy[0].field.isKeyField())}(e)||n.isEqual(M.min())?this.Fn(t,e):this.On.Pn(t,r).next(i=>{const o=this.Mn(e,i);return(Wt(e)||Yt(e))&&this.Ln(e.limitType,o,r,n)?this.Fn(t,e):(d()<=s["a"].DEBUG&&p("QueryEngine","Re-using previous result from %s to execute query: %s",n.toString(),ie(e)),this.On.getDocumentsMatchingQuery(t,e,n).next(t=>(o.forEach(e=>{t=t.insert(e.key,e)}),t)))})}Mn(t,e){let n=new Ye(oe(t));return e.forEach((e,r)=>{se(t,r)&&(n=n.add(r))}),n}Ln(t,e,n,r){if(n.size!==e.size)return!0;const i="F"===t?e.last():e.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}Fn(t,e){return d()<=s["a"].DEBUG&&p("QueryEngine","Using full collection scan to execute query:",ie(e)),this.On.getDocumentsMatchingQuery(t,e,M.min())}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qi{constructor(t,e,n,r){this.persistence=t,this.Bn=e,this.N=r,this.Un=new $e(D),this.qn=new Ei(t=>Tt(t),St),this.Kn=M.min(),this.In=t.getMutationQueue(n),this.jn=t.getRemoteDocumentCache(),this.ze=t.getTargetCache(),this.Qn=new Mi(this.jn,this.In,this.persistence.getIndexManager()),this.Je=t.getBundleCache(),this.Bn.$n(this.Qn)}collectGarbage(t){return this.persistence.runTransaction("Collect garbage","readwrite-primary",e=>t.collect(e,this.Un))}}function Vi(t,e,n,r){return new qi(t,e,n,r)}async function zi(t,e){const n=_(t);let r=n.In,i=n.Qn;const s=await n.persistence.runTransaction("Handle user change","readonly",t=>{let s;return n.In.getAllMutationBatches(t).next(o=>(s=o,r=n.persistence.getMutationQueue(e),i=new Mi(n.jn,r,n.persistence.getIndexManager()),r.getAllMutationBatches(t))).next(e=>{const n=[],r=[];let o=sn();for(const t of s){n.push(t.batchId);for(const e of t.mutations)o=o.add(e.key)}for(const t of e){r.push(t.batchId);for(const e of t.mutations)o=o.add(e.key)}return i.Pn(t,o).next(t=>({Wn:t,removedBatchIds:n,addedBatchIds:r}))})});return n.In=r,n.Qn=i,n.Bn.$n(n.Qn),s}function Hi(t,e){const n=_(t);return n.persistence.runTransaction("Acknowledge batch","readwrite-primary",t=>{const r=e.batch.keys(),i=n.jn.newChangeBuffer({trackRemovals:!0});return function(t,e,n,r){const i=n.batch,s=i.keys();let o=Er.resolve();return s.forEach(t=>{o=o.next(()=>r.getEntry(e,t)).next(e=>{const s=n.docVersions.get(t);v(null!==s),e.version.compareTo(s)<0&&(i.applyToRemoteDocument(e,n),e.isValidDocument()&&r.addEntry(e,n.commitVersion))})}),o.next(()=>t.In.removeMutationBatch(e,i))}(n,t,e,i).next(()=>i.apply(t)).next(()=>n.In.performConsistencyCheck(t)).next(()=>n.Qn.Pn(t,r))})}function Ki(t){const e=_(t);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.ze.getLastRemoteSnapshotVersion(t))}function $i(t,e){const n=_(t),r=e.snapshotVersion;let i=n.Un;return n.persistence.runTransaction("Apply remote event","readwrite-primary",t=>{const s=n.jn.newChangeBuffer({trackRemovals:!0});i=n.Un;const o=[];e.targetChanges.forEach((e,s)=>{const a=i.get(s);if(!a)return;o.push(n.ze.removeMatchingKeys(t,e.removedDocuments,s).next(()=>n.ze.addMatchingKeys(t,e.addedDocuments,s)));const c=e.resumeToken;if(c.approximateByteSize()>0){const u=a.withResumeToken(c,r).withSequenceNumber(t.currentSequenceNumber);i=i.insert(s,u),function(t,e,n){return v(e.resumeToken.approximateByteSize()>0),0===t.resumeToken.approximateByteSize()||(e.snapshotVersion.toMicroseconds()-t.snapshotVersion.toMicroseconds()>=3e8||n.addedDocuments.size+n.modifiedDocuments.size+n.removedDocuments.size>0)}(a,u,e)&&o.push(n.ze.updateTargetData(t,u))}});let a=Xe();if(e.documentUpdates.forEach((r,i)=>{e.resolvedLimboDocuments.has(r)&&o.push(n.persistence.referenceDelegate.updateLimboDocument(t,r))}),o.push(Gi(t,s,e.documentUpdates,r,void 0).next(t=>{a=t})),!r.isEqual(M.min())){const e=n.ze.getLastRemoteSnapshotVersion(t).next(e=>n.ze.setTargetsMetadata(t,t.currentSequenceNumber,r));o.push(e)}return Er.waitFor(o).next(()=>s.apply(t)).next(()=>n.Qn.vn(t,a)).next(()=>a)}).then(t=>(n.Un=i,t))}function Gi(t,e,n,r,i){let s=sn();return n.forEach(t=>s=s.add(t)),e.getEntries(t,s).next(t=>{let s=Xe();return n.forEach((n,o)=>{const a=t.get(n),c=(null==i?void 0:i.get(n))||r;o.isNoDocument()&&o.version.isEqual(M.min())?(e.removeEntry(n,c),s=s.insert(n,o)):!a.isValidDocument()||o.version.compareTo(a.version)>0||0===o.version.compareTo(a.version)&&a.hasPendingWrites?(e.addEntry(o,c),s=s.insert(n,o)):p("LocalStore","Ignoring outdated watch update for ",n,". Current version:",a.version," Watch version:",o.version)}),s})}function Wi(t,e){const n=_(t);return n.persistence.runTransaction("Get next mutation batch","readonly",t=>(void 0===e&&(e=-1),n.In.getNextMutationBatchAfterBatchId(t,e)))}function Yi(t,e){const n=_(t);return n.persistence.runTransaction("Allocate target","readwrite",t=>{let r;return n.ze.getTargetData(t,e).next(i=>i?(r=i,Er.resolve(r)):n.ze.allocateTargetId(t).next(i=>(r=new Lr(e,i,0,t.currentSequenceNumber),n.ze.addTargetData(t,r).next(()=>r))))}).then(t=>{const r=n.Un.get(t.targetId);return(null===r||t.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(n.Un=n.Un.insert(t.targetId,t),n.qn.set(e,t.targetId)),t})}async function Qi(t,e,n){const r=_(t),i=r.Un.get(e),s=n?"readwrite":"readwrite-primary";try{n||await r.persistence.runTransaction("Release target",s,t=>r.persistence.referenceDelegate.removeTarget(t,i))}catch(t){if(!Ar(t))throw t;p("LocalStore",`Failed to update sequence numbers for target ${e}: ${t}`)}r.Un=r.Un.remove(e),r.qn.delete(i.target)}function Ji(t,e,n){const r=_(t);let i=M.min(),s=sn();return r.persistence.runTransaction("Execute query","readonly",t=>function(t,e,n){const r=_(t),i=r.qn.get(n);return void 0!==i?Er.resolve(r.Un.get(i)):r.ze.getTargetData(e,n)}(r,t,te(e)).next(e=>{if(e)return i=e.lastLimboFreeSnapshotVersion,r.ze.getMatchingKeysForTargetId(t,e.targetId).next(t=>{s=t})}).next(()=>r.Bn.getDocumentsMatchingQuery(t,e,n?i:M.min(),n?s:sn())).next(t=>({documents:t,Gn:s})))}function Xi(t,e){const n=_(t),r=_(n.ze),i=n.Un.get(e);return i?Promise.resolve(i.target):n.persistence.runTransaction("Get target data","readonly",t=>r.Tt(t,e).next(t=>t?t.target:null))}function Zi(t){const e=_(t);return e.persistence.runTransaction("Get new document changes","readonly",t=>function(t,e,n){const r=_(t);let i=Xe(),s=qr(n);const o=Ai(e),a=IDBKeyRange.lowerBound(s,!0);return o.Kt({index:hr.readTimeIndex,range:a},(t,e)=>{const n=Ur(r.N,e);i=i.insert(n.key,n),s=e.readTime}).next(()=>({En:i,readTime:Vr(s)}))}(e.jn,t,e.Kn)).then(({En:t,readTime:n})=>(e.Kn=n,t))}async function ts(t){const e=_(t);return e.persistence.runTransaction("Synchronize last document change read time","readonly",t=>function(t){const e=Ai(t);let n=M.min();return e.Kt({index:hr.readTimeIndex,reverse:!0},(t,e,r)=>{e.readTime&&(n=Vr(e.readTime)),r.done()}).next(()=>n)}(t)).then(t=>{e.Kn=t})}async function es(t,e,n,r){const i=_(t);let s=sn(),o=Xe(),a=nn();for(const l of n){const t=e.zn(l.metadata.name);l.document&&(s=s.add(t)),o=o.insert(t,e.Hn(l)),a=a.insert(t,e.Jn(l.metadata.readTime))}const c=i.jn.newChangeBuffer({trackRemovals:!0}),u=await Yi(i,function(t){return te(Gt(z.fromString("__bundle__/docs/"+t)))}(r));return i.persistence.runTransaction("Apply bundle documents","readwrite",t=>Gi(t,c,o,M.min(),a).next(e=>(c.apply(t),e)).next(e=>i.ze.removeMatchingKeysForTargetId(t,u.targetId).next(()=>i.ze.addMatchingKeys(t,s,u.targetId)).next(()=>i.Qn.vn(t,e)).next(()=>e)))}async function ns(t,e,n=sn()){const r=await Yi(t,te(Wr(e.bundledQuery))),i=_(t);return i.persistence.runTransaction("Save named query","readwrite",t=>{const s=En(e.readTime);if(r.snapshotVersion.compareTo(s)>=0)return i.Je.saveNamedQuery(t,e);const o=r.withResumeToken(W.EMPTY_BYTE_STRING,s);return i.Un=i.Un.insert(o.targetId,o),i.ze.updateTargetData(t,o).next(()=>i.ze.removeMatchingKeysForTargetId(t,r.targetId)).next(()=>i.ze.addMatchingKeys(t,n,r.targetId)).next(()=>i.Je.saveNamedQuery(t,e))})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rs{constructor(t){this.N=t,this.Yn=new Map,this.Xn=new Map}getBundleMetadata(t,e){return Er.resolve(this.Yn.get(e))}saveBundleMetadata(t,e){var n;return this.Yn.set(e.id,{id:(n=e).id,version:n.version,createTime:En(n.createTime)}),Er.resolve()}getNamedQuery(t,e){return Er.resolve(this.Xn.get(e))}saveNamedQuery(t,e){return this.Xn.set(e.name,function(t){return{name:t.name,query:Wr(t.bundledQuery),readTime:En(t.readTime)}}(e)),Er.resolve()}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class is{constructor(){this.Zn=new Ye(ss.ts),this.es=new Ye(ss.ns)}isEmpty(){return this.Zn.isEmpty()}addReference(t,e){const n=new ss(t,e);this.Zn=this.Zn.add(n),this.es=this.es.add(n)}ss(t,e){t.forEach(t=>this.addReference(t,e))}removeReference(t,e){this.rs(new ss(t,e))}os(t,e){t.forEach(t=>this.removeReference(t,e))}cs(t){const e=new st(new z([])),n=new ss(e,t),r=new ss(e,t+1),i=[];return this.es.forEachInRange([n,r],t=>{this.rs(t),i.push(t.key)}),i}us(){this.Zn.forEach(t=>this.rs(t))}rs(t){this.Zn=this.Zn.delete(t),this.es=this.es.delete(t)}hs(t){const e=new st(new z([])),n=new ss(e,t),r=new ss(e,t+1);let i=sn();return this.es.forEachInRange([n,r],t=>{i=i.add(t.key)}),i}containsKey(t){const e=new ss(t,0),n=this.Zn.firstAfterOrEqual(e);return null!==n&&t.isEqual(n.key)}}class ss{constructor(t,e){this.key=t,this.ls=e}static ts(t,e){return st.comparator(t.key,e.key)||D(t.ls,e.ls)}static ns(t,e){return D(t.ls,e.ls)||st.comparator(t.key,e.key)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class os{constructor(t,e){this.Ht=t,this.referenceDelegate=e,this.In=[],this.fs=1,this.ds=new Ye(ss.ts)}checkEmpty(t){return Er.resolve(0===this.In.length)}addMutationBatch(t,e,n,r){const i=this.fs;this.fs++,this.In.length>0&&this.In[this.In.length-1];const s=new Pr(i,e,n,r);this.In.push(s);for(const o of r)this.ds=this.ds.add(new ss(o.key,i)),this.Ht.addToCollectionParentIndex(t,o.key.path.popLast());return Er.resolve(s)}lookupMutationBatch(t,e){return Er.resolve(this.ws(e))}getNextMutationBatchAfterBatchId(t,e){const n=e+1,r=this._s(n),i=r<0?0:r;return Er.resolve(this.In.length>i?this.In[i]:null)}getHighestUnacknowledgedBatchId(){return Er.resolve(0===this.In.length?-1:this.fs-1)}getAllMutationBatches(t){return Er.resolve(this.In.slice())}getAllMutationBatchesAffectingDocumentKey(t,e){const n=new ss(e,0),r=new ss(e,Number.POSITIVE_INFINITY),i=[];return this.ds.forEachInRange([n,r],t=>{const e=this.ws(t.ls);i.push(e)}),Er.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new Ye(D);return e.forEach(t=>{const e=new ss(t,0),r=new ss(t,Number.POSITIVE_INFINITY);this.ds.forEachInRange([e,r],t=>{n=n.add(t.ls)})}),Er.resolve(this.gs(n))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,r=n.length+1;let i=n;st.isDocumentKey(i)||(i=i.child(""));const s=new ss(new st(i),0);let o=new Ye(D);return this.ds.forEachWhile(t=>{const e=t.key.path;return!!n.isPrefixOf(e)&&(e.length===r&&(o=o.add(t.ls)),!0)},s),Er.resolve(this.gs(o))}gs(t){const e=[];return t.forEach(t=>{const n=this.ws(t);null!==n&&e.push(n)}),e}removeMutationBatch(t,e){v(0===this.ys(e.batchId,"removed")),this.In.shift();let n=this.ds;return Er.forEach(e.mutations,r=>{const i=new ss(r.key,e.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(t,r.key)}).next(()=>{this.ds=n})}te(t){}containsKey(t,e){const n=new ss(e,0),r=this.ds.firstAfterOrEqual(n);return Er.resolve(e.isEqual(r&&r.key))}performConsistencyCheck(t){return this.In.length,Er.resolve()}ys(t,e){return this._s(t)}_s(t){return 0===this.In.length?0:t-this.In[0].batchId}ws(t){const e=this._s(t);return e<0||e>=this.In.length?null:this.In[e]}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class as{constructor(t,e){this.Ht=t,this.ps=e,this.docs=new $e(st.comparator),this.size=0}addEntry(t,e,n){const r=e.key,i=this.docs.get(r),s=i?i.size:0,o=this.ps(e);return this.docs=this.docs.insert(r,{document:e.clone(),size:o,readTime:n}),this.size+=o-s,this.Ht.addToCollectionParentIndex(t,r.path.popLast())}removeEntry(t){const e=this.docs.get(t);e&&(this.docs=this.docs.remove(t),this.size-=e.size)}getEntry(t,e){const n=this.docs.get(e);return Er.resolve(n?n.document.clone():It.newInvalidDocument(e))}getEntries(t,e){let n=Xe();return e.forEach(t=>{const e=this.docs.get(t);n=n.insert(t,e?e.document.clone():It.newInvalidDocument(t))}),Er.resolve(n)}getDocumentsMatchingQuery(t,e,n){let r=Xe();const i=new st(e.path.child("")),s=this.docs.getIteratorFrom(i);for(;s.hasNext();){const{key:t,value:{document:i,readTime:o}}=s.getNext();if(!e.path.isPrefixOf(t.path))break;o.compareTo(n)<=0||se(e,i)&&(r=r.insert(i.key,i.clone()))}return Er.resolve(r)}Ts(t,e){return Er.forEach(this.docs,t=>e(t))}newChangeBuffer(t){return new cs(this)}getSize(t){return Er.resolve(this.size)}}class cs extends Oi{constructor(t){super(),this.Se=t}applyChanges(t){const e=[];return this.changes.forEach((n,r)=>{r.document.isValidDocument()?e.push(this.Se.addEntry(t,r.document,this.getReadTime(n))):this.Se.removeEntry(n)}),Er.waitFor(e)}getFromCache(t,e){return this.Se.getEntry(t,e)}getAllFromCache(t,e){return this.Se.getEntries(t,e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class us{constructor(t){this.persistence=t,this.Es=new Ei(t=>Tt(t),St),this.lastRemoteSnapshotVersion=M.min(),this.highestTargetId=0,this.Is=0,this.As=new is,this.targetCount=0,this.Rs=hi.se()}forEachTarget(t,e){return this.Es.forEach((t,n)=>e(n)),Er.resolve()}getLastRemoteSnapshotVersion(t){return Er.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(t){return Er.resolve(this.Is)}allocateTargetId(t){return this.highestTargetId=this.Rs.next(),Er.resolve(this.highestTargetId)}setTargetsMetadata(t,e,n){return n&&(this.lastRemoteSnapshotVersion=n),e>this.Is&&(this.Is=e),Er.resolve()}ce(t){this.Es.set(t.target,t);const e=t.targetId;e>this.highestTargetId&&(this.Rs=new hi(e),this.highestTargetId=e),t.sequenceNumber>this.Is&&(this.Is=t.sequenceNumber)}addTargetData(t,e){return this.ce(e),this.targetCount+=1,Er.resolve()}updateTargetData(t,e){return this.ce(e),Er.resolve()}removeTargetData(t,e){return this.Es.delete(e.target),this.As.cs(e.targetId),this.targetCount-=1,Er.resolve()}removeTargets(t,e,n){let r=0;const i=[];return this.Es.forEach((s,o)=>{o.sequenceNumber<=e&&null===n.get(o.targetId)&&(this.Es.delete(s),i.push(this.removeMatchingKeysForTargetId(t,o.targetId)),r++)}),Er.waitFor(i).next(()=>r)}getTargetCount(t){return Er.resolve(this.targetCount)}getTargetData(t,e){const n=this.Es.get(e)||null;return Er.resolve(n)}addMatchingKeys(t,e,n){return this.As.ss(e,n),Er.resolve()}removeMatchingKeys(t,e,n){this.As.os(e,n);const r=this.persistence.referenceDelegate,i=[];return r&&e.forEach(e=>{i.push(r.markPotentiallyOrphaned(t,e))}),Er.waitFor(i)}removeMatchingKeysForTargetId(t,e){return this.As.cs(e),Er.resolve()}getMatchingKeysForTargetId(t,e){const n=this.As.hs(e);return Er.resolve(n)}containsKey(t,e){return Er.resolve(this.As.containsKey(e))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ls{constructor(t,e){this.bs={},this.Le=new C(0),this.Be=!1,this.Be=!0,this.referenceDelegate=t(this),this.ze=new us(this),this.Ht=new Xr,this.He=function(t,e){return new as(t,e)}(this.Ht,t=>this.referenceDelegate.Ps(t)),this.N=new Mr(e),this.Je=new rs(this.N)}start(){return Promise.resolve()}shutdown(){return this.Be=!1,Promise.resolve()}get started(){return this.Be}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(){return this.Ht}getMutationQueue(t){let e=this.bs[t.toKey()];return e||(e=new os(this.Ht,this.referenceDelegate),this.bs[t.toKey()]=e),e}getTargetCache(){return this.ze}getRemoteDocumentCache(){return this.He}getBundleCache(){return this.Je}runTransaction(t,e,n){p("MemoryPersistence","Starting transaction:",t);const r=new hs(this.Le.next());return this.referenceDelegate.vs(),n(r).next(t=>this.referenceDelegate.Vs(r).next(()=>t)).toPromise().then(t=>(r.raiseOnCommittedEvent(),t))}Ss(t,e){return Er.or(Object.values(this.bs).map(n=>()=>n.containsKey(t,e)))}}class hs extends Ir{constructor(t){super(),this.currentSequenceNumber=t}}class ds{constructor(t){this.persistence=t,this.Ds=new is,this.Cs=null}static Ns(t){return new ds(t)}get xs(){if(this.Cs)return this.Cs;throw b()}addReference(t,e,n){return this.Ds.addReference(n,e),this.xs.delete(n.toString()),Er.resolve()}removeReference(t,e,n){return this.Ds.removeReference(n,e),this.xs.add(n.toString()),Er.resolve()}markPotentiallyOrphaned(t,e){return this.xs.add(e.toString()),Er.resolve()}removeTarget(t,e){this.Ds.cs(e.targetId).forEach(t=>this.xs.add(t.toString()));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(t,e.targetId).next(t=>{t.forEach(t=>this.xs.add(t.toString()))}).next(()=>n.removeTargetData(t,e))}vs(){this.Cs=new Set}Vs(t){const e=this.persistence.getRemoteDocumentCache().newChangeBuffer();return Er.forEach(this.xs,n=>{const r=st.fromPath(n);return this.ks(t,r).next(t=>{t||e.removeEntry(r)})}).next(()=>(this.Cs=null,e.apply(t)))}updateLimboDocument(t,e){return this.ks(t,e).next(t=>{t?this.xs.delete(e.toString()):this.xs.add(e.toString())})}Ps(t){return 0}ks(t,e){return Er.or([()=>Er.resolve(this.Ds.containsKey(e)),()=>this.persistence.getTargetCache().containsKey(t,e),()=>this.persistence.Ss(t,e)])}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fs(t,e){return`firestore_clients_${t}_${e}`}function ps(t,e,n){let r=`firestore_mutations_${t}_${n}`;return e.isAuthenticated()&&(r+="_"+e.uid),r}function ms(t,e){return`firestore_targets_${t}_${e}`}class gs{constructor(t,e,n,r){this.user=t,this.batchId=e,this.state=n,this.error=r}static $s(t,e,n){const r=JSON.parse(n);let i,s="object"==typeof r&&-1!==["pending","acknowledged","rejected"].indexOf(r.state)&&(void 0===r.error||"object"==typeof r.error);return s&&r.error&&(s="string"==typeof r.error.message&&"string"==typeof r.error.code,s&&(i=new E(r.error.code,r.error.message))),s?new gs(t,e,r.state,i):(m("SharedClientState",`Failed to parse mutation state for ID '${e}': ${n}`),null)}Os(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class ys{constructor(t,e,n){this.targetId=t,this.state=e,this.error=n}static $s(t,e){const n=JSON.parse(e);let r,i="object"==typeof n&&-1!==["not-current","current","rejected"].indexOf(n.state)&&(void 0===n.error||"object"==typeof n.error);return i&&n.error&&(i="string"==typeof n.error.message&&"string"==typeof n.error.code,i&&(r=new E(n.error.code,n.error.message))),i?new ys(t,n.state,r):(m("SharedClientState",`Failed to parse target state for ID '${t}': ${e}`),null)}Os(){const t={state:this.state,updateTimeMs:Date.now()};return this.error&&(t.error={code:this.error.code,message:this.error.message}),JSON.stringify(t)}}class bs{constructor(t,e){this.clientId=t,this.activeTargetIds=e}static $s(t,e){const n=JSON.parse(e);let r="object"==typeof n&&n.activeTargetIds instanceof Array,i=an();for(let s=0;r&&s<n.activeTargetIds.length;++s)r=it(n.activeTargetIds[s]),i=i.add(n.activeTargetIds[s]);return r?new bs(t,i):(m("SharedClientState",`Failed to parse client data for instance '${t}': ${e}`),null)}}class vs{constructor(t,e){this.clientId=t,this.onlineState=e}static $s(t){const e=JSON.parse(t);return"object"==typeof e&&-1!==["Unknown","Online","Offline"].indexOf(e.onlineState)&&"string"==typeof e.clientId?new vs(e.clientId,e.onlineState):(m("SharedClientState","Failed to parse online state: "+t),null)}}class ws{constructor(){this.activeTargetIds=an()}Fs(t){this.activeTargetIds=this.activeTargetIds.add(t)}Ms(t){this.activeTargetIds=this.activeTargetIds.delete(t)}Os(){const t={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(t)}}class _s{constructor(t,e,n,r,i){this.window=t,this.Oe=e,this.persistenceKey=n,this.Ls=r,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.Bs=this.Us.bind(this),this.qs=new $e(D),this.started=!1,this.Ks=[];const s=n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=i,this.js=fs(this.persistenceKey,this.Ls),this.Qs=function(t){return"firestore_sequence_number_"+t}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(this.persistenceKey),this.qs=this.qs.insert(this.Ls,new ws),this.Ws=new RegExp(`^firestore_clients_${s}_([^_]*)$`),this.Gs=new RegExp(`^firestore_mutations_${s}_(\\d+)(?:_(.*))?$`),this.zs=new RegExp(`^firestore_targets_${s}_(\\d+)$`),this.Hs=function(t){return"firestore_online_state_"+t}(this.persistenceKey),this.Js=function(t){return"firestore_bundle_loaded_"+t}(this.persistenceKey),this.window.addEventListener("storage",this.Bs)}static bt(t){return!(!t||!t.localStorage)}async start(){const t=await this.syncEngine.pn();for(const n of t){if(n===this.Ls)continue;const t=this.getItem(fs(this.persistenceKey,n));if(t){const e=bs.$s(n,t);e&&(this.qs=this.qs.insert(e.clientId,e))}}this.Ys();const e=this.storage.getItem(this.Hs);if(e){const t=this.Xs(e);t&&this.Zs(t)}for(const n of this.Ks)this.Us(n);this.Ks=[],this.window.addEventListener("pagehide",()=>this.shutdown()),this.started=!0}writeSequenceNumber(t){this.setItem(this.Qs,JSON.stringify(t))}getAllActiveQueryTargets(){return this.ti(this.qs)}isActiveQueryTarget(t){let e=!1;return this.qs.forEach((n,r)=>{r.activeTargetIds.has(t)&&(e=!0)}),e}addPendingMutation(t){this.ei(t,"pending")}updateMutationState(t,e,n){this.ei(t,e,n),this.ni(t)}addLocalQueryTarget(t){let e="not-current";if(this.isActiveQueryTarget(t)){const n=this.storage.getItem(ms(this.persistenceKey,t));if(n){const r=ys.$s(t,n);r&&(e=r.state)}}return this.si.Fs(t),this.Ys(),e}removeLocalQueryTarget(t){this.si.Ms(t),this.Ys()}isLocalQueryTarget(t){return this.si.activeTargetIds.has(t)}clearQueryState(t){this.removeItem(ms(this.persistenceKey,t))}updateQueryState(t,e,n){this.ii(t,e,n)}handleUserChange(t,e,n){e.forEach(t=>{this.ni(t)}),this.currentUser=t,n.forEach(t=>{this.addPendingMutation(t)})}setOnlineState(t){this.ri(t)}notifyBundleLoaded(){this.oi()}shutdown(){this.started&&(this.window.removeEventListener("storage",this.Bs),this.removeItem(this.js),this.started=!1)}getItem(t){const e=this.storage.getItem(t);return p("SharedClientState","READ",t,e),e}setItem(t,e){p("SharedClientState","SET",t,e),this.storage.setItem(t,e)}removeItem(t){p("SharedClientState","REMOVE",t),this.storage.removeItem(t)}Us(t){const e=t;if(e.storageArea===this.storage){if(p("SharedClientState","EVENT",e.key,e.newValue),e.key===this.js)return void m("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.Oe.enqueueRetryable(async()=>{if(this.started){if(null!==e.key)if(this.Ws.test(e.key)){if(null==e.newValue){const t=this.ci(e.key);return this.ai(t,null)}{const t=this.ui(e.key,e.newValue);if(t)return this.ai(t.clientId,t)}}else if(this.Gs.test(e.key)){if(null!==e.newValue){const t=this.hi(e.key,e.newValue);if(t)return this.li(t)}}else if(this.zs.test(e.key)){if(null!==e.newValue){const t=this.fi(e.key,e.newValue);if(t)return this.di(t)}}else if(e.key===this.Hs){if(null!==e.newValue){const t=this.Xs(e.newValue);if(t)return this.Zs(t)}}else if(e.key===this.Qs){const t=function(t){let e=C.T;if(null!=t)try{const n=JSON.parse(t);v("number"==typeof n),e=n}catch(t){m("SharedClientState","Failed to read sequence number from WebStorage",t)}return e}(e.newValue);t!==C.T&&this.sequenceNumberHandler(t)}else if(e.key===this.Js)return this.syncEngine.wi()}else this.Ks.push(e)})}}get si(){return this.qs.get(this.Ls)}Ys(){this.setItem(this.js,this.si.Os())}ei(t,e,n){const r=new gs(this.currentUser,t,e,n),i=ps(this.persistenceKey,this.currentUser,t);this.setItem(i,r.Os())}ni(t){const e=ps(this.persistenceKey,this.currentUser,t);this.removeItem(e)}ri(t){const e={clientId:this.Ls,onlineState:t};this.storage.setItem(this.Hs,JSON.stringify(e))}ii(t,e,n){const r=ms(this.persistenceKey,t),i=new ys(t,e,n);this.setItem(r,i.Os())}oi(){this.setItem(this.Js,"value-not-used")}ci(t){const e=this.Ws.exec(t);return e?e[1]:null}ui(t,e){const n=this.ci(t);return bs.$s(n,e)}hi(t,e){const n=this.Gs.exec(t),r=Number(n[1]),i=void 0!==n[2]?n[2]:null;return gs.$s(new u(i),r,e)}fi(t,e){const n=this.zs.exec(t),r=Number(n[1]);return ys.$s(r,e)}Xs(t){return vs.$s(t)}async li(t){if(t.user.uid===this.currentUser.uid)return this.syncEngine._i(t.batchId,t.state,t.error);p("SharedClientState","Ignoring mutation for non-active user "+t.user.uid)}di(t){return this.syncEngine.mi(t.targetId,t.state,t.error)}ai(t,e){const n=e?this.qs.insert(t,e):this.qs.remove(t),r=this.ti(this.qs),i=this.ti(n),s=[],o=[];return i.forEach(t=>{r.has(t)||s.push(t)}),r.forEach(t=>{i.has(t)||o.push(t)}),this.syncEngine.gi(s,o).then(()=>{this.qs=n})}Zs(t){this.qs.get(t.clientId)&&this.onlineStateHandler(t.onlineState)}ti(t){let e=an();return t.forEach((t,n)=>{e=e.unionWith(n.activeTargetIds)}),e}}class Is{constructor(){this.yi=new ws,this.pi={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(t){}updateMutationState(t,e,n){}addLocalQueryTarget(t){return this.yi.Fs(t),this.pi[t]||"not-current"}updateQueryState(t,e,n){this.pi[t]=e}removeLocalQueryTarget(t){this.yi.Ms(t)}isLocalQueryTarget(t){return this.yi.activeTargetIds.has(t)}clearQueryState(t){delete this.pi[t]}getAllActiveQueryTargets(){return this.yi.activeTargetIds}isActiveQueryTarget(t){return this.yi.activeTargetIds.has(t)}start(){return this.yi=new ws,Promise.resolve()}handleUserChange(t,e,n){}setOnlineState(t){}shutdown(){}writeSequenceNumber(t){}notifyBundleLoaded(){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es{Ti(t){}shutdown(){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Os{constructor(){this.Ei=()=>this.Ii(),this.Ai=()=>this.Ri(),this.bi=[],this.Pi()}Ti(t){this.bi.push(t)}shutdown(){window.removeEventListener("online",this.Ei),window.removeEventListener("offline",this.Ai)}Pi(){window.addEventListener("online",this.Ei),window.addEventListener("offline",this.Ai)}Ii(){p("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(const t of this.bi)t(0)}Ri(){p("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(const t of this.bi)t(1)}static bt(){return"undefined"!=typeof window&&void 0!==window.addEventListener&&void 0!==window.removeEventListener}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ts={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery"};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ks{constructor(t){this.vi=t.vi,this.Vi=t.Vi}Si(t){this.Di=t}Ci(t){this.Ni=t}onMessage(t){this.xi=t}close(){this.Vi()}send(t){this.vi(t)}ki(){this.Di()}$i(t){this.Ni(t)}Oi(t){this.xi(t)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ss extends class{constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const e=t.ssl?"https":"http";this.Fi=e+"://"+t.host,this.Mi="projects/"+this.databaseId.projectId+"/databases/"+this.databaseId.database+"/documents"}Li(t,e,n,r){const i=this.Bi(t,e);p("RestConnection","Sending: ",i,n);const s={};return this.Ui(s,r),this.qi(t,i,s,n).then(t=>(p("RestConnection","Received: ",t),t),e=>{throw g("RestConnection",t+" failed with error: ",e,"url: ",i,"request:",n),e})}Ki(t,e,n,r){return this.Li(t,e,n,r)}Ui(t,e){if(t["X-Goog-Api-Client"]="gl-js/ fire/"+l,t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),e)for(const n in e.authHeaders)e.authHeaders.hasOwnProperty(n)&&(t[n]=e.authHeaders[n])}Bi(t,e){const n=Ts[t];return`${this.Fi}/v1/${e}:${n}`}}{constructor(t){super(t),this.forceLongPolling=t.forceLongPolling,this.autoDetectLongPolling=t.autoDetectLongPolling,this.useFetchStreams=t.useFetchStreams}qi(t,e,n,r){return new Promise((i,s)=>{const o=new a["g"];o.listenOnce(a["c"].COMPLETE,()=>{try{switch(o.getLastErrorCode()){case a["a"].NO_ERROR:const e=o.getResponseJson();p("Connection","XHR received:",JSON.stringify(e)),i(e);break;case a["a"].TIMEOUT:p("Connection",'RPC "'+t+'" timed out'),s(new E(I.DEADLINE_EXCEEDED,"Request time out"));break;case a["a"].HTTP_ERROR:const n=o.getStatus();if(p("Connection",'RPC "'+t+'" failed with status:',n,"response text:",o.getResponseText()),n>0){const t=o.getResponseJson().error;if(t&&t.status&&t.message){const e=function(t){const e=t.toLowerCase().replace(/_/g,"-");return Object.values(I).indexOf(e)>=0?e:I.UNKNOWN}(t.status);s(new E(e,t.message))}else s(new E(I.UNKNOWN,"Server responded with status "+o.getStatus()))}else s(new E(I.UNAVAILABLE,"Connection failed."));break;default:b()}}finally{p("Connection",'RPC "'+t+'" completed.')}});const c=JSON.stringify(r);o.send(e,"POST",c,n,15)})}ji(t,e){const n=[this.Fi,"/","google.firestore.v1.Firestore","/",t,"/channel"],r=Object(a["h"])(),i=Object(a["i"])(),s={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling};this.useFetchStreams&&(s.xmlHttpFactory=new a["d"]({})),this.Ui(s.initMessageHeaders,e),Object(o["s"])()||Object(o["u"])()||Object(o["o"])()||Object(o["q"])()||Object(o["w"])()||Object(o["n"])()||(s.httpHeadersOverwriteParam="$httpHeaders");const c=n.join("");p("Connection","Creating WebChannel: "+c,s);const u=r.createWebChannel(c,s);let l=!1,h=!1;const d=new ks({vi:t=>{h?p("Connection","Not sending because WebChannel is closed:",t):(l||(p("Connection","Opening WebChannel transport."),u.open(),l=!0),p("Connection","WebChannel sending:",t),u.send(t))},Vi:()=>u.close()}),f=(t,e,n)=>{t.listen(e,t=>{try{n(t)}catch(t){setTimeout(()=>{throw t},0)}})};return f(u,a["f"].EventType.OPEN,()=>{h||p("Connection","WebChannel transport opened.")}),f(u,a["f"].EventType.CLOSE,()=>{h||(h=!0,p("Connection","WebChannel transport closed"),d.$i())}),f(u,a["f"].EventType.ERROR,t=>{h||(h=!0,g("Connection","WebChannel transport errored:",t),d.$i(new E(I.UNAVAILABLE,"The operation could not be completed")))}),f(u,a["f"].EventType.MESSAGE,t=>{var e;if(!h){const n=t.data[0];v(!!n);const r=n,i=r.error||(null===(e=r[0])||void 0===e?void 0:e.error);if(i){p("Connection","WebChannel received error:",i);const t=i.status;let e=function(t){const e=Ve[t];if(void 0!==e)return Ke(e)}(t),n=i.message;void 0===e&&(e=I.INTERNAL,n="Unknown error status: "+t+" with message "+i.message),h=!0,d.$i(new E(e,n)),u.close()}else p("Connection","WebChannel received:",n),d.Oi(n)}}),f(i,a["b"].STAT_EVENT,t=>{t.stat===a["e"].PROXY?p("Connection","Detected buffering proxy"):t.stat===a["e"].NOPROXY&&p("Connection","Detected no buffering proxy")}),setTimeout(()=>{d.ki()},0),d}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function As(){return"undefined"!=typeof window?window:null}function js(){return"undefined"!=typeof document?document:null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ns(t){return new vn(t,!0)}class Cs{constructor(t,e,n=1e3,r=1.5,i=6e4){this.Oe=t,this.timerId=e,this.Qi=n,this.Wi=r,this.Gi=i,this.zi=0,this.Hi=null,this.Ji=Date.now(),this.reset()}reset(){this.zi=0}Yi(){this.zi=this.Gi}Xi(t){this.cancel();const e=Math.floor(this.zi+this.Zi()),n=Math.max(0,Date.now()-this.Ji),r=Math.max(0,e-n);r>0&&p("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.zi} ms, delay with jitter: ${e} ms, last attempt: ${n} ms ago)`),this.Hi=this.Oe.enqueueAfterDelay(this.timerId,r,()=>(this.Ji=Date.now(),t())),this.zi*=this.Wi,this.zi<this.Qi&&(this.zi=this.Qi),this.zi>this.Gi&&(this.zi=this.Gi)}tr(){null!==this.Hi&&(this.Hi.skipDelay(),this.Hi=null)}cancel(){null!==this.Hi&&(this.Hi.cancel(),this.Hi=null)}Zi(){return(Math.random()-.5)*this.zi}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rs{constructor(t,e,n,r,i,s,o){this.Oe=t,this.er=n,this.nr=r,this.sr=i,this.credentialsProvider=s,this.listener=o,this.state=0,this.ir=0,this.rr=null,this.cr=null,this.stream=null,this.ar=new Cs(t,e)}ur(){return 1===this.state||5===this.state||this.hr()}hr(){return 2===this.state||3===this.state}start(){4!==this.state?this.auth():this.lr()}async stop(){this.ur()&&await this.close(0)}dr(){this.state=0,this.ar.reset()}wr(){this.hr()&&null===this.rr&&(this.rr=this.Oe.enqueueAfterDelay(this.er,6e4,()=>this._r()))}mr(t){this.gr(),this.stream.send(t)}async _r(){if(this.hr())return this.close(0)}gr(){this.rr&&(this.rr.cancel(),this.rr=null)}yr(){this.cr&&(this.cr.cancel(),this.cr=null)}async close(t,e){this.gr(),this.yr(),this.ar.cancel(),this.ir++,4!==t?this.ar.reset():e&&e.code===I.RESOURCE_EXHAUSTED?(m(e.toString()),m("Using maximum backoff delay to prevent overloading the backend."),this.ar.Yi()):e&&e.code===I.UNAUTHENTICATED&&3!==this.state&&this.credentialsProvider.invalidateToken(),null!==this.stream&&(this.pr(),this.stream.close(),this.stream=null),this.state=t,await this.listener.Ci(e)}pr(){}auth(){this.state=1;const t=this.Tr(this.ir),e=this.ir;this.credentialsProvider.getToken().then(t=>{this.ir===e&&this.Er(t)},e=>{t(()=>{const t=new E(I.UNKNOWN,"Fetching auth token failed: "+e.message);return this.Ir(t)})})}Er(t){const e=this.Tr(this.ir);this.stream=this.Ar(t),this.stream.Si(()=>{e(()=>(this.state=2,this.cr=this.Oe.enqueueAfterDelay(this.nr,1e4,()=>(this.hr()&&(this.state=3),Promise.resolve())),this.listener.Si()))}),this.stream.Ci(t=>{e(()=>this.Ir(t))}),this.stream.onMessage(t=>{e(()=>this.onMessage(t))})}lr(){this.state=5,this.ar.Xi(async()=>{this.state=0,this.start()})}Ir(t){return p("PersistentStream","close with error: "+t),this.stream=null,this.close(4,t)}Tr(t){return e=>{this.Oe.enqueueAndForget(()=>this.ir===t?e():(p("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class xs extends Rs{constructor(t,e,n,r,i){super(t,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",e,n,i),this.N=r}Ar(t){return this.sr.ji("Listen",t)}onMessage(t){this.ar.reset();const e=Pn(this.N,t),n=function(t){if(!("targetChange"in t))return M.min();const e=t.targetChange;return e.targetIds&&e.targetIds.length?M.min():e.readTime?En(e.readTime):M.min()}(t);return this.listener.Rr(e,n)}br(t){const e={};e.database=Nn(this.N),e.addTarget=function(t,e){let n;const r=e.target;return n=At(r)?{documents:Un(t,r)}:{query:Bn(t,r)},n.targetId=e.targetId,e.resumeToken.approximateByteSize()>0?n.resumeToken=_n(t,e.resumeToken):e.snapshotVersion.compareTo(M.min())>0&&(n.readTime=wn(t,e.snapshotVersion.toTimestamp())),n}(this.N,t);const n=Vn(this.N,t);n&&(e.labels=n),this.mr(e)}Pr(t){const e={};e.database=Nn(this.N),e.removeTarget=t,this.mr(e)}}class Ds extends Rs{constructor(t,e,n,r,i){super(t,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",e,n,i),this.N=r,this.vr=!1}get Vr(){return this.vr}start(){this.vr=!1,this.lastStreamToken=void 0,super.start()}pr(){this.vr&&this.Sr([])}Ar(t){return this.sr.ji("Write",t)}onMessage(t){if(v(!!t.streamToken),this.lastStreamToken=t.streamToken,this.vr){this.ar.reset();const e=Mn(t.writeResults,t.commitTime),n=En(t.commitTime);return this.listener.Dr(n,e)}return v(!t.writeResults||0===t.writeResults.length),this.vr=!0,this.listener.Cr()}Nr(){const t={};t.database=Nn(this.N),this.mr(t)}Sr(t){const e={streamToken:this.lastStreamToken,writes:t.map(t=>Fn(this.N,t))};this.mr(e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps extends class{}{constructor(t,e,n){super(),this.credentials=t,this.sr=e,this.N=n,this.kr=!1}$r(){if(this.kr)throw new E(I.FAILED_PRECONDITION,"The client has already been terminated.")}Li(t,e,n){return this.$r(),this.credentials.getToken().then(r=>this.sr.Li(t,e,n,r)).catch(t=>{throw"FirebaseError"===t.name?(t.code===I.UNAUTHENTICATED&&this.credentials.invalidateToken(),t):new E(I.UNKNOWN,t.toString())})}Ki(t,e,n){return this.$r(),this.credentials.getToken().then(r=>this.sr.Ki(t,e,n,r)).catch(t=>{throw"FirebaseError"===t.name?(t.code===I.UNAUTHENTICATED&&this.credentials.invalidateToken(),t):new E(I.UNKNOWN,t.toString())})}terminate(){this.kr=!0}}class Fs{constructor(t,e){this.asyncQueue=t,this.onlineStateHandler=e,this.state="Unknown",this.Or=0,this.Fr=null,this.Mr=!0}Lr(){0===this.Or&&(this.Br("Unknown"),this.Fr=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.Fr=null,this.Ur("Backend didn't respond within 10 seconds."),this.Br("Offline"),Promise.resolve())))}qr(t){"Online"===this.state?this.Br("Unknown"):(this.Or++,this.Or>=1&&(this.Kr(),this.Ur("Connection failed 1 times. Most recent error: "+t.toString()),this.Br("Offline")))}set(t){this.Kr(),this.Or=0,"Online"===t&&(this.Mr=!1),this.Br(t)}Br(t){t!==this.state&&(this.state=t,this.onlineStateHandler(t))}Ur(t){const e=`Could not reach Cloud Firestore backend. ${t}\nThis typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Mr?(m(e),this.Mr=!1):p("OnlineStateTracker",e)}Kr(){null!==this.Fr&&(this.Fr.cancel(),this.Fr=null)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ls{constructor(t,e,n,r,i){this.localStore=t,this.datastore=e,this.asyncQueue=n,this.remoteSyncer={},this.jr=[],this.Qr=new Map,this.Wr=new Set,this.Gr=[],this.zr=i,this.zr.Ti(t=>{n.enqueueAndForget(async()=>{$s(this)&&(p("RemoteStore","Restarting streams for network reachability change."),await async function(t){const e=_(t);e.Wr.add(4),await Us(e),e.Hr.set("Unknown"),e.Wr.delete(4),await Ms(e)}(this))})}),this.Hr=new Fs(n,r)}}async function Ms(t){if($s(t))for(const e of t.Gr)await e(!0)}async function Us(t){for(const e of t.Gr)await e(!1)}function Bs(t,e){const n=_(t);n.Qr.has(e.targetId)||(n.Qr.set(e.targetId,e),Ks(n)?Hs(n):uo(n).hr()&&Vs(n,e))}function qs(t,e){const n=_(t),r=uo(n);n.Qr.delete(e),r.hr()&&zs(n,e),0===n.Qr.size&&(r.hr()?r.wr():$s(n)&&n.Hr.set("Unknown"))}function Vs(t,e){t.Jr.Y(e.targetId),uo(t).br(e)}function zs(t,e){t.Jr.Y(e),uo(t).Pr(e)}function Hs(t){t.Jr=new pn({getRemoteKeysForTarget:e=>t.remoteSyncer.getRemoteKeysForTarget(e),Tt:e=>t.Qr.get(e)||null}),uo(t).start(),t.Hr.Lr()}function Ks(t){return $s(t)&&!uo(t).ur()&&t.Qr.size>0}function $s(t){return 0===_(t).Wr.size}function Gs(t){t.Jr=void 0}async function Ws(t){t.Qr.forEach((e,n)=>{Vs(t,e)})}async function Ys(t,e){Gs(t),Ks(t)?(t.Hr.qr(e),Hs(t)):t.Hr.set("Unknown")}async function Qs(t,e,n){if(t.Hr.set("Online"),e instanceof dn&&2===e.state&&e.cause)try{await async function(t,e){const n=e.cause;for(const r of e.targetIds)t.Qr.has(r)&&(await t.remoteSyncer.rejectListen(r,n),t.Qr.delete(r),t.Jr.removeTarget(r))}(t,e)}catch(n){p("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),n),await Js(t,n)}else if(e instanceof ln?t.Jr.rt(e):e instanceof hn?t.Jr.ft(e):t.Jr.at(e),!n.isEqual(M.min()))try{const e=await Ki(t.localStore);n.compareTo(e)>=0&&await function(t,e){const n=t.Jr._t(e);return n.targetChanges.forEach((n,r)=>{if(n.resumeToken.approximateByteSize()>0){const i=t.Qr.get(r);i&&t.Qr.set(r,i.withResumeToken(n.resumeToken,e))}}),n.targetMismatches.forEach(e=>{const n=t.Qr.get(e);if(!n)return;t.Qr.set(e,n.withResumeToken(W.EMPTY_BYTE_STRING,n.snapshotVersion)),zs(t,e);const r=new Lr(n.target,e,1,n.sequenceNumber);Vs(t,r)}),t.remoteSyncer.applyRemoteEvent(n)}(t,n)}catch(e){p("RemoteStore","Failed to raise snapshot:",e),await Js(t,e)}}async function Js(t,e,n){if(!Ar(e))throw e;t.Wr.add(1),await Us(t),t.Hr.set("Offline"),n||(n=()=>Ki(t.localStore)),t.asyncQueue.enqueueRetryable(async()=>{p("RemoteStore","Retrying IndexedDB access"),await n(),t.Wr.delete(1),await Ms(t)})}function Xs(t,e){return e().catch(n=>Js(t,n,e))}async function Zs(t){const e=_(t),n=lo(e);let r=e.jr.length>0?e.jr[e.jr.length-1].batchId:-1;for(;to(e);)try{const t=await Wi(e.localStore,r);if(null===t){0===e.jr.length&&n.wr();break}r=t.batchId,eo(e,t)}catch(t){await Js(e,t)}no(e)&&ro(e)}function to(t){return $s(t)&&t.jr.length<10}function eo(t,e){t.jr.push(e);const n=lo(t);n.hr()&&n.Vr&&n.Sr(e.mutations)}function no(t){return $s(t)&&!lo(t).ur()&&t.jr.length>0}function ro(t){lo(t).start()}async function io(t){lo(t).Nr()}async function so(t){const e=lo(t);for(const n of t.jr)e.Sr(n.mutations)}async function oo(t,e,n){const r=t.jr.shift(),i=Fr.from(r,e,n);await Xs(t,()=>t.remoteSyncer.applySuccessfulWrite(i)),await Zs(t)}async function ao(t,e){e&&lo(t).Vr&&await async function(t,e){if(n=e.code,He(n)&&n!==I.ABORTED){const n=t.jr.shift();lo(t).dr(),await Xs(t,()=>t.remoteSyncer.rejectFailedWrite(n.batchId,e)),await Zs(t)}var n}(t,e),no(t)&&ro(t)}async function co(t,e){const n=_(t);e?(n.Wr.delete(2),await Ms(n)):e||(n.Wr.add(2),await Us(n),n.Hr.set("Unknown"))}function uo(t){return t.Yr||(t.Yr=function(t,e,n){const r=_(t);return r.$r(),new xs(e,r.sr,r.credentials,r.N,n)
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}(t.datastore,t.asyncQueue,{Si:Ws.bind(null,t),Ci:Ys.bind(null,t),Rr:Qs.bind(null,t)}),t.Gr.push(async e=>{e?(t.Yr.dr(),Ks(t)?Hs(t):t.Hr.set("Unknown")):(await t.Yr.stop(),Gs(t))})),t.Yr}function lo(t){return t.Xr||(t.Xr=function(t,e,n){const r=_(t);return r.$r(),new Ds(e,r.sr,r.credentials,r.N,n)}(t.datastore,t.asyncQueue,{Si:io.bind(null,t),Ci:ao.bind(null,t),Cr:so.bind(null,t),Dr:oo.bind(null,t)}),t.Gr.push(async e=>{e?(t.Xr.dr(),await Zs(t)):(await t.Xr.stop(),t.jr.length>0&&(p("RemoteStore",`Stopping write stream with ${t.jr.length} pending writes`),t.jr=[]))})),t.Xr
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class ho{constructor(t,e,n,r,i){this.asyncQueue=t,this.timerId=e,this.targetTimeMs=n,this.op=r,this.removalCallback=i,this.deferred=new O,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(t=>{})}static createAndSchedule(t,e,n,r,i){const s=Date.now()+n,o=new ho(t,e,s,r,i);return o.start(n),o}start(t){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),t)}skipDelay(){return this.handleDelayElapsed()}cancel(t){null!==this.timerHandle&&(this.clearTimeout(),this.deferred.reject(new E(I.CANCELLED,"Operation cancelled"+(t?": "+t:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>null!==this.timerHandle?(this.clearTimeout(),this.op().then(t=>this.deferred.resolve(t))):Promise.resolve())}clearTimeout(){null!==this.timerHandle&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function fo(t,e){if(m("AsyncQueue",`${e}: ${t}`),Ar(t))return new E(I.UNAVAILABLE,`${e}: ${t}`);throw t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class po{constructor(t){this.comparator=t?(e,n)=>t(e,n)||st.comparator(e.key,n.key):(t,e)=>st.comparator(t.key,e.key),this.keyedMap=tn(),this.sortedSet=new $e(this.comparator)}static emptySet(t){return new po(t.comparator)}has(t){return null!=this.keyedMap.get(t)}get(t){return this.keyedMap.get(t)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(t){const e=this.keyedMap.get(t);return e?this.sortedSet.indexOf(e):-1}get size(){return this.sortedSet.size}forEach(t){this.sortedSet.inorderTraversal((e,n)=>(t(e),!1))}add(t){const e=this.delete(t.key);return e.copy(e.keyedMap.insert(t.key,t),e.sortedSet.insert(t,null))}delete(t){const e=this.get(t);return e?this.copy(this.keyedMap.remove(t),this.sortedSet.remove(e)):this}isEqual(t){if(!(t instanceof po))return!1;if(this.size!==t.size)return!1;const e=this.sortedSet.getIterator(),n=t.sortedSet.getIterator();for(;e.hasNext();){const t=e.getNext().key,r=n.getNext().key;if(!t.isEqual(r))return!1}return!0}toString(){const t=[];return this.forEach(e=>{t.push(e.toString())}),0===t.length?"DocumentSet ()":"DocumentSet (\n  "+t.join("  \n")+"\n)"}copy(t,e){const n=new po;return n.comparator=this.comparator,n.keyedMap=t,n.sortedSet=e,n}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mo{constructor(){this.Zr=new $e(st.comparator)}track(t){const e=t.doc.key,n=this.Zr.get(e);n?0!==t.type&&3===n.type?this.Zr=this.Zr.insert(e,t):3===t.type&&1!==n.type?this.Zr=this.Zr.insert(e,{type:n.type,doc:t.doc}):2===t.type&&2===n.type?this.Zr=this.Zr.insert(e,{type:2,doc:t.doc}):2===t.type&&0===n.type?this.Zr=this.Zr.insert(e,{type:0,doc:t.doc}):1===t.type&&0===n.type?this.Zr=this.Zr.remove(e):1===t.type&&2===n.type?this.Zr=this.Zr.insert(e,{type:1,doc:n.doc}):0===t.type&&1===n.type?this.Zr=this.Zr.insert(e,{type:2,doc:t.doc}):b():this.Zr=this.Zr.insert(e,t)}eo(){const t=[];return this.Zr.inorderTraversal((e,n)=>{t.push(n)}),t}}class go{constructor(t,e,n,r,i,s,o,a){this.query=t,this.docs=e,this.oldDocs=n,this.docChanges=r,this.mutatedKeys=i,this.fromCache=s,this.syncStateChanged=o,this.excludesMetadataChanges=a}static fromInitialDocuments(t,e,n,r){const i=[];return e.forEach(t=>{i.push({type:0,doc:t})}),new go(t,e,po.emptySet(e),i,n,r,!0,!1)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(t){if(!(this.fromCache===t.fromCache&&this.syncStateChanged===t.syncStateChanged&&this.mutatedKeys.isEqual(t.mutatedKeys)&&ne(this.query,t.query)&&this.docs.isEqual(t.docs)&&this.oldDocs.isEqual(t.oldDocs)))return!1;const e=this.docChanges,n=t.docChanges;if(e.length!==n.length)return!1;for(let r=0;r<e.length;r++)if(e[r].type!==n[r].type||!e[r].doc.isEqual(n[r].doc))return!1;return!0}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yo{constructor(){this.no=void 0,this.listeners=[]}}class bo{constructor(){this.queries=new Ei(t=>re(t),ne),this.onlineState="Unknown",this.so=new Set}}async function vo(t,e){const n=_(t),r=e.query;let i=!1,s=n.queries.get(r);if(s||(i=!0,s=new yo),i)try{s.no=await n.onListen(r)}catch(t){const n=fo(t,`Initialization of query '${ie(e.query)}' failed`);return void e.onError(n)}n.queries.set(r,s),s.listeners.push(e),e.io(n.onlineState),s.no&&e.ro(s.no)&&Eo(n)}async function wo(t,e){const n=_(t),r=e.query;let i=!1;const s=n.queries.get(r);if(s){const t=s.listeners.indexOf(e);t>=0&&(s.listeners.splice(t,1),i=0===s.listeners.length)}if(i)return n.queries.delete(r),n.onUnlisten(r)}function _o(t,e){const n=_(t);let r=!1;for(const i of e){const t=i.query,e=n.queries.get(t);if(e){for(const t of e.listeners)t.ro(i)&&(r=!0);e.no=i}}r&&Eo(n)}function Io(t,e,n){const r=_(t),i=r.queries.get(e);if(i)for(const s of i.listeners)s.onError(n);r.queries.delete(e)}function Eo(t){t.so.forEach(t=>{t.next()})}class Oo{constructor(t,e,n){this.query=t,this.oo=e,this.co=!1,this.ao=null,this.onlineState="Unknown",this.options=n||{}}ro(t){if(!this.options.includeMetadataChanges){const e=[];for(const n of t.docChanges)3!==n.type&&e.push(n);t=new go(t.query,t.docs,t.oldDocs,e,t.mutatedKeys,t.fromCache,t.syncStateChanged,!0)}let e=!1;return this.co?this.uo(t)&&(this.oo.next(t),e=!0):this.ho(t,this.onlineState)&&(this.lo(t),e=!0),this.ao=t,e}onError(t){this.oo.error(t)}io(t){this.onlineState=t;let e=!1;return this.ao&&!this.co&&this.ho(this.ao,t)&&(this.lo(this.ao),e=!0),e}ho(t,e){if(!t.fromCache)return!0;const n="Offline"!==e;return(!this.options.fo||!n)&&(!t.docs.isEmpty()||"Offline"===e)}uo(t){if(t.docChanges.length>0)return!0;const e=this.ao&&this.ao.hasPendingWrites!==t.hasPendingWrites;return!(!t.syncStateChanged&&!e)&&!0===this.options.includeMetadataChanges}lo(t){t=go.fromInitialDocuments(t.query,t.docs,t.mutatedKeys,t.fromCache),this.co=!0,this.oo.next(t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class To{constructor(t,e){this.payload=t,this.byteLength=e}wo(){return"metadata"in this.payload}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ko{constructor(t){this.N=t}zn(t){return Sn(this.N,t)}Hn(t){return t.metadata.exists?xn(this.N,t.document,!1):It.newNoDocument(this.zn(t.metadata.name),this.Jn(t.metadata.readTime))}Jn(t){return En(t)}}class So{constructor(t,e,n){this._o=t,this.localStore=e,this.N=n,this.queries=[],this.documents=[],this.progress=Ao(t)}mo(t){this.progress.bytesLoaded+=t.byteLength;let e=this.progress.documentsLoaded;return t.payload.namedQuery?this.queries.push(t.payload.namedQuery):t.payload.documentMetadata?(this.documents.push({metadata:t.payload.documentMetadata}),t.payload.documentMetadata.exists||++e):t.payload.document&&(this.documents[this.documents.length-1].document=t.payload.document,++e),e!==this.progress.documentsLoaded?(this.progress.documentsLoaded=e,Object.assign({},this.progress)):null}yo(t){const e=new Map,n=new ko(this.N);for(const r of t)if(r.metadata.queries){const t=n.zn(r.metadata.name);for(const n of r.metadata.queries){const r=(e.get(n)||sn()).add(t);e.set(n,r)}}return e}async complete(){const t=await es(this.localStore,new ko(this.N),this.documents,this._o.id),e=this.yo(this.documents);for(const n of this.queries)await ns(this.localStore,n,e.get(n.name));return this.progress.taskState="Success",new Li(Object.assign({},this.progress),t)}}function Ao(t){return{taskState:"Running",documentsLoaded:0,bytesLoaded:0,totalDocuments:t.totalDocuments,totalBytes:t.totalBytes}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jo{constructor(t){this.key=t}}class No{constructor(t){this.key=t}}class Co{constructor(t,e){this.query=t,this.po=e,this.To=null,this.current=!1,this.Eo=sn(),this.mutatedKeys=sn(),this.Io=oe(t),this.Ao=new po(this.Io)}get Ro(){return this.po}bo(t,e){const n=e?e.Po:new mo,r=e?e.Ao:this.Ao;let i=e?e.mutatedKeys:this.mutatedKeys,s=r,o=!1;const a=Wt(this.query)&&r.size===this.query.limit?r.last():null,c=Yt(this.query)&&r.size===this.query.limit?r.first():null;if(t.inorderTraversal((t,e)=>{const u=r.get(t),l=se(this.query,e)?e:null,h=!!u&&this.mutatedKeys.has(u.key),d=!!l&&(l.hasLocalMutations||this.mutatedKeys.has(l.key)&&l.hasCommittedMutations);let f=!1;u&&l?u.data.isEqual(l.data)?h!==d&&(n.track({type:3,doc:l}),f=!0):this.vo(u,l)||(n.track({type:2,doc:l}),f=!0,(a&&this.Io(l,a)>0||c&&this.Io(l,c)<0)&&(o=!0)):!u&&l?(n.track({type:0,doc:l}),f=!0):u&&!l&&(n.track({type:1,doc:u}),f=!0,(a||c)&&(o=!0)),f&&(l?(s=s.add(l),i=d?i.add(t):i.delete(t)):(s=s.delete(t),i=i.delete(t)))}),Wt(this.query)||Yt(this.query))for(;s.size>this.query.limit;){const t=Wt(this.query)?s.last():s.first();s=s.delete(t.key),i=i.delete(t.key),n.track({type:1,doc:t})}return{Ao:s,Po:n,Ln:o,mutatedKeys:i}}vo(t,e){return t.hasLocalMutations&&e.hasCommittedMutations&&!e.hasLocalMutations}applyChanges(t,e,n){const r=this.Ao;this.Ao=t.Ao,this.mutatedKeys=t.mutatedKeys;const i=t.Po.eo();i.sort((t,e)=>function(t,e){const n=t=>{switch(t){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return b()}};return n(t)-n(e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(t.type,e.type)||this.Io(t.doc,e.doc)),this.Vo(n);const s=e?this.So():[],o=0===this.Eo.size&&this.current?1:0,a=o!==this.To;return this.To=o,0!==i.length||a?{snapshot:new go(this.query,t.Ao,r,i,t.mutatedKeys,0===o,a,!1),Do:s}:{Do:s}}io(t){return this.current&&"Offline"===t?(this.current=!1,this.applyChanges({Ao:this.Ao,Po:new mo,mutatedKeys:this.mutatedKeys,Ln:!1},!1)):{Do:[]}}Co(t){return!this.po.has(t)&&!!this.Ao.has(t)&&!this.Ao.get(t).hasLocalMutations}Vo(t){t&&(t.addedDocuments.forEach(t=>this.po=this.po.add(t)),t.modifiedDocuments.forEach(t=>{}),t.removedDocuments.forEach(t=>this.po=this.po.delete(t)),this.current=t.current)}So(){if(!this.current)return[];const t=this.Eo;this.Eo=sn(),this.Ao.forEach(t=>{this.Co(t.key)&&(this.Eo=this.Eo.add(t.key))});const e=[];return t.forEach(t=>{this.Eo.has(t)||e.push(new No(t))}),this.Eo.forEach(n=>{t.has(n)||e.push(new jo(n))}),e}No(t){this.po=t.Gn,this.Eo=sn();const e=this.bo(t.documents);return this.applyChanges(e,!0)}xo(){return go.fromInitialDocuments(this.query,this.Ao,this.mutatedKeys,0===this.To)}}class Ro{constructor(t,e,n){this.query=t,this.targetId=e,this.view=n}}class xo{constructor(t){this.key=t,this.ko=!1}}class Do{constructor(t,e,n,r,i,s){this.localStore=t,this.remoteStore=e,this.eventManager=n,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=s,this.$o={},this.Oo=new Ei(t=>re(t),ne),this.Fo=new Map,this.Mo=new Set,this.Lo=new $e(st.comparator),this.Bo=new Map,this.Uo=new is,this.qo={},this.Ko=new Map,this.jo=hi.ie(),this.onlineState="Unknown",this.Qo=void 0}get isPrimaryClient(){return!0===this.Qo}}async function Po(t,e){const n=la(t);let r,i;const s=n.Oo.get(e);if(s)r=s.targetId,n.sharedClientState.addLocalQueryTarget(r),i=s.view.xo();else{const t=await Yi(n.localStore,te(e)),s=n.sharedClientState.addLocalQueryTarget(t.targetId);r=t.targetId,i=await Fo(n,e,r,"current"===s),n.isPrimaryClient&&Bs(n.remoteStore,t)}return i}async function Fo(t,e,n,r){t.Wo=(e,n,r)=>async function(t,e,n,r){let i=e.view.bo(n);i.Ln&&(i=await Ji(t.localStore,e.query,!1).then(({documents:t})=>e.view.bo(t,i)));const s=r&&r.targetChanges.get(e.targetId),o=e.view.applyChanges(i,t.isPrimaryClient,s);return Yo(t,e.targetId,o.Do),o.snapshot}(t,e,n,r);const i=await Ji(t.localStore,e,!0),s=new Co(e,i.Gn),o=s.bo(i.documents),a=un.createSynthesizedTargetChangeForCurrentChange(n,r&&"Offline"!==t.onlineState),c=s.applyChanges(o,t.isPrimaryClient,a);Yo(t,n,c.Do);const u=new Ro(e,n,s);return t.Oo.set(e,u),t.Fo.has(n)?t.Fo.get(n).push(e):t.Fo.set(n,[e]),c.snapshot}async function Lo(t,e){const n=_(t),r=n.Oo.get(e),i=n.Fo.get(r.targetId);if(i.length>1)return n.Fo.set(r.targetId,i.filter(t=>!ne(t,e))),void n.Oo.delete(e);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(r.targetId),n.sharedClientState.isActiveQueryTarget(r.targetId)||await Qi(n.localStore,r.targetId,!1).then(()=>{n.sharedClientState.clearQueryState(r.targetId),qs(n.remoteStore,r.targetId),Go(n,r.targetId)}).catch(gi)):(Go(n,r.targetId),await Qi(n.localStore,r.targetId,!0))}async function Mo(t,e,n){const r=ha(t);try{const t=await function(t,e){const n=_(t),r=L.now(),i=e.reduce((t,e)=>t.add(e.key),sn());let s;return n.persistence.runTransaction("Locally write mutations","readwrite",t=>n.Qn.Pn(t,i).next(i=>{s=i;const o=[];for(const t of e){const e=Ce(t,s.get(t.key));null!=e&&o.push(new Pe(t.key,e,_t(e.value.mapValue),ke.exists(!0)))}return n.In.addMutationBatch(t,r,o,e)})).then(t=>(t.applyToLocalDocumentSet(s),{batchId:t.batchId,changes:s}))}(r.localStore,e);r.sharedClientState.addPendingMutation(t.batchId),function(t,e,n){let r=t.qo[t.currentUser.toKey()];r||(r=new $e(D)),r=r.insert(e,n),t.qo[t.currentUser.toKey()]=r}(r,t.batchId,n),await Xo(r,t.changes),await Zs(r.remoteStore)}catch(t){const e=fo(t,"Failed to persist write");n.reject(e)}}async function Uo(t,e){const n=_(t);try{const t=await $i(n.localStore,e);e.targetChanges.forEach((t,e)=>{const r=n.Bo.get(e);r&&(v(t.addedDocuments.size+t.modifiedDocuments.size+t.removedDocuments.size<=1),t.addedDocuments.size>0?r.ko=!0:t.modifiedDocuments.size>0?v(r.ko):t.removedDocuments.size>0&&(v(r.ko),r.ko=!1))}),await Xo(n,t,e)}catch(t){await gi(t)}}function Bo(t,e,n){const r=_(t);if(r.isPrimaryClient&&0===n||!r.isPrimaryClient&&1===n){const t=[];r.Oo.forEach((n,r)=>{const i=r.view.io(e);i.snapshot&&t.push(i.snapshot)}),function(t,e){const n=_(t);n.onlineState=e;let r=!1;n.queries.forEach((t,n)=>{for(const i of n.listeners)i.io(e)&&(r=!0)}),r&&Eo(n)}(r.eventManager,e),t.length&&r.$o.Rr(t),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function qo(t,e,n){const r=_(t);r.sharedClientState.updateQueryState(e,"rejected",n);const i=r.Bo.get(e),s=i&&i.key;if(s){let t=new $e(st.comparator);t=t.insert(s,It.newNoDocument(s,M.min()));const n=sn().add(s),i=new cn(M.min(),new Map,new Ye(D),t,n);await Uo(r,i),r.Lo=r.Lo.remove(s),r.Bo.delete(e),Jo(r)}else await Qi(r.localStore,e,!1).then(()=>Go(r,e,n)).catch(gi)}async function Vo(t,e){const n=_(t),r=e.batch.batchId;try{const t=await Hi(n.localStore,e);$o(n,r,null),Ko(n,r),n.sharedClientState.updateMutationState(r,"acknowledged"),await Xo(n,t)}catch(t){await gi(t)}}async function zo(t,e,n){const r=_(t);try{const t=await function(t,e){const n=_(t);return n.persistence.runTransaction("Reject batch","readwrite-primary",t=>{let r;return n.In.lookupMutationBatch(t,e).next(e=>(v(null!==e),r=e.keys(),n.In.removeMutationBatch(t,e))).next(()=>n.In.performConsistencyCheck(t)).next(()=>n.Qn.Pn(t,r))})}(r.localStore,e);$o(r,e,n),Ko(r,e),r.sharedClientState.updateMutationState(e,"rejected",n),await Xo(r,t)}catch(n){await gi(n)}}async function Ho(t,e){const n=_(t);$s(n.remoteStore)||p("SyncEngine","The network is disabled. The task returned by 'awaitPendingWrites()' will not complete until the network is enabled.");try{const t=await function(t){const e=_(t);return e.persistence.runTransaction("Get highest unacknowledged batch id","readonly",t=>e.In.getHighestUnacknowledgedBatchId(t))}(n.localStore);if(-1===t)return void e.resolve();const r=n.Ko.get(t)||[];r.push(e),n.Ko.set(t,r)}catch(t){const n=fo(t,"Initialization of waitForPendingWrites() operation failed");e.reject(n)}}function Ko(t,e){(t.Ko.get(e)||[]).forEach(t=>{t.resolve()}),t.Ko.delete(e)}function $o(t,e,n){const r=_(t);let i=r.qo[r.currentUser.toKey()];if(i){const t=i.get(e);t&&(n?t.reject(n):t.resolve(),i=i.remove(e)),r.qo[r.currentUser.toKey()]=i}}function Go(t,e,n=null){t.sharedClientState.removeLocalQueryTarget(e);for(const r of t.Fo.get(e))t.Oo.delete(r),n&&t.$o.Go(r,n);t.Fo.delete(e),t.isPrimaryClient&&t.Uo.cs(e).forEach(e=>{t.Uo.containsKey(e)||Wo(t,e)})}function Wo(t,e){t.Mo.delete(e.path.canonicalString());const n=t.Lo.get(e);null!==n&&(qs(t.remoteStore,n),t.Lo=t.Lo.remove(e),t.Bo.delete(n),Jo(t))}function Yo(t,e,n){for(const r of n)r instanceof jo?(t.Uo.addReference(r.key,e),Qo(t,r)):r instanceof No?(p("SyncEngine","Document no longer in limbo: "+r.key),t.Uo.removeReference(r.key,e),t.Uo.containsKey(r.key)||Wo(t,r.key)):b()}function Qo(t,e){const n=e.key,r=n.path.canonicalString();t.Lo.get(n)||t.Mo.has(r)||(p("SyncEngine","New document in limbo: "+n),t.Mo.add(r),Jo(t))}function Jo(t){for(;t.Mo.size>0&&t.Lo.size<t.maxConcurrentLimboResolutions;){const e=t.Mo.values().next().value;t.Mo.delete(e);const n=new st(z.fromString(e)),r=t.jo.next();t.Bo.set(r,new xo(n)),t.Lo=t.Lo.insert(n,r),Bs(t.remoteStore,new Lr(te(Gt(n.path)),r,2,C.T))}}async function Xo(t,e,n){const r=_(t),i=[],s=[],o=[];r.Oo.isEmpty()||(r.Oo.forEach((t,a)=>{o.push(r.Wo(a,e,n).then(t=>{if(t){r.isPrimaryClient&&r.sharedClientState.updateQueryState(a.targetId,t.fromCache?"not-current":"current"),i.push(t);const e=Ui.kn(a.targetId,t);s.push(e)}}))}),await Promise.all(o),r.$o.Rr(i),await async function(t,e){const n=_(t);try{await n.persistence.runTransaction("notifyLocalViewChanges","readwrite",t=>Er.forEach(e,e=>Er.forEach(e.Nn,r=>n.persistence.referenceDelegate.addReference(t,e.targetId,r)).next(()=>Er.forEach(e.xn,r=>n.persistence.referenceDelegate.removeReference(t,e.targetId,r)))))}catch(t){if(!Ar(t))throw t;p("LocalStore","Failed to update sequence numbers: "+t)}for(const r of e){const t=r.targetId;if(!r.fromCache){const e=n.Un.get(t),r=e.snapshotVersion,i=e.withLastLimboFreeSnapshotVersion(r);n.Un=n.Un.insert(t,i)}}}(r.localStore,s))}async function Zo(t,e){const n=_(t);if(!n.currentUser.isEqual(e)){p("SyncEngine","User change. New user:",e.toKey());const t=await zi(n.localStore,e);n.currentUser=e,function(t,e){t.Ko.forEach(t=>{t.forEach(t=>{t.reject(new E(I.CANCELLED,e))})}),t.Ko.clear()}(n,"'waitForPendingWrites' promise is rejected due to a user change."),n.sharedClientState.handleUserChange(e,t.removedBatchIds,t.addedBatchIds),await Xo(n,t.Wn)}}function ta(t,e){const n=_(t),r=n.Bo.get(e);if(r&&r.ko)return sn().add(r.key);{let t=sn();const r=n.Fo.get(e);if(!r)return t;for(const e of r){const r=n.Oo.get(e);t=t.unionWith(r.view.Ro)}return t}}async function ea(t,e){const n=_(t),r=await Ji(n.localStore,e.query,!0),i=e.view.No(r);return n.isPrimaryClient&&Yo(n,e.targetId,i.Do),i}async function na(t){const e=_(t);return Zi(e.localStore).then(t=>Xo(e,t))}async function ra(t,e,n,r){const i=_(t),s=await function(t,e){const n=_(t),r=_(n.In);return n.persistence.runTransaction("Lookup mutation documents","readonly",t=>r.Xt(t,e).next(e=>e?n.Qn.Pn(t,e):Er.resolve(null)))}(i.localStore,e);null!==s?("pending"===n?await Zs(i.remoteStore):"acknowledged"===n||"rejected"===n?($o(i,e,r||null),Ko(i,e),function(t,e){_(_(t).In).te(e)}(i.localStore,e)):b(),await Xo(i,s)):p("SyncEngine","Cannot apply mutation batch with id: "+e)}async function ia(t,e){const n=_(t);if(la(n),ha(n),!0===e&&!0!==n.Qo){const t=n.sharedClientState.getAllActiveQueryTargets(),e=await sa(n,t.toArray());n.Qo=!0,await co(n.remoteStore,!0);for(const r of e)Bs(n.remoteStore,r)}else if(!1===e&&!1!==n.Qo){const t=[];let e=Promise.resolve();n.Fo.forEach((r,i)=>{n.sharedClientState.isLocalQueryTarget(i)?t.push(i):e=e.then(()=>(Go(n,i),Qi(n.localStore,i,!0))),qs(n.remoteStore,i)}),await e,await sa(n,t),function(t){const e=_(t);e.Bo.forEach((t,n)=>{qs(e.remoteStore,n)}),e.Uo.us(),e.Bo=new Map,e.Lo=new $e(st.comparator)}(n),n.Qo=!1,await co(n.remoteStore,!1)}}async function sa(t,e,n){const r=_(t),i=[],s=[];for(const o of e){let t;const e=r.Fo.get(o);if(e&&0!==e.length){t=await Yi(r.localStore,te(e[0]));for(const t of e){const e=r.Oo.get(t),n=await ea(r,e);n.snapshot&&s.push(n.snapshot)}}else{const e=await Xi(r.localStore,o);t=await Yi(r.localStore,e),await Fo(r,oa(e),o,!1)}i.push(t)}return r.$o.Rr(s),i}function oa(t){return $t(t.path,t.collectionGroup,t.orderBy,t.filters,t.limit,"F",t.startAt,t.endAt)}function aa(t){const e=_(t);return _(_(e.localStore).persistence).pn()}async function ca(t,e,n,r){const i=_(t);if(i.Qo)p("SyncEngine","Ignoring unexpected query state notification.");else if(i.Fo.has(e))switch(n){case"current":case"not-current":{const t=await Zi(i.localStore),r=cn.createSynthesizedRemoteEventForCurrentChange(e,"current"===n);await Xo(i,t,r);break}case"rejected":await Qi(i.localStore,e,!0),Go(i,e,r);break;default:b()}}async function ua(t,e,n){const r=la(t);if(r.Qo){for(const t of e){if(r.Fo.has(t)){p("SyncEngine","Adding an already active target "+t);continue}const e=await Xi(r.localStore,t),n=await Yi(r.localStore,e);await Fo(r,oa(e),n.targetId,!1),Bs(r.remoteStore,n)}for(const t of n)r.Fo.has(t)&&await Qi(r.localStore,t,!1).then(()=>{qs(r.remoteStore,t),Go(r,t)}).catch(gi)}}function la(t){const e=_(t);return e.remoteStore.remoteSyncer.applyRemoteEvent=Uo.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=ta.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=qo.bind(null,e),e.$o.Rr=_o.bind(null,e.eventManager),e.$o.Go=Io.bind(null,e.eventManager),e}function ha(t){const e=_(t);return e.remoteStore.remoteSyncer.applySuccessfulWrite=Vo.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=zo.bind(null,e),e}function da(t,e,n){const r=_(t);(async function(t,e,n){try{const r=await e.getMetadata();if(await function(t,e){const n=_(t),r=En(e.createTime);return n.persistence.runTransaction("hasNewerBundle","readonly",t=>n.Je.getBundleMetadata(t,e.id)).then(t=>!!t&&t.createTime.compareTo(r)>=0)}(t.localStore,r))return await e.close(),void n._completeWith(function(t){return{taskState:"Success",documentsLoaded:t.totalDocuments,bytesLoaded:t.totalBytes,totalDocuments:t.totalDocuments,totalBytes:t.totalBytes}}(r));n._updateProgress(Ao(r));const i=new So(r,t.localStore,e.N);let s=await e.zo();for(;s;){const t=await i.mo(s);t&&n._updateProgress(t),s=await e.zo()}const o=await i.complete();await Xo(t,o.En,void 0),await function(t,e){const n=_(t);return n.persistence.runTransaction("Save bundle","readwrite",t=>n.Je.saveBundleMetadata(t,e))}(t.localStore,r),n._completeWith(o.progress)}catch(t){g("SyncEngine","Loading bundle failed with "+t),n._failWith(t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */)(r,e,n).then(()=>{r.sharedClientState.notifyBundleLoaded()})}class fa{constructor(){this.synchronizeTabs=!1}async initialize(t){this.N=Ns(t.databaseInfo.databaseId),this.sharedClientState=this.Ho(t),this.persistence=this.Jo(t),await this.persistence.start(),this.gcScheduler=this.Yo(t),this.localStore=this.Xo(t)}Yo(t){return null}Xo(t){return Vi(this.persistence,new Bi,t.initialUser,this.N)}Jo(t){return new ls(ds.Ns,this.N)}Ho(t){return new Is}async terminate(){this.gcScheduler&&this.gcScheduler.stop(),await this.sharedClientState.shutdown(),await this.persistence.shutdown()}}class pa extends fa{constructor(t,e,n){super(),this.Zo=t,this.cacheSizeBytes=e,this.forceOwnership=n,this.synchronizeTabs=!1}async initialize(t){await super.initialize(t),await ts(this.localStore),await this.Zo.initialize(this,t),await ha(this.Zo.syncEngine),await Zs(this.Zo.remoteStore),await this.persistence.nn(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(this.localStore),Promise.resolve()))}Xo(t){return Vi(this.persistence,new Bi,t.initialUser,this.N)}Yo(t){const e=this.persistence.referenceDelegate.garbageCollector;return new vi(e,t.asyncQueue)}Jo(t){const e=Fi(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey),n=void 0!==this.cacheSizeBytes?ri.withCacheSize(this.cacheSizeBytes):ri.DEFAULT;return new xi(this.synchronizeTabs,e,t.clientId,n,t.asyncQueue,As(),js(),this.N,this.sharedClientState,!!this.forceOwnership)}Ho(t){return new Is}}class ma extends pa{constructor(t,e){super(t,e,!1),this.Zo=t,this.cacheSizeBytes=e,this.synchronizeTabs=!0}async initialize(t){await super.initialize(t);const e=this.Zo.syncEngine;this.sharedClientState instanceof _s&&(this.sharedClientState.syncEngine={_i:ra.bind(null,e),mi:ca.bind(null,e),gi:ua.bind(null,e),pn:aa.bind(null,e),wi:na.bind(null,e)},await this.sharedClientState.start()),await this.persistence.nn(async t=>{await ia(this.Zo.syncEngine,t),this.gcScheduler&&(t&&!this.gcScheduler.started?this.gcScheduler.start(this.localStore):t||this.gcScheduler.stop())})}Ho(t){const e=As();if(!_s.bt(e))throw new E(I.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const n=Fi(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey);return new _s(e,t.asyncQueue,n,t.clientId,t.initialUser)}}class ga{async initialize(t,e){this.localStore||(this.localStore=t.localStore,this.sharedClientState=t.sharedClientState,this.datastore=this.createDatastore(e),this.remoteStore=this.createRemoteStore(e),this.eventManager=this.createEventManager(e),this.syncEngine=this.createSyncEngine(e,!t.synchronizeTabs),this.sharedClientState.onlineStateHandler=t=>Bo(this.syncEngine,t,1),this.remoteStore.remoteSyncer.handleCredentialChange=Zo.bind(null,this.syncEngine),await co(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(t){return new bo}createDatastore(t){const e=Ns(t.databaseInfo.databaseId),n=(r=t.databaseInfo,new Ss(r));var r;return function(t,e,n){return new Ps(t,e,n)}(t.credentials,n,e)}createRemoteStore(t){return e=this.localStore,n=this.datastore,r=t.asyncQueue,i=t=>Bo(this.syncEngine,t,0),s=Os.bt()?new Os:new Es,new Ls(e,n,r,i,s);var e,n,r,i,s}createSyncEngine(t,e){return function(t,e,n,r,i,s,o){const a=new Do(t,e,n,r,i,s);return o&&(a.Qo=!0),a}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,t.initialUser,t.maxConcurrentLimboResolutions,e)}terminate(){return async function(t){const e=_(t);p("RemoteStore","RemoteStore shutting down."),e.Wr.add(5),await Us(e),e.zr.shutdown(),e.Hr.set("Unknown")}(this.remoteStore)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ya(t,e=10240){let n=0;return{async read(){if(n<t.byteLength){const r={value:t.slice(n,n+e),done:!1};return n+=e,r}return{done:!0}},async cancel(){},releaseLock(){},closed:Promise.reject("unimplemented")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ba{constructor(t){this.observer=t,this.muted=!1}next(t){this.observer.next&&this.tc(this.observer.next,t)}error(t){this.observer.error?this.tc(this.observer.error,t):console.error("Uncaught Error in snapshot listener:",t)}ec(){this.muted=!0}tc(t,e){this.muted||setTimeout(()=>{this.muted||t(e)},0)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va{constructor(t,e){this.nc=t,this.N=e,this.metadata=new O,this.buffer=new Uint8Array,this.sc=new TextDecoder("utf-8"),this.ic().then(t=>{t&&t.wo()?this.metadata.resolve(t.payload.metadata):this.metadata.reject(new Error("The first element of the bundle is not a metadata, it is\n             "+JSON.stringify(null==t?void 0:t.payload)))},t=>this.metadata.reject(t))}close(){return this.nc.cancel()}async getMetadata(){return this.metadata.promise}async zo(){return await this.getMetadata(),this.ic()}async ic(){const t=await this.rc();if(null===t)return null;const e=this.sc.decode(t),n=Number(e);isNaN(n)&&this.oc(`length string (${e}) is not valid number`);const r=await this.cc(n);return new To(JSON.parse(r),t.length+n)}ac(){return this.buffer.findIndex(t=>t==="{".charCodeAt(0))}async rc(){for(;this.ac()<0;)if(await this.uc())break;if(0===this.buffer.length)return null;const t=this.ac();t<0&&this.oc("Reached the end of bundle when a length string is expected.");const e=this.buffer.slice(0,t);return this.buffer=this.buffer.slice(t),e}async cc(t){for(;this.buffer.length<t;)await this.uc()&&this.oc("Reached the end of bundle when more is expected.");const e=this.sc.decode(this.buffer.slice(0,t));return this.buffer=this.buffer.slice(t),e}oc(t){throw this.nc.cancel(),new Error("Invalid bundle format: "+t)}async uc(){const t=await this.nc.read();if(!t.done){const e=new Uint8Array(this.buffer.length+t.value.length);e.set(this.buffer),e.set(t.value,this.buffer.length),this.buffer=e}return t.done}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wa{constructor(t){this.datastore=t,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastWriteError=null,this.writtenDocs=new Set}async lookup(t){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw new E(I.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes.");const e=await async function(t,e){const n=_(t),r=Nn(n.N)+"/documents",i={documents:e.map(t=>kn(n.N,t))},s=await n.Ki("BatchGetDocuments",r,i),o=new Map;s.forEach(t=>{const e=Dn(n.N,t);o.set(e.key.toString(),e)});const a=[];return e.forEach(t=>{const e=o.get(t.toString());v(!!e),a.push(e)}),a}(this.datastore,t);return e.forEach(t=>this.recordVersion(t)),e}set(t,e){this.write(e.toMutation(t,this.precondition(t))),this.writtenDocs.add(t.toString())}update(t,e){try{this.write(e.toMutation(t,this.preconditionForUpdate(t)))}catch(t){this.lastWriteError=t}this.writtenDocs.add(t.toString())}delete(t){this.write(new Ue(t,this.precondition(t))),this.writtenDocs.add(t.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastWriteError)throw this.lastWriteError;const t=this.readVersions;this.mutations.forEach(e=>{t.delete(e.key.toString())}),t.forEach((t,e)=>{const n=st.fromPath(e);this.mutations.push(new Be(n,this.precondition(n)))}),await async function(t,e){const n=_(t),r=Nn(n.N)+"/documents",i={writes:e.map(t=>Fn(n.N,t))};await n.Li("Commit",r,i)}(this.datastore,this.mutations),this.committed=!0}recordVersion(t){let e;if(t.isFoundDocument())e=t.version;else{if(!t.isNoDocument())throw b();e=M.min()}const n=this.readVersions.get(t.key.toString());if(n){if(!e.isEqual(n))throw new E(I.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(t.key.toString(),e)}precondition(t){const e=this.readVersions.get(t.toString());return!this.writtenDocs.has(t.toString())&&e?ke.updateTime(e):ke.none()}preconditionForUpdate(t){const e=this.readVersions.get(t.toString());if(!this.writtenDocs.has(t.toString())&&e){if(e.isEqual(M.min()))throw new E(I.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return ke.updateTime(e)}return ke.exists(!0)}write(t){this.ensureCommitNotCalled(),this.mutations.push(t)}ensureCommitNotCalled(){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _a{constructor(t,e,n,r){this.asyncQueue=t,this.datastore=e,this.updateFunction=n,this.deferred=r,this.hc=5,this.ar=new Cs(this.asyncQueue,"transaction_retry")}run(){this.hc-=1,this.lc()}lc(){this.ar.Xi(async()=>{const t=new wa(this.datastore),e=this.fc(t);e&&e.then(e=>{this.asyncQueue.enqueueAndForget(()=>t.commit().then(()=>{this.deferred.resolve(e)}).catch(t=>{this.dc(t)}))}).catch(t=>{this.dc(t)})})}fc(t){try{const e=this.updateFunction(t);return!nt(e)&&e.catch&&e.then?e:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(t){return this.deferred.reject(t),null}}dc(t){this.hc>0&&this.wc(t)?(this.hc-=1,this.asyncQueue.enqueueAndForget(()=>(this.lc(),Promise.resolve()))):this.deferred.reject(t)}wc(t){if("FirebaseError"===t.name){const e=t.code;return"aborted"===e||"failed-precondition"===e||!He(e)}return!1}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ia{constructor(t,e,n){this.credentials=t,this.asyncQueue=e,this.databaseInfo=n,this.user=u.UNAUTHENTICATED,this.clientId=x.I(),this.credentialListener=()=>Promise.resolve(),this.credentials.start(e,async t=>{p("FirestoreClient","Received user=",t.uid),await this.credentialListener(t),this.user=t})}async getConfiguration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,credentials:this.credentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(t){this.credentialListener=t}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new E(I.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();const t=new O;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this.onlineComponents&&await this.onlineComponents.terminate(),this.offlineComponents&&await this.offlineComponents.terminate(),this.credentials.shutdown(),t.resolve()}catch(e){const n=fo(e,"Failed to shutdown persistence");t.reject(n)}}),t.promise}}async function Ea(t,e){t.asyncQueue.verifyOperationInProgress(),p("FirestoreClient","Initializing OfflineComponentProvider");const n=await t.getConfiguration();await e.initialize(n);let r=n.initialUser;t.setCredentialChangeListener(async t=>{r.isEqual(t)||(await zi(e.localStore,t),r=t)}),e.persistence.setDatabaseDeletedListener(()=>t.terminate()),t.offlineComponents=e}async function Oa(t,e){t.asyncQueue.verifyOperationInProgress();const n=await Ta(t);p("FirestoreClient","Initializing OnlineComponentProvider");const r=await t.getConfiguration();await e.initialize(n,r),t.setCredentialChangeListener(t=>async function(t,e){const n=_(t);n.asyncQueue.verifyOperationInProgress(),p("RemoteStore","RemoteStore received new credentials");const r=$s(n);n.Wr.add(3),await Us(n),r&&n.Hr.set("Unknown"),await n.remoteSyncer.handleCredentialChange(e),n.Wr.delete(3),await Ms(n)}(e.remoteStore,t)),t.onlineComponents=e}async function Ta(t){return t.offlineComponents||(p("FirestoreClient","Using default OfflineComponentProvider"),await Ea(t,new fa)),t.offlineComponents}async function ka(t){return t.onlineComponents||(p("FirestoreClient","Using default OnlineComponentProvider"),await Oa(t,new ga)),t.onlineComponents}function Sa(t){return Ta(t).then(t=>t.persistence)}function Aa(t){return Ta(t).then(t=>t.localStore)}function ja(t){return ka(t).then(t=>t.remoteStore)}function Na(t){return ka(t).then(t=>t.syncEngine)}async function Ca(t){const e=await ka(t),n=e.eventManager;return n.onListen=Po.bind(null,e.syncEngine),n.onUnlisten=Lo.bind(null,e.syncEngine),n}function Ra(t){return t.asyncQueue.enqueue(async()=>{const e=await Sa(t),n=await ja(t);return e.setNetworkEnabled(!0),function(t){const e=_(t);return e.Wr.delete(0),Ms(e)}(n)})}function xa(t){return t.asyncQueue.enqueue(async()=>{const e=await Sa(t),n=await ja(t);return e.setNetworkEnabled(!1),async function(t){const e=_(t);e.Wr.add(0),await Us(e),e.Hr.set("Offline")}(n)})}function Da(t,e){const n=new O;return t.asyncQueue.enqueueAndForget(async()=>async function(t,e,n){try{const r=await function(t,e){const n=_(t);return n.persistence.runTransaction("read document","readonly",t=>n.Qn.An(t,e))}(t,e);r.isFoundDocument()?n.resolve(r):r.isNoDocument()?n.resolve(null):n.reject(new E(I.UNAVAILABLE,"Failed to get document from cache. (However, this document may exist on the server. Run again without setting 'source' in the GetOptions to attempt to retrieve the document from the server.)"))}catch(t){const r=fo(t,`Failed to get document '${e} from cache`);n.reject(r)}}(await Aa(t),e,n)),n.promise}function Pa(t,e,n={}){const r=new O;return t.asyncQueue.enqueueAndForget(async()=>function(t,e,n,r,i){const s=new ba({next:s=>{e.enqueueAndForget(()=>wo(t,o));const a=s.docs.has(n);!a&&s.fromCache?i.reject(new E(I.UNAVAILABLE,"Failed to get document because the client is offline.")):a&&s.fromCache&&r&&"server"===r.source?i.reject(new E(I.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):i.resolve(s)},error:t=>i.reject(t)}),o=new Oo(Gt(n.path),s,{includeMetadataChanges:!0,fo:!0});return vo(t,o)}(await Ca(t),t.asyncQueue,e,n,r)),r.promise}function Fa(t,e){const n=new O;return t.asyncQueue.enqueueAndForget(async()=>async function(t,e,n){try{const r=await Ji(t,e,!0),i=new Co(e,r.Gn),s=i.bo(r.documents),o=i.applyChanges(s,!1);n.resolve(o.snapshot)}catch(t){const r=fo(t,`Failed to execute query '${e} against cache`);n.reject(r)}}(await Aa(t),e,n)),n.promise}function La(t,e,n={}){const r=new O;return t.asyncQueue.enqueueAndForget(async()=>function(t,e,n,r,i){const s=new ba({next:n=>{e.enqueueAndForget(()=>wo(t,o)),n.fromCache&&"server"===r.source?i.reject(new E(I.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):i.resolve(n)},error:t=>i.reject(t)}),o=new Oo(n,s,{includeMetadataChanges:!0,fo:!0});return vo(t,o)}(await Ca(t),t.asyncQueue,e,n,r)),r.promise}function Ma(t,e){const n=new ba(e);return t.asyncQueue.enqueueAndForget(async()=>function(t,e){_(t).so.add(e),e.next()}(await Ca(t),n)),()=>{n.ec(),t.asyncQueue.enqueueAndForget(async()=>function(t,e){_(t).so.delete(e)}(await Ca(t),n))}}function Ua(t,e){const n=new O;return t.asyncQueue.enqueueAndForget(async()=>{const r=await function(t){return ka(t).then(t=>t.datastore)}(t);new _a(t.asyncQueue,r,e,n).run()}),n.promise}function Ba(t,e,n,r){const i=function(t,e){let n;return n="string"==typeof t?(new TextEncoder).encode(t):t,function(t,e){return new va(t,e)}(function(t,e){if(t instanceof Uint8Array)return ya(t,e);if(t instanceof ArrayBuffer)return ya(new Uint8Array(t),e);if(t instanceof ReadableStream)return t.getReader();throw new Error("Source of `toByteStreamReader` has to be a ArrayBuffer or ReadableStream")}(n),e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(n,Ns(e));t.asyncQueue.enqueueAndForget(async()=>{da(await Na(t),i,r)})}function qa(t,e){return t.asyncQueue.enqueue(async()=>function(t,e){const n=_(t);return n.persistence.runTransaction("Get named query","readonly",t=>n.Je.getNamedQuery(t,e))}(await Aa(t),e))}class Va{constructor(t,e,n,r,i,s,o,a){this.databaseId=t,this.appId=e,this.persistenceKey=n,this.host=r,this.ssl=i,this.forceLongPolling=s,this.autoDetectLongPolling=o,this.useFetchStreams=a}}class za{constructor(t,e){this.projectId=t,this.database=e||"(default)"}get isDefaultDatabase(){return"(default)"===this.database}isEqual(t){return t instanceof za&&t.projectId===this.projectId&&t.database===this.database}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ha=new Map;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ka(t,e,n){if(!n)throw new E(I.INVALID_ARGUMENT,`Function ${t}() cannot be called with an empty ${e}.`)}function $a(t,e,n,r){if(!0===e&&!0===r)throw new E(I.INVALID_ARGUMENT,`${t} and ${n} cannot be used together.`)}function Ga(t){if(!st.isDocumentKey(t))throw new E(I.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`)}function Wa(t){if(st.isDocumentKey(t))throw new E(I.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${t} has ${t.length}.`)}function Ya(t){if(void 0===t)return"undefined";if(null===t)return"null";if("string"==typeof t)return t.length>20&&(t=t.substring(0,20)+"..."),JSON.stringify(t);if("number"==typeof t||"boolean"==typeof t)return""+t;if("object"==typeof t){if(t instanceof Array)return"an array";{const e=function(t){return t.constructor?t.constructor.name:null}(t);return e?`a custom ${e} object`:"an object"}}return"function"==typeof t?"a function":b()}function Qa(t,e){if("_delegate"in t&&(t=t._delegate),!(t instanceof e)){if(e.name===t.constructor.name)throw new E(I.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const n=Ya(t);throw new E(I.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${n}`)}}return t}function Ja(t,e){if(e<=0)throw new E(I.INVALID_ARGUMENT,`Function ${t}() requires a positive number, but it was: ${e}.`)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xa{constructor(t){var e;if(void 0===t.host){if(void 0!==t.ssl)throw new E(I.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=t.host,this.ssl=null===(e=t.ssl)||void 0===e||e;if(this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,void 0===t.cacheSizeBytes)this.cacheSizeBytes=41943040;else{if(-1!==t.cacheSizeBytes&&t.cacheSizeBytes<1048576)throw new E(I.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.useFetchStreams=!!t.useFetchStreams,$a("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling)}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Za{constructor(t,e){this._credentials=e,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Xa({}),this._settingsFrozen=!1,t instanceof za?this._databaseId=t:(this._app=t,this._databaseId=function(t){if(!Object.prototype.hasOwnProperty.apply(t.options,["projectId"]))throw new E(I.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new za(t.options.projectId)}(t))}get app(){if(!this._app)throw new E(I.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return void 0!==this._terminateTask}_setSettings(t){if(this._settingsFrozen)throw new E(I.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Xa(t),void 0!==t.credentials&&(this._credentials=function(t){if(!t)return new k;switch(t.type){case"gapi":const e=t.client;return v(!("object"!=typeof e||null===e||!e.auth||!e.auth.getAuthHeaderValueForFirstParty)),new N(e,t.sessionIndex||"0",t.iamToken||null);case"provider":return t.client;default:throw new E(I.INVALID_ARGUMENT,"makeCredentialsProvider failed due to invalid credential type")}}(t.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const e=Ha.get(t);e&&(p("ComponentProvider","Removing Datastore"),Ha.delete(t),e.terminate())}(this),Promise.resolve()}}function tc(t,e,n,r={}){var i;const s=(t=Qa(t,Za))._getSettings();if("firestore.googleapis.com"!==s.host&&s.host!==e&&g("Host has been set in both settings() and useEmulator(), emulator host will be used"),t._setSettings(Object.assign(Object.assign({},s),{host:`${e}:${n}`,ssl:!1})),r.mockUserToken){let e,n;if("string"==typeof r.mockUserToken)e=r.mockUserToken,n=u.MOCK_USER;else{e=Object(o["f"])(r.mockUserToken,null===(i=t._app)||void 0===i?void 0:i.options.projectId);const s=r.mockUserToken.sub||r.mockUserToken.user_id;if(!s)throw new E(I.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");n=new u(s)}t._credentials=new S(new T(e,n))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ec{constructor(t,e,n){this.converter=e,this._key=n,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new rc(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new ec(this.firestore,t,this._key)}}class nc{constructor(t,e,n){this.converter=e,this._query=n,this.type="query",this.firestore=t}withConverter(t){return new nc(this.firestore,t,this._query)}}class rc extends nc{constructor(t,e,n){super(t,e,Gt(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new ec(this.firestore,null,new st(t))}withConverter(t){return new rc(this.firestore,t,this._path)}}function ic(t,e,...n){if(t=Object(o["k"])(t),Ka("collection","path",e),t instanceof Za){const r=z.fromString(e,...n);return Wa(r),new rc(t,null,r)}{if(!(t instanceof ec||t instanceof rc))throw new E(I.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=t._path.child(z.fromString(e,...n));return Wa(r),new rc(t.firestore,null,r)}}function sc(t,e){if(t=Qa(t,Za),Ka("collectionGroup","collection id",e),e.indexOf("/")>=0)throw new E(I.INVALID_ARGUMENT,`Invalid collection ID '${e}' passed to function collectionGroup(). Collection IDs must not contain '/'.`);return new nc(t,null,function(t){return new Kt(z.emptyPath(),t)}(e))}function oc(t,e,...n){if(t=Object(o["k"])(t),1===arguments.length&&(e=x.I()),Ka("doc","path",e),t instanceof Za){const r=z.fromString(e,...n);return Ga(r),new ec(t,null,new st(r))}{if(!(t instanceof ec||t instanceof rc))throw new E(I.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=t._path.child(z.fromString(e,...n));return Ga(r),new ec(t.firestore,t instanceof rc?t.converter:null,new st(r))}}function ac(t,e){return t=Object(o["k"])(t),e=Object(o["k"])(e),(t instanceof ec||t instanceof rc)&&(e instanceof ec||e instanceof rc)&&t.firestore===e.firestore&&t.path===e.path&&t.converter===e.converter}function cc(t,e){return t=Object(o["k"])(t),e=Object(o["k"])(e),t instanceof nc&&e instanceof nc&&t.firestore===e.firestore&&ne(t._query,e._query)&&t.converter===e.converter
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class uc{constructor(){this._c=Promise.resolve(),this.mc=[],this.gc=!1,this.yc=[],this.Tc=null,this.Ec=!1,this.Ic=!1,this.Ac=[],this.ar=new Cs(this,"async_queue_retry"),this.Rc=()=>{const t=js();t&&p("AsyncQueue","Visibility state changed to "+t.visibilityState),this.ar.tr()};const t=js();t&&"function"==typeof t.addEventListener&&t.addEventListener("visibilitychange",this.Rc)}get isShuttingDown(){return this.gc}enqueueAndForget(t){this.enqueue(t)}enqueueAndForgetEvenWhileRestricted(t){this.bc(),this.Pc(t)}enterRestrictedMode(t){if(!this.gc){this.gc=!0,this.Ic=t||!1;const e=js();e&&"function"==typeof e.removeEventListener&&e.removeEventListener("visibilitychange",this.Rc)}}enqueue(t){if(this.bc(),this.gc)return new Promise(()=>{});const e=new O;return this.Pc(()=>this.gc&&this.Ic?Promise.resolve():(t().then(e.resolve,e.reject),e.promise)).then(()=>e.promise)}enqueueRetryable(t){this.enqueueAndForget(()=>(this.mc.push(t),this.vc()))}async vc(){if(0!==this.mc.length){try{await this.mc[0](),this.mc.shift(),this.ar.reset()}catch(t){if(!Ar(t))throw t;p("AsyncQueue","Operation failed with retryable error: "+t)}this.mc.length>0&&this.ar.Xi(()=>this.vc())}}Pc(t){const e=this._c.then(()=>(this.Ec=!0,t().catch(t=>{this.Tc=t,this.Ec=!1;const e=function(t){let e=t.message||"";return t.stack&&(e=t.stack.includes(t.message)?t.stack:t.message+"\n"+t.stack),e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(t);throw m("INTERNAL UNHANDLED ERROR: ",e),t}).then(t=>(this.Ec=!1,t))));return this._c=e,e}enqueueAfterDelay(t,e,n){this.bc(),this.Ac.indexOf(t)>-1&&(e=0);const r=ho.createAndSchedule(this,t,e,n,t=>this.Vc(t));return this.yc.push(r),r}bc(){this.Tc&&b()}verifyOperationInProgress(){}async Sc(){let t;do{t=this._c,await t}while(t!==this._c)}Dc(t){for(const e of this.yc)if(e.timerId===t)return!0;return!1}Cc(t){return this.Sc().then(()=>{this.yc.sort((t,e)=>t.targetTimeMs-e.targetTimeMs);for(const e of this.yc)if(e.skipDelay(),"all"!==t&&e.timerId===t)break;return this.Sc()})}Nc(t){this.Ac.push(t)}Vc(t){const e=this.yc.indexOf(t);this.yc.splice(e,1)}}function lc(t){return function(t,e){if("object"!=typeof t||null===t)return!1;const n=t;for(const r of e)if(r in n&&"function"==typeof n[r])return!0;return!1}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(t,["next","error","complete"])}class hc{constructor(){this._progressObserver={},this._taskCompletionResolver=new O,this._lastProgress={taskState:"Running",totalBytes:0,totalDocuments:0,bytesLoaded:0,documentsLoaded:0}}onProgress(t,e,n){this._progressObserver={next:t,error:e,complete:n}}catch(t){return this._taskCompletionResolver.promise.catch(t)}then(t,e){return this._taskCompletionResolver.promise.then(t,e)}_completeWith(t){this._updateProgress(t),this._progressObserver.complete&&this._progressObserver.complete(),this._taskCompletionResolver.resolve(t)}_failWith(t){this._lastProgress.taskState="Error",this._progressObserver.next&&this._progressObserver.next(this._lastProgress),this._progressObserver.error&&this._progressObserver.error(t),this._taskCompletionResolver.reject(t)}_updateProgress(t){this._lastProgress=t,this._progressObserver.next&&this._progressObserver.next(t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dc=-1;class fc extends Za{constructor(t,e){super(t,e),this.type="firestore",this._queue=new uc,this._persistenceKey="name"in t?t.name:"[DEFAULT]"}_terminate(){return this._firestoreClient||mc(this),this._firestoreClient.terminate()}}function pc(t){return t._firestoreClient||mc(t),t._firestoreClient.verifyNotTerminated(),t._firestoreClient}function mc(t){var e;const n=t._freezeSettings(),r=function(t,e,n,r){return new Va(t,e,n,r.host,r.ssl,r.experimentalForceLongPolling,r.experimentalAutoDetectLongPolling,r.useFetchStreams)}(t._databaseId,(null===(e=t._app)||void 0===e?void 0:e.options.appId)||"",t._persistenceKey,n);t._firestoreClient=new Ia(t._credentials,t._queue,r)}function gc(t,e){Tc(t=Qa(t,fc));const n=pc(t),r=t._freezeSettings(),i=new ga;return bc(n,i,new pa(i,r.cacheSizeBytes,null==e?void 0:e.forceOwnership))}function yc(t){Tc(t=Qa(t,fc));const e=pc(t),n=t._freezeSettings(),r=new ga;return bc(e,r,new ma(r,n.cacheSizeBytes))}function bc(t,e,n){const r=new O;return t.asyncQueue.enqueue(async()=>{try{await Ea(t,n),await Oa(t,e),r.resolve()}catch(t){if(!function(t){return"FirebaseError"===t.name?t.code===I.FAILED_PRECONDITION||t.code===I.UNIMPLEMENTED:!("undefined"!=typeof DOMException&&t instanceof DOMException)||(22===t.code||20===t.code||11===t.code)}(t))throw t;console.warn("Error enabling offline persistence. Falling back to persistence disabled: "+t),r.reject(t)}}).then(()=>r.promise)}function vc(t){if(t._initialized&&!t._terminated)throw new E(I.FAILED_PRECONDITION,"Persistence can only be cleared before a Firestore instance is initialized or after it is terminated.");const e=new O;return t._queue.enqueueAndForgetEvenWhileRestricted(async()=>{try{await async function(t){if(!Tr.bt())return Promise.resolve();const e=t+"main";await Tr.delete(e)}(Fi(t._databaseId,t._persistenceKey)),e.resolve()}catch(t){e.reject(t)}}),e.promise}function wc(t){return function(t){const e=new O;return t.asyncQueue.enqueueAndForget(async()=>Ho(await Na(t),e)),e.promise}(pc(t=Qa(t,fc)))}function _c(t){return Ra(pc(t=Qa(t,fc)))}function Ic(t){return xa(pc(t=Qa(t,fc)))}function Ec(t,e){const n=pc(t=Qa(t,fc)),r=new hc;return Ba(n,t._databaseId,e,r),r}function Oc(t,e){return qa(pc(t=Qa(t,fc)),e).then(e=>e?new nc(t,null,e.query):null)}function Tc(t){if(t._initialized||t._terminated)throw new E(I.FAILED_PRECONDITION,"Firestore has already been started and persistence can no longer be enabled. You can only enable persistence before calling any other methods on a Firestore object.")}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kc{constructor(...t){for(let e=0;e<t.length;++e)if(0===t[e].length)throw new E(I.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new K(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(t){this._byteString=t}static fromBase64String(t){try{return new Sc(W.fromBase64String(t))}catch(t){throw new E(I.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(t){return new Sc(W.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ac{constructor(t){this._methodName=t}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jc{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new E(I.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new E(I.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(t){return D(this._lat,t._lat)||D(this._long,t._long)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nc=/^__.*__$/;class Cc{constructor(t,e,n){this.data=t,this.fieldMask=e,this.fieldTransforms=n}toMutation(t,e){return null!==this.fieldMask?new Pe(t,this.data,this.fieldMask,e,this.fieldTransforms):new De(t,this.data,e,this.fieldTransforms)}}class Rc{constructor(t,e,n){this.data=t,this.fieldMask=e,this.fieldTransforms=n}toMutation(t,e){return new Pe(t,this.data,this.fieldMask,e,this.fieldTransforms)}}function xc(t){switch(t){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw b()}}class Dc{constructor(t,e,n,r,i,s){this.settings=t,this.databaseId=e,this.N=n,this.ignoreUndefinedProperties=r,void 0===i&&this.xc(),this.fieldTransforms=i||[],this.fieldMask=s||[]}get path(){return this.settings.path}get kc(){return this.settings.kc}$c(t){return new Dc(Object.assign(Object.assign({},this.settings),t),this.databaseId,this.N,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}Oc(t){var e;const n=null===(e=this.path)||void 0===e?void 0:e.child(t),r=this.$c({path:n,Fc:!1});return r.Mc(t),r}Lc(t){var e;const n=null===(e=this.path)||void 0===e?void 0:e.child(t),r=this.$c({path:n,Fc:!1});return r.xc(),r}Bc(t){return this.$c({path:void 0,Fc:!0})}Uc(t){return tu(t,this.settings.methodName,this.settings.qc||!1,this.path,this.settings.Kc)}contains(t){return void 0!==this.fieldMask.find(e=>t.isPrefixOf(e))||void 0!==this.fieldTransforms.find(e=>t.isPrefixOf(e.field))}xc(){if(this.path)for(let t=0;t<this.path.length;t++)this.Mc(this.path.get(t))}Mc(t){if(0===t.length)throw this.Uc("Document fields must not be empty");if(xc(this.kc)&&Nc.test(t))throw this.Uc('Document fields cannot begin and end with "__"')}}class Pc{constructor(t,e,n){this.databaseId=t,this.ignoreUndefinedProperties=e,this.N=n||Ns(t)}jc(t,e,n,r=!1){return new Dc({kc:t,methodName:e,Kc:n,path:K.emptyPath(),Fc:!1,qc:r},this.databaseId,this.N,this.ignoreUndefinedProperties)}}function Fc(t){const e=t._freezeSettings(),n=Ns(t._databaseId);return new Pc(t._databaseId,!!e.ignoreUndefinedProperties,n)}function Lc(t,e,n,r,i,s={}){const o=t.jc(s.merge||s.mergeFields?2:0,e,n,i);Qc("Data must be an object, but it was:",o,r);const a=Wc(r,o);let c,u;if(s.merge)c=new $(o.fieldMask),u=o.fieldTransforms;else if(s.mergeFields){const t=[];for(const r of s.mergeFields){const i=Jc(e,r,n);if(!o.contains(i))throw new E(I.INVALID_ARGUMENT,`Field '${i}' is specified in your field mask but missing from your input data.`);eu(t,i)||t.push(i)}c=new $(t),u=o.fieldTransforms.filter(t=>c.covers(t.field))}else c=null,u=o.fieldTransforms;return new Cc(new wt(a),c,u)}class Mc extends Ac{_toFieldTransform(t){if(2!==t.kc)throw 1===t.kc?t.Uc(this._methodName+"() can only appear at the top level of your update data"):t.Uc(this._methodName+"() cannot be used with set() unless you pass {merge:true}");return t.fieldMask.push(t.path),null}isEqual(t){return t instanceof Mc}}function Uc(t,e,n){return new Dc({kc:3,Kc:e.settings.Kc,methodName:t._methodName,Fc:n},e.databaseId,e.N,e.ignoreUndefinedProperties)}class Bc extends Ac{_toFieldTransform(t){return new Ee(t.path,new me)}isEqual(t){return t instanceof Bc}}class qc extends Ac{constructor(t,e){super(t),this.Qc=e}_toFieldTransform(t){const e=Uc(this,t,!0),n=this.Qc.map(t=>Gc(t,e)),r=new ge(n);return new Ee(t.path,r)}isEqual(t){return this===t}}class Vc extends Ac{constructor(t,e){super(t),this.Qc=e}_toFieldTransform(t){const e=Uc(this,t,!0),n=this.Qc.map(t=>Gc(t,e)),r=new be(n);return new Ee(t.path,r)}isEqual(t){return this===t}}class zc extends Ac{constructor(t,e){super(t),this.Wc=e}_toFieldTransform(t){const e=new we(t.N,le(t.N,this.Wc));return new Ee(t.path,e)}isEqual(t){return this===t}}function Hc(t,e,n,r){const i=t.jc(1,e,n);Qc("Data must be an object, but it was:",i,r);const s=[],a=wt.empty();B(r,(t,r)=>{const c=Zc(e,t,n);r=Object(o["k"])(r);const u=i.Lc(c);if(r instanceof Mc)s.push(c);else{const t=Gc(r,u);null!=t&&(s.push(c),a.set(c,t))}});const c=new $(s);return new Rc(a,c,i.fieldTransforms)}function Kc(t,e,n,r,i,s){const a=t.jc(1,e,n),c=[Jc(e,r,n)],u=[i];if(s.length%2!=0)throw new E(I.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let o=0;o<s.length;o+=2)c.push(Jc(e,s[o])),u.push(s[o+1]);const l=[],h=wt.empty();for(let f=c.length-1;f>=0;--f)if(!eu(l,c[f])){const t=c[f];let e=u[f];e=Object(o["k"])(e);const n=a.Lc(t);if(e instanceof Mc)l.push(t);else{const r=Gc(e,n);null!=r&&(l.push(t),h.set(t,r))}}const d=new $(l);return new Rc(h,d,a.fieldTransforms)}function $c(t,e,n,r=!1){return Gc(n,t.jc(r?4:3,e))}function Gc(t,e){if(Yc(t=Object(o["k"])(t)))return Qc("Unsupported field value:",e,t),Wc(t,e);if(t instanceof Ac)return function(t,e){if(!xc(e.kc))throw e.Uc(t._methodName+"() can only be used with update() and set()");if(!e.path)throw e.Uc(t._methodName+"() is not currently supported inside arrays");const n=t._toFieldTransform(e);n&&e.fieldTransforms.push(n)}(t,e),null;if(void 0===t&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),t instanceof Array){if(e.settings.Fc&&4!==e.kc)throw e.Uc("Nested arrays are not supported");return function(t,e){const n=[];let r=0;for(const i of t){let t=Gc(i,e.Bc(r));null==t&&(t={nullValue:"NULL_VALUE"}),n.push(t),r++}return{arrayValue:{values:n}}}(t,e)}return function(t,e){if(null===(t=Object(o["k"])(t)))return{nullValue:"NULL_VALUE"};if("number"==typeof t)return le(e.N,t);if("boolean"==typeof t)return{booleanValue:t};if("string"==typeof t)return{stringValue:t};if(t instanceof Date){const n=L.fromDate(t);return{timestampValue:wn(e.N,n)}}if(t instanceof L){const n=new L(t.seconds,1e3*Math.floor(t.nanoseconds/1e3));return{timestampValue:wn(e.N,n)}}if(t instanceof jc)return{geoPointValue:{latitude:t.latitude,longitude:t.longitude}};if(t instanceof Sc)return{bytesValue:_n(e.N,t._byteString)};if(t instanceof ec){const n=e.databaseId,r=t.firestore._databaseId;if(!r.isEqual(n))throw e.Uc(`Document reference is for database ${r.projectId}/${r.database} but should be for database ${n.projectId}/${n.database}`);return{referenceValue:On(t.firestore._databaseId||e.databaseId,t._key.path)}}throw e.Uc("Unsupported field value: "+Ya(t))}(t,e)}function Wc(t,e){const n={};return q(t)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):B(t,(t,r)=>{const i=Gc(r,e.Oc(t));null!=i&&(n[t]=i)}),{mapValue:{fields:n}}}function Yc(t){return!("object"!=typeof t||null===t||t instanceof Array||t instanceof Date||t instanceof L||t instanceof jc||t instanceof Sc||t instanceof ec||t instanceof Ac)}function Qc(t,e,n){if(!Yc(n)||!function(t){return"object"==typeof t&&null!==t&&(Object.getPrototypeOf(t)===Object.prototype||null===Object.getPrototypeOf(t))}(n)){const r=Ya(n);throw"an object"===r?e.Uc(t+" a custom object"):e.Uc(t+" "+r)}}function Jc(t,e,n){if((e=Object(o["k"])(e))instanceof kc)return e._internalPath;if("string"==typeof e)return Zc(t,e);throw tu("Field path arguments must be of type string or FieldPath.",t,!1,void 0,n)}const Xc=new RegExp("[~\\*/\\[\\]]");function Zc(t,e,n){if(e.search(Xc)>=0)throw tu(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,t,!1,void 0,n);try{return new kc(...e.split("."))._internalPath}catch(r){throw tu(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,t,!1,void 0,n)}}function tu(t,e,n,r,i){const s=r&&!r.isEmpty(),o=void 0!==i;let a=`Function ${e}() called with invalid data`;n&&(a+=" (via `toFirestore()`)"),a+=". ";let c="";return(s||o)&&(c+=" (found",s&&(c+=" in field "+r),o&&(c+=" in document "+i),c+=")"),new E(I.INVALID_ARGUMENT,a+t+c)}function eu(t,e){return t.some(t=>t.isEqual(e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nu{constructor(t,e,n,r,i){this._firestore=t,this._userDataWriter=e,this._key=n,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new ec(this._firestore,this._converter,this._key)}exists(){return null!==this._document}data(){if(this._document){if(this._converter){const t=new ru(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}get(t){if(this._document){const e=this._document.data.field(iu("DocumentSnapshot.get",t));if(null!==e)return this._userDataWriter.convertValue(e)}}}class ru extends nu{data(){return super.data()}}function iu(t,e){return"string"==typeof e?Zc(t,e):e instanceof kc?e._internalPath:e._delegate._internalPath}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class su{constructor(t,e){this.hasPendingWrites=t,this.fromCache=e}isEqual(t){return this.hasPendingWrites===t.hasPendingWrites&&this.fromCache===t.fromCache}}class ou extends nu{constructor(t,e,n,r,i,s){super(t,e,n,r,s),this._firestore=t,this._firestoreImpl=t,this.metadata=i}exists(){return super.exists()}data(t={}){if(this._document){if(this._converter){const e=new au(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(e,t)}return this._userDataWriter.convertValue(this._document.data.value,t.serverTimestamps)}}get(t,e={}){if(this._document){const n=this._document.data.field(iu("DocumentSnapshot.get",t));if(null!==n)return this._userDataWriter.convertValue(n,e.serverTimestamps)}}}class au extends ou{data(t={}){return super.data(t)}}class cu{constructor(t,e,n,r){this._firestore=t,this._userDataWriter=e,this._snapshot=r,this.metadata=new su(r.hasPendingWrites,r.fromCache),this.query=n}get docs(){const t=[];return this.forEach(e=>t.push(e)),t}get size(){return this._snapshot.docs.size}get empty(){return 0===this.size}forEach(t,e){this._snapshot.docs.forEach(n=>{t.call(e,new au(this._firestore,this._userDataWriter,n.key,n,new su(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))})}docChanges(t={}){const e=!!t.includeMetadataChanges;if(e&&this._snapshot.excludesMetadataChanges)throw new E(I.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===e||(this._cachedChanges=function(t,e){if(t._snapshot.oldDocs.isEmpty()){let e=0;return t._snapshot.docChanges.map(n=>({type:"added",doc:new au(t._firestore,t._userDataWriter,n.doc.key,n.doc,new su(t._snapshot.mutatedKeys.has(n.doc.key),t._snapshot.fromCache),t.query.converter),oldIndex:-1,newIndex:e++}))}{let n=t._snapshot.oldDocs;return t._snapshot.docChanges.filter(t=>e||3!==t.type).map(e=>{const r=new au(t._firestore,t._userDataWriter,e.doc.key,e.doc,new su(t._snapshot.mutatedKeys.has(e.doc.key),t._snapshot.fromCache),t.query.converter);let i=-1,s=-1;return 0!==e.type&&(i=n.indexOf(e.doc.key),n=n.delete(e.doc.key)),1!==e.type&&(n=n.add(e.doc),s=n.indexOf(e.doc.key)),{type:uu(e.type),doc:r,oldIndex:i,newIndex:s}})}}(this,e),this._cachedChangesIncludeMetadataChanges=e),this._cachedChanges}}function uu(t){switch(t){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return b()}}function lu(t,e){return t instanceof ou&&e instanceof ou?t._firestore===e._firestore&&t._key.isEqual(e._key)&&(null===t._document?null===e._document:t._document.isEqual(e._document))&&t._converter===e._converter:t instanceof cu&&e instanceof cu&&t._firestore===e._firestore&&cc(t.query,e.query)&&t.metadata.isEqual(e.metadata)&&t._snapshot.isEqual(e._snapshot)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hu(t){if(Yt(t)&&0===t.explicitOrderBy.length)throw new E(I.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class du{}function fu(t,...e){for(const n of e)t=n._apply(t);return t}class pu extends du{constructor(t,e,n){super(),this.Gc=t,this.zc=e,this.Hc=n,this.type="where"}_apply(t){const e=Fc(t.firestore),n=function(t,e,n,r,i,s,o){let a;if(i.isKeyField()){if("array-contains"===s||"array-contains-any"===s)throw new E(I.INVALID_ARGUMENT,`Invalid Query. You can't perform '${s}' queries on FieldPath.documentId().`);if("in"===s||"not-in"===s){ju(o,s);const e=[];for(const n of o)e.push(Au(r,t,n));a={arrayValue:{values:e}}}else a=Au(r,t,o)}else"in"!==s&&"not-in"!==s&&"array-contains-any"!==s||ju(o,s),a=$c(n,e,o,"in"===s||"not-in"===s);const c=jt.create(i,s,a);return function(t,e){if(e.v()){const n=Jt(t);if(null!==n&&!n.isEqual(e.field))throw new E(I.INVALID_ARGUMENT,`Invalid query. All where filters with an inequality (<, <=, !=, not-in, >, or >=) must be on the same field. But you have inequality filters on '${n.toString()}' and '${e.field.toString()}'`);const r=Qt(t);null!==r&&Nu(t,e.field,r)}const n=function(t,e){for(const n of t.filters)if(e.indexOf(n.op)>=0)return n.op;return null}(t,function(t){switch(t){case"!=":return["!=","not-in"];case"array-contains":return["array-contains","array-contains-any","not-in"];case"in":return["array-contains-any","in","not-in"];case"array-contains-any":return["array-contains","array-contains-any","in","not-in"];case"not-in":return["array-contains","array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(null!==n)throw n===e.op?new E(I.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new E(I.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${n.toString()}' filters.`)}(t,c),c}(t._query,"where",e,t.firestore._databaseId,this.Gc,this.zc,this.Hc);return new nc(t.firestore,t.converter,function(t,e){const n=t.filters.concat([e]);return new Kt(t.path,t.collectionGroup,t.explicitOrderBy.slice(),n,t.limit,t.limitType,t.startAt,t.endAt)}(t._query,n))}}function mu(t,e,n){const r=e,i=iu("where",t);return new pu(i,r,n)}class gu extends du{constructor(t,e){super(),this.Gc=t,this.Jc=e,this.type="orderBy"}_apply(t){const e=function(t,e,n){if(null!==t.startAt)throw new E(I.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(null!==t.endAt)throw new E(I.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");const r=new qt(e,n);return function(t,e){if(null===Qt(t)){const n=Jt(t);null!==n&&Nu(t,n,e.field)}}(t,r),r}(t._query,this.Gc,this.Jc);return new nc(t.firestore,t.converter,function(t,e){const n=t.explicitOrderBy.concat([e]);return new Kt(t.path,t.collectionGroup,n,t.filters.slice(),t.limit,t.limitType,t.startAt,t.endAt)}(t._query,e))}}function yu(t,e="asc"){const n=e,r=iu("orderBy",t);return new gu(r,n)}class bu extends du{constructor(t,e,n){super(),this.type=t,this.Yc=e,this.Xc=n}_apply(t){return new nc(t.firestore,t.converter,ee(t._query,this.Yc,this.Xc))}}function vu(t){return Ja("limit",t),new bu("limit",t,"F")}function wu(t){return Ja("limitToLast",t),new bu("limitToLast",t,"L")}class _u extends du{constructor(t,e,n){super(),this.type=t,this.Zc=e,this.ta=n}_apply(t){const e=Su(t,this.type,this.Zc,this.ta);return new nc(t.firestore,t.converter,function(t,e){return new Kt(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),t.limit,t.limitType,e,t.endAt)}(t._query,e))}}function Iu(...t){return new _u("startAt",t,!0)}function Eu(...t){return new _u("startAfter",t,!1)}class Ou extends du{constructor(t,e,n){super(),this.type=t,this.Zc=e,this.ta=n}_apply(t){const e=Su(t,this.type,this.Zc,this.ta);return new nc(t.firestore,t.converter,function(t,e){return new Kt(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),t.limit,t.limitType,t.startAt,e)}(t._query,e))}}function Tu(...t){return new Ou("endBefore",t,!0)}function ku(...t){return new Ou("endAt",t,!1)}function Su(t,e,n,r){if(n[0]=Object(o["k"])(n[0]),n[0]instanceof nu)return function(t,e,n,r,i){if(!r)throw new E(I.NOT_FOUND,`Can't use a DocumentSnapshot that doesn't exist for ${n}().`);const s=[];for(const o of Zt(t))if(o.field.isKeyField())s.push(ft(e,r.key));else{const t=r.data.field(o.field);if(Z(t))throw new E(I.INVALID_ARGUMENT,'Invalid query. You are trying to start or end a query using a document for which the field "'+o.field+'" is an uncommitted server timestamp. (Since the value of this field is unknown, you cannot start/end a query with it.)');if(null===t){const t=o.field.canonicalString();throw new E(I.INVALID_ARGUMENT,`Invalid query. You are trying to start or end a query using a document for which the field '${t}' (used as the orderBy) does not exist.`)}s.push(t)}return new Ut(s,i)}(t._query,t.firestore._databaseId,e,n[0]._document,r);{const i=Fc(t.firestore);return function(t,e,n,r,i,s){const o=t.explicitOrderBy;if(i.length>o.length)throw new E(I.INVALID_ARGUMENT,`Too many arguments provided to ${r}(). The number of arguments must be less than or equal to the number of orderBy() clauses`);const a=[];for(let c=0;c<i.length;c++){const s=i[c];if(o[c].field.isKeyField()){if("string"!=typeof s)throw new E(I.INVALID_ARGUMENT,`Invalid query. Expected a string for document ID in ${r}(), but got a ${typeof s}`);if(!Xt(t)&&-1!==s.indexOf("/"))throw new E(I.INVALID_ARGUMENT,`Invalid query. When querying a collection and ordering by FieldPath.documentId(), the value passed to ${r}() must be a plain document ID, but '${s}' contains a slash.`);const n=t.path.child(z.fromString(s));if(!st.isDocumentKey(n))throw new E(I.INVALID_ARGUMENT,`Invalid query. When querying a collection group and ordering by FieldPath.documentId(), the value passed to ${r}() must result in a valid document path, but '${n}' is not because it contains an odd number of segments.`);const i=new st(n);a.push(ft(e,i))}else{const t=$c(n,r,s);a.push(t)}}return new Ut(a,s)}(t._query,t.firestore._databaseId,i,e,n,r)}}function Au(t,e,n){if("string"==typeof(n=Object(o["k"])(n))){if(""===n)throw new E(I.INVALID_ARGUMENT,"Invalid query. When querying with FieldPath.documentId(), you must provide a valid document ID, but it was an empty string.");if(!Xt(e)&&-1!==n.indexOf("/"))throw new E(I.INVALID_ARGUMENT,`Invalid query. When querying a collection by FieldPath.documentId(), you must provide a plain document ID, but '${n}' contains a '/' character.`);const r=e.path.child(z.fromString(n));if(!st.isDocumentKey(r))throw new E(I.INVALID_ARGUMENT,`Invalid query. When querying a collection group by FieldPath.documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return ft(t,new st(r))}if(n instanceof ec)return ft(t,n._key);throw new E(I.INVALID_ARGUMENT,`Invalid query. When querying with FieldPath.documentId(), you must provide a valid string or a DocumentReference, but it was: ${Ya(n)}.`)}function ju(t,e){if(!Array.isArray(t)||0===t.length)throw new E(I.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`);if(t.length>10)throw new E(I.INVALID_ARGUMENT,`Invalid Query. '${e.toString()}' filters support a maximum of 10 elements in the value array.`)}function Nu(t,e,n){if(!n.isEqual(e))throw new E(I.INVALID_ARGUMENT,`Invalid query. You have a where filter with an inequality (<, <=, !=, not-in, >, or >=) on field '${e.toString()}' and so you must also use '${e.toString()}' as your first argument to orderBy(), but your first orderBy() is on field '${n.toString()}' instead.`)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cu{convertValue(t,e="none"){switch(ot(t)){case 0:return null;case 1:return t.booleanValue;case 2:return J(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(X(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 10:return this.convertObject(t.mapValue,e);default:throw b()}}convertObject(t,e){const n={};return B(t.fields,(t,r)=>{n[t]=this.convertValue(r,e)}),n}convertGeoPoint(t){return new jc(J(t.latitude),J(t.longitude))}convertArray(t,e){return(t.values||[]).map(t=>this.convertValue(t,e))}convertServerTimestamp(t,e){switch(e){case"previous":const n=tt(t);return null==n?null:this.convertValue(n,e);case"estimate":return this.convertTimestamp(et(t));default:return null}}convertTimestamp(t){const e=Q(t);return new L(e.seconds,e.nanos)}convertDocumentKey(t,e){const n=z.fromString(t);v(Zn(n));const r=new za(n.get(1),n.get(3)),i=new st(n.popFirst(5));return r.isEqual(e)||m(`Document ${i} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),i}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ru(t,e,n){let r;return r=t?n&&(n.merge||n.mergeFields)?t.toFirestore(e,n):t.toFirestore(e):e,r}class xu extends Cu{constructor(t){super(),this.firestore=t}convertBytes(t){return new Sc(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new ec(this.firestore,null,e)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Du{constructor(t,e){this._firestore=t,this._commitHandler=e,this._mutations=[],this._committed=!1,this._dataReader=Fc(t)}set(t,e,n){this._verifyNotCommitted();const r=Pu(t,this._firestore),i=Ru(r.converter,e,n),s=Lc(this._dataReader,"WriteBatch.set",r._key,i,null!==r.converter,n);return this._mutations.push(s.toMutation(r._key,ke.none())),this}update(t,e,n,...r){this._verifyNotCommitted();const i=Pu(t,this._firestore);let s;return s="string"==typeof(e=Object(o["k"])(e))||e instanceof kc?Kc(this._dataReader,"WriteBatch.update",i._key,e,n,r):Hc(this._dataReader,"WriteBatch.update",i._key,e),this._mutations.push(s.toMutation(i._key,ke.exists(!0))),this}delete(t){this._verifyNotCommitted();const e=Pu(t,this._firestore);return this._mutations=this._mutations.concat(new Ue(e._key,ke.none())),this}commit(){return this._verifyNotCommitted(),this._committed=!0,this._mutations.length>0?this._commitHandler(this._mutations):Promise.resolve()}_verifyNotCommitted(){if(this._committed)throw new E(I.FAILED_PRECONDITION,"A write batch can no longer be used after commit() has been called.")}}function Pu(t,e){if((t=Object(o["k"])(t)).firestore!==e)throw new E(I.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return t}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fu(t){t=Qa(t,ec);const e=Qa(t.firestore,fc);return Pa(pc(e),t._key).then(n=>Qu(e,t,n))}class Lu extends Cu{constructor(t){super(),this.firestore=t}convertBytes(t){return new Sc(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new ec(this.firestore,null,e)}}function Mu(t){t=Qa(t,ec);const e=Qa(t.firestore,fc),n=pc(e),r=new Lu(e);return Da(n,t._key).then(n=>new ou(e,r,t._key,n,new su(null!==n&&n.hasLocalMutations,!0),t.converter))}function Uu(t){t=Qa(t,ec);const e=Qa(t.firestore,fc);return Pa(pc(e),t._key,{source:"server"}).then(n=>Qu(e,t,n))}function Bu(t){t=Qa(t,nc);const e=Qa(t.firestore,fc),n=pc(e),r=new Lu(e);return hu(t._query),La(n,t._query).then(n=>new cu(e,r,t,n))}function qu(t){t=Qa(t,nc);const e=Qa(t.firestore,fc),n=pc(e),r=new Lu(e);return Fa(n,t._query).then(n=>new cu(e,r,t,n))}function Vu(t){t=Qa(t,nc);const e=Qa(t.firestore,fc),n=pc(e),r=new Lu(e);return La(n,t._query,{source:"server"}).then(n=>new cu(e,r,t,n))}function zu(t,e,n){t=Qa(t,ec);const r=Qa(t.firestore,fc),i=Ru(t.converter,e,n);return Yu(r,[Lc(Fc(r),"setDoc",t._key,i,null!==t.converter,n).toMutation(t._key,ke.none())])}function Hu(t,e,n,...r){t=Qa(t,ec);const i=Qa(t.firestore,fc),s=Fc(i);let a;return a="string"==typeof(e=Object(o["k"])(e))||e instanceof kc?Kc(s,"updateDoc",t._key,e,n,r):Hc(s,"updateDoc",t._key,e),Yu(i,[a.toMutation(t._key,ke.exists(!0))])}function Ku(t){return Yu(Qa(t.firestore,fc),[new Ue(t._key,ke.none())])}function $u(t,e){const n=Qa(t.firestore,fc),r=oc(t),i=Ru(t.converter,e);return Yu(n,[Lc(Fc(t.firestore),"addDoc",r._key,i,null!==t.converter,{}).toMutation(r._key,ke.exists(!1))]).then(()=>r)}function Gu(t,...e){var n,r,i;t=Object(o["k"])(t);let s={includeMetadataChanges:!1},a=0;"object"!=typeof e[a]||lc(e[a])||(s=e[a],a++);const c={includeMetadataChanges:s.includeMetadataChanges};if(lc(e[a])){const t=e[a];e[a]=null===(n=t.next)||void 0===n?void 0:n.bind(t),e[a+1]=null===(r=t.error)||void 0===r?void 0:r.bind(t),e[a+2]=null===(i=t.complete)||void 0===i?void 0:i.bind(t)}let u,l,h;if(t instanceof ec)l=Qa(t.firestore,fc),h=Gt(t._key.path),u={next:n=>{e[a]&&e[a](Qu(l,t,n))},error:e[a+1],complete:e[a+2]};else{const n=Qa(t,nc);l=Qa(n.firestore,fc),h=n._query;const r=new Lu(l);u={next:t=>{e[a]&&e[a](new cu(l,r,n,t))},error:e[a+1],complete:e[a+2]},hu(t._query)}return function(t,e,n,r){const i=new ba(r),s=new Oo(e,i,n);return t.asyncQueue.enqueueAndForget(async()=>vo(await Ca(t),s)),()=>{i.ec(),t.asyncQueue.enqueueAndForget(async()=>wo(await Ca(t),s))}}(pc(l),h,c,u)}function Wu(t,e){return Ma(pc(t=Qa(t,fc)),lc(e)?e:{next:e})}function Yu(t,e){return function(t,e){const n=new O;return t.asyncQueue.enqueueAndForget(async()=>Mo(await Na(t),e,n)),n.promise}(pc(t),e)}function Qu(t,e,n){const r=n.docs.get(e._key),i=new Lu(t);return new ou(t,i,e._key,r,new su(n.hasPendingWrites,n.fromCache),e.converter)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ju extends class{constructor(t,e){this._firestore=t,this._transaction=e,this._dataReader=Fc(t)}get(t){const e=Pu(t,this._firestore),n=new xu(this._firestore);return this._transaction.lookup([e._key]).then(t=>{if(!t||1!==t.length)return b();const r=t[0];if(r.isFoundDocument())return new nu(this._firestore,n,r.key,r,e.converter);if(r.isNoDocument())return new nu(this._firestore,n,e._key,null,e.converter);throw b()})}set(t,e,n){const r=Pu(t,this._firestore),i=Ru(r.converter,e,n),s=Lc(this._dataReader,"Transaction.set",r._key,i,null!==r.converter,n);return this._transaction.set(r._key,s),this}update(t,e,n,...r){const i=Pu(t,this._firestore);let s;return s="string"==typeof(e=Object(o["k"])(e))||e instanceof kc?Kc(this._dataReader,"Transaction.update",i._key,e,n,r):Hc(this._dataReader,"Transaction.update",i._key,e),this._transaction.update(i._key,s),this}delete(t){const e=Pu(t,this._firestore);return this._transaction.delete(e._key),this}}{constructor(t,e){super(t,e),this._firestore=t}get(t){const e=Pu(t,this._firestore),n=new Lu(this._firestore);return super.get(t).then(t=>new ou(this._firestore,n,e._key,t._document,new su(!1,!1),e.converter))}}function Xu(t,e){return Ua(pc(t=Qa(t,fc)),n=>e(new Ju(t,n)))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zu(){return new Mc("deleteField")}function tl(){return new Bc("serverTimestamp")}function el(...t){return new qc("arrayUnion",t)}function nl(...t){return new Vc("arrayRemove",t)}function rl(t){return new zc("increment",t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */!function(t,e=!0){!function(t){l=t}(r["SDK_VERSION"]),Object(r["_registerComponent"])(new i["a"]("firestore",(t,{options:n})=>{const r=t.getProvider("app").getImmediate(),i=new fc(r,new A(t.getProvider("auth-internal")));return n=Object.assign({useFetchStreams:e},n),i._setSettings(n),i},"PUBLIC")),Object(r["registerVersion"])(c,"3.3.1",t),Object(r["registerVersion"])(c,"3.3.1","esm2017")}()}).call(this,n("4362"))},"0a06":function(t,e,n){"use strict";var r=n("c532"),i=n("30b5"),s=n("f6b4"),o=n("5270"),a=n("4a7b"),c=n("848b"),u=c.validators;function l(t){this.defaults=t,this.interceptors={request:new s,response:new s}}l.prototype.request=function(t){"string"===typeof t?(t=arguments[1]||{},t.url=arguments[0]):t=t||{},t=a(this.defaults,t),t.method?t.method=t.method.toLowerCase():this.defaults.method?t.method=this.defaults.method.toLowerCase():t.method="get";var e=t.transitional;void 0!==e&&c.assertOptions(e,{silentJSONParsing:u.transitional(u.boolean),forcedJSONParsing:u.transitional(u.boolean),clarifyTimeoutError:u.transitional(u.boolean)},!1);var n=[],r=!0;this.interceptors.request.forEach((function(e){"function"===typeof e.runWhen&&!1===e.runWhen(t)||(r=r&&e.synchronous,n.unshift(e.fulfilled,e.rejected))}));var i,s=[];if(this.interceptors.response.forEach((function(t){s.push(t.fulfilled,t.rejected)})),!r){var l=[o,void 0];Array.prototype.unshift.apply(l,n),l=l.concat(s),i=Promise.resolve(t);while(l.length)i=i.then(l.shift(),l.shift());return i}var h=t;while(n.length){var d=n.shift(),f=n.shift();try{h=d(h)}catch(p){f(p);break}}try{i=o(h)}catch(p){return Promise.reject(p)}while(s.length)i=i.then(s.shift(),s.shift());return i},l.prototype.getUri=function(t){return t=a(this.defaults,t),i(t.url,t.params,t.paramsSerializer).replace(/^\?/,"")},r.forEach(["delete","get","head","options"],(function(t){l.prototype[t]=function(e,n){return this.request(a(n||{},{method:t,url:e,data:(n||{}).data}))}})),r.forEach(["post","put","patch"],(function(t){l.prototype[t]=function(e,n,r){return this.request(a(r||{},{method:t,url:e,data:n}))}})),t.exports=l},"0b64":function(t,e){function n(t){t=t||{},this.ms=t.min||100,this.max=t.max||1e4,this.factor=t.factor||2,this.jitter=t.jitter>0&&t.jitter<=1?t.jitter:0,this.attempts=0}t.exports=n,n.prototype.duration=function(){var t=this.ms*Math.pow(this.factor,this.attempts++);if(this.jitter){var e=Math.random(),n=Math.floor(e*this.jitter*t);t=0==(1&Math.floor(10*e))?t-n:t+n}return 0|Math.min(t,this.max)},n.prototype.reset=function(){this.attempts=0},n.prototype.setMin=function(t){this.ms=t},n.prototype.setMax=function(t){this.max=t},n.prototype.setJitter=function(t){this.jitter=t}},"0df6":function(t,e,n){"use strict";t.exports=function(t){return function(e){return t.apply(null,e)}}},"1d2b":function(t,e,n){"use strict";t.exports=function(t,e){return function(){for(var n=new Array(arguments.length),r=0;r<n.length;r++)n[r]=arguments[r];return t.apply(e,n)}}},"1f49":function(t,e,n){"use strict";(function(t){n.d(e,"a",(function(){return d}));var r=n("34ba"),i=n("4f2a"),s=n.n(i),o=n("0299"),a=n.n(o),c=n("af7f"),u=n("744a"),l=n("33e8");const h="undefined"!==typeof navigator&&"string"===typeof navigator.product&&"reactnative"===navigator.product.toLowerCase();class d extends r["a"]{constructor(t){super(t),this.supportsBinary=!t.forceBase64}get name(){return"websocket"}doOpen(){if(!this.check())return;const t=this.uri(),e=this.opts.protocols,n=h?{}:Object(c["b"])(this.opts,"agent","perMessageDeflate","pfx","key","passphrase","cert","ca","ciphers","rejectUnauthorized","localAddress","protocolVersion","origin","maxPayload","family","checkServerIdentity");this.opts.extraHeaders&&(n.headers=this.opts.extraHeaders);try{this.ws=u["d"]&&!h?e?new u["a"](t,e):new u["a"](t):new u["a"](t,e,n)}catch(r){return this.emit("error",r)}this.ws.binaryType=this.socket.binaryType||u["b"],this.addEventListeners()}addEventListeners(){this.ws.onopen=()=>{this.opts.autoUnref&&this.ws._socket.unref(),this.onOpen()},this.ws.onclose=this.onClose.bind(this),this.ws.onmessage=t=>this.onData(t.data),this.ws.onerror=t=>this.onError("websocket error",t)}write(e){this.writable=!1;for(let n=0;n<e.length;n++){const r=e[n],i=n===e.length-1;Object(l["c"])(r,this.supportsBinary,e=>{const n={};if(!u["d"]&&(r.options&&(n.compress=r.options.compress),this.opts.perMessageDeflate)){const r="string"===typeof e?t.byteLength(e):e.length;r<this.opts.perMessageDeflate.threshold&&(n.compress=!1)}try{u["d"]?this.ws.send(e):this.ws.send(e,n)}catch(s){}i&&Object(u["c"])(()=>{this.writable=!0,this.emit("drain")},this.setTimeoutFn)})}}doClose(){"undefined"!==typeof this.ws&&(this.ws.close(),this.ws=null)}uri(){let t=this.query||{};const e=this.opts.secure?"wss":"ws";let n="";this.opts.port&&("wss"===e&&443!==Number(this.opts.port)||"ws"===e&&80!==Number(this.opts.port))&&(n=":"+this.opts.port),this.opts.timestampRequests&&(t[this.opts.timestampParam]=a()()),this.supportsBinary||(t.b64=1);const r=s.a.encode(t),i=-1!==this.opts.hostname.indexOf(":");return e+"://"+(i?"["+this.opts.hostname+"]":this.opts.hostname)+n+this.opts.path+(r.length?"?"+r:"")}check(){return!!u["a"]&&!("__initialize"in u["a"]&&this.name===d.prototype.name)}}}).call(this,n("b639").Buffer)},"1f5a":function(t,e,n){"use strict";n.d(e,"a",(function(){return u})),n.d(e,"b",(function(){return Mt})),n.d(e,"c",(function(){return ue})),n.d(e,"d",(function(){return fe})),n.d(e,"e",(function(){return me})),n.d(e,"f",(function(){return pe})),n.d(e,"g",(function(){return Zt})),n.d(e,"h",(function(){return de})),n.d(e,"i",(function(){return Rr})),n.d(e,"j",(function(){return $i})),n.d(e,"k",(function(){return c})),n.d(e,"l",(function(){return Or})),n.d(e,"m",(function(){return ye})),n.d(e,"n",(function(){return ve})),n.d(e,"o",(function(){return we})),n.d(e,"p",(function(){return I})),n.d(e,"q",(function(){return Ct})),n.d(e,"r",(function(){return y})),n.d(e,"s",(function(){return Pn})),n.d(e,"t",(function(){return k})),n.d(e,"u",(function(){return si})),n.d(e,"v",(function(){return ft})),n.d(e,"x",(function(){return ze})),n.d(e,"y",(function(){return Nn})),n.d(e,"z",(function(){return zi})),n.d(e,"A",(function(){return Rn})),n.d(e,"B",(function(){return He})),n.d(e,"C",(function(){return Ve})),n.d(e,"D",(function(){return xt})),n.d(e,"F",(function(){return $e})),n.d(e,"G",(function(){return d})),n.d(e,"H",(function(){return Xe})),n.d(e,"I",(function(){return pn})),n.d(e,"J",(function(){return yn})),n.d(e,"K",(function(){return ii})),n.d(e,"L",(function(){return dt})),n.d(e,"M",(function(){return rr})),n.d(e,"N",(function(){return Ye})),n.d(e,"O",(function(){return De})),n.d(e,"P",(function(){return Ar})),n.d(e,"Q",(function(){return Vr})),n.d(e,"R",(function(){return ni})),n.d(e,"S",(function(){return En})),n.d(e,"T",(function(){return Pe})),n.d(e,"U",(function(){return jr})),n.d(e,"V",(function(){return qr})),n.d(e,"W",(function(){return ti})),n.d(e,"X",(function(){return Ze})),n.d(e,"Y",(function(){return qe})),n.d(e,"Z",(function(){return We})),n.d(e,"ab",(function(){return Oe})),n.d(e,"bb",(function(){return xe})),n.d(e,"cb",(function(){return Le})),n.d(e,"db",(function(){return Ge})),n.d(e,"eb",(function(){return Qe})),n.d(e,"fb",(function(){return Sr})),n.d(e,"gb",(function(){return Br})),n.d(e,"hb",(function(){return Xr})),n.d(e,"ib",(function(){return Ae})),n.d(e,"jb",(function(){return rn})),n.d(e,"kb",(function(){return sn})),n.d(e,"lb",(function(){return Cr})),n.d(e,"mb",(function(){return nn})),n.d(e,"nb",(function(){return tn})),n.d(e,"ob",(function(){return Ke})),n.d(e,"w",(function(){return Es})),n.d(e,"E",(function(){return _s}));var r=n("1fd5"),i=n("589b");function s(t,e){var n={};for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r]);if(null!=t&&"function"===typeof Object.getOwnPropertySymbols){var i=0;for(r=Object.getOwnPropertySymbols(t);i<r.length;i++)e.indexOf(r[i])<0&&Object.prototype.propertyIsEnumerable.call(t,r[i])&&(n[r[i]]=t[r[i]])}return n}Object.create;Object.create;var o=n("e691"),a=n("22e5");
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const c={FACEBOOK:"facebook.com",GITHUB:"github.com",GOOGLE:"google.com",PASSWORD:"password",PHONE:"phone",TWITTER:"twitter.com"},u={EMAIL_SIGNIN:"EMAIL_SIGNIN",PASSWORD_RESET:"PASSWORD_RESET",RECOVER_EMAIL:"RECOVER_EMAIL",REVERT_SECOND_FACTOR_ADDITION:"REVERT_SECOND_FACTOR_ADDITION",VERIFY_AND_CHANGE_EMAIL:"VERIFY_AND_CHANGE_EMAIL",VERIFY_EMAIL:"VERIFY_EMAIL"};
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function l(){return{["admin-restricted-operation"]:"This operation is restricted to administrators only.",["argument-error"]:"",["app-not-authorized"]:"This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",["app-not-installed"]:"The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",["captcha-check-failed"]:"The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",["code-expired"]:"The SMS code has expired. Please re-send the verification code to try again.",["cordova-not-ready"]:"Cordova framework is not ready.",["cors-unsupported"]:"This browser is not supported.",["credential-already-in-use"]:"This credential is already associated with a different user account.",["custom-token-mismatch"]:"The custom token corresponds to a different audience.",["requires-recent-login"]:"This operation is sensitive and requires recent authentication. Log in again before retrying this request.",["dependent-sdk-initialized-before-auth"]:"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK.",["dynamic-link-not-activated"]:"Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",["email-change-needs-verification"]:"Multi-factor users must always have a verified email.",["email-already-in-use"]:"The email address is already in use by another account.",["emulator-config-failed"]:'Auth instance has already been used to make a network call. Auth can no longer be configured to use the emulator. Try calling "connectAuthEmulator()" sooner.',["expired-action-code"]:"The action code has expired.",["cancelled-popup-request"]:"This operation has been cancelled due to another conflicting popup being opened.",["internal-error"]:"An internal AuthError has occurred.",["invalid-app-credential"]:"The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",["invalid-app-id"]:"The mobile app identifier is not registed for the current project.",["invalid-user-token"]:"This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",["invalid-auth-event"]:"An internal AuthError has occurred.",["invalid-verification-code"]:"The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure to use the verification code provided by the user.",["invalid-continue-uri"]:"The continue URL provided in the request is invalid.",["invalid-cordova-configuration"]:"The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",["invalid-custom-token"]:"The custom token format is incorrect. Please check the documentation.",["invalid-dynamic-link-domain"]:"The provided dynamic link domain is not configured or authorized for the current project.",["invalid-email"]:"The email address is badly formatted.",["invalid-emulator-scheme"]:"Emulator URL must start with a valid scheme (http:// or https://).",["invalid-api-key"]:"Your API key is invalid, please check you have copied it correctly.",["invalid-cert-hash"]:"The SHA-1 certificate hash provided is invalid.",["invalid-credential"]:"The supplied auth credential is malformed or has expired.",["invalid-message-payload"]:"The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",["invalid-multi-factor-session"]:"The request does not contain a valid proof of first factor successful sign-in.",["invalid-oauth-provider"]:"EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",["invalid-oauth-client-id"]:"The OAuth client ID provided is either invalid or does not match the specified API key.",["unauthorized-domain"]:"This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",["invalid-action-code"]:"The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",["wrong-password"]:"The password is invalid or the user does not have a password.",["invalid-persistence-type"]:"The specified persistence type is invalid. It can only be local, session or none.",["invalid-phone-number"]:"The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",["invalid-provider-id"]:"The specified provider ID is invalid.",["invalid-recipient-email"]:"The email corresponding to this action failed to send as the provided recipient email address is invalid.",["invalid-sender"]:"The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",["invalid-verification-id"]:"The verification ID used to create the phone auth credential is invalid.",["invalid-tenant-id"]:"The Auth instance's tenant ID is invalid.",["missing-android-pkg-name"]:"An Android Package Name must be provided if the Android App is required to be installed.",["auth-domain-config-required"]:"Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",["missing-app-credential"]:"The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",["missing-verification-code"]:"The phone auth credential was created with an empty SMS verification code.",["missing-continue-uri"]:"A continue URL must be provided in the request.",["missing-iframe-start"]:"An internal AuthError has occurred.",["missing-ios-bundle-id"]:"An iOS Bundle ID must be provided if an App Store ID is provided.",["missing-or-invalid-nonce"]:"The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",["missing-multi-factor-info"]:"No second factor identifier is provided.",["missing-multi-factor-session"]:"The request is missing proof of first factor successful sign-in.",["missing-phone-number"]:"To send verification codes, provide a phone number for the recipient.",["missing-verification-id"]:"The phone auth credential was created with an empty verification ID.",["app-deleted"]:"This instance of FirebaseApp has been deleted.",["multi-factor-info-not-found"]:"The user does not have a second factor matching the identifier provided.",["multi-factor-auth-required"]:"Proof of ownership of a second factor is required to complete sign-in.",["account-exists-with-different-credential"]:"An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.",["network-request-failed"]:"A network AuthError (such as timeout, interrupted connection or unreachable host) has occurred.",["no-auth-event"]:"An internal AuthError has occurred.",["no-such-provider"]:"User was not linked to an account with the given provider.",["null-user"]:"A null user object was provided as the argument for an operation which requires a non-null user object.",["operation-not-allowed"]:"The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",["operation-not-supported-in-this-environment"]:'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',["popup-blocked"]:"Unable to establish a connection with the popup. It may have been blocked by the browser.",["popup-closed-by-user"]:"The popup has been closed by the user before finalizing the operation.",["provider-already-linked"]:"User can only be linked to one identity for the given provider.",["quota-exceeded"]:"The project's quota for this operation has been exceeded.",["redirect-cancelled-by-user"]:"The redirect operation has been cancelled by the user before finalizing.",["redirect-operation-pending"]:"A redirect sign-in operation is already pending.",["rejected-credential"]:"The request contains malformed or mismatching credentials.",["second-factor-already-in-use"]:"The second factor is already enrolled on this account.",["maximum-second-factor-count-exceeded"]:"The maximum allowed number of second factors on a user has been exceeded.",["tenant-id-mismatch"]:"The provided tenant ID does not match the Auth instance's tenant ID",["timeout"]:"The operation has timed out.",["user-token-expired"]:"The user's credential is no longer valid. The user must sign in again.",["too-many-requests"]:"We have blocked all requests from this device due to unusual activity. Try again later.",["unauthorized-continue-uri"]:"The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",["unsupported-first-factor"]:"Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",["unsupported-persistence-type"]:"The current environment does not support the specified persistence type.",["unsupported-tenant-operation"]:"This operation is not supported in a multi-tenant context.",["unverified-email"]:"The operation requires a verified email.",["user-cancelled"]:"The user did not grant your application the permissions it requested.",["user-not-found"]:"There is no user record corresponding to this identifier. The user may have been deleted.",["user-disabled"]:"The user account has been disabled by an administrator.",["user-mismatch"]:"The supplied credentials do not correspond to the previously signed in user.",["user-signed-out"]:"",["weak-password"]:"The password must be 6 characters long or more.",["web-storage-unsupported"]:"This browser is not supported or 3rd party cookies and data may be disabled.",["already-initialized"]:"initializeAuth() has already been called with different options. To avoid this error, call initializeAuth() with the same options as when it was originally called, or call getAuth() to return the already initialized instance."}}function h(){return{["dependent-sdk-initialized-before-auth"]:"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const d=l,f=h,p=new r["b"]("auth","Firebase",h()),m=new o["b"]("@firebase/auth");function g(t,...e){m.logLevel<=o["a"].ERROR&&m.error(`Auth (${i["SDK_VERSION"]}): ${t}`,...e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function y(t,...e){throw _(t,...e)}function b(t,...e){return _(t,...e)}function v(t,e,n){const i=Object.assign(Object.assign({},f()),{[e]:n}),s=new r["b"]("auth","Firebase",i);return s.create(e,{appName:t.name})}function w(t,e,n){const r=n;if(!(e instanceof r))throw r.name!==e.constructor.name&&y(t,"argument-error"),v(t,"argument-error",`Type of ${e.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`)}function _(t,...e){if("string"!==typeof t){const n=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=t.name),t._errorFactory.create(n,...r)}return p.create(t,...e)}function I(t,e,...n){if(!t)throw _(e,...n)}function E(t){const e="INTERNAL ASSERTION FAILED: "+t;throw g(e),new Error(e)}function O(t,e){t||E(e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const T=new Map;function k(t){O(t instanceof Function,"Expected a class definition");let e=T.get(t);return e?(O(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,T.set(t,e),e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function S(t,e){const n=(null===e||void 0===e?void 0:e.persistence)||[],r=(Array.isArray(n)?n:[n]).map(k);(null===e||void 0===e?void 0:e.errorMap)&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(r,null===e||void 0===e?void 0:e.popupRedirectResolver)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function A(){var t;return"undefined"!==typeof self&&(null===(t=self.location)||void 0===t?void 0:t.href)||""}function j(){return"http:"===N()||"https:"===N()}function N(){var t;return"undefined"!==typeof self&&(null===(t=self.location)||void 0===t?void 0:t.protocol)||null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function C(){return!("undefined"!==typeof navigator&&navigator&&"onLine"in navigator&&"boolean"===typeof navigator.onLine&&(j()||Object(r["n"])()||"connection"in navigator))||navigator.onLine}function R(){if("undefined"===typeof navigator)return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x{constructor(t,e){this.shortDelay=t,this.longDelay=e,O(e>t,"Short delay should be less than long delay!"),this.isMobile=Object(r["s"])()||Object(r["u"])()}get(){return C()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function D(t,e){O(t.emulator,"Emulator should always be set here");const{url:n}=t.emulator;return e?`${n}${e.startsWith("/")?e.slice(1):e}`:n}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P{static initialize(t,e,n){this.fetchImpl=t,e&&(this.headersImpl=e),n&&(this.responseImpl=n)}static fetch(){return this.fetchImpl?this.fetchImpl:"undefined"!==typeof self&&"fetch"in self?self.fetch:void E("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){return this.headersImpl?this.headersImpl:"undefined"!==typeof self&&"Headers"in self?self.Headers:void E("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){return this.responseImpl?this.responseImpl:"undefined"!==typeof self&&"Response"in self?self.Response:void E("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F={["CREDENTIAL_MISMATCH"]:"custom-token-mismatch",["MISSING_CUSTOM_TOKEN"]:"internal-error",["INVALID_IDENTIFIER"]:"invalid-email",["MISSING_CONTINUE_URI"]:"internal-error",["INVALID_PASSWORD"]:"wrong-password",["MISSING_PASSWORD"]:"internal-error",["EMAIL_EXISTS"]:"email-already-in-use",["PASSWORD_LOGIN_DISABLED"]:"operation-not-allowed",["INVALID_IDP_RESPONSE"]:"invalid-credential",["INVALID_PENDING_TOKEN"]:"invalid-credential",["FEDERATED_USER_ID_ALREADY_LINKED"]:"credential-already-in-use",["MISSING_REQ_TYPE"]:"internal-error",["EMAIL_NOT_FOUND"]:"user-not-found",["RESET_PASSWORD_EXCEED_LIMIT"]:"too-many-requests",["EXPIRED_OOB_CODE"]:"expired-action-code",["INVALID_OOB_CODE"]:"invalid-action-code",["MISSING_OOB_CODE"]:"internal-error",["CREDENTIAL_TOO_OLD_LOGIN_AGAIN"]:"requires-recent-login",["INVALID_ID_TOKEN"]:"invalid-user-token",["TOKEN_EXPIRED"]:"user-token-expired",["USER_NOT_FOUND"]:"user-token-expired",["TOO_MANY_ATTEMPTS_TRY_LATER"]:"too-many-requests",["INVALID_CODE"]:"invalid-verification-code",["INVALID_SESSION_INFO"]:"invalid-verification-id",["INVALID_TEMPORARY_PROOF"]:"invalid-credential",["MISSING_SESSION_INFO"]:"missing-verification-id",["SESSION_EXPIRED"]:"code-expired",["MISSING_ANDROID_PACKAGE_NAME"]:"missing-android-pkg-name",["UNAUTHORIZED_DOMAIN"]:"unauthorized-continue-uri",["INVALID_OAUTH_CLIENT_ID"]:"invalid-oauth-client-id",["ADMIN_ONLY_OPERATION"]:"admin-restricted-operation",["INVALID_MFA_PENDING_CREDENTIAL"]:"invalid-multi-factor-session",["MFA_ENROLLMENT_NOT_FOUND"]:"multi-factor-info-not-found",["MISSING_MFA_ENROLLMENT_ID"]:"missing-multi-factor-info",["MISSING_MFA_PENDING_CREDENTIAL"]:"missing-multi-factor-session",["SECOND_FACTOR_EXISTS"]:"second-factor-already-in-use",["SECOND_FACTOR_LIMIT_EXCEEDED"]:"maximum-second-factor-count-exceeded",["BLOCKING_FUNCTION_ERROR_RESPONSE"]:"internal-error"},L=new x(3e4,6e4);
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M(t,e){return t.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:t.tenantId}):e}async function U(t,e,n,i,s={}){return B(t,s,()=>{let s={},o={};i&&("GET"===e?o=i:s={body:JSON.stringify(i)});const a=Object(r["x"])(Object.assign({key:t.config.apiKey},o)).slice(1),c=new(P.headers());return c.set("Content-Type","application/json"),c.set("X-Client-Version",t._getSdkClientVersion()),t.languageCode&&c.set("X-Firebase-Locale",t.languageCode),P.fetch()(V(t,t.config.apiHost,n,a),Object.assign({method:e,headers:c,referrerPolicy:"no-referrer"},s))})}async function B(t,e,n){t._canInitEmulator=!1;const i=Object.assign(Object.assign({},F),e);try{const e=new z(t),r=await Promise.race([n(),e.promise]);e.clearNetworkTimeout();const s=await r.json();if("needConfirmation"in s)throw H(t,"account-exists-with-different-credential",s);if(r.ok&&!("errorMessage"in s))return s;{const e=r.ok?s.errorMessage:s.error.message,[n,o]=e.split(" : ");if("FEDERATED_USER_ID_ALREADY_LINKED"===n)throw H(t,"credential-already-in-use",s);if("EMAIL_EXISTS"===n)throw H(t,"email-already-in-use",s);const a=i[n]||n.toLowerCase().replace(/[_\s]+/g,"-");if(o)throw v(t,a,o);y(t,a)}}catch(s){if(s instanceof r["c"])throw s;y(t,"network-request-failed")}}async function q(t,e,n,r,i={}){const s=await U(t,e,n,r,i);return"mfaPendingCredential"in s&&y(t,"multi-factor-auth-required",{_serverResponse:s}),s}function V(t,e,n,r){const i=`${e}${n}?${r}`;return t.config.emulator?D(t.config,i):`${t.config.apiScheme}://${i}`}class z{constructor(t){this.auth=t,this.timer=null,this.promise=new Promise((t,e)=>{this.timer=setTimeout(()=>e(b(this.auth,"timeout")),L.get())})}clearNetworkTimeout(){clearTimeout(this.timer)}}function H(t,e,n){const r={appName:t.name};n.email&&(r.email=n.email),n.phoneNumber&&(r.phoneNumber=n.phoneNumber);const i=b(t,e,r);return i.customData._tokenResponse=n,i}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function K(t,e){return U(t,"POST","/v1/accounts:delete",e)}async function $(t,e){return U(t,"POST","/v1/accounts:update",e)}async function G(t,e){return U(t,"POST","/v1/accounts:lookup",e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch(e){}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Y(t,e=!1){const n=Object(r["k"])(t),i=await n.getIdToken(e),s=J(i);I(s&&s.exp&&s.auth_time&&s.iat,n.auth,"internal-error");const o="object"===typeof s.firebase?s.firebase:void 0,a=null===o||void 0===o?void 0:o["sign_in_provider"];return{claims:s,token:i,authTime:W(Q(s.auth_time)),issuedAtTime:W(Q(s.iat)),expirationTime:W(Q(s.exp)),signInProvider:a||null,signInSecondFactor:(null===o||void 0===o?void 0:o["sign_in_second_factor"])||null}}function Q(t){return 1e3*Number(t)}function J(t){const[e,n,i]=t.split(".");if(void 0===e||void 0===n||void 0===i)return g("JWT malformed, contained fewer than 3 sections"),null;try{const t=Object(r["d"])(n);return t?JSON.parse(t):(g("Failed to decode base64 JWT payload"),null)}catch(s){return g("Caught error parsing JWT payload as JSON",s),null}}function X(t){const e=J(t);return I(e,"internal-error"),I("undefined"!==typeof e.exp,"internal-error"),I("undefined"!==typeof e.iat,"internal-error"),Number(e.exp)-Number(e.iat)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Z(t,e,n=!1){if(n)return e;try{return await e}catch(i){throw i instanceof r["c"]&&tt(i)&&t.auth.currentUser===t&&await t.auth.signOut(),i}}function tt({code:t}){return"auth/user-disabled"===t||"auth/user-token-expired"===t}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class et{constructor(t){this.user=t,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,null!==this.timerId&&clearTimeout(this.timerId))}getInterval(t){var e;if(t){const t=this.errorBackoff;return this.errorBackoff=Math.min(2*this.errorBackoff,96e4),t}{this.errorBackoff=3e4;const t=null!==(e=this.user.stsTokenManager.expirationTime)&&void 0!==e?e:0,n=t-Date.now()-3e5;return Math.max(0,n)}}schedule(t=!1){if(!this.isRunning)return;const e=this.getInterval(t);this.timerId=setTimeout(async()=>{await this.iteration()},e)}async iteration(){try{await this.user.getIdToken(!0)}catch(t){return void("auth/network-request-failed"===t.code&&this.schedule(!0))}this.schedule()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nt{constructor(t,e){this.createdAt=t,this.lastLoginAt=e,this._initializeTime()}_initializeTime(){this.lastSignInTime=W(this.lastLoginAt),this.creationTime=W(this.createdAt)}_copy(t){this.createdAt=t.createdAt,this.lastLoginAt=t.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rt(t){var e;const n=t.auth,r=await t.getIdToken(),i=await Z(t,G(n,{idToken:r}));I(null===i||void 0===i?void 0:i.users.length,n,"internal-error");const s=i.users[0];t._notifyReloadListener(s);const o=(null===(e=s.providerUserInfo)||void 0===e?void 0:e.length)?ot(s.providerUserInfo):[],a=st(t.providerData,o),c=t.isAnonymous,u=!(t.email&&s.passwordHash)&&!(null===a||void 0===a?void 0:a.length),l=!!c&&u,h={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:a,metadata:new nt(s.createdAt,s.lastLoginAt),isAnonymous:l};Object.assign(t,h)}async function it(t){const e=Object(r["k"])(t);await rt(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function st(t,e){const n=t.filter(t=>!e.some(e=>e.providerId===t.providerId));return[...n,...e]}function ot(t){return t.map(t=>{var{providerId:e}=t,n=s(t,["providerId"]);return{providerId:e,uid:n.rawId||"",displayName:n.displayName||null,email:n.email||null,phoneNumber:n.phoneNumber||null,photoURL:n.photoUrl||null}})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function at(t,e){const n=await B(t,{},()=>{const n=Object(r["x"])({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:s}=t.config,o=V(t,i,"/v1/token","key="+s);return P.fetch()(o,{method:"POST",headers:{"X-Client-Version":t._getSdkClientVersion(),"Content-Type":"application/x-www-form-urlencoded"},body:n})});return{accessToken:n.access_token,expiresIn:n.expires_in,refreshToken:n.refresh_token}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ct{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(t){I(t.idToken,"internal-error"),I("undefined"!==typeof t.idToken,"internal-error"),I("undefined"!==typeof t.refreshToken,"internal-error");const e="expiresIn"in t&&"undefined"!==typeof t.expiresIn?Number(t.expiresIn):X(t.idToken);this.updateTokensAndExpiration(t.idToken,t.refreshToken,e)}async getToken(t,e=!1){return I(!this.accessToken||this.refreshToken,t,"user-token-expired"),e||!this.accessToken||this.isExpired?this.refreshToken?(await this.refresh(t,this.refreshToken),this.accessToken):null:this.accessToken}clearRefreshToken(){this.refreshToken=null}async refresh(t,e){const{accessToken:n,refreshToken:r,expiresIn:i}=await at(t,e);this.updateTokensAndExpiration(n,r,Number(i))}updateTokensAndExpiration(t,e,n){this.refreshToken=e||null,this.accessToken=t||null,this.expirationTime=Date.now()+1e3*n}static fromJSON(t,e){const{refreshToken:n,accessToken:r,expirationTime:i}=e,s=new ct;return n&&(I("string"===typeof n,"internal-error",{appName:t}),s.refreshToken=n),r&&(I("string"===typeof r,"internal-error",{appName:t}),s.accessToken=r),i&&(I("number"===typeof i,"internal-error",{appName:t}),s.expirationTime=i),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(t){this.accessToken=t.accessToken,this.refreshToken=t.refreshToken,this.expirationTime=t.expirationTime}_clone(){return Object.assign(new ct,this.toJSON())}_performRefresh(){return E("not implemented")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ut(t,e){I("string"===typeof t||"undefined"===typeof t,"internal-error",{appName:e})}class lt{constructor(t){var{uid:e,auth:n,stsTokenManager:r}=t,i=s(t,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.emailVerified=!1,this.isAnonymous=!1,this.tenantId=null,this.providerData=[],this.proactiveRefresh=new et(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=n,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.metadata=new nt(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(t){const e=await Z(this,this.stsTokenManager.getToken(this.auth,t));return I(e,this.auth,"internal-error"),this.accessToken!==e&&(this.accessToken=e,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),e}getIdTokenResult(t){return Y(this,t)}reload(){return it(this)}_assign(t){this!==t&&(I(this.uid===t.uid,this.auth,"internal-error"),this.displayName=t.displayName,this.photoURL=t.photoURL,this.email=t.email,this.emailVerified=t.emailVerified,this.phoneNumber=t.phoneNumber,this.isAnonymous=t.isAnonymous,this.tenantId=t.tenantId,this.providerData=t.providerData.map(t=>Object.assign({},t)),this.metadata._copy(t.metadata),this.stsTokenManager._assign(t.stsTokenManager))}_clone(t){return new lt(Object.assign(Object.assign({},this),{auth:t,stsTokenManager:this.stsTokenManager._clone()}))}_onReload(t){I(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=t,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(t){this.reloadListener?this.reloadListener(t):this.reloadUserInfo=t}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(t,e=!1){let n=!1;t.idToken&&t.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(t),n=!0),e&&await rt(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){const t=await this.getIdToken();return await Z(this,K(this.auth,{idToken:t})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(t=>Object.assign({},t)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(t,e){var n,r,i,s,o,a,c,u;const l=null!==(n=e.displayName)&&void 0!==n?n:void 0,h=null!==(r=e.email)&&void 0!==r?r:void 0,d=null!==(i=e.phoneNumber)&&void 0!==i?i:void 0,f=null!==(s=e.photoURL)&&void 0!==s?s:void 0,p=null!==(o=e.tenantId)&&void 0!==o?o:void 0,m=null!==(a=e._redirectEventId)&&void 0!==a?a:void 0,g=null!==(c=e.createdAt)&&void 0!==c?c:void 0,y=null!==(u=e.lastLoginAt)&&void 0!==u?u:void 0,{uid:b,emailVerified:v,isAnonymous:w,providerData:_,stsTokenManager:E}=e;I(b&&E,t,"internal-error");const O=ct.fromJSON(this.name,E);I("string"===typeof b,t,"internal-error"),ut(l,t.name),ut(h,t.name),I("boolean"===typeof v,t,"internal-error"),I("boolean"===typeof w,t,"internal-error"),ut(d,t.name),ut(f,t.name),ut(p,t.name),ut(m,t.name),ut(g,t.name),ut(y,t.name);const T=new lt({uid:b,auth:t,email:h,emailVerified:v,displayName:l,isAnonymous:w,photoURL:f,phoneNumber:d,tenantId:p,stsTokenManager:O,createdAt:g,lastLoginAt:y});return _&&Array.isArray(_)&&(T.providerData=_.map(t=>Object.assign({},t))),m&&(T._redirectEventId=m),T}static async _fromIdTokenResponse(t,e,n=!1){const r=new ct;r.updateFromServerResponse(e);const i=new lt({uid:e.localId,auth:t,stsTokenManager:r,isAnonymous:n});return await rt(i),i}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(t,e){this.storage[t]=e}async _get(t){const e=this.storage[t];return void 0===e?null:e}async _remove(t){delete this.storage[t]}_addListener(t,e){}_removeListener(t,e){}}ht.type="NONE";const dt=ht;
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ft(t,e,n){return`firebase:${t}:${e}:${n}`}class pt{constructor(t,e,n){this.persistence=t,this.auth=e,this.userKey=n;const{config:r,name:i}=this.auth;this.fullUserKey=ft(this.userKey,r.apiKey,i),this.fullPersistenceKey=ft("persistence",r.apiKey,i),this.boundEventHandler=e._onStorageEvent.bind(e),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(t){return this.persistence._set(this.fullUserKey,t.toJSON())}async getCurrentUser(){const t=await this.persistence._get(this.fullUserKey);return t?lt._fromJSON(this.auth,t):null}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(t){if(this.persistence===t)return;const e=await this.getCurrentUser();return await this.removeCurrentUser(),this.persistence=t,e?this.setCurrentUser(e):void 0}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(t,e,n="authUser"){if(!e.length)return new pt(k(dt),t,n);const r=(await Promise.all(e.map(async t=>{if(await t._isAvailable())return t}))).filter(t=>t);let i=r[0]||k(dt);const s=ft(n,t.config.apiKey,t.name);let o=null;for(const u of e)try{const e=await u._get(s);if(e){const n=lt._fromJSON(t,e);u!==i&&(o=n),i=u;break}}catch(c){}const a=r.filter(t=>t._shouldAllowMigration);return i._shouldAllowMigration&&a.length?(i=a[0],o&&await i._set(s,o.toJSON()),await Promise.all(e.map(async t=>{if(t!==i)try{await t._remove(s)}catch(c){}})),new pt(i,t,n)):new pt(i,t,n)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mt(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(vt(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(gt(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(_t(e))return"Blackberry";if(It(e))return"Webos";if(yt(e))return"Safari";if((e.includes("chrome/")||bt(e))&&!e.includes("edge/"))return"Chrome";if(wt(e))return"Android";{const e=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,n=t.match(e);if(2===(null===n||void 0===n?void 0:n.length))return n[1]}return"Other"}function gt(t=Object(r["l"])()){return/firefox\//i.test(t)}function yt(t=Object(r["l"])()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function bt(t=Object(r["l"])()){return/crios\//i.test(t)}function vt(t=Object(r["l"])()){return/iemobile/i.test(t)}function wt(t=Object(r["l"])()){return/android/i.test(t)}function _t(t=Object(r["l"])()){return/blackberry/i.test(t)}function It(t=Object(r["l"])()){return/webos/i.test(t)}function Et(t=Object(r["l"])()){return/iphone|ipad|ipod/i.test(t)}function Ot(t=Object(r["l"])()){return/(iPad|iPhone|iPod).*OS 7_\d/i.test(t)||/(iPad|iPhone|iPod).*OS 8_\d/i.test(t)}function Tt(t=Object(r["l"])()){var e;return Et(t)&&!!(null===(e=window.navigator)||void 0===e?void 0:e.standalone)}function kt(){return Object(r["q"])()&&10===document.documentMode}function St(t=Object(r["l"])()){return Et(t)||wt(t)||It(t)||_t(t)||/windows phone/i.test(t)||vt(t)}function At(){try{return!(!window||window===window.top)}catch(t){return!1}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jt(t,e=[]){let n;switch(t){case"Browser":n=mt(Object(r["l"])());break;case"Worker":n=`${mt(Object(r["l"])())}-${t}`;break;default:n=t}const s=e.length?e.join(","):"FirebaseCore-web";return`${n}/JsCore/${i["SDK_VERSION"]}/${s}`}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nt{constructor(t,e){this.app=t,this.config=e,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Rt(this),this.idTokenSubscription=new Rt(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=p,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=t.name,this.clientVersion=e.sdkClientVersion}_initializeWithPersistence(t,e){return e&&(this._popupRedirectResolver=k(e)),this._initializationPromise=this.queue(async()=>{var n,r;this._deleted||(this.persistenceManager=await pt.create(this,t),this._deleted||((null===(n=this._popupRedirectResolver)||void 0===n?void 0:n._shouldInitProactively)&&await this._popupRedirectResolver._initialize(this),await this.initializeCurrentUser(e),this.lastNotifiedUid=(null===(r=this.currentUser)||void 0===r?void 0:r.uid)||null,this._deleted||(this._isInitialized=!0)))}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const t=await this.assertedPersistence.getCurrentUser();return this.currentUser||t?this.currentUser&&t&&this.currentUser.uid===t.uid?(this._currentUser._assign(t),void await this.currentUser.getIdToken()):void await this._updateCurrentUser(t):void 0}async initializeCurrentUser(t){var e;let n=await this.assertedPersistence.getCurrentUser();if(t&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const r=null===(e=this.redirectUser)||void 0===e?void 0:e._redirectEventId,i=null===n||void 0===n?void 0:n._redirectEventId,s=await this.tryRedirectSignIn(t);r&&r!==i||!(null===s||void 0===s?void 0:s.user)||(n=s.user)}return n?n._redirectEventId?(I(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===n._redirectEventId?this.directlySetCurrentUser(n):this.reloadAndSetCurrentUserOrClear(n)):this.reloadAndSetCurrentUserOrClear(n):this.directlySetCurrentUser(null)}async tryRedirectSignIn(t){let e=null;try{e=await this._popupRedirectResolver._completeRedirectFn(this,t,!0)}catch(n){await this._setRedirectUser(null)}return e}async reloadAndSetCurrentUserOrClear(t){try{await rt(t)}catch(e){if("auth/network-request-failed"!==e.code)return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(t)}useDeviceLanguage(){this.languageCode=R()}async _delete(){this._deleted=!0}async updateCurrentUser(t){const e=t?Object(r["k"])(t):null;return e&&I(e.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(e&&e._clone(this))}async _updateCurrentUser(t){if(!this._deleted)return t&&I(this.tenantId===t.tenantId,this,"tenant-id-mismatch"),this.queue(async()=>{await this.directlySetCurrentUser(t),this.notifyAuthListeners()})}async signOut(){return(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null)}setPersistence(t){return this.queue(async()=>{await this.assertedPersistence.setPersistence(k(t))})}_getPersistence(){return this.assertedPersistence.persistence.type}_updateErrorMap(t){this._errorFactory=new r["b"]("auth","Firebase",t())}onAuthStateChanged(t,e,n){return this.registerStateListener(this.authStateSubscription,t,e,n)}onIdTokenChanged(t,e,n){return this.registerStateListener(this.idTokenSubscription,t,e,n)}toJSON(){var t;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:null===(t=this._currentUser)||void 0===t?void 0:t.toJSON()}}async _setRedirectUser(t,e){const n=await this.getOrInitRedirectPersistenceManager(e);return null===t?n.removeCurrentUser():n.setCurrentUser(t)}async getOrInitRedirectPersistenceManager(t){if(!this.redirectPersistenceManager){const e=t&&k(t)||this._popupRedirectResolver;I(e,this,"argument-error"),this.redirectPersistenceManager=await pt.create(this,[k(e._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(t){var e,n;return this._isInitialized&&await this.queue(async()=>{}),(null===(e=this._currentUser)||void 0===e?void 0:e._redirectEventId)===t?this._currentUser:(null===(n=this.redirectUser)||void 0===n?void 0:n._redirectEventId)===t?this.redirectUser:null}async _persistUserIfCurrent(t){if(t===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(t))}_notifyListenersIfCurrent(t){t===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t,e;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const n=null!==(e=null===(t=this.currentUser)||void 0===t?void 0:t.uid)&&void 0!==e?e:null;this.lastNotifiedUid!==n&&(this.lastNotifiedUid=n,this.authStateSubscription.next(this.currentUser))}registerStateListener(t,e,n,r){if(this._deleted)return()=>{};const i="function"===typeof e?e:e.next.bind(e),s=this._isInitialized?Promise.resolve():this._initializationPromise;return I(s,this,"internal-error"),s.then(()=>i(this.currentUser)),"function"===typeof e?t.addObserver(e,n,r):t.addObserver(e)}async directlySetCurrentUser(t){this.currentUser&&this.currentUser!==t&&(this._currentUser._stopProactiveRefresh(),t&&this.isProactiveRefreshEnabled&&t._startProactiveRefresh()),this.currentUser=t,t?await this.assertedPersistence.setCurrentUser(t):await this.assertedPersistence.removeCurrentUser()}queue(t){return this.operations=this.operations.then(t,t),this.operations}get assertedPersistence(){return I(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(t){t&&!this.frameworks.includes(t)&&(this.frameworks.push(t),this.frameworks.sort(),this.clientVersion=jt(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}_getSdkClientVersion(){return this.clientVersion}}function Ct(t){return Object(r["k"])(t)}class Rt{constructor(t){this.auth=t,this.observer=null,this.addObserver=Object(r["g"])(t=>this.observer=t)}get next(){return I(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}function xt(t,e,n){const r=Ct(t);I(r._canInitEmulator,r,"emulator-config-failed"),I(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const i=!!(null===n||void 0===n?void 0:n.disableWarnings),s=Dt(e),{host:o,port:a}=Pt(e),c=null===a?"":":"+a;r.config.emulator={url:`${s}//${o}${c}/`},r.settings.appVerificationDisabledForTesting=!0,r.emulatorConfig=Object.freeze({host:o,port:a,protocol:s.replace(":",""),options:Object.freeze({disableWarnings:i})}),i||Lt()}function Dt(t){const e=t.indexOf(":");return e<0?"":t.substr(0,e+1)}function Pt(t){const e=Dt(t),n=/(\/\/)?([^?#/]+)/.exec(t.substr(e.length));if(!n)return{host:"",port:null};const r=n[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const t=i[1];return{host:t,port:Ft(r.substr(t.length+1))}}{const[t,e]=r.split(":");return{host:t,port:Ft(e)}}}function Ft(t){if(!t)return null;const e=Number(t);return isNaN(e)?null:e}function Lt(){function t(){const t=document.createElement("p"),e=t.style;t.innerText="Running in emulator mode. Do not use with production credentials.",e.position="fixed",e.width="100%",e.backgroundColor="#ffffff",e.border=".1em solid #000000",e.color="#b50000",e.bottom="0px",e.left="0px",e.margin="0px",e.zIndex="10000",e.textAlign="center",t.classList.add("firebase-emulator-warning"),document.body.appendChild(t)}"undefined"!==typeof console&&"function"===typeof console.info&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),"undefined"!==typeof window&&"undefined"!==typeof document&&("loading"===document.readyState?window.addEventListener("DOMContentLoaded",t):t())}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mt{constructor(t,e){this.providerId=t,this.signInMethod=e}toJSON(){return E("not implemented")}_getIdTokenResponse(t){return E("not implemented")}_linkToIdToken(t,e){return E("not implemented")}_getReauthenticationResolver(t){return E("not implemented")}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ut(t,e){return U(t,"POST","/v1/accounts:resetPassword",M(t,e))}async function Bt(t,e){return U(t,"POST","/v1/accounts:update",e)}async function qt(t,e){return U(t,"POST","/v1/accounts:update",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vt(t,e){return q(t,"POST","/v1/accounts:signInWithPassword",M(t,e))}async function zt(t,e){return U(t,"POST","/v1/accounts:sendOobCode",M(t,e))}async function Ht(t,e){return zt(t,e)}async function Kt(t,e){return zt(t,e)}async function $t(t,e){return zt(t,e)}async function Gt(t,e){return zt(t,e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Wt(t,e){return q(t,"POST","/v1/accounts:signInWithEmailLink",M(t,e))}async function Yt(t,e){return q(t,"POST","/v1/accounts:signInWithEmailLink",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qt extends Mt{constructor(t,e,n,r=null){super("password",n),this._email=t,this._password=e,this._tenantId=r}static _fromEmailAndPassword(t,e){return new Qt(t,e,"password")}static _fromEmailAndCode(t,e,n=null){return new Qt(t,e,"emailLink",n)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(t){const e="string"===typeof t?JSON.parse(t):t;if((null===e||void 0===e?void 0:e.email)&&(null===e||void 0===e?void 0:e.password)){if("password"===e.signInMethod)return this._fromEmailAndPassword(e.email,e.password);if("emailLink"===e.signInMethod)return this._fromEmailAndCode(e.email,e.password,e.tenantId)}return null}async _getIdTokenResponse(t){switch(this.signInMethod){case"password":return Vt(t,{returnSecureToken:!0,email:this._email,password:this._password});case"emailLink":return Wt(t,{email:this._email,oobCode:this._password});default:y(t,"internal-error")}}async _linkToIdToken(t,e){switch(this.signInMethod){case"password":return Bt(t,{idToken:e,returnSecureToken:!0,email:this._email,password:this._password});case"emailLink":return Yt(t,{idToken:e,email:this._email,oobCode:this._password});default:y(t,"internal-error")}}_getReauthenticationResolver(t){return this._getIdTokenResponse(t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Jt(t,e){return q(t,"POST","/v1/accounts:signInWithIdp",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xt="http://localhost";class Zt extends Mt{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(t){const e=new Zt(t.providerId,t.signInMethod);return t.idToken||t.accessToken?(t.idToken&&(e.idToken=t.idToken),t.accessToken&&(e.accessToken=t.accessToken),t.nonce&&!t.pendingToken&&(e.nonce=t.nonce),t.pendingToken&&(e.pendingToken=t.pendingToken)):t.oauthToken&&t.oauthTokenSecret?(e.accessToken=t.oauthToken,e.secret=t.oauthTokenSecret):y("argument-error"),e}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(t){const e="string"===typeof t?JSON.parse(t):t,{providerId:n,signInMethod:r}=e,i=s(e,["providerId","signInMethod"]);if(!n||!r)return null;const o=new Zt(n,r);return o.idToken=i.idToken||void 0,o.accessToken=i.accessToken||void 0,o.secret=i.secret,o.nonce=i.nonce,o.pendingToken=i.pendingToken||null,o}_getIdTokenResponse(t){const e=this.buildRequest();return Jt(t,e)}_linkToIdToken(t,e){const n=this.buildRequest();return n.idToken=e,Jt(t,n)}_getReauthenticationResolver(t){const e=this.buildRequest();return e.autoCreate=!1,Jt(t,e)}buildRequest(){const t={requestUri:Xt,returnSecureToken:!0};if(this.pendingToken)t.pendingToken=this.pendingToken;else{const e={};this.idToken&&(e["id_token"]=this.idToken),this.accessToken&&(e["access_token"]=this.accessToken),this.secret&&(e["oauth_token_secret"]=this.secret),e["providerId"]=this.providerId,this.nonce&&!this.pendingToken&&(e["nonce"]=this.nonce),t.postBody=Object(r["x"])(e)}return t}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function te(t,e){return U(t,"POST","/v1/accounts:sendVerificationCode",M(t,e))}async function ee(t,e){return q(t,"POST","/v1/accounts:signInWithPhoneNumber",M(t,e))}async function ne(t,e){const n=await q(t,"POST","/v1/accounts:signInWithPhoneNumber",M(t,e));if(n.temporaryProof)throw H(t,"account-exists-with-different-credential",n);return n}const re={["USER_NOT_FOUND"]:"user-not-found"};async function ie(t,e){const n=Object.assign(Object.assign({},e),{operation:"REAUTH"});return q(t,"POST","/v1/accounts:signInWithPhoneNumber",M(t,n),re)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class se extends Mt{constructor(t){super("phone","phone"),this.params=t}static _fromVerification(t,e){return new se({verificationId:t,verificationCode:e})}static _fromTokenResponse(t,e){return new se({phoneNumber:t,temporaryProof:e})}_getIdTokenResponse(t){return ee(t,this._makeVerificationRequest())}_linkToIdToken(t,e){return ne(t,Object.assign({idToken:e},this._makeVerificationRequest()))}_getReauthenticationResolver(t){return ie(t,this._makeVerificationRequest())}_makeVerificationRequest(){const{temporaryProof:t,phoneNumber:e,verificationId:n,verificationCode:r}=this.params;return t&&e?{temporaryProof:t,phoneNumber:e}:{sessionInfo:n,code:r}}toJSON(){const t={providerId:this.providerId};return this.params.phoneNumber&&(t.phoneNumber=this.params.phoneNumber),this.params.temporaryProof&&(t.temporaryProof=this.params.temporaryProof),this.params.verificationCode&&(t.verificationCode=this.params.verificationCode),this.params.verificationId&&(t.verificationId=this.params.verificationId),t}static fromJSON(t){"string"===typeof t&&(t=JSON.parse(t));const{verificationId:e,verificationCode:n,phoneNumber:r,temporaryProof:i}=t;return n||e||r||i?new se({verificationId:e,verificationCode:n,phoneNumber:r,temporaryProof:i}):null}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oe(t){switch(t){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function ae(t){const e=Object(r["y"])(Object(r["j"])(t))["link"],n=e?Object(r["y"])(Object(r["j"])(e))["deep_link_id"]:null,i=Object(r["y"])(Object(r["j"])(t))["deep_link_id"],s=i?Object(r["y"])(Object(r["j"])(i))["link"]:null;return s||i||n||e||t}class ce{constructor(t){var e,n,i,s,o,a;const c=Object(r["y"])(Object(r["j"])(t)),u=null!==(e=c["apiKey"])&&void 0!==e?e:null,l=null!==(n=c["oobCode"])&&void 0!==n?n:null,h=oe(null!==(i=c["mode"])&&void 0!==i?i:null);I(u&&l&&h,"argument-error"),this.apiKey=u,this.operation=h,this.code=l,this.continueUrl=null!==(s=c["continueUrl"])&&void 0!==s?s:null,this.languageCode=null!==(o=c["languageCode"])&&void 0!==o?o:null,this.tenantId=null!==(a=c["tenantId"])&&void 0!==a?a:null}static parseLink(t){const e=ae(t);try{return new ce(e)}catch(n){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue{constructor(){this.providerId=ue.PROVIDER_ID}static credential(t,e){return Qt._fromEmailAndPassword(t,e)}static credentialWithLink(t,e){const n=ce.parseLink(e);return I(n,"argument-error"),Qt._fromEmailAndCode(t,n.code,n.tenantId)}}ue.PROVIDER_ID="password",ue.EMAIL_PASSWORD_SIGN_IN_METHOD="password",ue.EMAIL_LINK_SIGN_IN_METHOD="emailLink";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class le{constructor(t){this.providerId=t,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(t){this.defaultLanguageCode=t}setCustomParameters(t){return this.customParameters=t,this}getCustomParameters(){return this.customParameters}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class he extends le{constructor(){super(...arguments),this.scopes=[]}addScope(t){return this.scopes.includes(t)||this.scopes.push(t),this}getScopes(){return[...this.scopes]}}class de extends he{static credentialFromJSON(t){const e="string"===typeof t?JSON.parse(t):t;return I("providerId"in e&&"signInMethod"in e,"argument-error"),Zt._fromParams(e)}credential(t){return this._credential(Object.assign(Object.assign({},t),{nonce:t.rawNonce}))}_credential(t){return I(t.idToken||t.accessToken,"argument-error"),Zt._fromParams(Object.assign(Object.assign({},t),{providerId:this.providerId,signInMethod:this.providerId}))}static credentialFromResult(t){return de.oauthCredentialFromTaggedObject(t)}static credentialFromError(t){return de.oauthCredentialFromTaggedObject(t.customData||{})}static oauthCredentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{oauthIdToken:e,oauthAccessToken:n,oauthTokenSecret:r,pendingToken:i,nonce:s,providerId:o}=t;if(!n&&!r&&!e&&!i)return null;if(!o)return null;try{return new de(o)._credential({idToken:e,accessToken:n,nonce:s,pendingToken:i})}catch(a){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fe extends he{constructor(){super("facebook.com")}static credential(t){return Zt._fromParams({providerId:fe.PROVIDER_ID,signInMethod:fe.FACEBOOK_SIGN_IN_METHOD,accessToken:t})}static credentialFromResult(t){return fe.credentialFromTaggedObject(t)}static credentialFromError(t){return fe.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t||!("oauthAccessToken"in t))return null;if(!t.oauthAccessToken)return null;try{return fe.credential(t.oauthAccessToken)}catch(e){return null}}}fe.FACEBOOK_SIGN_IN_METHOD="facebook.com",fe.PROVIDER_ID="facebook.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends he{constructor(){super("google.com"),this.addScope("profile")}static credential(t,e){return Zt._fromParams({providerId:pe.PROVIDER_ID,signInMethod:pe.GOOGLE_SIGN_IN_METHOD,idToken:t,accessToken:e})}static credentialFromResult(t){return pe.credentialFromTaggedObject(t)}static credentialFromError(t){return pe.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{oauthIdToken:e,oauthAccessToken:n}=t;if(!e&&!n)return null;try{return pe.credential(e,n)}catch(r){return null}}}pe.GOOGLE_SIGN_IN_METHOD="google.com",pe.PROVIDER_ID="google.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class me extends he{constructor(){super("github.com")}static credential(t){return Zt._fromParams({providerId:me.PROVIDER_ID,signInMethod:me.GITHUB_SIGN_IN_METHOD,accessToken:t})}static credentialFromResult(t){return me.credentialFromTaggedObject(t)}static credentialFromError(t){return me.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t||!("oauthAccessToken"in t))return null;if(!t.oauthAccessToken)return null;try{return me.credential(t.oauthAccessToken)}catch(e){return null}}}me.GITHUB_SIGN_IN_METHOD="github.com",me.PROVIDER_ID="github.com";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ge="http://localhost";class ye extends Mt{constructor(t,e){super(t,t),this.pendingToken=e}_getIdTokenResponse(t){const e=this.buildRequest();return Jt(t,e)}_linkToIdToken(t,e){const n=this.buildRequest();return n.idToken=e,Jt(t,n)}_getReauthenticationResolver(t){const e=this.buildRequest();return e.autoCreate=!1,Jt(t,e)}toJSON(){return{signInMethod:this.signInMethod,providerId:this.providerId,pendingToken:this.pendingToken}}static fromJSON(t){const e="string"===typeof t?JSON.parse(t):t,{providerId:n,signInMethod:r,pendingToken:i}=e;return n&&r&&i&&n===r?new ye(n,i):null}static _create(t,e){return new ye(t,e)}buildRequest(){return{requestUri:ge,returnSecureToken:!0,pendingToken:this.pendingToken}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const be="saml.";class ve extends le{constructor(t){I(t.startsWith(be),"argument-error"),super(t)}static credentialFromResult(t){return ve.samlCredentialFromTaggedObject(t)}static credentialFromError(t){return ve.samlCredentialFromTaggedObject(t.customData||{})}static credentialFromJSON(t){const e=ye.fromJSON(t);return I(e,"argument-error"),e}static samlCredentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{pendingToken:e,providerId:n}=t;if(!e||!n)return null;try{return ye._create(n,e)}catch(r){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class we extends he{constructor(){super("twitter.com")}static credential(t,e){return Zt._fromParams({providerId:we.PROVIDER_ID,signInMethod:we.TWITTER_SIGN_IN_METHOD,oauthToken:t,oauthTokenSecret:e})}static credentialFromResult(t){return we.credentialFromTaggedObject(t)}static credentialFromError(t){return we.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{oauthAccessToken:e,oauthTokenSecret:n}=t;if(!e||!n)return null;try{return we.credential(e,n)}catch(r){return null}}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _e(t,e){return q(t,"POST","/v1/accounts:signUp",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */we.TWITTER_SIGN_IN_METHOD="twitter.com",we.PROVIDER_ID="twitter.com";class Ie{constructor(t){this.user=t.user,this.providerId=t.providerId,this._tokenResponse=t._tokenResponse,this.operationType=t.operationType}static async _fromIdTokenResponse(t,e,n,r=!1){const i=await lt._fromIdTokenResponse(t,n,r),s=Ee(n),o=new Ie({user:i,providerId:s,_tokenResponse:n,operationType:e});return o}static async _forOperation(t,e,n){await t._updateTokensIfNecessary(n,!0);const r=Ee(n);return new Ie({user:t,providerId:r,_tokenResponse:n,operationType:e})}}function Ee(t){return t.providerId?t.providerId:"phoneNumber"in t?"phone":null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oe(t){var e;const n=Ct(t);if(await n._initializationPromise,null===(e=n.currentUser)||void 0===e?void 0:e.isAnonymous)return new Ie({user:n.currentUser,providerId:null,operationType:"signIn"});const r=await _e(n,{returnSecureToken:!0}),i=await Ie._fromIdTokenResponse(n,"signIn",r,!0);return await n._updateCurrentUser(i.user),i}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Te extends r["c"]{constructor(t,e,n,r){var i;super(e.code,e.message),this.operationType=n,this.user=r,Object.setPrototypeOf(this,Te.prototype),this.customData={appName:t.name,tenantId:null!==(i=t.tenantId)&&void 0!==i?i:void 0,_serverResponse:e.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(t,e,n,r){return new Te(t,e,n,r)}}function ke(t,e,n,r){const i="reauthenticate"===e?n._getReauthenticationResolver(t):n._getIdTokenResponse(t);return i.catch(n=>{if("auth/multi-factor-auth-required"===n.code)throw Te._fromErrorAndOperation(t,n,e,r);throw n})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Se(t){return new Set(t.map(({providerId:t})=>t).filter(t=>!!t))}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ae(t,e){const n=Object(r["k"])(t);await Ne(!0,n,e);const{providerUserInfo:i}=await $(n.auth,{idToken:await n.getIdToken(),deleteProvider:[e]}),s=Se(i||[]);return n.providerData=n.providerData.filter(t=>s.has(t.providerId)),s.has("phone")||(n.phoneNumber=null),await n.auth._persistUserIfCurrent(n),n}async function je(t,e,n=!1){const r=await Z(t,e._linkToIdToken(t.auth,await t.getIdToken()),n);return Ie._forOperation(t,"link",r)}async function Ne(t,e,n){await rt(e);const r=Se(e.providerData),i=!1===t?"provider-already-linked":"no-such-provider";I(r.has(n)===t,e.auth,i)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ce(t,e,n=!1){const{auth:r}=t,i="reauthenticate";try{const s=await Z(t,ke(r,i,e,t),n);I(s.idToken,r,"internal-error");const o=J(s.idToken);I(o,r,"internal-error");const{sub:a}=o;return I(t.uid===a,r,"user-mismatch"),Ie._forOperation(t,i,s)}catch(s){throw"auth/user-not-found"===(null===s||void 0===s?void 0:s.code)&&y(r,"user-mismatch"),s}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Re(t,e,n=!1){const r="signIn",i=await ke(t,r,e),s=await Ie._fromIdTokenResponse(t,r,i);return n||await t._updateCurrentUser(s.user),s}async function xe(t,e){return Re(Ct(t),e)}async function De(t,e){const n=Object(r["k"])(t);return await Ne(!1,n,e.providerId),je(n,e)}async function Pe(t,e){return Ce(Object(r["k"])(t),e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fe(t,e){return q(t,"POST","/v1/accounts:signInWithCustomToken",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Le(t,e){const n=Ct(t),r=await Fe(n,{token:e,returnSecureToken:!0}),i=await Ie._fromIdTokenResponse(n,"signIn",r);return await n._updateCurrentUser(i.user),i}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Me{constructor(t,e){this.factorId=t,this.uid=e.mfaEnrollmentId,this.enrollmentTime=new Date(e.enrolledAt).toUTCString(),this.displayName=e.displayName}static _fromServerResponse(t,e){return"phoneInfo"in e?Ue._fromServerResponse(t,e):y(t,"internal-error")}}class Ue extends Me{constructor(t){super("phone",t),this.phoneNumber=t.phoneInfo}static _fromServerResponse(t,e){return new Ue(e)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Be(t,e,n){var r;I((null===(r=n.url)||void 0===r?void 0:r.length)>0,t,"invalid-continue-uri"),I("undefined"===typeof n.dynamicLinkDomain||n.dynamicLinkDomain.length>0,t,"invalid-dynamic-link-domain"),e.continueUrl=n.url,e.dynamicLinkDomain=n.dynamicLinkDomain,e.canHandleCodeInApp=n.handleCodeInApp,n.iOS&&(I(n.iOS.bundleId.length>0,t,"missing-ios-bundle-id"),e.iOSBundleId=n.iOS.bundleId),n.android&&(I(n.android.packageName.length>0,t,"missing-android-pkg-name"),e.androidInstallApp=n.android.installApp,e.androidMinimumVersionCode=n.android.minimumVersion,e.androidPackageName=n.android.packageName)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qe(t,e,n){const i=Object(r["k"])(t),s={requestType:"PASSWORD_RESET",email:e};n&&Be(i,s,n),await Kt(i,s)}async function Ve(t,e,n){await Ut(Object(r["k"])(t),{oobCode:e,newPassword:n})}async function ze(t,e){await qt(Object(r["k"])(t),{oobCode:e})}async function He(t,e){const n=Object(r["k"])(t),i=await Ut(n,{oobCode:e}),s=i.requestType;switch(I(s,n,"internal-error"),s){case"EMAIL_SIGNIN":break;case"VERIFY_AND_CHANGE_EMAIL":I(i.newEmail,n,"internal-error");break;case"REVERT_SECOND_FACTOR_ADDITION":I(i.mfaInfo,n,"internal-error");default:I(i.email,n,"internal-error")}let o=null;return i.mfaInfo&&(o=Me._fromServerResponse(Ct(n),i.mfaInfo)),{data:{email:("VERIFY_AND_CHANGE_EMAIL"===i.requestType?i.newEmail:i.email)||null,previousEmail:("VERIFY_AND_CHANGE_EMAIL"===i.requestType?i.email:i.newEmail)||null,multiFactorInfo:o},operation:s}}async function Ke(t,e){const{data:n}=await He(Object(r["k"])(t),e);return n.email}async function $e(t,e,n){const r=Ct(t),i=await _e(r,{returnSecureToken:!0,email:e,password:n}),s=await Ie._fromIdTokenResponse(r,"signIn",i);return await r._updateCurrentUser(s.user),s}function Ge(t,e,n){return xe(Object(r["k"])(t),ue.credential(e,n))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function We(t,e,n){const i=Object(r["k"])(t),s={requestType:"EMAIL_SIGNIN",email:e};I(n.handleCodeInApp,i,"argument-error"),n&&Be(i,s,n),await $t(i,s)}function Ye(t,e){const n=ce.parseLink(e);return"EMAIL_SIGNIN"===(null===n||void 0===n?void 0:n.operation)}async function Qe(t,e,n){const i=Object(r["k"])(t),s=ue.credentialWithLink(e,n||A());return I(s._tenantId===(i.tenantId||null),i,"tenant-id-mismatch"),xe(i,s)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Je(t,e){return U(t,"POST","/v1/accounts:createAuthUri",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Xe(t,e){const n=j()?A():"http://localhost",i={identifier:e,continueUri:n},{signinMethods:s}=await Je(Object(r["k"])(t),i);return s||[]}async function Ze(t,e){const n=Object(r["k"])(t),i=await t.getIdToken(),s={requestType:"VERIFY_EMAIL",idToken:i};e&&Be(n.auth,s,e);const{email:o}=await Ht(n.auth,s);o!==t.email&&await t.reload()}async function tn(t,e,n){const i=Object(r["k"])(t),s=await t.getIdToken(),o={requestType:"VERIFY_AND_CHANGE_EMAIL",idToken:s,newEmail:e};n&&Be(i.auth,o,n);const{email:a}=await Gt(i.auth,o);a!==t.email&&await t.reload()}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function en(t,e){return U(t,"POST","/v1/accounts:update",e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function nn(t,{displayName:e,photoURL:n}){if(void 0===e&&void 0===n)return;const i=Object(r["k"])(t),s=await i.getIdToken(),o={idToken:s,displayName:e,photoUrl:n,returnSecureToken:!0},a=await Z(i,en(i.auth,o));i.displayName=a.displayName||null,i.photoURL=a.photoUrl||null;const c=i.providerData.find(({providerId:t})=>"password"===t);c&&(c.displayName=i.displayName,c.photoURL=i.photoURL),await i._updateTokensIfNecessary(a)}function rn(t,e){return on(Object(r["k"])(t),e,null)}function sn(t,e){return on(Object(r["k"])(t),null,e)}async function on(t,e,n){const{auth:r}=t,i=await t.getIdToken(),s={idToken:i,returnSecureToken:!0};e&&(s.email=e),n&&(s.password=n);const o=await Z(t,Bt(r,s));await t._updateTokensIfNecessary(o,!0)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function an(t){var e,n;if(!t)return null;const{providerId:r}=t,i=t.rawUserInfo?JSON.parse(t.rawUserInfo):{},s=t.isNewUser||"identitytoolkit#SignupNewUserResponse"===t.kind;if(!r&&(null===t||void 0===t?void 0:t.idToken)){const r=null===(n=null===(e=J(t.idToken))||void 0===e?void 0:e.firebase)||void 0===n?void 0:n["sign_in_provider"];if(r){const t="anonymous"!==r&&"custom"!==r?r:null;return new cn(s,t)}}if(!r)return null;switch(r){case"facebook.com":return new ln(s,i);case"github.com":return new hn(s,i);case"google.com":return new dn(s,i);case"twitter.com":return new fn(s,i,t.screenName||null);case"custom":case"anonymous":return new cn(s,null);default:return new cn(s,r,i)}}class cn{constructor(t,e,n={}){this.isNewUser=t,this.providerId=e,this.profile=n}}class un extends cn{constructor(t,e,n,r){super(t,e,n),this.username=r}}class ln extends cn{constructor(t,e){super(t,"facebook.com",e)}}class hn extends un{constructor(t,e){super(t,"github.com",e,"string"===typeof(null===e||void 0===e?void 0:e.login)?null===e||void 0===e?void 0:e.login:null)}}class dn extends cn{constructor(t,e){super(t,"google.com",e)}}class fn extends un{constructor(t,e,n){super(t,"twitter.com",e,n)}}function pn(t){const{user:e,_tokenResponse:n}=t;return e.isAnonymous&&!n?{providerId:null,isNewUser:!1,profile:null}:an(n)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mn{constructor(t,e){this.type=t,this.credential=e}static _fromIdtoken(t){return new mn("enroll",t)}static _fromMfaPendingCredential(t){return new mn("signin",t)}toJSON(){const t="enroll"===this.type?"idToken":"pendingCredential";return{multiFactorSession:{[t]:this.credential}}}static fromJSON(t){var e,n;if(null===t||void 0===t?void 0:t.multiFactorSession){if(null===(e=t.multiFactorSession)||void 0===e?void 0:e.pendingCredential)return mn._fromMfaPendingCredential(t.multiFactorSession.pendingCredential);if(null===(n=t.multiFactorSession)||void 0===n?void 0:n.idToken)return mn._fromIdtoken(t.multiFactorSession.idToken)}return null}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gn{constructor(t,e,n){this.session=t,this.hints=e,this.signInResolver=n}static _fromError(t,e){const n=Ct(t),r=e.customData._serverResponse,i=(r.mfaInfo||[]).map(t=>Me._fromServerResponse(n,t));I(r.mfaPendingCredential,n,"internal-error");const s=mn._fromMfaPendingCredential(r.mfaPendingCredential);return new gn(s,i,async t=>{const i=await t._process(n,s);delete r.mfaInfo,delete r.mfaPendingCredential;const o=Object.assign(Object.assign({},r),{idToken:i.idToken,refreshToken:i.refreshToken});switch(e.operationType){case"signIn":const t=await Ie._fromIdTokenResponse(n,e.operationType,o);return await n._updateCurrentUser(t.user),t;case"reauthenticate":return I(e.user,n,"internal-error"),Ie._forOperation(e.user,e.operationType,o);default:y(n,"internal-error")}})}async resolveSignIn(t){const e=t;return this.signInResolver(e)}}function yn(t,e){var n;const i=Object(r["k"])(t),s=e;return I(e.customData.operationType,i,"argument-error"),I(null===(n=s.customData._serverResponse)||void 0===n?void 0:n.mfaPendingCredential,i,"argument-error"),gn._fromError(i,s)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bn(t,e){return U(t,"POST","/v2/accounts/mfaEnrollment:start",M(t,e))}function vn(t,e){return U(t,"POST","/v2/accounts/mfaEnrollment:finalize",M(t,e))}function wn(t,e){return U(t,"POST","/v2/accounts/mfaEnrollment:withdraw",M(t,e))}class _n{constructor(t){this.user=t,this.enrolledFactors=[],t._onReload(e=>{e.mfaInfo&&(this.enrolledFactors=e.mfaInfo.map(e=>Me._fromServerResponse(t.auth,e)))})}static _fromUser(t){return new _n(t)}async getSession(){return mn._fromIdtoken(await this.user.getIdToken())}async enroll(t,e){const n=t,r=await this.getSession(),i=await Z(this.user,n._process(this.user.auth,r,e));return await this.user._updateTokensIfNecessary(i),this.user.reload()}async unenroll(t){const e="string"===typeof t?t:t.uid,n=await this.user.getIdToken(),r=await Z(this.user,wn(this.user.auth,{idToken:n,mfaEnrollmentId:e}));this.enrolledFactors=this.enrolledFactors.filter(({uid:t})=>t!==e),await this.user._updateTokensIfNecessary(r);try{await this.user.reload()}catch(i){if("auth/user-token-expired"!==i.code)throw i}}}const In=new WeakMap;function En(t){const e=Object(r["k"])(t);return In.has(e)||In.set(e,_n._fromUser(e)),In.get(e)}const On="__sak";
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tn{constructor(t,e){this.storageRetriever=t,this.type=e}_isAvailable(){try{return this.storage?(this.storage.setItem(On,"1"),this.storage.removeItem(On),Promise.resolve(!0)):Promise.resolve(!1)}catch(t){return Promise.resolve(!1)}}_set(t,e){return this.storage.setItem(t,JSON.stringify(e)),Promise.resolve()}_get(t){const e=this.storage.getItem(t);return Promise.resolve(e?JSON.parse(e):null)}_remove(t){return this.storage.removeItem(t),Promise.resolve()}get storage(){return this.storageRetriever()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kn(){const t=Object(r["l"])();return yt(t)||Et(t)}const Sn=1e3,An=10;class jn extends Tn{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(t,e)=>this.onStorageEvent(t,e),this.listeners={},this.localCache={},this.pollTimer=null,this.safariLocalStorageNotSynced=kn()&&At(),this.fallbackToPolling=St(),this._shouldAllowMigration=!0}forAllChangedKeys(t){for(const e of Object.keys(this.listeners)){const n=this.storage.getItem(e),r=this.localCache[e];n!==r&&t(e,r,n)}}onStorageEvent(t,e=!1){if(!t.key)return void this.forAllChangedKeys((t,e,n)=>{this.notifyListeners(t,n)});const n=t.key;if(e?this.detachListener():this.stopPolling(),this.safariLocalStorageNotSynced){const r=this.storage.getItem(n);if(t.newValue!==r)null!==t.newValue?this.storage.setItem(n,t.newValue):this.storage.removeItem(n);else if(this.localCache[n]===t.newValue&&!e)return}const r=()=>{const t=this.storage.getItem(n);(e||this.localCache[n]!==t)&&this.notifyListeners(n,t)},i=this.storage.getItem(n);kt()&&i!==t.newValue&&t.newValue!==t.oldValue?setTimeout(r,An):r()}notifyListeners(t,e){this.localCache[t]=e;const n=this.listeners[t];if(n)for(const r of Array.from(n))r(e?JSON.parse(e):e)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((t,e,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:t,oldValue:e,newValue:n}),!0)})},Sn)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(t,e){0===Object.keys(this.listeners).length&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[t]||(this.listeners[t]=new Set,this.localCache[t]=this.storage.getItem(t)),this.listeners[t].add(e)}_removeListener(t,e){this.listeners[t]&&(this.listeners[t].delete(e),0===this.listeners[t].size&&delete this.listeners[t]),0===Object.keys(this.listeners).length&&(this.detachListener(),this.stopPolling())}async _set(t,e){await super._set(t,e),this.localCache[t]=JSON.stringify(e)}async _get(t){const e=await super._get(t);return this.localCache[t]=JSON.stringify(e),e}async _remove(t){await super._remove(t),delete this.localCache[t]}}jn.type="LOCAL";const Nn=jn;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cn extends Tn{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(t,e){}_removeListener(t,e){}}Cn.type="SESSION";const Rn=Cn;
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xn(t){return Promise.all(t.map(async t=>{try{const e=await t;return{fulfilled:!0,value:e}}catch(e){return{fulfilled:!1,reason:e}}}))}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dn{constructor(t){this.eventTarget=t,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(t){const e=this.receivers.find(e=>e.isListeningto(t));if(e)return e;const n=new Dn(t);return this.receivers.push(n),n}isListeningto(t){return this.eventTarget===t}async handleEvent(t){const e=t,{eventId:n,eventType:r,data:i}=e.data,s=this.handlersMap[r];if(!(null===s||void 0===s?void 0:s.size))return;e.ports[0].postMessage({status:"ack",eventId:n,eventType:r});const o=Array.from(s).map(async t=>t(e.origin,i)),a=await xn(o);e.ports[0].postMessage({status:"done",eventId:n,eventType:r,response:a})}_subscribe(t,e){0===Object.keys(this.handlersMap).length&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[t]||(this.handlersMap[t]=new Set),this.handlersMap[t].add(e)}_unsubscribe(t,e){this.handlersMap[t]&&e&&this.handlersMap[t].delete(e),e&&0!==this.handlersMap[t].size||delete this.handlersMap[t],0===Object.keys(this.handlersMap).length&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pn(t="",e=10){let n="";for(let r=0;r<e;r++)n+=Math.floor(10*Math.random());return t+n}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Dn.receivers=[];class Fn{constructor(t){this.target=t,this.handlers=new Set}removeMessageHandler(t){t.messageChannel&&(t.messageChannel.port1.removeEventListener("message",t.onMessage),t.messageChannel.port1.close()),this.handlers.delete(t)}async _send(t,e,n=50){const r="undefined"!==typeof MessageChannel?new MessageChannel:null;if(!r)throw new Error("connection_unavailable");let i,s;return new Promise((o,a)=>{const c=Pn("",20);r.port1.start();const u=setTimeout(()=>{a(new Error("unsupported_event"))},n);s={messageChannel:r,onMessage(t){const e=t;if(e.data.eventId===c)switch(e.data.status){case"ack":clearTimeout(u),i=setTimeout(()=>{a(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),o(e.data.response);break;default:clearTimeout(u),clearTimeout(i),a(new Error("invalid_response"));break}}},this.handlers.add(s),r.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:t,eventId:c,data:e},[r.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ln(){return window}function Mn(t){Ln().location.href=t}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Un(){return"undefined"!==typeof Ln()["WorkerGlobalScope"]&&"function"===typeof Ln()["importScripts"]}async function Bn(){if(!(null===navigator||void 0===navigator?void 0:navigator.serviceWorker))return null;try{const t=await navigator.serviceWorker.ready;return t.active}catch(t){return null}}function qn(){var t;return(null===(t=null===navigator||void 0===navigator?void 0:navigator.serviceWorker)||void 0===t?void 0:t.controller)||null}function Vn(){return Un()?self:null}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zn="firebaseLocalStorageDb",Hn=1,Kn="firebaseLocalStorage",$n="fbase_key";class Gn{constructor(t){this.request=t}toPromise(){return new Promise((t,e)=>{this.request.addEventListener("success",()=>{t(this.request.result)}),this.request.addEventListener("error",()=>{e(this.request.error)})})}}function Wn(t,e){return t.transaction([Kn],e?"readwrite":"readonly").objectStore(Kn)}function Yn(){const t=indexedDB.deleteDatabase(zn);return new Gn(t).toPromise()}function Qn(){const t=indexedDB.open(zn,Hn);return new Promise((e,n)=>{t.addEventListener("error",()=>{n(t.error)}),t.addEventListener("upgradeneeded",()=>{const e=t.result;try{e.createObjectStore(Kn,{keyPath:$n})}catch(r){n(r)}}),t.addEventListener("success",async()=>{const n=t.result;n.objectStoreNames.contains(Kn)?e(n):(n.close(),await Yn(),e(await Qn()))})})}async function Jn(t,e,n){const r=Wn(t,!0).put({[$n]:e,value:n});return new Gn(r).toPromise()}async function Xn(t,e){const n=Wn(t,!1).get(e),r=await new Gn(n).toPromise();return void 0===r?null:r.value}function Zn(t,e){const n=Wn(t,!0).delete(e);return new Gn(n).toPromise()}const tr=800,er=3;class nr{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db||(this.db=await Qn()),this.db}async _withRetries(t){let e=0;while(1)try{const e=await this._openDb();return await t(e)}catch(n){if(e++>er)throw n;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Un()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Dn._getInstance(Vn()),this.receiver._subscribe("keyChanged",async(t,e)=>{const n=await this._poll();return{keyProcessed:n.includes(e.key)}}),this.receiver._subscribe("ping",async(t,e)=>["keyChanged"])}async initializeSender(){var t,e;if(this.activeServiceWorker=await Bn(),!this.activeServiceWorker)return;this.sender=new Fn(this.activeServiceWorker);const n=await this.sender._send("ping",{},800);n&&(null===(t=n[0])||void 0===t?void 0:t.fulfilled)&&(null===(e=n[0])||void 0===e?void 0:e.value.includes("keyChanged"))&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(t){if(this.sender&&this.activeServiceWorker&&qn()===this.activeServiceWorker)try{await this.sender._send("keyChanged",{key:t},this.serviceWorkerReceiverAvailable?800:50)}catch(e){}}async _isAvailable(){try{if(!indexedDB)return!1;const t=await Qn();return await Jn(t,On,"1"),await Zn(t,On),!0}catch(t){}return!1}async _withPendingWrite(t){this.pendingWrites++;try{await t()}finally{this.pendingWrites--}}async _set(t,e){return this._withPendingWrite(async()=>(await this._withRetries(n=>Jn(n,t,e)),this.localCache[t]=e,this.notifyServiceWorker(t)))}async _get(t){const e=await this._withRetries(e=>Xn(e,t));return this.localCache[t]=e,e}async _remove(t){return this._withPendingWrite(async()=>(await this._withRetries(e=>Zn(e,t)),delete this.localCache[t],this.notifyServiceWorker(t)))}async _poll(){const t=await this._withRetries(t=>{const e=Wn(t,!1).getAll();return new Gn(e).toPromise()});if(!t)return[];if(0!==this.pendingWrites)return[];const e=[],n=new Set;for(const{fbase_key:r,value:i}of t)n.add(r),JSON.stringify(this.localCache[r])!==JSON.stringify(i)&&(this.notifyListeners(r,i),e.push(r));for(const r of Object.keys(this.localCache))this.localCache[r]&&!n.has(r)&&(this.notifyListeners(r,null),e.push(r));return e}notifyListeners(t,e){this.localCache[t]=e;const n=this.listeners[t];if(n)for(const r of Array.from(n))r(e)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),tr)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(t,e){0===Object.keys(this.listeners).length&&this.startPolling(),this.listeners[t]||(this.listeners[t]=new Set,this._get(t)),this.listeners[t].add(e)}_removeListener(t,e){this.listeners[t]&&(this.listeners[t].delete(e),0===this.listeners[t].size&&delete this.listeners[t]),0===Object.keys(this.listeners).length&&this.stopPolling()}}nr.type="LOCAL";const rr=nr;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ir(t,e){return U(t,"POST","/v2/accounts/mfaSignIn:start",M(t,e))}function sr(t,e){return U(t,"POST","/v2/accounts/mfaSignIn:finalize",M(t,e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function or(t){return(await U(t,"GET","/v1/recaptchaParams")).recaptchaSiteKey||""}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ar(){var t,e;return null!==(e=null===(t=document.getElementsByTagName("head"))||void 0===t?void 0:t[0])&&void 0!==e?e:document}function cr(t){return new Promise((e,n)=>{const r=document.createElement("script");r.setAttribute("src",t),r.onload=e,r.onerror=t=>{const e=b("internal-error");e.customData=t,n(e)},r.type="text/javascript",r.charset="UTF-8",ar().appendChild(r)})}function ur(t){return`__${t}${Math.floor(1e6*Math.random())}`}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lr=500,hr=6e4,dr=1e12;class fr{constructor(t){this.auth=t,this.counter=dr,this._widgets=new Map}render(t,e){const n=this.counter;return this._widgets.set(n,new pr(t,this.auth.name,e||{})),this.counter++,n}reset(t){var e;const n=t||dr;null===(e=this._widgets.get(n))||void 0===e||e.delete(),this._widgets.delete(n)}getResponse(t){var e;const n=t||dr;return(null===(e=this._widgets.get(n))||void 0===e?void 0:e.getResponse())||""}async execute(t){var e;const n=t||dr;return null===(e=this._widgets.get(n))||void 0===e||e.execute(),""}}class pr{constructor(t,e,n){this.params=n,this.timerId=null,this.deleted=!1,this.responseToken=null,this.clickHandler=()=>{this.execute()};const r="string"===typeof t?document.getElementById(t):t;I(r,"argument-error",{appName:e}),this.container=r,this.isVisible="invisible"!==this.params.size,this.isVisible?this.execute():this.container.addEventListener("click",this.clickHandler)}getResponse(){return this.checkIfDeleted(),this.responseToken}delete(){this.checkIfDeleted(),this.deleted=!0,this.timerId&&(clearTimeout(this.timerId),this.timerId=null),this.container.removeEventListener("click",this.clickHandler)}execute(){this.checkIfDeleted(),this.timerId||(this.timerId=window.setTimeout(()=>{this.responseToken=mr(50);const{callback:t,"expired-callback":e}=this.params;if(t)try{t(this.responseToken)}catch(n){}this.timerId=window.setTimeout(()=>{if(this.timerId=null,this.responseToken=null,e)try{e()}catch(n){}this.isVisible&&this.execute()},hr)},lr))}checkIfDeleted(){if(this.deleted)throw new Error("reCAPTCHA mock was already deleted!")}}function mr(t){const e=[],n="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";for(let r=0;r<t;r++)e.push(n.charAt(Math.floor(Math.random()*n.length)));return e.join("")}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gr=ur("rcb"),yr=new x(3e4,6e4),br="https://www.google.com/recaptcha/api.js?";class vr{constructor(){this.hostLanguage="",this.counter=0,this.librarySeparatelyLoaded=!!Ln().grecaptcha}load(t,e=""){return I(wr(e),t,"argument-error"),this.shouldResolveImmediately(e)?Promise.resolve(Ln().grecaptcha):new Promise((n,i)=>{const s=Ln().setTimeout(()=>{i(b(t,"network-request-failed"))},yr.get());Ln()[gr]=()=>{Ln().clearTimeout(s),delete Ln()[gr];const r=Ln().grecaptcha;if(!r)return void i(b(t,"internal-error"));const o=r.render;r.render=(t,e)=>{const n=o(t,e);return this.counter++,n},this.hostLanguage=e,n(r)};const o=`${br}?${Object(r["x"])({onload:gr,render:"explicit",hl:e})}`;cr(o).catch(()=>{clearTimeout(s),i(b(t,"internal-error"))})})}clearedOneInstance(){this.counter--}shouldResolveImmediately(t){return!!Ln().grecaptcha&&(t===this.hostLanguage||this.counter>0||this.librarySeparatelyLoaded)}}function wr(t){return t.length<=6&&/^\s*[a-zA-Z0-9\-]*\s*$/.test(t)}class _r{async load(t){return new fr(t)}clearedOneInstance(){}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ir="recaptcha",Er={theme:"light",type:"image"};class Or{constructor(t,e=Object.assign({},Er),n){this.parameters=e,this.type=Ir,this.destroyed=!1,this.widgetId=null,this.tokenChangeListeners=new Set,this.renderPromise=null,this.recaptcha=null,this.auth=Ct(n),this.isInvisible="invisible"===this.parameters.size,I("undefined"!==typeof document,this.auth,"operation-not-supported-in-this-environment");const r="string"===typeof t?document.getElementById(t):t;I(r,this.auth,"argument-error"),this.container=r,this.parameters.callback=this.makeTokenCallback(this.parameters.callback),this._recaptchaLoader=this.auth.settings.appVerificationDisabledForTesting?new _r:new vr,this.validateStartingState()}async verify(){this.assertNotDestroyed();const t=await this.render(),e=this.getAssertedRecaptcha(),n=e.getResponse(t);return n||new Promise(n=>{const r=t=>{t&&(this.tokenChangeListeners.delete(r),n(t))};this.tokenChangeListeners.add(r),this.isInvisible&&e.execute(t)})}render(){try{this.assertNotDestroyed()}catch(t){return Promise.reject(t)}return this.renderPromise||(this.renderPromise=this.makeRenderPromise().catch(t=>{throw this.renderPromise=null,t})),this.renderPromise}_reset(){this.assertNotDestroyed(),null!==this.widgetId&&this.getAssertedRecaptcha().reset(this.widgetId)}clear(){this.assertNotDestroyed(),this.destroyed=!0,this._recaptchaLoader.clearedOneInstance(),this.isInvisible||this.container.childNodes.forEach(t=>{this.container.removeChild(t)})}validateStartingState(){I(!this.parameters.sitekey,this.auth,"argument-error"),I(this.isInvisible||!this.container.hasChildNodes(),this.auth,"argument-error"),I("undefined"!==typeof document,this.auth,"operation-not-supported-in-this-environment")}makeTokenCallback(t){return e=>{if(this.tokenChangeListeners.forEach(t=>t(e)),"function"===typeof t)t(e);else if("string"===typeof t){const n=Ln()[t];"function"===typeof n&&n(e)}}}assertNotDestroyed(){I(!this.destroyed,this.auth,"internal-error")}async makeRenderPromise(){if(await this.init(),!this.widgetId){let t=this.container;if(!this.isInvisible){const e=document.createElement("div");t.appendChild(e),t=e}this.widgetId=this.getAssertedRecaptcha().render(t,this.parameters)}return this.widgetId}async init(){I(j()&&!Un(),this.auth,"internal-error"),await Tr(),this.recaptcha=await this._recaptchaLoader.load(this.auth,this.auth.languageCode||void 0);const t=await or(this.auth);I(t,this.auth,"internal-error"),this.parameters.sitekey=t}getAssertedRecaptcha(){return I(this.recaptcha,this.auth,"internal-error"),this.recaptcha}}function Tr(){let t=null;return new Promise(e=>{"complete"!==document.readyState?(t=()=>e(),window.addEventListener("load",t)):e()}).catch(e=>{throw t&&window.removeEventListener("load",t),e})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kr{constructor(t,e){this.verificationId=t,this.onConfirmation=e}confirm(t){const e=se._fromVerification(this.verificationId,t);return this.onConfirmation(e)}}async function Sr(t,e,n){const i=Ct(t),s=await Nr(i,e,Object(r["k"])(n));return new kr(s,t=>xe(i,t))}async function Ar(t,e,n){const i=Object(r["k"])(t);await Ne(!1,i,"phone");const s=await Nr(i.auth,e,Object(r["k"])(n));return new kr(s,t=>De(i,t))}async function jr(t,e,n){const i=Object(r["k"])(t),s=await Nr(i.auth,e,Object(r["k"])(n));return new kr(s,t=>Pe(i,t))}async function Nr(t,e,n){var r;const i=await n.verify();try{let s;if(I("string"===typeof i,t,"argument-error"),I(n.type===Ir,t,"argument-error"),s="string"===typeof e?{phoneNumber:e}:e,"session"in s){const e=s.session;if("phoneNumber"in s){I("enroll"===e.type,t,"internal-error");const n=await bn(t,{idToken:e.credential,phoneEnrollmentInfo:{phoneNumber:s.phoneNumber,recaptchaToken:i}});return n.phoneSessionInfo.sessionInfo}{I("signin"===e.type,t,"internal-error");const n=(null===(r=s.multiFactorHint)||void 0===r?void 0:r.uid)||s.multiFactorUid;I(n,t,"missing-multi-factor-info");const o=await ir(t,{mfaPendingCredential:e.credential,mfaEnrollmentId:n,phoneSignInInfo:{recaptchaToken:i}});return o.phoneResponseInfo.sessionInfo}}{const{sessionInfo:e}=await te(t,{phoneNumber:s.phoneNumber,recaptchaToken:i});return e}}finally{n._reset()}}async function Cr(t,e){await je(Object(r["k"])(t),e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rr{constructor(t){this.providerId=Rr.PROVIDER_ID,this.auth=Ct(t)}verifyPhoneNumber(t,e){return Nr(this.auth,t,Object(r["k"])(e))}static credential(t,e){return se._fromVerification(t,e)}static credentialFromResult(t){const e=t;return Rr.credentialFromTaggedObject(e)}static credentialFromError(t){return Rr.credentialFromTaggedObject(t.customData||{})}static credentialFromTaggedObject({_tokenResponse:t}){if(!t)return null;const{phoneNumber:e,temporaryProof:n}=t;return e&&n?se._fromTokenResponse(e,n):null}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xr(t,e){return e?k(e):(I(t._popupRedirectResolver,t,"argument-error"),t._popupRedirectResolver)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Rr.PROVIDER_ID="phone",Rr.PHONE_SIGN_IN_METHOD="phone";class Dr extends Mt{constructor(t){super("custom","custom"),this.params=t}_getIdTokenResponse(t){return Jt(t,this._buildIdpRequest())}_linkToIdToken(t,e){return Jt(t,this._buildIdpRequest(e))}_getReauthenticationResolver(t){return Jt(t,this._buildIdpRequest())}_buildIdpRequest(t){const e={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return t&&(e.idToken=t),e}}function Pr(t){return Re(t.auth,new Dr(t),t.bypassAuthState)}function Fr(t){const{auth:e,user:n}=t;return I(n,e,"internal-error"),Ce(n,new Dr(t),t.bypassAuthState)}async function Lr(t){const{auth:e,user:n}=t;return I(n,e,"internal-error"),je(n,new Dr(t),t.bypassAuthState)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr{constructor(t,e,n,r,i=!1){this.auth=t,this.resolver=n,this.user=r,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(e)?e:[e]}execute(){return new Promise(async(t,e)=>{this.pendingPromise={resolve:t,reject:e};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}})}async onAuthEvent(t){const{urlResponse:e,sessionId:n,postBody:r,tenantId:i,error:s,type:o}=t;if(s)return void this.reject(s);const a={auth:this.auth,requestUri:e,sessionId:n,tenantId:i||void 0,postBody:r||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(o)(a))}catch(c){this.reject(c)}}onError(t){this.reject(t)}getIdpTask(t){switch(t){case"signInViaPopup":case"signInViaRedirect":return Pr;case"linkViaPopup":case"linkViaRedirect":return Lr;case"reauthViaPopup":case"reauthViaRedirect":return Fr;default:y(this.auth,"internal-error")}}resolve(t){O(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(t),this.unregisterAndCleanUp()}reject(t){O(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(t),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ur=new x(2e3,1e4);async function Br(t,e,n){const r=Ct(t);w(t,e,le);const i=xr(r,n),s=new zr(r,"signInViaPopup",e,i);return s.executeNotNull()}async function qr(t,e,n){const i=Object(r["k"])(t);w(i.auth,e,le);const s=xr(i.auth,n),o=new zr(i.auth,"reauthViaPopup",e,s,i);return o.executeNotNull()}async function Vr(t,e,n){const i=Object(r["k"])(t);w(i.auth,e,le);const s=xr(i.auth,n),o=new zr(i.auth,"linkViaPopup",e,s,i);return o.executeNotNull()}class zr extends Mr{constructor(t,e,n,r,i){super(t,e,r,i),this.provider=n,this.authWindow=null,this.pollId=null,zr.currentPopupAction&&zr.currentPopupAction.cancel(),zr.currentPopupAction=this}async executeNotNull(){const t=await this.execute();return I(t,this.auth,"internal-error"),t}async onExecution(){O(1===this.filter.length,"Popup operations only handle one event");const t=Pn();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],t),this.authWindow.associatedEvent=t,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(b(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var t;return(null===(t=this.authWindow)||void 0===t?void 0:t.associatedEvent)||null}cancel(){this.reject(b(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,zr.currentPopupAction=null}pollUserCancellation(){const t=()=>{var e,n;(null===(n=null===(e=this.authWindow)||void 0===e?void 0:e.window)||void 0===n?void 0:n.closed)?this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(b(this.auth,"popup-closed-by-user"))},2e3):this.pollId=window.setTimeout(t,Ur.get())};t()}}zr.currentPopupAction=null;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hr="pendingRedirect",Kr=new Map;class $r extends Mr{constructor(t,e,n=!1){super(t,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],e,void 0,n),this.eventId=null}async execute(){let t=Kr.get(this.auth._key());if(!t){try{const e=await Gr(this.resolver,this.auth),n=e?await super.execute():null;t=()=>Promise.resolve(n)}catch(e){t=()=>Promise.reject(e)}Kr.set(this.auth._key(),t)}return this.bypassAuthState||Kr.set(this.auth._key(),()=>Promise.resolve(null)),t()}async onAuthEvent(t){if("signInViaRedirect"===t.type)return super.onAuthEvent(t);if("unknown"!==t.type){if(t.eventId){const e=await this.auth._redirectUserForId(t.eventId);if(e)return this.user=e,super.onAuthEvent(t);this.resolve(null)}}else this.resolve(null)}async onExecution(){}cleanUp(){}}async function Gr(t,e){const n=Jr(e),r=Qr(t);if(!await r._isAvailable())return!1;const i="true"===await r._get(n);return await r._remove(n),i}async function Wr(t,e){return Qr(t)._set(Jr(e),"true")}function Yr(){Kr.clear()}function Qr(t){return k(t._redirectPersistence)}function Jr(t){return ft(Hr,t.config.apiKey,t.name)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xr(t,e,n){return Zr(t,e,n)}async function Zr(t,e,n){const r=Ct(t);w(t,e,le);const i=xr(r,n);return await Wr(i,r),i._openRedirect(r,e,"signInViaRedirect")}function ti(t,e,n){return ei(t,e,n)}async function ei(t,e,n){const i=Object(r["k"])(t);w(i.auth,e,le);const s=xr(i.auth,n);await Wr(s,i.auth);const o=await oi(i);return s._openRedirect(i.auth,e,"reauthViaRedirect",o)}function ni(t,e,n){return ri(t,e,n)}async function ri(t,e,n){const i=Object(r["k"])(t);w(i.auth,e,le);const s=xr(i.auth,n);await Ne(!1,i,e.providerId),await Wr(s,i.auth);const o=await oi(i);return s._openRedirect(i.auth,e,"linkViaRedirect",o)}async function ii(t,e){return await Ct(t)._initializationPromise,si(t,e,!1)}async function si(t,e,n=!1){const r=Ct(t),i=xr(r,e),s=new $r(r,i,n),o=await s.execute();return o&&!n&&(delete o.user._redirectEventId,await r._persistUserIfCurrent(o.user),await r._setRedirectUser(null,e)),o}async function oi(t){const e=Pn(t.uid+":::");return t._redirectEventId=e,await t.auth._setRedirectUser(t),await t.auth._persistUserIfCurrent(t),e}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ai=6e5;class ci{constructor(t){this.auth=t,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(t){this.consumers.add(t),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,t)&&(this.sendToConsumer(this.queuedRedirectEvent,t),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(t){this.consumers.delete(t)}onEvent(t){if(this.hasEventBeenHandled(t))return!1;let e=!1;return this.consumers.forEach(n=>{this.isEventForConsumer(t,n)&&(e=!0,this.sendToConsumer(t,n),this.saveEventToCache(t))}),this.hasHandledPotentialRedirect||!hi(t)||(this.hasHandledPotentialRedirect=!0,e||(this.queuedRedirectEvent=t,e=!0)),e}sendToConsumer(t,e){var n;if(t.error&&!li(t)){const r=(null===(n=t.error.code)||void 0===n?void 0:n.split("auth/")[1])||"internal-error";e.onError(b(this.auth,r))}else e.onAuthEvent(t)}isEventForConsumer(t,e){const n=null===e.eventId||!!t.eventId&&t.eventId===e.eventId;return e.filter.includes(t.type)&&n}hasEventBeenHandled(t){return Date.now()-this.lastProcessedEventTime>=ai&&this.cachedEventUids.clear(),this.cachedEventUids.has(ui(t))}saveEventToCache(t){this.cachedEventUids.add(ui(t)),this.lastProcessedEventTime=Date.now()}}function ui(t){return[t.type,t.eventId,t.sessionId,t.tenantId].filter(t=>t).join("-")}function li({type:t,error:e}){return"unknown"===t&&"auth/no-auth-event"===(null===e||void 0===e?void 0:e.code)}function hi(t){switch(t.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return li(t);default:return!1}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function di(t,e={}){return U(t,"GET","/v1/projects",e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fi=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,pi=/^https?/;async function mi(t){if(t.config.emulator)return;const{authorizedDomains:e}=await di(t);for(const r of e)try{if(gi(r))return}catch(n){}y(t,"unauthorized-domain")}function gi(t){const e=A(),{protocol:n,hostname:r}=new URL(e);if(t.startsWith("chrome-extension://")){const i=new URL(t);return""===i.hostname&&""===r?"chrome-extension:"===n&&t.replace("chrome-extension://","")===e.replace("chrome-extension://",""):"chrome-extension:"===n&&i.hostname===r}if(!pi.test(n))return!1;if(fi.test(t))return r===t;const i=t.replace(/\./g,"\\."),s=new RegExp("^(.+\\."+i+"|"+i+")$","i");return s.test(r)}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yi=new x(3e4,6e4);function bi(){const t=Ln().___jsl;if(null===t||void 0===t?void 0:t.H)for(const e of Object.keys(t.H))if(t.H[e].r=t.H[e].r||[],t.H[e].L=t.H[e].L||[],t.H[e].r=[...t.H[e].L],t.CP)for(let n=0;n<t.CP.length;n++)t.CP[n]=null}function vi(t){return new Promise((e,n)=>{var r,i,s;function o(){bi(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{bi(),n(b(t,"network-request-failed"))},timeout:yi.get()})}if(null===(i=null===(r=Ln().gapi)||void 0===r?void 0:r.iframes)||void 0===i?void 0:i.Iframe)e(gapi.iframes.getContext());else{if(!(null===(s=Ln().gapi)||void 0===s?void 0:s.load)){const e=ur("iframefcb");return Ln()[e]=()=>{gapi.load?o():n(b(t,"network-request-failed"))},cr("https://apis.google.com/js/api.js?onload="+e)}o()}}).catch(t=>{throw wi=null,t})}let wi=null;function _i(t){return wi=wi||vi(t),wi}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ii=new x(5e3,15e3),Ei="__/auth/iframe",Oi="emulator/auth/iframe",Ti={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},ki=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function Si(t){const e=t.config;I(e.authDomain,t,"auth-domain-config-required");const n=e.emulator?D(e,Oi):`https://${t.config.authDomain}/${Ei}`,s={apiKey:e.apiKey,appName:t.name,v:i["SDK_VERSION"]},o=ki.get(t.config.apiHost);o&&(s.eid=o);const a=t._getFrameworks();return a.length&&(s.fw=a.join(",")),`${n}?${Object(r["x"])(s).slice(1)}`}async function Ai(t){const e=await _i(t),n=Ln().gapi;return I(n,t,"internal-error"),e.open({where:document.body,url:Si(t),messageHandlersFilter:n.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Ti,dontclear:!0},e=>new Promise(async(n,r)=>{await e.restyle({setHideOnLeave:!1});const i=b(t,"network-request-failed"),s=Ln().setTimeout(()=>{r(i)},Ii.get());function o(){Ln().clearTimeout(s),n(e)}e.ping(o).then(o,()=>{r(i)})}))}
/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ji={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},Ni=500,Ci=600,Ri="_blank",xi="http://localhost";class Di{constructor(t){this.window=t,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch(t){}}}function Pi(t,e,n,i=Ni,s=Ci){const o=Math.max((window.screen.availHeight-s)/2,0).toString(),a=Math.max((window.screen.availWidth-i)/2,0).toString();let c="";const u=Object.assign(Object.assign({},ji),{width:i.toString(),height:s.toString(),top:o,left:a}),l=Object(r["l"])().toLowerCase();n&&(c=bt(l)?Ri:n),gt(l)&&(e=e||xi,u.scrollbars="yes");const h=Object.entries(u).reduce((t,[e,n])=>`${t}${e}=${n},`,"");if(Tt(l)&&"_self"!==c)return Fi(e||"",c),new Di(null);const d=window.open(e||"",c,h);I(d,t,"popup-blocked");try{d.focus()}catch(f){}return new Di(d)}function Fi(t,e){const n=document.createElement("a");n.href=t,n.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),n.dispatchEvent(r)}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Li="__/auth/handler",Mi="emulator/auth/handler";function Ui(t,e,n,s,o,a){I(t.config.authDomain,t,"auth-domain-config-required"),I(t.config.apiKey,t,"invalid-api-key");const c={apiKey:t.config.apiKey,appName:t.name,authType:n,redirectUrl:s,v:i["SDK_VERSION"],eventId:o};if(e instanceof le){e.setDefaultLanguage(t.languageCode),c.providerId=e.providerId||"",Object(r["p"])(e.getCustomParameters())||(c.customParameters=JSON.stringify(e.getCustomParameters()));for(const[t,e]of Object.entries(a||{}))c[t]=e}if(e instanceof he){const t=e.getScopes().filter(t=>""!==t);t.length>0&&(c.scopes=t.join(","))}t.tenantId&&(c.tid=t.tenantId);const u=c;for(const r of Object.keys(u))void 0===u[r]&&delete u[r];return`${Bi(t)}?${Object(r["x"])(u).slice(1)}`}function Bi({config:t}){return t.emulator?D(t,Mi):`https://${t.authDomain}/${Li}`}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qi="webStorageSupport";class Vi{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Rn,this._completeRedirectFn=si}async _openPopup(t,e,n,r){var i;O(null===(i=this.eventManagers[t._key()])||void 0===i?void 0:i.manager,"_initialize() not called before _openPopup()");const s=Ui(t,e,n,A(),r);return Pi(t,s,Pn())}async _openRedirect(t,e,n,r){return await this._originValidation(t),Mn(Ui(t,e,n,A(),r)),new Promise(()=>{})}_initialize(t){const e=t._key();if(this.eventManagers[e]){const{manager:t,promise:n}=this.eventManagers[e];return t?Promise.resolve(t):(O(n,"If manager is not set, promise should be"),n)}const n=this.initAndGetManager(t);return this.eventManagers[e]={promise:n},n}async initAndGetManager(t){const e=await Ai(t),n=new ci(t);return e.register("authEvent",e=>{I(null===e||void 0===e?void 0:e.authEvent,t,"invalid-auth-event");const r=n.onEvent(e.authEvent);return{status:r?"ACK":"ERROR"}},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[t._key()]={manager:n},this.iframes[t._key()]=e,n}_isIframeWebStorageSupported(t,e){const n=this.iframes[t._key()];n.send(qi,{type:qi},n=>{var r;const i=null===(r=null===n||void 0===n?void 0:n[0])||void 0===r?void 0:r[qi];void 0!==i&&e(!!i),y(t,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(t){const e=t._key();return this.originValidationPromises[e]||(this.originValidationPromises[e]=mi(t)),this.originValidationPromises[e]}get _shouldInitProactively(){return St()||yt()||Et()}}const zi=Vi;class Hi{constructor(t){this.factorId=t}_process(t,e,n){switch(e.type){case"enroll":return this._finalizeEnroll(t,e.credential,n);case"signin":return this._finalizeSignIn(t,e.credential);default:return E("unexpected MultiFactorSessionType")}}}class Ki extends Hi{constructor(t){super("phone"),this.credential=t}static _fromCredential(t){return new Ki(t)}_finalizeEnroll(t,e,n){return vn(t,{idToken:e,displayName:n,phoneVerificationInfo:this.credential._makeVerificationRequest()})}_finalizeSignIn(t,e){return sr(t,{mfaPendingCredential:e,phoneVerificationInfo:this.credential._makeVerificationRequest()})}}class $i{constructor(){}static assertion(t){return Ki._fromCredential(t)}}$i.FACTOR_ID="phone";var Gi="@firebase/auth",Wi="0.19.3";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(t){this.auth=t,this.internalListeners=new Map}getUid(){var t;return this.assertAuthConfigured(),(null===(t=this.auth.currentUser)||void 0===t?void 0:t.uid)||null}async getToken(t){if(this.assertAuthConfigured(),await this.auth._initializationPromise,!this.auth.currentUser)return null;const e=await this.auth.currentUser.getIdToken(t);return{accessToken:e}}addAuthTokenListener(t){if(this.assertAuthConfigured(),this.internalListeners.has(t))return;const e=this.auth.onIdTokenChanged(e=>{var n;t((null===(n=e)||void 0===n?void 0:n.stsTokenManager.accessToken)||null)});this.internalListeners.set(t,e),this.updateProactiveRefresh()}removeAuthTokenListener(t){this.assertAuthConfigured();const e=this.internalListeners.get(t);e&&(this.internalListeners.delete(t),e(),this.updateProactiveRefresh())}assertAuthConfigured(){I(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qi(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";default:return}}function Ji(t){Object(i["_registerComponent"])(new a["a"]("auth",(e,{options:n})=>{const r=e.getProvider("app").getImmediate(),{apiKey:i,authDomain:s}=r.options;return(e=>{I(i&&!i.includes(":"),"invalid-api-key",{appName:e.name}),I(!(null===s||void 0===s?void 0:s.includes(":")),"argument-error",{appName:e.name});const r={apiKey:i,authDomain:s,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:jt(t)},o=new Nt(e,r);return S(o,n),o})(r)},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((t,e,n)=>{const r=t.getProvider("auth-internal");r.initialize()})),Object(i["_registerComponent"])(new a["a"]("auth-internal",t=>{const e=Ct(t.getProvider("auth").getImmediate());return(t=>new Yi(t))(e)},"PRIVATE").setInstantiationMode("EXPLICIT")),Object(i["registerVersion"])(Gi,Wi,Qi(t)),Object(i["registerVersion"])(Gi,Wi,"esm2017")}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Xi(){return window}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ji("Browser");const Zi=2e3;async function ts(t,e,n){var r;const{BuildInfo:i}=Xi();O(e.sessionId,"AuthEvent did not contain a session ID");const s=await ss(e.sessionId),o={};return Et()?o["ibi"]=i.packageName:wt()?o["apn"]=i.packageName:y(t,"operation-not-supported-in-this-environment"),i.displayName&&(o["appDisplayName"]=i.displayName),o["sessionId"]=s,Ui(t,n,e.type,void 0,null!==(r=e.eventId)&&void 0!==r?r:void 0,o)}async function es(t){const{BuildInfo:e}=Xi(),n={};Et()?n.iosBundleId=e.packageName:wt()?n.androidPackageName=e.packageName:y(t,"operation-not-supported-in-this-environment"),await di(t,n)}function ns(t){const{cordova:e}=Xi();return new Promise(n=>{e.plugins.browsertab.isAvailable(r=>{let i=null;r?e.plugins.browsertab.openUrl(t):i=e.InAppBrowser.open(t,Ot()?"_blank":"_system","location=yes"),n(i)})})}async function rs(t,e,n){const{cordova:r}=Xi();let i=()=>{};try{await new Promise((s,o)=>{let a=null;function c(){var t;s();const e=null===(t=r.plugins.browsertab)||void 0===t?void 0:t.close;"function"===typeof e&&e(),"function"===typeof(null===n||void 0===n?void 0:n.close)&&n.close()}function u(){a||(a=window.setTimeout(()=>{o(b(t,"redirect-cancelled-by-user"))},Zi))}function l(){"visible"===(null===document||void 0===document?void 0:document.visibilityState)&&u()}e.addPassiveListener(c),document.addEventListener("resume",u,!1),wt()&&document.addEventListener("visibilitychange",l,!1),i=()=>{e.removePassiveListener(c),document.removeEventListener("resume",u,!1),document.removeEventListener("visibilitychange",l,!1),a&&window.clearTimeout(a)}})}finally{i()}}function is(t){var e,n,r,i,s,o,a,c,u,l;const h=Xi();I("function"===typeof(null===(e=null===h||void 0===h?void 0:h.universalLinks)||void 0===e?void 0:e.subscribe),t,"invalid-cordova-configuration",{missingPlugin:"cordova-universal-links-plugin-fix"}),I("undefined"!==typeof(null===(n=null===h||void 0===h?void 0:h.BuildInfo)||void 0===n?void 0:n.packageName),t,"invalid-cordova-configuration",{missingPlugin:"cordova-plugin-buildInfo"}),I("function"===typeof(null===(s=null===(i=null===(r=null===h||void 0===h?void 0:h.cordova)||void 0===r?void 0:r.plugins)||void 0===i?void 0:i.browsertab)||void 0===s?void 0:s.openUrl),t,"invalid-cordova-configuration",{missingPlugin:"cordova-plugin-browsertab"}),I("function"===typeof(null===(c=null===(a=null===(o=null===h||void 0===h?void 0:h.cordova)||void 0===o?void 0:o.plugins)||void 0===a?void 0:a.browsertab)||void 0===c?void 0:c.isAvailable),t,"invalid-cordova-configuration",{missingPlugin:"cordova-plugin-browsertab"}),I("function"===typeof(null===(l=null===(u=null===h||void 0===h?void 0:h.cordova)||void 0===u?void 0:u.InAppBrowser)||void 0===l?void 0:l.open),t,"invalid-cordova-configuration",{missingPlugin:"cordova-plugin-inappbrowser"})}async function ss(t){const e=os(t),n=await crypto.subtle.digest("SHA-256",e),r=Array.from(new Uint8Array(n));return r.map(t=>t.toString(16).padStart(2,"0")).join("")}function os(t){if(O(/[0-9a-zA-Z]+/.test(t),"Can only convert alpha-numeric strings"),"undefined"!==typeof TextEncoder)return(new TextEncoder).encode(t);const e=new ArrayBuffer(t.length),n=new Uint8Array(e);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const as=20;class cs extends ci{constructor(){super(...arguments),this.passiveListeners=new Set,this.initPromise=new Promise(t=>{this.resolveInialized=t})}addPassiveListener(t){this.passiveListeners.add(t)}removePassiveListener(t){this.passiveListeners.delete(t)}resetRedirect(){this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1}onEvent(t){return this.resolveInialized(),this.passiveListeners.forEach(e=>e(t)),super.onEvent(t)}async initialized(){await this.initPromise}}function us(t,e,n=null){return{type:e,eventId:n,urlResponse:null,sessionId:fs(),postBody:null,tenantId:t.tenantId,error:b(t,"no-auth-event")}}function ls(t,e){return ps()._set(ms(t),e)}async function hs(t){const e=await ps()._get(ms(t));return e&&await ps()._remove(ms(t)),e}function ds(t,e){var n,r;const i=ys(e);if(i.includes("/__/auth/callback")){const e=bs(i),s=e["firebaseError"]?gs(decodeURIComponent(e["firebaseError"])):null,o=null===(r=null===(n=null===s||void 0===s?void 0:s["code"])||void 0===n?void 0:n.split("auth/"))||void 0===r?void 0:r[1],a=o?b(o):null;return a?{type:t.type,eventId:t.eventId,tenantId:t.tenantId,error:a,urlResponse:null,sessionId:null,postBody:null}:{type:t.type,eventId:t.eventId,tenantId:t.tenantId,sessionId:t.sessionId,urlResponse:i,postBody:null}}return null}function fs(){const t=[],e="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";for(let n=0;n<as;n++){const n=Math.floor(Math.random()*e.length);t.push(e.charAt(n))}return t.join("")}function ps(){return k(Nn)}function ms(t){return ft("authEvent",t.config.apiKey,t.name)}function gs(t){try{return JSON.parse(t)}catch(e){return null}}function ys(t){const e=bs(t),n=e["link"]?decodeURIComponent(e["link"]):void 0,r=bs(n)["link"],i=e["deep_link_id"]?decodeURIComponent(e["deep_link_id"]):void 0,s=bs(i)["link"];return s||i||r||n||t}function bs(t){if(!(null===t||void 0===t?void 0:t.includes("?")))return{};const[e,...n]=t.split("?");return Object(r["y"])(n.join("?"))}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vs=500;class ws{constructor(){this._redirectPersistence=Rn,this._shouldInitProactively=!0,this.eventManagers=new Map,this.originValidationPromises={},this._completeRedirectFn=si}async _initialize(t){const e=t._key();let n=this.eventManagers.get(e);return n||(n=new cs(t),this.eventManagers.set(e,n),this.attachCallbackListeners(t,n)),n}_openPopup(t){y(t,"operation-not-supported-in-this-environment")}async _openRedirect(t,e,n,r){is(t);const i=await this._initialize(t);await i.initialized(),i.resetRedirect(),Yr(),await this._originValidation(t);const s=us(t,n,r);await ls(t,s);const o=await ts(t,s,e),a=await ns(o);return rs(t,i,a)}_isIframeWebStorageSupported(t,e){throw new Error("Method not implemented.")}_originValidation(t){const e=t._key();return this.originValidationPromises[e]||(this.originValidationPromises[e]=es(t)),this.originValidationPromises[e]}attachCallbackListeners(t,e){const{universalLinks:n,handleOpenURL:r,BuildInfo:i}=Xi(),s=setTimeout(async()=>{await hs(t),e.onEvent(Is())},vs),o=async n=>{clearTimeout(s);const r=await hs(t);let i=null;r&&(null===n||void 0===n?void 0:n["url"])&&(i=ds(r,n["url"])),e.onEvent(i||Is())};"undefined"!==typeof n&&"function"===typeof n.subscribe&&n.subscribe(null,o);const a=r,c=i.packageName.toLowerCase()+"://";Xi().handleOpenURL=async t=>{if(t.toLowerCase().startsWith(c)&&o({url:t}),"function"===typeof a)try{a(t)}catch(e){console.error(e)}}}}const _s=ws;function Is(){return{type:"unknown",eventId:null,sessionId:null,urlResponse:null,postBody:null,tenantId:null,error:b("no-auth-event")}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Es(t,e){Ct(t)._logFramework(e)}},"1fb5":function(t,e,n){"use strict";e.byteLength=l,e.toByteArray=d,e.fromByteArray=m;for(var r=[],i=[],s="undefined"!==typeof Uint8Array?Uint8Array:Array,o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",a=0,c=o.length;a<c;++a)r[a]=o[a],i[o.charCodeAt(a)]=a;function u(t){var e=t.length;if(e%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var n=t.indexOf("=");-1===n&&(n=e);var r=n===e?0:4-n%4;return[n,r]}function l(t){var e=u(t),n=e[0],r=e[1];return 3*(n+r)/4-r}function h(t,e,n){return 3*(e+n)/4-n}function d(t){var e,n,r=u(t),o=r[0],a=r[1],c=new s(h(t,o,a)),l=0,d=a>0?o-4:o;for(n=0;n<d;n+=4)e=i[t.charCodeAt(n)]<<18|i[t.charCodeAt(n+1)]<<12|i[t.charCodeAt(n+2)]<<6|i[t.charCodeAt(n+3)],c[l++]=e>>16&255,c[l++]=e>>8&255,c[l++]=255&e;return 2===a&&(e=i[t.charCodeAt(n)]<<2|i[t.charCodeAt(n+1)]>>4,c[l++]=255&e),1===a&&(e=i[t.charCodeAt(n)]<<10|i[t.charCodeAt(n+1)]<<4|i[t.charCodeAt(n+2)]>>2,c[l++]=e>>8&255,c[l++]=255&e),c}function f(t){return r[t>>18&63]+r[t>>12&63]+r[t>>6&63]+r[63&t]}function p(t,e,n){for(var r,i=[],s=e;s<n;s+=3)r=(t[s]<<16&16711680)+(t[s+1]<<8&65280)+(255&t[s+2]),i.push(f(r));return i.join("")}function m(t){for(var e,n=t.length,i=n%3,s=[],o=16383,a=0,c=n-i;a<c;a+=o)s.push(p(t,a,a+o>c?c:a+o));return 1===i?(e=t[n-1],s.push(r[e>>2]+r[e<<4&63]+"==")):2===i&&(e=(t[n-2]<<8)+t[n-1],s.push(r[e>>10]+r[e>>4&63]+r[e<<2&63]+"=")),s.join("")}i["-".charCodeAt(0)]=62,i["_".charCodeAt(0)]=63},"1fd5":function(t,e,n){"use strict";(function(t){n.d(e,"a",(function(){return h})),n.d(e,"b",(function(){return k})),n.d(e,"c",(function(){return T})),n.d(e,"d",(function(){return c})),n.d(e,"e",(function(){return j})),n.d(e,"f",(function(){return d})),n.d(e,"g",(function(){return F})),n.d(e,"h",(function(){return C})),n.d(e,"i",(function(){return u})),n.d(e,"j",(function(){return P})),n.d(e,"k",(function(){return B})),n.d(e,"l",(function(){return f})),n.d(e,"m",(function(){return g})),n.d(e,"n",(function(){return y})),n.d(e,"o",(function(){return v})),n.d(e,"p",(function(){return N})),n.d(e,"q",(function(){return w})),n.d(e,"r",(function(){return E})),n.d(e,"s",(function(){return p})),n.d(e,"t",(function(){return m})),n.d(e,"u",(function(){return b})),n.d(e,"v",(function(){return I})),n.d(e,"w",(function(){return _})),n.d(e,"x",(function(){return x})),n.d(e,"y",(function(){return D}));
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r=function(t){const e=[];let n=0;for(let r=0;r<t.length;r++){let i=t.charCodeAt(r);i<128?e[n++]=i:i<2048?(e[n++]=i>>6|192,e[n++]=63&i|128):55296===(64512&i)&&r+1<t.length&&56320===(64512&t.charCodeAt(r+1))?(i=65536+((1023&i)<<10)+(1023&t.charCodeAt(++r)),e[n++]=i>>18|240,e[n++]=i>>12&63|128,e[n++]=i>>6&63|128,e[n++]=63&i|128):(e[n++]=i>>12|224,e[n++]=i>>6&63|128,e[n++]=63&i|128)}return e},i=function(t){const e=[];let n=0,r=0;while(n<t.length){const i=t[n++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){const s=t[n++];e[r++]=String.fromCharCode((31&i)<<6|63&s)}else if(i>239&&i<365){const s=t[n++],o=t[n++],a=t[n++],c=((7&i)<<18|(63&s)<<12|(63&o)<<6|63&a)-65536;e[r++]=String.fromCharCode(55296+(c>>10)),e[r++]=String.fromCharCode(56320+(1023&c))}else{const s=t[n++],o=t[n++];e[r++]=String.fromCharCode((15&i)<<12|(63&s)<<6|63&o)}}return e.join("")},s={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:"function"===typeof atob,encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<t.length;i+=3){const e=t[i],s=i+1<t.length,o=s?t[i+1]:0,a=i+2<t.length,c=a?t[i+2]:0,u=e>>2,l=(3&e)<<4|o>>4;let h=(15&o)<<2|c>>6,d=63&c;a||(d=64,s||(h=64)),r.push(n[u],n[l],n[h],n[d])}return r.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(r(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):i(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const n=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<t.length;){const e=n[t.charAt(i++)],s=i<t.length,o=s?n[t.charAt(i)]:0;++i;const a=i<t.length,c=a?n[t.charAt(i)]:64;++i;const u=i<t.length,l=u?n[t.charAt(i)]:64;if(++i,null==e||null==o||null==c||null==l)throw Error();const h=e<<2|o>>4;if(r.push(h),64!==c){const t=o<<4&240|c>>2;if(r.push(t),64!==l){const t=c<<6&192|l;r.push(t)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}},o=function(t){const e=r(t);return s.encodeByteArray(e,!0)},a=function(t){return o(t).replace(/\./g,"")},c=function(t){try{return s.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function u(t,e){if(!(e instanceof Object))return e;switch(e.constructor){case Date:const n=e;return new Date(n.getTime());case Object:void 0===t&&(t={});break;case Array:t=[];break;default:return e}for(const n in e)e.hasOwnProperty(n)&&l(n)&&(t[n]=u(t[n],e[n]));return t}function l(t){return"__proto__"!==t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class h{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}wrapCallback(t){return(e,n)=>{e?this.reject(e):this.resolve(n),"function"===typeof t&&(this.promise.catch(()=>{}),1===t.length?t(e):t(e,n))}}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function d(t,e){if(t.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const n={alg:"none",type:"JWT"},r=e||"demo-project",i=t.iat||0,s=t.sub||t.user_id;if(!s)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o=Object.assign({iss:"https://securetoken.google.com/"+r,aud:r,iat:i,exp:i+3600,auth_time:i,sub:s,user_id:s,firebase:{sign_in_provider:"custom",identities:{}}},t),c="";return[a(JSON.stringify(n)),a(JSON.stringify(o)),c].join(".")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function f(){return"undefined"!==typeof navigator&&"string"===typeof navigator["userAgent"]?navigator["userAgent"]:""}function p(){return"undefined"!==typeof window&&!!(window["cordova"]||window["phonegap"]||window["PhoneGap"])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(f())}function m(){try{return"[object process]"===Object.prototype.toString.call(t.process)}catch(e){return!1}}function g(){return"object"===typeof self&&self.self===self}function y(){const t="object"===typeof chrome?chrome.runtime:"object"===typeof browser?browser.runtime:void 0;return"object"===typeof t&&void 0!==t.id}function b(){return"object"===typeof navigator&&"ReactNative"===navigator["product"]}function v(){return f().indexOf("Electron/")>=0}function w(){const t=f();return t.indexOf("MSIE ")>=0||t.indexOf("Trident/")>=0}function _(){return f().indexOf("MSAppHost/")>=0}function I(){return!m()&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function E(){return"object"===typeof indexedDB}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const O="FirebaseError";class T extends Error{constructor(t,e,n){super(e),this.code=t,this.customData=n,this.name=O,Object.setPrototypeOf(this,T.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,k.prototype.create)}}class k{constructor(t,e,n){this.service=t,this.serviceName=e,this.errors=n}create(t,...e){const n=e[0]||{},r=`${this.service}/${t}`,i=this.errors[t],s=i?S(i,n):"Error",o=`${this.serviceName}: ${s} (${r}).`,a=new T(r,o,n);return a}}function S(t,e){return t.replace(A,(t,n)=>{const r=e[n];return null!=r?String(r):`<${n}?>`})}const A=/\{\$([^}]+)}/g;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function j(t,e){return Object.prototype.hasOwnProperty.call(t,e)}function N(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}function C(t,e){if(t===e)return!0;const n=Object.keys(t),r=Object.keys(e);for(const i of n){if(!r.includes(i))return!1;const n=t[i],s=e[i];if(R(n)&&R(s)){if(!C(n,s))return!1}else if(n!==s)return!1}for(const i of r)if(!n.includes(i))return!1;return!0}function R(t){return null!==t&&"object"===typeof t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function x(t){const e=[];for(const[n,r]of Object.entries(t))Array.isArray(r)?r.forEach(t=>{e.push(encodeURIComponent(n)+"="+encodeURIComponent(t))}):e.push(encodeURIComponent(n)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function D(t){const e={},n=t.replace(/^\?/,"").split("&");return n.forEach(t=>{if(t){const[n,r]=t.split("=");e[decodeURIComponent(n)]=decodeURIComponent(r)}}),e}function P(t){const e=t.indexOf("?");if(!e)return"";const n=t.indexOf("#",e);return t.substring(e,n>0?n:void 0)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function F(t,e){const n=new L(t,e);return n.subscribe.bind(n)}class L{constructor(t,e){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=e,this.task.then(()=>{t(this)}).catch(t=>{this.error(t)})}next(t){this.forEachObserver(e=>{e.next(t)})}error(t){this.forEachObserver(e=>{e.error(t)}),this.close(t)}complete(){this.forEachObserver(t=>{t.complete()}),this.close()}subscribe(t,e,n){let r;if(void 0===t&&void 0===e&&void 0===n)throw new Error("Missing Observer.");r=M(t,["next","error","complete"])?t:{next:t,error:e,complete:n},void 0===r.next&&(r.next=U),void 0===r.error&&(r.error=U),void 0===r.complete&&(r.complete=U);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?r.error(this.finalError):r.complete()}catch(t){}}),this.observers.push(r),i}unsubscribeOne(t){void 0!==this.observers&&void 0!==this.observers[t]&&(delete this.observers[t],this.observerCount-=1,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))}forEachObserver(t){if(!this.finalized)for(let e=0;e<this.observers.length;e++)this.sendOne(e,t)}sendOne(t,e){this.task.then(()=>{if(void 0!==this.observers&&void 0!==this.observers[t])try{e(this.observers[t])}catch(n){"undefined"!==typeof console&&console.error&&console.error(n)}})}close(t){this.finalized||(this.finalized=!0,void 0!==t&&(this.finalError=t),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function M(t,e){if("object"!==typeof t||null===t)return!1;for(const n of e)if(n in t&&"function"===typeof t[n])return!0;return!1}function U(){}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function B(t){return t&&t._delegate?t._delegate:t}}).call(this,n("c8ba"))},"20a4":function(t,e,n){"use strict";e["a"]=(()=>"undefined"!==typeof self?self:"undefined"!==typeof window?window:Function("return this")())()},"21bf":function(t,e,n){(function(e){(function(e,n){t.exports=n()})(0,(function(){var t=t||function(t,r){var i;if("undefined"!==typeof window&&window.crypto&&(i=window.crypto),"undefined"!==typeof self&&self.crypto&&(i=self.crypto),"undefined"!==typeof globalThis&&globalThis.crypto&&(i=globalThis.crypto),!i&&"undefined"!==typeof window&&window.msCrypto&&(i=window.msCrypto),!i&&"undefined"!==typeof e&&e.crypto&&(i=e.crypto),!i)try{i=n(1)}catch(y){}var s=function(){if(i){if("function"===typeof i.getRandomValues)try{return i.getRandomValues(new Uint32Array(1))[0]}catch(y){}if("function"===typeof i.randomBytes)try{return i.randomBytes(4).readInt32LE()}catch(y){}}throw new Error("Native crypto module could not be used to get secure random number.")},o=Object.create||function(){function t(){}return function(e){var n;return t.prototype=e,n=new t,t.prototype=null,n}}(),a={},c=a.lib={},u=c.Base=function(){return{extend:function(t){var e=o(this);return t&&e.mixIn(t),e.hasOwnProperty("init")&&this.init!==e.init||(e.init=function(){e.$super.init.apply(this,arguments)}),e.init.prototype=e,e.$super=this,e},create:function(){var t=this.extend();return t.init.apply(t,arguments),t},init:function(){},mixIn:function(t){for(var e in t)t.hasOwnProperty(e)&&(this[e]=t[e]);t.hasOwnProperty("toString")&&(this.toString=t.toString)},clone:function(){return this.init.prototype.extend(this)}}}(),l=c.WordArray=u.extend({init:function(t,e){t=this.words=t||[],this.sigBytes=e!=r?e:4*t.length},toString:function(t){return(t||d).stringify(this)},concat:function(t){var e=this.words,n=t.words,r=this.sigBytes,i=t.sigBytes;if(this.clamp(),r%4)for(var s=0;s<i;s++){var o=n[s>>>2]>>>24-s%4*8&255;e[r+s>>>2]|=o<<24-(r+s)%4*8}else for(var a=0;a<i;a+=4)e[r+a>>>2]=n[a>>>2];return this.sigBytes+=i,this},clamp:function(){var e=this.words,n=this.sigBytes;e[n>>>2]&=4294967295<<32-n%4*8,e.length=t.ceil(n/4)},clone:function(){var t=u.clone.call(this);return t.words=this.words.slice(0),t},random:function(t){for(var e=[],n=0;n<t;n+=4)e.push(s());return new l.init(e,t)}}),h=a.enc={},d=h.Hex={stringify:function(t){for(var e=t.words,n=t.sigBytes,r=[],i=0;i<n;i++){var s=e[i>>>2]>>>24-i%4*8&255;r.push((s>>>4).toString(16)),r.push((15&s).toString(16))}return r.join("")},parse:function(t){for(var e=t.length,n=[],r=0;r<e;r+=2)n[r>>>3]|=parseInt(t.substr(r,2),16)<<24-r%8*4;return new l.init(n,e/2)}},f=h.Latin1={stringify:function(t){for(var e=t.words,n=t.sigBytes,r=[],i=0;i<n;i++){var s=e[i>>>2]>>>24-i%4*8&255;r.push(String.fromCharCode(s))}return r.join("")},parse:function(t){for(var e=t.length,n=[],r=0;r<e;r++)n[r>>>2]|=(255&t.charCodeAt(r))<<24-r%4*8;return new l.init(n,e)}},p=h.Utf8={stringify:function(t){try{return decodeURIComponent(escape(f.stringify(t)))}catch(e){throw new Error("Malformed UTF-8 data")}},parse:function(t){return f.parse(unescape(encodeURIComponent(t)))}},m=c.BufferedBlockAlgorithm=u.extend({reset:function(){this._data=new l.init,this._nDataBytes=0},_append:function(t){"string"==typeof t&&(t=p.parse(t)),this._data.concat(t),this._nDataBytes+=t.sigBytes},_process:function(e){var n,r=this._data,i=r.words,s=r.sigBytes,o=this.blockSize,a=4*o,c=s/a;c=e?t.ceil(c):t.max((0|c)-this._minBufferSize,0);var u=c*o,h=t.min(4*u,s);if(u){for(var d=0;d<u;d+=o)this._doProcessBlock(i,d);n=i.splice(0,u),r.sigBytes-=h}return new l.init(n,h)},clone:function(){var t=u.clone.call(this);return t._data=this._data.clone(),t},_minBufferSize:0}),g=(c.Hasher=m.extend({cfg:u.extend(),init:function(t){this.cfg=this.cfg.extend(t),this.reset()},reset:function(){m.reset.call(this),this._doReset()},update:function(t){return this._append(t),this._process(),this},finalize:function(t){t&&this._append(t);var e=this._doFinalize();return e},blockSize:16,_createHelper:function(t){return function(e,n){return new t.init(n).finalize(e)}},_createHmacHelper:function(t){return function(e,n){return new g.HMAC.init(t,n).finalize(e)}}}),a.algo={});return a}(Math);return t}))}).call(this,n("c8ba"))},"22e5":function(t,e,n){"use strict";n.d(e,"a",(function(){return i})),n.d(e,"b",(function(){return u}));var r=n("1fd5");class i{constructor(t,e,n){this.name=t,this.instanceFactory=e,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const s="[DEFAULT]";
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o{constructor(t,e){this.name=t,this.container=e,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const e=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(e)){const t=new r["a"];if(this.instancesDeferred.set(e,t),this.isInitialized(e)||this.shouldAutoInitialize())try{const n=this.getOrInitializeService({instanceIdentifier:e});n&&t.resolve(n)}catch(n){}}return this.instancesDeferred.get(e).promise}getImmediate(t){var e;const n=this.normalizeInstanceIdentifier(null===t||void 0===t?void 0:t.identifier),r=null!==(e=null===t||void 0===t?void 0:t.optional)&&void 0!==e&&e;if(!this.isInitialized(n)&&!this.shouldAutoInitialize()){if(r)return null;throw Error(`Service ${this.name} is not available`)}try{return this.getOrInitializeService({instanceIdentifier:n})}catch(i){if(r)return null;throw i}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,this.shouldAutoInitialize()){if(c(t))try{this.getOrInitializeService({instanceIdentifier:s})}catch(e){}for(const[t,n]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(t);try{const t=this.getOrInitializeService({instanceIdentifier:r});n.resolve(t)}catch(e){}}}}clearInstance(t=s){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...t.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return null!=this.component}isInitialized(t=s){return this.instances.has(t)}getOptions(t=s){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:e={}}=t,n=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:n,options:e});for(const[i,s]of this.instancesDeferred.entries()){const t=this.normalizeInstanceIdentifier(i);n===t&&s.resolve(r)}return r}onInit(t,e){var n;const r=this.normalizeInstanceIdentifier(e),i=null!==(n=this.onInitCallbacks.get(r))&&void 0!==n?n:new Set;i.add(t),this.onInitCallbacks.set(r,i);const s=this.instances.get(r);return s&&t(s,r),()=>{i.delete(t)}}invokeOnInitCallbacks(t,e){const n=this.onInitCallbacks.get(e);if(n)for(const i of n)try{i(t,e)}catch(r){}}getOrInitializeService({instanceIdentifier:t,options:e={}}){let n=this.instances.get(t);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:a(t),options:e}),this.instances.set(t,n),this.instancesOptions.set(t,e),this.invokeOnInitCallbacks(n,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,n)}catch(r){}return n||null}normalizeInstanceIdentifier(t=s){return this.component?this.component.multipleInstances?t:s:t}shouldAutoInitialize(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode}}function a(t){return t===s?void 0:t}function c(t){return"EAGER"===t.instantiationMode}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const e=this.getProvider(t.name);if(e.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);e.setComponent(t)}addOrOverwriteComponent(t){const e=this.getProvider(t.name);e.isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const e=new o(t,this);return this.providers.set(t,e),e}getProviders(){return Array.from(this.providers.values())}}},2444:function(t,e,n){"use strict";(function(e){var r=n("c532"),i=n("c8af"),s=n("387f"),o={"Content-Type":"application/x-www-form-urlencoded"};function a(t,e){!r.isUndefined(t)&&r.isUndefined(t["Content-Type"])&&(t["Content-Type"]=e)}function c(){var t;return("undefined"!==typeof XMLHttpRequest||"undefined"!==typeof e&&"[object process]"===Object.prototype.toString.call(e))&&(t=n("b50d")),t}function u(t,e,n){if(r.isString(t))try{return(e||JSON.parse)(t),r.trim(t)}catch(i){if("SyntaxError"!==i.name)throw i}return(n||JSON.stringify)(t)}var l={transitional:{silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1},adapter:c(),transformRequest:[function(t,e){return i(e,"Accept"),i(e,"Content-Type"),r.isFormData(t)||r.isArrayBuffer(t)||r.isBuffer(t)||r.isStream(t)||r.isFile(t)||r.isBlob(t)?t:r.isArrayBufferView(t)?t.buffer:r.isURLSearchParams(t)?(a(e,"application/x-www-form-urlencoded;charset=utf-8"),t.toString()):r.isObject(t)||e&&"application/json"===e["Content-Type"]?(a(e,"application/json"),u(t)):t}],transformResponse:[function(t){var e=this.transitional||l.transitional,n=e&&e.silentJSONParsing,i=e&&e.forcedJSONParsing,o=!n&&"json"===this.responseType;if(o||i&&r.isString(t)&&t.length)try{return JSON.parse(t)}catch(a){if(o){if("SyntaxError"===a.name)throw s(a,this,"E_JSON_PARSE");throw a}}return t}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,validateStatus:function(t){return t>=200&&t<300},headers:{common:{Accept:"application/json, text/plain, */*"}}};r.forEach(["delete","get","head"],(function(t){l.headers[t]={}})),r.forEach(["post","put","patch"],(function(t){l.headers[t]=r.merge(o)})),t.exports=l}).call(this,n("4362"))},"2d83":function(t,e,n){"use strict";var r=n("387f");t.exports=function(t,e,n,i,s){var o=new Error(t);return r(o,e,n,i,s)}},"2e67":function(t,e,n){"use strict";t.exports=function(t){return!(!t||!t.__CANCEL__)}},"30b5":function(t,e,n){"use strict";var r=n("c532");function i(t){return encodeURIComponent(t).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}t.exports=function(t,e,n){if(!e)return t;var s;if(n)s=n(e);else if(r.isURLSearchParams(e))s=e.toString();else{var o=[];r.forEach(e,(function(t,e){null!==t&&"undefined"!==typeof t&&(r.isArray(t)?e+="[]":t=[t],r.forEach(t,(function(t){r.isDate(t)?t=t.toISOString():r.isObject(t)&&(t=JSON.stringify(t)),o.push(i(e)+"="+i(t))})))})),s=o.join("&")}if(s){var a=t.indexOf("#");-1!==a&&(t=t.slice(0,a)),t+=(-1===t.indexOf("?")?"?":"&")+s}return t}},"33e8":function(t,e,n){"use strict";n.d(e,"e",(function(){return O})),n.d(e,"c",(function(){return h})),n.d(e,"d",(function(){return I})),n.d(e,"a",(function(){return w})),n.d(e,"b",(function(){return E}));const r=Object.create(null);r["open"]="0",r["close"]="1",r["ping"]="2",r["pong"]="3",r["message"]="4",r["upgrade"]="5",r["noop"]="6";const i=Object.create(null);Object.keys(r).forEach(t=>{i[r[t]]=t});const s={type:"error",data:"parser error"},o="function"===typeof Blob||"undefined"!==typeof Blob&&"[object BlobConstructor]"===Object.prototype.toString.call(Blob),a="function"===typeof ArrayBuffer,c=t=>"function"===typeof ArrayBuffer.isView?ArrayBuffer.isView(t):t&&t.buffer instanceof ArrayBuffer,u=({type:t,data:e},n,i)=>o&&e instanceof Blob?n?i(e):l(e,i):a&&(e instanceof ArrayBuffer||c(e))?n?i(e):l(new Blob([e]),i):i(r[t]+(e||"")),l=(t,e)=>{const n=new FileReader;return n.onload=function(){const t=n.result.split(",")[1];e("b"+t)},n.readAsDataURL(t)};for(var h=u,d="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",f="undefined"===typeof Uint8Array?[]:new Uint8Array(256),p=0;p<d.length;p++)f[d.charCodeAt(p)]=p;var m=function(t){var e,n,r,i,s,o=.75*t.length,a=t.length,c=0;"="===t[t.length-1]&&(o--,"="===t[t.length-2]&&o--);var u=new ArrayBuffer(o),l=new Uint8Array(u);for(e=0;e<a;e+=4)n=f[t.charCodeAt(e)],r=f[t.charCodeAt(e+1)],i=f[t.charCodeAt(e+2)],s=f[t.charCodeAt(e+3)],l[c++]=n<<2|r>>4,l[c++]=(15&r)<<4|i>>2,l[c++]=(3&i)<<6|63&s;return u};const g="function"===typeof ArrayBuffer,y=(t,e)=>{if("string"!==typeof t)return{type:"message",data:v(t,e)};const n=t.charAt(0);if("b"===n)return{type:"message",data:b(t.substring(1),e)};const r=i[n];return r?t.length>1?{type:i[n],data:t.substring(1)}:{type:i[n]}:s},b=(t,e)=>{if(g){const n=m(t);return v(n,e)}return{base64:!0,data:t}},v=(t,e)=>{switch(e){case"blob":return t instanceof ArrayBuffer?new Blob([t]):t;case"arraybuffer":default:return t}};var w=y;const _=String.fromCharCode(30),I=(t,e)=>{const n=t.length,r=new Array(n);let i=0;t.forEach((t,s)=>{h(t,!1,t=>{r[s]=t,++i===n&&e(r.join(_))})})},E=(t,e)=>{const n=t.split(_),r=[];for(let i=0;i<n.length;i++){const t=w(n[i],e);if(r.push(t),"error"===t.type)break}return r},O=4},"34ba":function(t,e,n){"use strict";n.d(e,"a",(function(){return o}));var r=n("33e8"),i=n("b19d"),s=n("af7f");class o extends i["Emitter"]{constructor(t){super(),this.writable=!1,Object(s["a"])(this,t),this.opts=t,this.query=t.query,this.readyState="",this.socket=t.socket}onError(t,e){const n=new Error(t);return n.type="TransportError",n.description=e,super.emit("error",n),this}open(){return"closed"!==this.readyState&&""!==this.readyState||(this.readyState="opening",this.doOpen()),this}close(){return"opening"!==this.readyState&&"open"!==this.readyState||(this.doClose(),this.onClose()),this}send(t){"open"===this.readyState&&this.write(t)}onOpen(){this.readyState="open",this.writable=!0,super.emit("open")}onData(t){const e=Object(r["a"])(t,this.socket.binaryType);this.onPacket(e)}onPacket(t){super.emit("packet",t)}onClose(){this.readyState="closed",super.emit("close")}}},"387f":function(t,e,n){"use strict";t.exports=function(t,e,n,r,i){return t.config=e,n&&(t.code=n),t.request=r,t.response=i,t.isAxiosError=!0,t.toJSON=function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:this.config,code:this.code,status:this.response&&this.response.status?this.response.status:null}},t}},3934:function(t,e,n){"use strict";var r=n("c532");t.exports=r.isStandardBrowserEnv()?function(){var t,e=/(msie|trident)/i.test(navigator.userAgent),n=document.createElement("a");function i(t){var r=t;return e&&(n.setAttribute("href",r),r=n.href),n.setAttribute("href",r),{href:n.href,protocol:n.protocol?n.protocol.replace(/:$/,""):"",host:n.host,search:n.search?n.search.replace(/^\?/,""):"",hash:n.hash?n.hash.replace(/^#/,""):"",hostname:n.hostname,port:n.port,pathname:"/"===n.pathname.charAt(0)?n.pathname:"/"+n.pathname}}return t=i(window.location.href),function(e){var n=r.isString(e)?i(e):e;return n.protocol===t.protocol&&n.host===t.host}}():function(){return function(){return!0}}()},"3f4e":function(t,e,n){"use strict";n.d(e,"setupDevtoolsPlugin",(function(){return o}));var r=n("abc5"),i=n("b774"),s=n("f30a");function o(t,e){const n=Object(r["b"])(),o=Object(r["a"])(),a=r["c"]&&t.enableEarlyProxy;if(!o||!n.__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__&&a){const r=a?new s["a"](t,o):null,i=n.__VUE_DEVTOOLS_PLUGINS__=n.__VUE_DEVTOOLS_PLUGINS__||[];i.push({pluginDescriptor:t,setupFn:e,proxy:r}),r&&e(r.proxiedTarget)}else o.emit(i["b"],t,e)}},4362:function(t,e,n){e.nextTick=function(t){var e=Array.prototype.slice.call(arguments);e.shift(),setTimeout((function(){t.apply(null,e)}),0)},e.platform=e.arch=e.execPath=e.title="browser",e.pid=1,e.browser=!0,e.env={},e.argv=[],e.binding=function(t){throw new Error("No such module. (Possibly not yet loaded)")},function(){var t,r="/";e.cwd=function(){return r},e.chdir=function(e){t||(t=n("df7c")),r=t.resolve(e,r)}}(),e.exit=e.kill=e.umask=e.dlopen=e.uptime=e.memoryUsage=e.uvCounters=function(){},e.features={}},"467f":function(t,e,n){"use strict";var r=n("2d83");t.exports=function(t,e,n){var i=n.config.validateStatus;n.status&&i&&!i(n.status)?e(r("Request failed with status code "+n.status,n.config,null,n.request,n)):t(n)}},4705:function(t,e,n){"use strict";function r(t,e,n,r,i,s){return null}var i=n("a5fa"),s=i["a"].next({name:"service:toast",properties:["data"],setup:function(t){return{vue:i["a"]}}}),o=n("6b0d"),a=n.n(o);const c=a()(s,[["render",r]]);var u=c;function l(t,e,n,r,i,s){return null}var h=i["a"].next({name:"service:notification",properties:["data"],setup:function(t){return{vue:i["a"]}}});const d=a()(h,[["render",l]]);var f=d,p=n("7a23");const m={element:""};function g(t,e,n,r,i,s){return Object(p["u"])(),Object(p["f"])("div",m,[Object(p["A"])(t.$slots,"default")])}var y=i["a"].next({name:"element",properties:[],setup:function(t){return{vue:i["a"]}}});const b=a()(y,[["render",g]]);var v=b;const w={element:"text","pixel-view":"",text:""};function _(t,e,n,r,i,s){return Object(p["u"])(),Object(p["f"])("span",w,[Object(p["A"])(t.$slots,"default")])}var I=i["a"].next({name:"text",properties:[],setup:function(t){return{vue:i["a"]}}});const E=a()(I,[["render",_]]);var O=E;function T(t,e,n,r,i,s){return Object(p["u"])(),Object(p["f"])("span",{class:Object(p["o"])(t.css),element:"icon:material",icon:""},Object(p["E"])(t.src),3)}var k=i["a"].next({name:"icon:material",properties:["src","style-sheet"],setup:function(t){var e=i["a"].reference(A[t.src]||t.src),n=i["a"].reference(t[i["a"].prop("style-sheet")]||S.style.name),r=i["a"].reference(n.value?[S.css,S.style.sheet[n.value]||n.value].join("-"):S.css);return i["a"].watch(t,(function(){e.value=A[t.src]||t.src,(n.value=t[i["a"].prop("style-sheet")]||S.style.name)&&(r.value=[S.css,S.style.sheet[n.value]||n.value].join("-"))})),{vue:i["a"],css:r,src:e}}}),S={css:"material-icon".concat("s"),style:{name:null,sheet:{line:"out".concat("line").concat("d"),tone:"two".concat("-").concat("tone")}}},A={icon:""};const j=a()(k,[["render",T]]);var N=j;const C={key:0,element:"button:material"},R={key:1,element:"button:material"};function x(t,e,n,r,i,s){const o=Object(p["B"])("div:text"),a=Object(p["B"])("icon:material");return"end"===t.icon.position?(Object(p["u"])(),Object(p["f"])("button",C,[t.slot()?(Object(p["u"])(),Object(p["d"])(o,{key:0},{default:Object(p["M"])(()=>[Object(p["A"])(t.$slots,"default")]),_:3})):Object(p["e"])("",!0),t.icon.src?(Object(p["u"])(),Object(p["d"])(a,{key:1,src:t.icon.src,"style-sheet":t.icon.style},null,8,["src","style-sheet"])):Object(p["e"])("",!0)])):(Object(p["u"])(),Object(p["f"])("button",R,[t.icon.src?(Object(p["u"])(),Object(p["d"])(a,{key:0,src:t.icon.src,"style-sheet":t.icon.style},null,8,["src","style-sheet"])):Object(p["e"])("",!0),t.slot()?(Object(p["u"])(),Object(p["d"])(o,{key:1},{default:Object(p["M"])(()=>[Object(p["A"])(t.$slots,"default")]),_:3})):Object(p["e"])("",!0)]))}var D=i["a"].next({name:"button:material",properties:["icon","icon-style","icon-position"],setup:function(t){var e=i["a"].reactive({src:t.icon,style:t[i["a"].prop("icon-style")],position:t[i["a"].prop("icon-position")]});return i["a"].watch(t,(function(){e.src=t.icon,e.style=t[i["a"].prop("icon-style")],e.position=t[i["a"].prop("icon-position")]})),{vue:i["a"],icon:e}},method:{function(){},slot(){return i["a"].slot(this).default}}});const P=a()(D,[["render",x]]);var F=P;const L=["for","autocapitalize","autocorrect","autocomplete","spellcheck"],M=["autocapitalize","autocorrect","autocomplete","spellcheck"];function U(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("textarea",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,element:"text:area"},null,40,L)),[[p["J"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("textarea",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,element:"text:area"},null,8,M)),[[p["J"],t.vue.model[t.model]]])}var B=i["a"].next({name:"text:area",properties:["for","capitalize","correct","complete","spell","model"],setup:function(t){var e=i["a"].reactive(i["a"].element.io.attribute(t)),n=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){(e=i["a"].reactive(i["a"].element.io.attribute(t)))&&(n.value=i["a"].form.model.format(t.model))})),{vue:i["a"],properties:t,attribute:e,model:n}}});const q=a()(B,[["render",U]]);var V=q;const z=["for","autocapitalize","autocorrect","autocomplete","spellcheck"],H=["autocapitalize","autocorrect","autocomplete","spellcheck"];function K(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,element:"form:input"},null,40,z)),[[p["J"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,element:"form:input"},null,8,H)),[[p["J"],t.vue.model[t.model]]])}var $=i["a"].next({name:"form:input",properties:["for","capitalize","correct","complete","spell","model"],setup:function(t){var e=i["a"].reactive(i["a"].element.io.attribute(t)),n=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){(e=i["a"].reactive(i["a"].element.io.attribute(t)))&&(n.value=i["a"].form.model.format(t.model))})),{vue:i["a"],properties:t,attribute:e,model:n}}});const G=a()($,[["render",K]]);var W=G;const Y=["for","autocapitalize","autocorrect","autocomplete","spellcheck"],Q=["autocapitalize","autocorrect","autocomplete","spellcheck"];function J(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"text",element:"input:text"},null,40,Y)),[[p["J"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"text",element:"input:text"},null,8,Q)),[[p["J"],t.vue.model[t.model]]])}var X=i["a"].next({name:"input:text",properties:["for","capitalize","correct","complete","spell","model"],setup:function(t){var e=i["a"].reactive(i["a"].element.io.attribute(t)),n=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){(e=i["a"].reactive(i["a"].element.io.attribute(t)))&&(n.value=i["a"].form.model.format(t.model))})),{vue:i["a"],properties:t,attribute:e,model:n}}});const Z=a()(X,[["render",J]]);var tt=Z;const et=["for","autocapitalize","autocorrect","autocomplete","spellcheck"],nt=["autocapitalize","autocorrect","autocomplete","spellcheck"];function rt(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"password",element:"input:password"},null,40,et)),[[p["J"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"password",element:"input:password"},null,8,nt)),[[p["J"],t.vue.model[t.model]]])}var it=i["a"].next({name:"input:password",properties:["for","capitalize","correct","complete","spell","model"],setup:function(t){var e=i["a"].reactive(i["a"].element.io.attribute(t)),n=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){(e=i["a"].reactive(i["a"].element.io.attribute(t)))&&(n.value=i["a"].form.model.format(t.model))})),{vue:i["a"],properties:t,attribute:e,model:n}}});const st=a()(it,[["render",rt]]);var ot=st;const at=["for","autocapitalize","autocorrect","autocomplete","spellcheck"],ct=["autocapitalize","autocorrect","autocomplete","spellcheck"];function ut(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"date",element:"input:date"},null,40,at)),[[p["J"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),autocapitalize:t.attribute.capitalize,autocorrect:t.attribute.correct,autocomplete:t.attribute.complete,spellcheck:t.attribute.spell,type:"date",element:"input:date"},null,8,ct)),[[p["J"],t.vue.model[t.model]]])}var lt=i["a"].next({name:"input:date",properties:["for","capitalize","correct","complete","spell","model"],setup:function(t){var e=i["a"].reactive(i["a"].element.io.attribute(t)),n=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){(e=i["a"].reactive(i["a"].element.io.attribute(t)))&&(n.value=i["a"].form.model.format(t.model))})),{vue:i["a"],properties:t,attribute:e,model:n}}});const ht=a()(lt,[["render",ut]]);var dt=ht;const ft=["for"];function pt(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),type:"checkbox",element:"input:check"},null,40,ft)),[[p["H"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),type:"checkbox",element:"input:check"},null,512)),[[p["H"],t.vue.model[t.model]]])}var mt=i["a"].next({name:"input:check",properties:["for","model"],setup:function(t){var e=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){e.value=i["a"].form.model.format(t.model)})),{vue:i["a"],properties:t,model:e}}});const gt=a()(mt,[["render",pt]]);var yt=gt;const bt=["for"];function vt(t,e,n,r,i,s){return t.properties.for?Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:0,for:t.properties.for,"onUpdate:modelValue":e[0]||(e[0]=e=>t.vue.model[t.model]=e),onFocus:e[1]||(e[1]=(...e)=>t.vue.element.io.focus&&t.vue.element.io.focus(...e)),onBlur:e[2]||(e[2]=(...e)=>t.vue.element.io.blur&&t.vue.element.io.blur(...e)),type:"radio",element:"input:bullet"},null,40,bt)),[[p["I"],t.vue.model[t.model]]]):Object(p["N"])((Object(p["u"])(),Object(p["f"])("input",{key:1,"onUpdate:modelValue":e[3]||(e[3]=e=>t.vue.model[t.model]=e),type:"radio",element:"input:bullet"},null,512)),[[p["I"],t.vue.model[t.model]]])}var wt=i["a"].next({name:"input:bullet",properties:["for","model"],setup:function(t){var e=i["a"].reference(i["a"].form.model.format(t.model));return i["a"].watch(t,(function(){e.value=i["a"].form.model.format(t.model)})),{vue:i["a"],properties:t,model:e}}});const _t=a()(wt,[["render",vt]]);var It=_t,Et={"service:toast":u,"service:notification":f,element:v,"span:text":O,"icon:material":N,"button:material":F,"form:input":W,"text:area":V,"input:text":tt,"input:password":ot,"input:date":dt,"input:check":yt,"input:bullet":It};e["a"]={install:function(t,e){for(var n in t.directive("element",(function(t,e){})),t.directive("component",(function(t,e){})),Et)t.component(n,Et[n])}}},"4a7b":function(t,e,n){"use strict";var r=n("c532");t.exports=function(t,e){e=e||{};var n={};function i(t,e){return r.isPlainObject(t)&&r.isPlainObject(e)?r.merge(t,e):r.isPlainObject(e)?r.merge({},e):r.isArray(e)?e.slice():e}function s(n){return r.isUndefined(e[n])?r.isUndefined(t[n])?void 0:i(void 0,t[n]):i(t[n],e[n])}function o(t){if(!r.isUndefined(e[t]))return i(void 0,e[t])}function a(n){return r.isUndefined(e[n])?r.isUndefined(t[n])?void 0:i(void 0,t[n]):i(void 0,e[n])}function c(n){return n in e?i(t[n],e[n]):n in t?i(void 0,t[n]):void 0}var u={url:o,method:o,data:o,baseURL:a,transformRequest:a,transformResponse:a,paramsSerializer:a,timeout:a,timeoutMessage:a,withCredentials:a,adapter:a,responseType:a,xsrfCookieName:a,xsrfHeaderName:a,onUploadProgress:a,onDownloadProgress:a,decompress:a,maxContentLength:a,maxBodyLength:a,transport:a,httpAgent:a,httpsAgent:a,cancelToken:a,socketPath:a,responseEncoding:a,validateStatus:c};return r.forEach(Object.keys(t).concat(Object.keys(e)),(function(t){var e=u[t]||s,i=e(t);r.isUndefined(i)&&e!==c||(n[t]=i)})),n}},"4a85":function(t,e,n){"use strict";var r=n("a5fa"),i=n("3234");r["a"].package=i;let{zero:s,one:o}=r["b"];r["a"].start=function(){r["a"].route=r["b"].route(),r["a"].router=r["b"].router(),r["a"].x=r["a"].store.use(),r["a"].date.start(),r["a"].account.start(),(r["a"].visitor=r["b"].visitor())&&(r["b"].dom.attribute("body","device",r["a"].visitor.device.name),["computer"].exist(r["a"].visitor.device.name)?r["a"].computer=!0:r["a"].mobile=!0),r["a"].socket.emit("package").then((function(t){r["a"].package=r["a"].reactive(r["b"].object.merge(r["a"].package,t.package)),r["a"].visitor=r["a"].reactive(r["b"].object.merge(r["a"].visitor,t.visitor)),r["a"].session.apply(t.session),r["a"].language.apply(t.language),r["a"].package.language&&(r["a"].language.list=r["a"].package.language.list),r["a"].db.setup(),r["a"].emit("set:up"),r["a"].ping.cache=r["b"].time.interval((function(){r["a"].emit("ping")}),r["a"].ping.interval=r["a"].package.ping.interval),r["b"].time.sleep((function(){r["a"].ready.value=!0}))})),r["a"].emit("setup")},r["a"].system=function(){},r["a"].system.ready=r["a"].reference(),r["a"].ready=r["a"].reference(),r["a"].setup=function(t,e){return r["b"].is.function(t)&&(e=t)&&(t=r["b"].un.define()),r["a"].system.ready.value&&e&&e.call(),r["a"].watch(r["a"].ready,(function(t){t&&e&&(r["a"].system.ready.value=!0)&&e.call()})),r["b"].object.join({vue:r["a"]},t)},window.url=r["b"].url.parse(r["b"].string(window.location)),r["a"].url=r["a"].reactive(),r["a"].url.param=function(t){return r["a"].route["param".concat("s")][t]},r["a"].url.previous=function(t=o){r["a"].router.go(-t)},r["a"].url.go=function(t,e){return r["b"].is.object(t)||"/"===t.begin()?r["a"].router.push(t):r["a"].router.push(r["b"].object.assign({name:t},e))},r["a"].parse_url=function(t=!0){var e=window.location.protocol.pop(),n=window.location.host,i=r["a"].route.path,s=r["b"].url.query.format(r["a"].route.query),o=r["b"].url.parse(e.concat("://").concat(n).concat(i).concat(s));for(var a in o)r["a"].url[a]=o[a]},r["a"].fetch=function(...t){return r["a"].fetch.get(...t)},r["a"].fetch.get=function(t,e){return t=[t],e&&t.push({["header".concat("s")]:e}),r["a"].request.get(...t)},r["a"].fetch.post=function(t,e,n){return r["a"].request.post(t,e,n)};var a=r["b"].object.assign({id:r["b"].session.shuffle()},r["a"].package.session);r["a"].session=new r["b"].session.manager,r["a"].session.start(a,(function(t){}));var c={url:r["b"].dom.attribute("meta[property=socket:url]","content")||r["a"].package["socket:url"]||"",token:r["b"].dom.attribute("meta[property=socket:token]","content")||r["a"].package["socket:token"]||"",key:null,value:null,option:function(){this.http={url:c.url},this.url=r["b"].web.socket.url(c.url),this.token=c.token,this.session=r["a"].session.id}};function u(t,e){return r["a"].language(t,e)}r["a"].socket=new r["b"].web.socket.io(c.option,(function(){})),r["a"].socket.connect(),r["a"].socket.get=function(t,e){return r["a"].fetch.get(this.http.url.concat(t),r["b"].object.assign({token:this.token},e))},r["a"].socket.post=function(t,e,n){return r["a"].fetch.post(this.http.url.concat(t),e,r["b"].object.assign({token:this.token},n))},r["a"].commit=function(t){return r["a"].x.commit("mutation",t)},r["a"].dispatch=function(t){return r["a"].x.dispatch("action",t)},r["a"].package.fire&&r["a"].package.fire.base&&(r["a"].fire={base:new r["b"].plugin.google.fire.base},r["a"].fire.base.start(r["a"].package.fire.base,c.url)),r["a"].language=function(t,e){return t?r["a"].__[t]||e||"":r["a"].__},r["a"].language.apply=function(t){for(var e in t)r["a"].__[e]=t[e]},r["a"].language.exist=function(t){return r["a"].language.list.exist(t)||t in r["c"].language},r["a"].language.set=function(t,...e){e=r["b"].function.argument(...e),e.object;var n=e.function,i=e.boolean;"universal"===t&&(r["a"].language.apply(r["c"].language.universal),r["a"].session.set("language",t,i),r["a"].socket.emit("session",{language:t}).then(n)),r["a"].language.exist(t)&&r["a"].socket.emit("language:set",t).then((function(e){r["a"].language.apply(e),r["a"].session.set("language",t,i),n&&n.call(null,t)}))},r["a"].language.list=[],r["a"].language.apply((r["c"].language={universal:r["a"].package.language.data}).universal),r["a"].date=r["a"].reactive({start:function(){r["b"].date.universal(r["b"].date.zone["universal"].offset),r["a"].date.set("time:zone",r["a"].session.get("time:zone"),{session:!0}),r["a"].date.routine(),r["a"].date.cache=r["b"].time.interval(r["a"].date.routine)},routine:function(){r["a"].date.create=r["b"].date.create({zone:r["a"].time.zone.offset}),r["a"].date.time=r["a"].date.create(r["a"].time.stamp=r["b"].time.stamp()),r["a"].date.time.use("month:name",r["a"].language("date-time:month")),r["a"].date.time.use("day:name",r["a"].language("date-time:day")),r["a"].date.current=r["a"].date.time.format(),r["a"].date.transform.current=r["a"].date.time.format("date"),r["a"].emit("date:routine")},format:function(...t){var e,n="default",i=r["a"].time.stamp;for(var s in t)r["b"].is.number(t[s])&&(i=t[s]),r["b"].is.string(t[s])&&(n=t[s]),r["b"].is.object(t[s])&&(e=t[s]);return r["a"].date.create(i).format(n,e)},transform:function(t,...e){return r["a"].date.create(t).format(...e)},factory:function(t){t=t.string();var e=t.substr(0,4),n=t.substr(4,2),r=t.substr(6,2);return r.concat("/").concat(n).concat("/").concat(e)},set:function(t,e,...n){n=r["b"].function.argument(...n);var i=n.object||{},s=n.function;"time:zone"===t&&(e in r["b"].time.zone||"universal"===e)&&(r["a"].time.zone={name:r["a"].session.set("time:zone",e,i.session)},r["a"].time.zone.offset=r["b"].time.zone(r["a"].time.zone.name).offset,r["a"].socket.emit("session",{time:{zone:r["a"].time.zone.name}}).then(s))},get:r["a"].reactive()}),r["a"].time=r["a"].reactive({stamp:r["b"].time.stamp(),zone:{name:"universal",offset:r["b"].date.zone["universal"].offset}}),r["b"].define(r["b"].db.socket,"collection",class{__(t,e,n){return this.command=t,this.collection=e,this.context=n,this}constructor(t){this.db=t,this.data={},this.option={}}create(t,e){return this.__("create",t,e)}list(t,e){return this.__("list",t,e)}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}then(t,...e){return"list"===this.command?this.db.socket.emit("db:list",{data:{base:this.data.base}},t||this.context):"create"===this.command?this.db.socket.emit("db-collection:create",{data:{base:this.data.base,entry:this.data.entry},collection:this.collection},t||this.context):void 0}}),r["b"].define(r["b"].db.socket,"view",class{__(t,e,n){return this.command=t,this.collection=e,this.context=n,this}constructor(t){this.db=t,this.data={},this.option={where:[],sort:[],limit:[]}}create(t,e){return this.__("create",t,e)}select(t,e){return this.__("select",t,e)}from(t){return this.data.base=t,this}meta(t){return this.data.meta=t,this}on(...t){return this.option.where=t,this}where(...t){return this.option.where=t,this}sort(...t){return this.option.sort=t,this}limit(...t){return this.option.limit=t,this}then(t,...e){return"create"===this.command?this.db.socket.emit("db-view:create",{data:{base:this.data.base,entry:this.data.entry},collection:this.collection},t||this.context):"select"===this.command?this.db.socket.emit("db-view:select",{data:{base:this.data.base},collection:this.collection,on:this.option.where,where:this.option.where,sort:this.option.sort,limit:this.option.limit},t||this.context):void 0}}),r["b"].define(r["b"].db.socket,"select",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={where:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}meta(t){return this.data.meta=t,this}parent(t){return this.data.parent=t,this}on(...t){if(this.option.where=t)return this}where(...t){if(this.option.where=t)return this}sort(...t){if(this.option.sort=t)return this}limit(...t){if(this.option.limit=t)return this}then(t,...e){return this.db.socket.emit("db:select",{data:{base:this.data.base},collection:this.collection,meta:this.data.meta,parent:this.data.parent,on:this.option.where,where:this.option.where,sort:this.option.sort,limit:this.option.limit},t||this.context)}}),r["b"].define(r["b"].db.socket,"insert",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={where:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}then(t,...e){return this.db.socket.emit("db:insert",{data:{base:this.data.base,entry:this.data.entry},collection:this.collection},t||this.context)}}),r["b"].define(r["b"].db.socket,"update",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={where:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}on(...t){if(this.option.where=t)return this}where(...t){if(this.option.where=t)return this}sort(...t){if(this.option.sort=t)return this}limit(...t){if(this.option.limit=t)return this}then(t,...e){return this.db.socket.emit("db:update",{data:{base:this.data.base,entry:this.data.entry},collection:this.collection,on:this.option.where,where:this.option.where,sort:this.option.sort,limit:this.option.limit},t||this.context)}}),r["b"].define(r["b"].db.socket,"delete",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={where:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}on(...t){if(this.option.where=t)return this}where(...t){if(this.option.where=t)return this}sort(...t){if(this.option.sort=t)return this}limit(...t){if(this.option.limit=t)return this}then(t,...e){return this.db.socket.emit("db:delete",{data:{base:this.data.base},collection:this.collection,on:this.option.where,where:this.option.where,sort:this.option.sort,limit:this.option.limit},t||this.context)}}),r["a"].db=new r["b"].db,r["a"].db.start({slot:"socket",socket:r["a"].socket}),r["a"].db.setup=function(t){if(!0===r["a"].package.db.setup===!1)for(var e in r["a"].package.db.collection)r["a"].db.collection.create(e).set(r["a"].package.db.collection[e]).then((function(e){t&&t.call(e)}))},r["a"].sound=function(t="audio"){return r["b"].audio(t)},r["b"].audio.play.list("alarm:analog","/audio/alarm/analog.mp3"),r["b"].audio.play.list("default","/audio/notification/003.ogg"),r["b"].audio.play.list("error","/audio/notification/014.ogg"),r["b"].audio.play.list("warning","/audio/notification/020.ogg"),r["b"].audio.play.list("tring","/audio/notification/001.ogg"),r["b"].audio.play.list("ding-dong","/audio/notification/003.ogg"),r["b"].audio.play.list("tic-toc","/audio/notification/007.ogg"),r["a"].geo=function(){},r["a"].geo.location=function(){},r["a"].geo.location.coordinate=r["a"].reactive({latitude:s,longitude:s}),r["a"].toast=function(){return!1},r["a"].model=r["a"].reactive({format:function(t){return(t||"*").replace("vue.model.")}}),r["a"].form=function(){},r["a"].form.model=function(){},r["a"].form.model.format=function(t){return console.info("deprecated","vue.form.model.format","use vue.model.format instead"),r["a"].model.format(t)},r["a"].element.io=function(){},r["a"].element.io.focus=function(t){r["b"].dom(r["b"].query({id:r["b"].dom(t.target).attribute("for")})).class.insert("--focus")},r["a"].element.io.blur=function(t){r["b"].dom(r["b"].query({id:r["b"].dom(t.target).attribute("for")})).class.delete("--focus")},r["a"].element.io.attribute=function(t){return{capitalize:r["b"].object.to_bool(t.capitalize),correct:r["b"].object.to_bool(t.correct),complete:r["b"].object.to_bool(t.complete),spell:r["b"].object.to_boolean(t.spell)}},r["a"].prop=function(t){var e=[];for(var n in t=t.split("-"))n==s?e.push(t[n]):e.push(t[n].uc_begin());return e.join("")},r["a"].prop.s=function(...t){return t.join("-")},r["a"].account=function(){},r["a"].account.engine=r["a"].fire.base.account,r["a"].account.user=r["a"].reactive(),r["a"].account.start=function(){r["a"].fire.base.account.state(r["a"].account.sign)},r["a"].account.sign=function(t){t&&(r["a"].account.on.line=!0,r["a"].socket.emit("account",t).then((function(e){var n=r["a"].fire.base.account.profile(t);r["a"].react(r["a"].account.user,r["b"].object.join(e,{profile:n}))})))},r["a"].account.sign.up=function(...t){var e=s,n=(t=r["b"].function.argument(...t),t.object),i=t.string,o=t.function;return n.user&&(!1===r["b"].is.user.name(n.user)?e++:n.user=r["b"].email.format(n.user,r["a"].fire.base.url.host.name)),!1===r["b"].is.email(n.email)&&e++,e===s?(r["a"].socket.emit("account:sign-up",n).then(o),r["a"].fire.base.account.sign.up(n,i)):r["a"].fire.base.account},r["a"].account.sign.in=function(...t){var e=s,n=(t=r["b"].function.argument(...t),t.object),i=t.string,o=t.function;return!1===r["b"].is.email(n.user)&&(r["b"].is.user.name(n.user)&&(n.user=r["b"].email.format(n.user,r["a"].fire.base.url.host.name))?e=s:e++),e===s?(r["a"].socket.emit("account:sign-in",n).then(o),r["a"].fire.base.account.sign.in(n,i)):r["a"].fire.base.account},r["a"].account.sign.out=function(t){return r["a"].account.on.line=null,r["a"].socket.emit("account:sign-out").then(t),r["a"].fire.base.account.sign.out()},r["a"].account.profile=function(){},r["a"].account.profile.update=function(){},r["a"].account.is_active=function(){return"active"===r["a"].account.user.status},r["a"].account.on=r["a"].reactive({line:null,access:null}),r["a"].ping=function(){},e["a"]={$$$:u}},"4f2a":function(t,e){e.encode=function(t){var e="";for(var n in t)t.hasOwnProperty(n)&&(e.length&&(e+="&"),e+=encodeURIComponent(n)+"="+encodeURIComponent(t[n]));return e},e.decode=function(t){for(var e={},n=t.split("&"),r=0,i=n.length;r<i;r++){var s=n[r].split("=");e[decodeURIComponent(s[0])]=decodeURIComponent(s[1])}return e}},5270:function(t,e,n){"use strict";var r=n("c532"),i=n("c401"),s=n("2e67"),o=n("2444"),a=n("7a77");function c(t){if(t.cancelToken&&t.cancelToken.throwIfRequested(),t.signal&&t.signal.aborted)throw new a("canceled")}t.exports=function(t){c(t),t.headers=t.headers||{},t.data=i.call(t,t.data,t.headers,t.transformRequest),t.headers=r.merge(t.headers.common||{},t.headers[t.method]||{},t.headers),r.forEach(["delete","get","head","post","put","patch","common"],(function(e){delete t.headers[e]}));var e=t.adapter||o.adapter;return e(t).then((function(e){return c(t),e.data=i.call(t,e.data,e.headers,t.transformResponse),e}),(function(e){return s(e)||(c(t),e&&e.response&&(e.response.data=i.call(t,e.response.data,e.response.headers,t.transformResponse))),Promise.reject(e)}))}},5317:function(t,e){var n=/^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/,r=["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"];function i(t,e){var n=/\/{2,9}/g,r=e.replace(n,"/").split("/");return"/"!=e.substr(0,1)&&0!==e.length||r.splice(0,1),"/"==e.substr(e.length-1,1)&&r.splice(r.length-1,1),r}function s(t,e){var n={};return e.replace(/(?:^|&)([^&=]*)=?([^&]*)/g,(function(t,e,r){e&&(n[e]=r)})),n}t.exports=function(t){var e=t,o=t.indexOf("["),a=t.indexOf("]");-1!=o&&-1!=a&&(t=t.substring(0,o)+t.substring(o,a).replace(/:/g,";")+t.substring(a,t.length));var c=n.exec(t||""),u={},l=14;while(l--)u[r[l]]=c[l]||"";return-1!=o&&-1!=a&&(u.source=e,u.host=u.host.substring(1,u.host.length-1).replace(/;/g,":"),u.authority=u.authority.replace("[","").replace("]","").replace(/;/g,":"),u.ipv6uri=!0),u.pathNames=i(u,u["path"]),u.queryKey=s(u,u["query"]),u}},5567:function(t,e){Function.define(String,"decode",(function(t){return atob(t)})),Function.define(String,"encode",(function(t){return btoa(t)}))},"589b":function(t,e,n){"use strict";n.r(e),n.d(e,"SDK_VERSION",(function(){return Y})),n.d(e,"_DEFAULT_ENTRY_NAME",(function(){return F})),n.d(e,"_addComponent",(function(){return B})),n.d(e,"_addOrOverwriteComponent",(function(){return q})),n.d(e,"_apps",(function(){return M})),n.d(e,"_clearComponents",(function(){return K})),n.d(e,"_components",(function(){return U})),n.d(e,"_getProvider",(function(){return z})),n.d(e,"_registerComponent",(function(){return V})),n.d(e,"_removeServiceInstance",(function(){return H})),n.d(e,"deleteApp",(function(){return Z})),n.d(e,"getApp",(function(){return J})),n.d(e,"getApps",(function(){return X})),n.d(e,"initializeApp",(function(){return Q})),n.d(e,"onLog",(function(){return et})),n.d(e,"registerVersion",(function(){return tt})),n.d(e,"setLogLevel",(function(){return nt}));var r=n("22e5"),i=n("e691"),s=n("1fd5");n.d(e,"FirebaseError",(function(){return s["c"]}));
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o{constructor(t){this.container=t}getPlatformInfoString(){const t=this.container.getProviders();return t.map(t=>{if(a(t)){const e=t.getImmediate();return`${e.library}/${e.version}`}return null}).filter(t=>t).join(" ")}}function a(t){const e=t.getComponent();return"VERSION"===(null===e||void 0===e?void 0:e.type)}const c="@firebase/app",u="0.7.9",l=new i["b"]("@firebase/app"),h="@firebase/app-compat",d="@firebase/analytics-compat",f="@firebase/analytics",p="@firebase/app-check-compat",m="@firebase/app-check",g="@firebase/auth",y="@firebase/auth-compat",b="@firebase/database",v="@firebase/database-compat",w="@firebase/functions",_="@firebase/functions-compat",I="@firebase/installations",E="@firebase/installations-compat",O="@firebase/messaging",T="@firebase/messaging-compat",k="@firebase/performance",S="@firebase/performance-compat",A="@firebase/remote-config",j="@firebase/remote-config-compat",N="@firebase/storage",C="@firebase/storage-compat",R="@firebase/firestore",x="@firebase/firestore-compat",D="firebase",P="9.5.0",F="[DEFAULT]",L={[c]:"fire-core",[h]:"fire-core-compat",[f]:"fire-analytics",[d]:"fire-analytics-compat",[m]:"fire-app-check",[p]:"fire-app-check-compat",[g]:"fire-auth",[y]:"fire-auth-compat",[b]:"fire-rtdb",[v]:"fire-rtdb-compat",[w]:"fire-fn",[_]:"fire-fn-compat",[I]:"fire-iid",[E]:"fire-iid-compat",[O]:"fire-fcm",[T]:"fire-fcm-compat",[k]:"fire-perf",[S]:"fire-perf-compat",[A]:"fire-rc",[j]:"fire-rc-compat",[N]:"fire-gcs",[C]:"fire-gcs-compat",[R]:"fire-fst",[x]:"fire-fst-compat","fire-js":"fire-js",[D]:"fire-js-all"},M=new Map,U=new Map;function B(t,e){try{t.container.addComponent(e)}catch(n){l.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function q(t,e){t.container.addOrOverwriteComponent(e)}function V(t){const e=t.name;if(U.has(e))return l.debug(`There were multiple attempts to register component ${e}.`),!1;U.set(e,t);for(const n of M.values())B(n,t);return!0}function z(t,e){return t.container.getProvider(e)}function H(t,e,n=F){z(t,e).clearInstance(n)}function K(){U.clear()}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $={["no-app"]:"No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",["bad-app-name"]:"Illegal App name: '{$appName}",["duplicate-app"]:"Firebase App named '{$appName}' already exists with different options or config",["app-deleted"]:"Firebase App named '{$appName}' already deleted",["invalid-app-argument"]:"firebase.{$appName}() takes either no argument or a Firebase App instance.",["invalid-log-argument"]:"First argument to `onLog` must be null or a function."},G=new s["b"]("app","Firebase",$);
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class W{constructor(t,e,n){this._isDeleted=!1,this._options=Object.assign({},t),this._config=Object.assign({},e),this._name=e.name,this._automaticDataCollectionEnabled=e.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new r["a"]("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw G.create("app-deleted",{appName:this._name})}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y=P;function Q(t,e={}){if("object"!==typeof e){const t=e;e={name:t}}const n=Object.assign({name:F,automaticDataCollectionEnabled:!1},e),i=n.name;if("string"!==typeof i||!i)throw G.create("bad-app-name",{appName:String(i)});const o=M.get(i);if(o){if(Object(s["h"])(t,o.options)&&Object(s["h"])(n,o.config))return o;throw G.create("duplicate-app",{appName:i})}const a=new r["b"](i);for(const r of U.values())a.addComponent(r);const c=new W(t,n,a);return M.set(i,c),c}function J(t=F){const e=M.get(t);if(!e)throw G.create("no-app",{appName:t});return e}function X(){return Array.from(M.values())}async function Z(t){const e=t.name;M.has(e)&&(M.delete(e),await Promise.all(t.container.getProviders().map(t=>t.delete())),t.isDeleted=!0)}function tt(t,e,n){var i;let s=null!==(i=L[t])&&void 0!==i?i:t;n&&(s+="-"+n);const o=s.match(/\s|\//),a=e.match(/\s|\//);if(o||a){const t=[`Unable to register library "${s}" with version "${e}":`];return o&&t.push(`library name "${s}" contains illegal characters (whitespace or "/")`),o&&a&&t.push("and"),a&&t.push(`version name "${e}" contains illegal characters (whitespace or "/")`),void l.warn(t.join(" "))}V(new r["a"](s+"-version",()=>({library:s,version:e}),"VERSION"))}function et(t,e){if(null!==t&&"function"!==typeof t)throw G.create("invalid-log-argument");Object(i["d"])(t,e)}function nt(t){Object(i["c"])(t)}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(t){V(new r["a"]("platform-logger",t=>new o(t),"PRIVATE")),tt(c,u,t),tt(c,u,"esm2017"),tt("fire-js","")}rt("")},5994:function(t,e,n){"use strict";(function(t){var e=n("7ded"),r=n("1f5a"),i=n("22e5"),s=n("1fd5"),o="@firebase/auth-compat",a="0.2.3";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const c=1e3;function u(){var t;return(null===(t=null===self||void 0===self?void 0:self.location)||void 0===t?void 0:t.protocol)||null}function l(){return"http:"===u()||"https:"===u()}function h(t=Object(s["l"])()){return!("file:"!==u()&&"ionic:"!==u()||!t.toLowerCase().match(/iphone|ipad|ipod|android/))}function d(){return Object(s["u"])()||Object(s["t"])()}function f(){return Object(s["q"])()&&11===(null===document||void 0===document?void 0:document.documentMode)}function p(t=Object(s["l"])()){return/Edge\/\d+/.test(t)}function m(t=Object(s["l"])()){return f()||p(t)}function g(){try{const t=self.localStorage,e=r["s"]();if(t)return t["setItem"](e,"1"),t["removeItem"](e),!m()||Object(s["r"])()}catch(t){return y()&&Object(s["r"])()}return!1}function y(){return"undefined"!==typeof t&&"WorkerGlobalScope"in t&&"importScripts"in t}function b(){return(l()||Object(s["n"])()||h())&&!d()&&g()&&!y()}function v(){return h()&&"undefined"!==typeof document}async function w(){return!!v()&&new Promise(t=>{const e=setTimeout(()=>{t(!1)},c);document.addEventListener("deviceready",()=>{clearTimeout(e),t(!0)})})}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _={LOCAL:"local",NONE:"none",SESSION:"session"},I=r["p"],E="persistence";function O(t,e){I(Object.values(_).includes(e),t,"invalid-persistence-type"),Object(s["u"])()?I(e!==_.SESSION,t,"unsupported-persistence-type"):Object(s["t"])()?I(e===_.NONE,t,"unsupported-persistence-type"):y()?I(e===_.NONE||e===_.LOCAL&&Object(s["r"])(),t,"unsupported-persistence-type"):I(e===_.NONE||g(),t,"unsupported-persistence-type")}async function T(t){await t._initializationPromise;const e=S(),n=r["v"](E,t.config.apiKey,t.name);(null===e||void 0===e?void 0:e.sessionStorage)&&e.sessionStorage.setItem(n,t._getPersistence())}function k(t,e){const n=S();if(!(null===n||void 0===n?void 0:n.sessionStorage))return[];const i=r["v"](E,t,e),s=n.sessionStorage.getItem(i);switch(s){case _.NONE:return[r["L"]];case _.LOCAL:return[r["M"],r["A"]];case _.SESSION:return[r["A"]];default:return[]}}function S(){return"undefined"!==typeof window?window:null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const A=r["p"];class j{constructor(){this.browserResolver=r["t"](r["z"]),this.cordovaResolver=r["t"](r["E"]),this.underlyingResolver=null,this._redirectPersistence=r["A"],this._completeRedirectFn=r["u"]}async _initialize(t){return await this.selectUnderlyingResolver(),this.assertedUnderlyingResolver._initialize(t)}async _openPopup(t,e,n,r){return await this.selectUnderlyingResolver(),this.assertedUnderlyingResolver._openPopup(t,e,n,r)}async _openRedirect(t,e,n,r){return await this.selectUnderlyingResolver(),this.assertedUnderlyingResolver._openRedirect(t,e,n,r)}_isIframeWebStorageSupported(t,e){this.assertedUnderlyingResolver._isIframeWebStorageSupported(t,e)}_originValidation(t){return this.assertedUnderlyingResolver._originValidation(t)}get _shouldInitProactively(){return v()||this.browserResolver._shouldInitProactively}get assertedUnderlyingResolver(){return A(this.underlyingResolver,"internal-error"),this.underlyingResolver}async selectUnderlyingResolver(){if(this.underlyingResolver)return;const t=await w();this.underlyingResolver=t?this.cordovaResolver:this.browserResolver}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function N(t){return t.unwrap()}function C(t){return t.wrapped()}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function R(t){return D(t)}function x(t,e){var n;const i=null===(n=e.customData)||void 0===n?void 0:n._tokenResponse;if("auth/multi-factor-auth-required"===e.code){const n=e;n.resolver=new L(t,r["J"](t,e))}else if(i){const t=D(e),n=e;t&&(n.credential=t,n.tenantId=i.tenantId||void 0,n.email=i.email||void 0,n.phoneNumber=i.phoneNumber||void 0)}}function D(t){const{_tokenResponse:e}=t instanceof s["c"]?t.customData:t;if(!e)return null;if(!(t instanceof s["c"])&&"temporaryProof"in e&&"phoneNumber"in e)return r["i"].credentialFromResult(t);const n=e.providerId;if(!n||n===r["k"].PASSWORD)return null;let i;switch(n){case r["k"].GOOGLE:i=r["f"];break;case r["k"].FACEBOOK:i=r["d"];break;case r["k"].GITHUB:i=r["e"];break;case r["k"].TWITTER:i=r["o"];break;default:const{oauthIdToken:t,oauthAccessToken:s,oauthTokenSecret:o,pendingToken:a,nonce:c}=e;return s||o||t||a?a?n.startsWith("saml.")?r["m"]._create(n,a):r["g"]._fromParams({providerId:n,signInMethod:n,pendingToken:a,idToken:t,accessToken:s}):new r["h"](n).credential({idToken:t,accessToken:s,rawNonce:c}):null}return t instanceof s["c"]?i.credentialFromError(t):i.credentialFromResult(t)}function P(t,e){return e.catch(e=>{throw e instanceof s["c"]&&x(t,e),e}).then(t=>{const e=t.operationType,n=t.user;return{operationType:e,credential:R(t),additionalUserInfo:r["I"](t),user:M.getOrCreate(n)}})}async function F(t,e){const n=await e;return{verificationId:n.verificationId,confirm:e=>P(t,n.confirm(e))}}class L{constructor(t,e){this.resolver=e,this.auth=C(t)}get session(){return this.resolver.session}get hints(){return this.resolver.hints}resolveSignIn(t){return P(N(this.auth),this.resolver.resolveSignIn(t))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M{constructor(t){this._delegate=t,this.multiFactor=r["S"](t)}static getOrCreate(t){return M.USER_MAP.has(t)||M.USER_MAP.set(t,new M(t)),M.USER_MAP.get(t)}delete(){return this._delegate.delete()}reload(){return this._delegate.reload()}toJSON(){return this._delegate.toJSON()}getIdTokenResult(t){return this._delegate.getIdTokenResult(t)}getIdToken(t){return this._delegate.getIdToken(t)}linkAndRetrieveDataWithCredential(t){return this.linkWithCredential(t)}async linkWithCredential(t){return P(this.auth,r["O"](this._delegate,t))}async linkWithPhoneNumber(t,e){return F(this.auth,r["P"](this._delegate,t,e))}async linkWithPopup(t){return P(this.auth,r["Q"](this._delegate,t,j))}async linkWithRedirect(t){return await T(r["q"](this.auth)),r["R"](this._delegate,t,j)}reauthenticateAndRetrieveDataWithCredential(t){return this.reauthenticateWithCredential(t)}async reauthenticateWithCredential(t){return P(this.auth,r["T"](this._delegate,t))}reauthenticateWithPhoneNumber(t,e){return F(this.auth,r["U"](this._delegate,t,e))}reauthenticateWithPopup(t){return P(this.auth,r["V"](this._delegate,t,j))}async reauthenticateWithRedirect(t){return await T(r["q"](this.auth)),r["W"](this._delegate,t,j)}sendEmailVerification(t){return r["X"](this._delegate,t)}async unlink(t){return await r["ib"](this._delegate,t),this}updateEmail(t){return r["jb"](this._delegate,t)}updatePassword(t){return r["kb"](this._delegate,t)}updatePhoneNumber(t){return r["lb"](this._delegate,t)}updateProfile(t){return r["mb"](this._delegate,t)}verifyBeforeUpdateEmail(t,e){return r["nb"](this._delegate,t,e)}get emailVerified(){return this._delegate.emailVerified}get isAnonymous(){return this._delegate.isAnonymous}get metadata(){return this._delegate.metadata}get phoneNumber(){return this._delegate.phoneNumber}get providerData(){return this._delegate.providerData}get refreshToken(){return this._delegate.refreshToken}get tenantId(){return this._delegate.tenantId}get displayName(){return this._delegate.displayName}get email(){return this._delegate.email}get photoURL(){return this._delegate.photoURL}get providerId(){return this._delegate.providerId}get uid(){return this._delegate.uid}get auth(){return this._delegate.auth}}M.USER_MAP=new WeakMap;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const U=r["p"];class B{constructor(t,e){if(this.app=t,e.isInitialized())return this._delegate=e.getImmediate(),void this.linkUnderlyingAuth();const{apiKey:n}=t.options;U(n,"invalid-api-key",{appName:t.name});let i=[r["L"]];if("undefined"!==typeof window){i=k(n,t.name);for(const t of[r["M"],r["y"],r["A"]])i.includes(t)||i.push(t)}U(n,"invalid-api-key",{appName:t.name});const s="undefined"!==typeof window?j:void 0;this._delegate=e.initialize({options:{persistence:i,popupRedirectResolver:s}}),this._delegate._updateErrorMap(r["G"]),this.linkUnderlyingAuth()}get emulatorConfig(){return this._delegate.emulatorConfig}get currentUser(){return this._delegate.currentUser?M.getOrCreate(this._delegate.currentUser):null}get languageCode(){return this._delegate.languageCode}set languageCode(t){this._delegate.languageCode=t}get settings(){return this._delegate.settings}get tenantId(){return this._delegate.tenantId}set tenantId(t){this._delegate.tenantId=t}useDeviceLanguage(){this._delegate.useDeviceLanguage()}signOut(){return this._delegate.signOut()}useEmulator(t,e){r["D"](this._delegate,t,e)}applyActionCode(t){return r["x"](this._delegate,t)}checkActionCode(t){return r["B"](this._delegate,t)}confirmPasswordReset(t,e){return r["C"](this._delegate,t,e)}async createUserWithEmailAndPassword(t,e){return P(this._delegate,r["F"](this._delegate,t,e))}fetchProvidersForEmail(t){return this.fetchSignInMethodsForEmail(t)}fetchSignInMethodsForEmail(t){return r["H"](this._delegate,t)}isSignInWithEmailLink(t){return r["N"](this._delegate,t)}async getRedirectResult(){U(b(),this._delegate,"operation-not-supported-in-this-environment");const t=await r["K"](this._delegate,j);return t?P(this._delegate,Promise.resolve(t)):{credential:null,user:null}}addFrameworkForLogging(t){r["w"](this._delegate,t)}onAuthStateChanged(t,e,n){const{next:r,error:i,complete:s}=q(t,e,n);return this._delegate.onAuthStateChanged(r,i,s)}onIdTokenChanged(t,e,n){const{next:r,error:i,complete:s}=q(t,e,n);return this._delegate.onIdTokenChanged(r,i,s)}sendSignInLinkToEmail(t,e){return r["Z"](this._delegate,t,e)}sendPasswordResetEmail(t,e){return r["Y"](this._delegate,t,e||void 0)}async setPersistence(t){let e;switch(O(this._delegate,t),t){case _.SESSION:e=r["A"];break;case _.LOCAL:const t=await r["t"](r["M"])._isAvailable();e=t?r["M"]:r["y"];break;case _.NONE:e=r["L"];break;default:return r["r"]("argument-error",{appName:this._delegate.name})}return this._delegate.setPersistence(e)}signInAndRetrieveDataWithCredential(t){return this.signInWithCredential(t)}signInAnonymously(){return P(this._delegate,r["ab"](this._delegate))}signInWithCredential(t){return P(this._delegate,r["bb"](this._delegate,t))}signInWithCustomToken(t){return P(this._delegate,r["cb"](this._delegate,t))}signInWithEmailAndPassword(t,e){return P(this._delegate,r["db"](this._delegate,t,e))}signInWithEmailLink(t,e){return P(this._delegate,r["eb"](this._delegate,t,e))}signInWithPhoneNumber(t,e){return F(this._delegate,r["fb"](this._delegate,t,e))}async signInWithPopup(t){return U(b(),this._delegate,"operation-not-supported-in-this-environment"),P(this._delegate,r["gb"](this._delegate,t,j))}async signInWithRedirect(t){return U(b(),this._delegate,"operation-not-supported-in-this-environment"),await T(this._delegate),r["hb"](this._delegate,t,j)}updateCurrentUser(t){return this._delegate.updateCurrentUser(t)}verifyPasswordResetCode(t){return r["ob"](this._delegate,t)}unwrap(){return this._delegate}_delete(){return this._delegate._delete()}linkUnderlyingAuth(){this._delegate.wrapped=()=>this}}function q(t,e,n){let r=t;"function"!==typeof t&&({next:r,error:e,complete:n}=t);const i=r,s=t=>i(t&&M.getOrCreate(t));return{next:s,error:e,complete:n}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */B.Persistence=_;class V{constructor(){this.providerId="phone",this._delegate=new r["i"](N(e["a"].auth()))}static credential(t,e){return r["i"].credential(t,e)}verifyPhoneNumber(t,e){return this._delegate.verifyPhoneNumber(t,e)}unwrap(){return this._delegate}}V.PHONE_SIGN_IN_METHOD=r["i"].PHONE_SIGN_IN_METHOD,V.PROVIDER_ID=r["i"].PROVIDER_ID;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const z=r["p"];class H{constructor(t,n,i=e["a"].app()){var s;z(null===(s=i.options)||void 0===s?void 0:s.apiKey,"invalid-api-key",{appName:i.name}),this._delegate=new r["l"](t,n,i.auth()),this.type=this._delegate.type}clear(){this._delegate.clear()}render(){return this._delegate.render()}verify(){return this._delegate.verify()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K="auth-compat";function $(t){t.INTERNAL.registerComponent(new i["a"](K,t=>{const e=t.getProvider("app-compat").getImmediate(),n=t.getProvider("auth");return new B(e,n)},"PUBLIC").setServiceProps({ActionCodeInfo:{Operation:{EMAIL_SIGNIN:r["a"].EMAIL_SIGNIN,PASSWORD_RESET:r["a"].PASSWORD_RESET,RECOVER_EMAIL:r["a"].RECOVER_EMAIL,REVERT_SECOND_FACTOR_ADDITION:r["a"].REVERT_SECOND_FACTOR_ADDITION,VERIFY_AND_CHANGE_EMAIL:r["a"].VERIFY_AND_CHANGE_EMAIL,VERIFY_EMAIL:r["a"].VERIFY_EMAIL}},EmailAuthProvider:r["c"],FacebookAuthProvider:r["d"],GithubAuthProvider:r["e"],GoogleAuthProvider:r["f"],OAuthProvider:r["h"],SAMLAuthProvider:r["n"],PhoneAuthProvider:V,PhoneMultiFactorGenerator:r["j"],RecaptchaVerifier:H,TwitterAuthProvider:r["o"],Auth:B,AuthCredential:r["b"],Error:s["c"]}).setInstantiationMode("LAZY").setMultipleInstances(!1)),t.registerVersion(o,a)}$(e["a"])}).call(this,n("c8ba"))},"5cce":function(t,e){t.exports={version:"0.24.0"}},"5f02":function(t,e,n){"use strict";t.exports=function(t){return"object"===typeof t&&!0===t.isAxiosError}},"6b0d":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=(t,e)=>{const n=t.__vccOpts||t;for(const[r,i]of e)n[r]=i;return n}},"72fe":function(t,e,n){(function(e,r){t.exports=r(n("21bf"))})(0,(function(t){return function(e){var n=t,r=n.lib,i=r.WordArray,s=r.Hasher,o=n.algo,a=[];(function(){for(var t=0;t<64;t++)a[t]=4294967296*e.abs(e.sin(t+1))|0})();var c=o.MD5=s.extend({_doReset:function(){this._hash=new i.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(t,e){for(var n=0;n<16;n++){var r=e+n,i=t[r];t[r]=16711935&(i<<8|i>>>24)|4278255360&(i<<24|i>>>8)}var s=this._hash.words,o=t[e+0],c=t[e+1],f=t[e+2],p=t[e+3],m=t[e+4],g=t[e+5],y=t[e+6],b=t[e+7],v=t[e+8],w=t[e+9],_=t[e+10],I=t[e+11],E=t[e+12],O=t[e+13],T=t[e+14],k=t[e+15],S=s[0],A=s[1],j=s[2],N=s[3];S=u(S,A,j,N,o,7,a[0]),N=u(N,S,A,j,c,12,a[1]),j=u(j,N,S,A,f,17,a[2]),A=u(A,j,N,S,p,22,a[3]),S=u(S,A,j,N,m,7,a[4]),N=u(N,S,A,j,g,12,a[5]),j=u(j,N,S,A,y,17,a[6]),A=u(A,j,N,S,b,22,a[7]),S=u(S,A,j,N,v,7,a[8]),N=u(N,S,A,j,w,12,a[9]),j=u(j,N,S,A,_,17,a[10]),A=u(A,j,N,S,I,22,a[11]),S=u(S,A,j,N,E,7,a[12]),N=u(N,S,A,j,O,12,a[13]),j=u(j,N,S,A,T,17,a[14]),A=u(A,j,N,S,k,22,a[15]),S=l(S,A,j,N,c,5,a[16]),N=l(N,S,A,j,y,9,a[17]),j=l(j,N,S,A,I,14,a[18]),A=l(A,j,N,S,o,20,a[19]),S=l(S,A,j,N,g,5,a[20]),N=l(N,S,A,j,_,9,a[21]),j=l(j,N,S,A,k,14,a[22]),A=l(A,j,N,S,m,20,a[23]),S=l(S,A,j,N,w,5,a[24]),N=l(N,S,A,j,T,9,a[25]),j=l(j,N,S,A,p,14,a[26]),A=l(A,j,N,S,v,20,a[27]),S=l(S,A,j,N,O,5,a[28]),N=l(N,S,A,j,f,9,a[29]),j=l(j,N,S,A,b,14,a[30]),A=l(A,j,N,S,E,20,a[31]),S=h(S,A,j,N,g,4,a[32]),N=h(N,S,A,j,v,11,a[33]),j=h(j,N,S,A,I,16,a[34]),A=h(A,j,N,S,T,23,a[35]),S=h(S,A,j,N,c,4,a[36]),N=h(N,S,A,j,m,11,a[37]),j=h(j,N,S,A,b,16,a[38]),A=h(A,j,N,S,_,23,a[39]),S=h(S,A,j,N,O,4,a[40]),N=h(N,S,A,j,o,11,a[41]),j=h(j,N,S,A,p,16,a[42]),A=h(A,j,N,S,y,23,a[43]),S=h(S,A,j,N,w,4,a[44]),N=h(N,S,A,j,E,11,a[45]),j=h(j,N,S,A,k,16,a[46]),A=h(A,j,N,S,f,23,a[47]),S=d(S,A,j,N,o,6,a[48]),N=d(N,S,A,j,b,10,a[49]),j=d(j,N,S,A,T,15,a[50]),A=d(A,j,N,S,g,21,a[51]),S=d(S,A,j,N,E,6,a[52]),N=d(N,S,A,j,p,10,a[53]),j=d(j,N,S,A,_,15,a[54]),A=d(A,j,N,S,c,21,a[55]),S=d(S,A,j,N,v,6,a[56]),N=d(N,S,A,j,k,10,a[57]),j=d(j,N,S,A,y,15,a[58]),A=d(A,j,N,S,O,21,a[59]),S=d(S,A,j,N,m,6,a[60]),N=d(N,S,A,j,I,10,a[61]),j=d(j,N,S,A,f,15,a[62]),A=d(A,j,N,S,w,21,a[63]),s[0]=s[0]+S|0,s[1]=s[1]+A|0,s[2]=s[2]+j|0,s[3]=s[3]+N|0},_doFinalize:function(){var t=this._data,n=t.words,r=8*this._nDataBytes,i=8*t.sigBytes;n[i>>>5]|=128<<24-i%32;var s=e.floor(r/4294967296),o=r;n[15+(i+64>>>9<<4)]=16711935&(s<<8|s>>>24)|4278255360&(s<<24|s>>>8),n[14+(i+64>>>9<<4)]=16711935&(o<<8|o>>>24)|4278255360&(o<<24|o>>>8),t.sigBytes=4*(n.length+1),this._process();for(var a=this._hash,c=a.words,u=0;u<4;u++){var l=c[u];c[u]=16711935&(l<<8|l>>>24)|4278255360&(l<<24|l>>>8)}return a},clone:function(){var t=s.clone.call(this);return t._hash=this._hash.clone(),t}});function u(t,e,n,r,i,s,o){var a=t+(e&n|~e&r)+i+o;return(a<<s|a>>>32-s)+e}function l(t,e,n,r,i,s,o){var a=t+(e&r|n&~r)+i+o;return(a<<s|a>>>32-s)+e}function h(t,e,n,r,i,s,o){var a=t+(e^n^r)+i+o;return(a<<s|a>>>32-s)+e}function d(t,e,n,r,i,s,o){var a=t+(n^(e|~r))+i+o;return(a<<s|a>>>32-s)+e}n.MD5=s._createHelper(c),n.HmacMD5=s._createHmacHelper(c)}(Math),t.MD5}))},"744a":function(t,e,n){"use strict";n.d(e,"c",(function(){return i})),n.d(e,"a",(function(){return s})),n.d(e,"d",(function(){return o})),n.d(e,"b",(function(){return a}));var r=n("20a4");const i=(()=>{const t="function"===typeof Promise&&"function"===typeof Promise.resolve;return t?t=>Promise.resolve().then(t):(t,e)=>e(t,0)})(),s=r["a"].WebSocket||r["a"].MozWebSocket,o=!0,a="arraybuffer"},"7a23":function(t,e,n){"use strict";n.d(e,"b",(function(){return Wt})),n.d(e,"y",(function(){return Et})),n.d(e,"z",(function(){return Lt})),n.d(e,"D",(function(){return Mt})),n.d(e,"F",(function(){return Ht})),n.d(e,"G",(function(){return qt})),n.d(e,"o",(function(){return r["I"]})),n.d(e,"E",(function(){return r["L"]})),n.d(e,"a",(function(){return zn})),n.d(e,"d",(function(){return er})),n.d(e,"e",(function(){return fr})),n.d(e,"f",(function(){return tr})),n.d(e,"g",(function(){return ar})),n.d(e,"h",(function(){return dr})),n.d(e,"i",(function(){return cr})),n.d(e,"j",(function(){return Oe})),n.d(e,"k",(function(){return Sr})),n.d(e,"l",(function(){return Ti})),n.d(e,"m",(function(){return fe})),n.d(e,"n",(function(){return oi})),n.d(e,"p",(function(){return Ae})),n.d(e,"q",(function(){return je})),n.d(e,"r",(function(){return Le})),n.d(e,"s",(function(){return qe})),n.d(e,"t",(function(){return Ue})),n.d(e,"u",(function(){return Yn})),n.d(e,"v",(function(){return ne})),n.d(e,"w",(function(){return de})),n.d(e,"x",(function(){return ee})),n.d(e,"A",(function(){return br})),n.d(e,"B",(function(){return Mn})),n.d(e,"C",(function(){return Bn})),n.d(e,"K",(function(){return wi})),n.d(e,"L",(function(){return bi})),n.d(e,"M",(function(){return re})),n.d(e,"N",(function(){return En})),n.d(e,"c",(function(){return Ds})),n.d(e,"H",(function(){return ks})),n.d(e,"I",(function(){return As})),n.d(e,"J",(function(){return Ts}));var r=n("9ff4");let i;const s=[];class o{constructor(t=!1){this.active=!0,this.effects=[],this.cleanups=[],!t&&i&&(this.parent=i,this.index=(i.scopes||(i.scopes=[])).push(this)-1)}run(t){if(this.active)try{return this.on(),t()}finally{this.off()}else 0}on(){this.active&&(s.push(this),i=this)}off(){this.active&&(s.pop(),i=s[s.length-1])}stop(t){if(this.active){if(this.effects.forEach(t=>t.stop()),this.cleanups.forEach(t=>t()),this.scopes&&this.scopes.forEach(t=>t.stop(!0)),this.parent&&!t){const t=this.parent.scopes.pop();t&&t!==this&&(this.parent.scopes[this.index]=t,t.index=this.index)}this.active=!1}}}function a(t,e){e=e||i,e&&e.active&&e.effects.push(t)}const c=t=>{const e=new Set(t);return e.w=0,e.n=0,e},u=t=>(t.w&m)>0,l=t=>(t.n&m)>0,h=({deps:t})=>{if(t.length)for(let e=0;e<t.length;e++)t[e].w|=m},d=t=>{const{deps:e}=t;if(e.length){let n=0;for(let r=0;r<e.length;r++){const i=e[r];u(i)&&!l(i)?i.delete(t):e[n++]=i,i.w&=~m,i.n&=~m}e.length=n}},f=new WeakMap;let p=0,m=1;const g=30,y=[];let b;const v=Symbol(""),w=Symbol("");class _{constructor(t,e=null,n){this.fn=t,this.scheduler=e,this.active=!0,this.deps=[],a(this,n)}run(){if(!this.active)return this.fn();if(!y.includes(this))try{return y.push(b=this),k(),m=1<<++p,p<=g?h(this):I(this),this.fn()}finally{p<=g&&d(this),m=1<<--p,S(),y.pop();const t=y.length;b=t>0?y[t-1]:void 0}}stop(){this.active&&(I(this),this.onStop&&this.onStop(),this.active=!1)}}function I(t){const{deps:e}=t;if(e.length){for(let n=0;n<e.length;n++)e[n].delete(t);e.length=0}}let E=!0;const O=[];function T(){O.push(E),E=!1}function k(){O.push(E),E=!0}function S(){const t=O.pop();E=void 0===t||t}function A(t,e,n){if(!j())return;let r=f.get(t);r||f.set(t,r=new Map);let i=r.get(n);i||r.set(n,i=c());const s=void 0;N(i,s)}function j(){return E&&void 0!==b}function N(t,e){let n=!1;p<=g?l(t)||(t.n|=m,n=!u(t)):n=!t.has(b),n&&(t.add(b),b.deps.push(t))}function C(t,e,n,i,s,o){const a=f.get(t);if(!a)return;let u=[];if("clear"===e)u=[...a.values()];else if("length"===n&&Object(r["o"])(t))a.forEach((t,e)=>{("length"===e||e>=i)&&u.push(t)});else switch(void 0!==n&&u.push(a.get(n)),e){case"add":Object(r["o"])(t)?Object(r["s"])(n)&&u.push(a.get("length")):(u.push(a.get(v)),Object(r["t"])(t)&&u.push(a.get(w)));break;case"delete":Object(r["o"])(t)||(u.push(a.get(v)),Object(r["t"])(t)&&u.push(a.get(w)));break;case"set":Object(r["t"])(t)&&u.push(a.get(v));break}if(1===u.length)u[0]&&R(u[0]);else{const t=[];for(const e of u)e&&t.push(...e);R(c(t))}}function R(t,e){for(const n of Object(r["o"])(t)?t:[...t])(n!==b||n.allowRecurse)&&(n.scheduler?n.scheduler():n.run())}const x=Object(r["H"])("__proto__,__v_isRef,__isVue"),D=new Set(Object.getOwnPropertyNames(Symbol).map(t=>Symbol[t]).filter(r["E"])),P=B(),F=B(!1,!0),L=B(!0),M=U();function U(){const t={};return["includes","indexOf","lastIndexOf"].forEach(e=>{t[e]=function(...t){const n=Nt(this);for(let e=0,i=this.length;e<i;e++)A(n,"get",e+"");const r=n[e](...t);return-1===r||!1===r?n[e](...t.map(Nt)):r}}),["push","pop","shift","unshift","splice"].forEach(e=>{t[e]=function(...t){T();const n=Nt(this)[e].apply(this,t);return S(),n}}),t}function B(t=!1,e=!1){return function(n,i,s){if("__v_isReactive"===i)return!t;if("__v_isReadonly"===i)return t;if("__v_raw"===i&&s===(t?e?wt:vt:e?bt:yt).get(n))return n;const o=Object(r["o"])(n);if(!t&&o&&Object(r["k"])(M,i))return Reflect.get(M,i,s);const a=Reflect.get(n,i,s);if(Object(r["E"])(i)?D.has(i):x(i))return a;if(t||A(n,"get",i),e)return a;if(Ft(a)){const t=!o||!Object(r["s"])(i);return t?a.value:a}return Object(r["v"])(a)?t?Tt(a):Et(a):a}}const q=z(),V=z(!0);function z(t=!1){return function(e,n,i,s){let o=e[n];if(!t&&(i=Nt(i),o=Nt(o),!Object(r["o"])(e)&&Ft(o)&&!Ft(i)))return o.value=i,!0;const a=Object(r["o"])(e)&&Object(r["s"])(n)?Number(n)<e.length:Object(r["k"])(e,n),c=Reflect.set(e,n,i,s);return e===Nt(s)&&(a?Object(r["j"])(i,o)&&C(e,"set",n,i,o):C(e,"add",n,i)),c}}function H(t,e){const n=Object(r["k"])(t,e),i=t[e],s=Reflect.deleteProperty(t,e);return s&&n&&C(t,"delete",e,void 0,i),s}function K(t,e){const n=Reflect.has(t,e);return Object(r["E"])(e)&&D.has(e)||A(t,"has",e),n}function $(t){return A(t,"iterate",Object(r["o"])(t)?"length":v),Reflect.ownKeys(t)}const G={get:P,set:q,deleteProperty:H,has:K,ownKeys:$},W={get:L,set(t,e){return!0},deleteProperty(t,e){return!0}},Y=Object(r["h"])({},G,{get:F,set:V}),Q=t=>t,J=t=>Reflect.getPrototypeOf(t);function X(t,e,n=!1,r=!1){t=t["__v_raw"];const i=Nt(t),s=Nt(e);e!==s&&!n&&A(i,"get",e),!n&&A(i,"get",s);const{has:o}=J(i),a=r?Q:n?xt:Rt;return o.call(i,e)?a(t.get(e)):o.call(i,s)?a(t.get(s)):void(t!==i&&t.get(e))}function Z(t,e=!1){const n=this["__v_raw"],r=Nt(n),i=Nt(t);return t!==i&&!e&&A(r,"has",t),!e&&A(r,"has",i),t===i?n.has(t):n.has(t)||n.has(i)}function tt(t,e=!1){return t=t["__v_raw"],!e&&A(Nt(t),"iterate",v),Reflect.get(t,"size",t)}function et(t){t=Nt(t);const e=Nt(this),n=J(e),r=n.has.call(e,t);return r||(e.add(t),C(e,"add",t,t)),this}function nt(t,e){e=Nt(e);const n=Nt(this),{has:i,get:s}=J(n);let o=i.call(n,t);o||(t=Nt(t),o=i.call(n,t));const a=s.call(n,t);return n.set(t,e),o?Object(r["j"])(e,a)&&C(n,"set",t,e,a):C(n,"add",t,e),this}function rt(t){const e=Nt(this),{has:n,get:r}=J(e);let i=n.call(e,t);i||(t=Nt(t),i=n.call(e,t));const s=r?r.call(e,t):void 0,o=e.delete(t);return i&&C(e,"delete",t,void 0,s),o}function it(){const t=Nt(this),e=0!==t.size,n=void 0,r=t.clear();return e&&C(t,"clear",void 0,void 0,n),r}function st(t,e){return function(n,r){const i=this,s=i["__v_raw"],o=Nt(s),a=e?Q:t?xt:Rt;return!t&&A(o,"iterate",v),s.forEach((t,e)=>n.call(r,a(t),a(e),i))}}function ot(t,e,n){return function(...i){const s=this["__v_raw"],o=Nt(s),a=Object(r["t"])(o),c="entries"===t||t===Symbol.iterator&&a,u="keys"===t&&a,l=s[t](...i),h=n?Q:e?xt:Rt;return!e&&A(o,"iterate",u?w:v),{next(){const{value:t,done:e}=l.next();return e?{value:t,done:e}:{value:c?[h(t[0]),h(t[1])]:h(t),done:e}},[Symbol.iterator](){return this}}}}function at(t){return function(...e){return"delete"!==t&&this}}function ct(){const t={get(t){return X(this,t)},get size(){return tt(this)},has:Z,add:et,set:nt,delete:rt,clear:it,forEach:st(!1,!1)},e={get(t){return X(this,t,!1,!0)},get size(){return tt(this)},has:Z,add:et,set:nt,delete:rt,clear:it,forEach:st(!1,!0)},n={get(t){return X(this,t,!0)},get size(){return tt(this,!0)},has(t){return Z.call(this,t,!0)},add:at("add"),set:at("set"),delete:at("delete"),clear:at("clear"),forEach:st(!0,!1)},r={get(t){return X(this,t,!0,!0)},get size(){return tt(this,!0)},has(t){return Z.call(this,t,!0)},add:at("add"),set:at("set"),delete:at("delete"),clear:at("clear"),forEach:st(!0,!0)},i=["keys","values","entries",Symbol.iterator];return i.forEach(i=>{t[i]=ot(i,!1,!1),n[i]=ot(i,!0,!1),e[i]=ot(i,!1,!0),r[i]=ot(i,!0,!0)}),[t,n,e,r]}const[ut,lt,ht,dt]=ct();function ft(t,e){const n=e?t?dt:ht:t?lt:ut;return(e,i,s)=>"__v_isReactive"===i?!t:"__v_isReadonly"===i?t:"__v_raw"===i?e:Reflect.get(Object(r["k"])(n,i)&&i in e?n:e,i,s)}const pt={get:ft(!1,!1)},mt={get:ft(!1,!0)},gt={get:ft(!0,!1)};const yt=new WeakMap,bt=new WeakMap,vt=new WeakMap,wt=new WeakMap;function _t(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function It(t){return t["__v_skip"]||!Object.isExtensible(t)?0:_t(Object(r["O"])(t))}function Et(t){return t&&t["__v_isReadonly"]?t:kt(t,!1,G,pt,yt)}function Ot(t){return kt(t,!1,Y,mt,bt)}function Tt(t){return kt(t,!0,W,gt,vt)}function kt(t,e,n,i,s){if(!Object(r["v"])(t))return t;if(t["__v_raw"]&&(!e||!t["__v_isReactive"]))return t;const o=s.get(t);if(o)return o;const a=It(t);if(0===a)return t;const c=new Proxy(t,2===a?i:n);return s.set(t,c),c}function St(t){return At(t)?St(t["__v_raw"]):!(!t||!t["__v_isReactive"])}function At(t){return!(!t||!t["__v_isReadonly"])}function jt(t){return St(t)||At(t)}function Nt(t){const e=t&&t["__v_raw"];return e?Nt(e):t}function Ct(t){return Object(r["g"])(t,"__v_skip",!0),t}const Rt=t=>Object(r["v"])(t)?Et(t):t,xt=t=>Object(r["v"])(t)?Tt(t):t;function Dt(t){j()&&(t=Nt(t),t.dep||(t.dep=c()),N(t.dep))}function Pt(t,e){t=Nt(t),t.dep&&R(t.dep)}function Ft(t){return Boolean(t&&!0===t.__v_isRef)}function Lt(t){return Ut(t,!1)}function Mt(t){return Ut(t,!0)}function Ut(t,e){return Ft(t)?t:new Bt(t,e)}class Bt{constructor(t,e){this._shallow=e,this.dep=void 0,this.__v_isRef=!0,this._rawValue=e?t:Nt(t),this._value=e?t:Rt(t)}get value(){return Dt(this),this._value}set value(t){t=this._shallow?t:Nt(t),Object(r["j"])(t,this._rawValue)&&(this._rawValue=t,this._value=this._shallow?t:Rt(t),Pt(this,t))}}function qt(t){return Ft(t)?t.value:t}const Vt={get:(t,e,n)=>qt(Reflect.get(t,e,n)),set:(t,e,n,r)=>{const i=t[e];return Ft(i)&&!Ft(n)?(i.value=n,!0):Reflect.set(t,e,n,r)}};function zt(t){return St(t)?t:new Proxy(t,Vt)}function Ht(t){const e=Object(r["o"])(t)?new Array(t.length):{};for(const n in t)e[n]=$t(t,n);return e}class Kt{constructor(t,e){this._object=t,this._key=e,this.__v_isRef=!0}get value(){return this._object[this._key]}set value(t){this._object[this._key]=t}}function $t(t,e){const n=t[e];return Ft(n)?n:new Kt(t,e)}class Gt{constructor(t,e,n){this._setter=e,this.dep=void 0,this._dirty=!0,this.__v_isRef=!0,this.effect=new _(t,()=>{this._dirty||(this._dirty=!0,Pt(this))}),this["__v_isReadonly"]=n}get value(){const t=Nt(this);return Dt(t),t._dirty&&(t._dirty=!1,t._value=t.effect.run()),t._value}set value(t){this._setter(t)}}function Wt(t,e){let n,i;const s=Object(r["p"])(t);s?(n=t,i=r["d"]):(n=t.get,i=t.set);const o=new Gt(n,i,s||!i);return o}Promise.resolve();new Set;new Map;function Yt(t,e,...n){const i=t.vnode.props||r["b"];let s=n;const o=e.startsWith("update:"),a=o&&e.slice(7);if(a&&a in i){const t=("modelValue"===a?"model":a)+"Modifiers",{number:e,trim:o}=i[t]||r["b"];o?s=n.map(t=>t.trim()):e&&(s=n.map(r["N"]))}let c;let u=i[c=Object(r["M"])(e)]||i[c=Object(r["M"])(Object(r["e"])(e))];!u&&o&&(u=i[c=Object(r["M"])(Object(r["l"])(e))]),u&&Hr(u,t,6,s);const l=i[c+"Once"];if(l){if(t.emitted){if(t.emitted[c])return}else t.emitted={};t.emitted[c]=!0,Hr(l,t,6,s)}}function Qt(t,e,n=!1){const i=e.emitsCache,s=i.get(t);if(void 0!==s)return s;const o=t.emits;let a={},c=!1;if(!Object(r["p"])(t)){const i=t=>{const n=Qt(t,e,!0);n&&(c=!0,Object(r["h"])(a,n))};!n&&e.mixins.length&&e.mixins.forEach(i),t.extends&&i(t.extends),t.mixins&&t.mixins.forEach(i)}return o||c?(Object(r["o"])(o)?o.forEach(t=>a[t]=null):Object(r["h"])(a,o),i.set(t,a),a):(i.set(t,null),null)}function Jt(t,e){return!(!t||!Object(r["w"])(e))&&(e=e.slice(2).replace(/Once$/,""),Object(r["k"])(t,e[0].toLowerCase()+e.slice(1))||Object(r["k"])(t,Object(r["l"])(e))||Object(r["k"])(t,e))}let Xt=null,Zt=null;function te(t){const e=Xt;return Xt=t,Zt=t&&t.type.__scopeId||null,e}function ee(t){Zt=t}function ne(){Zt=null}function re(t,e=Xt,n){if(!e)return t;if(t._n)return t;const r=(...n)=>{r._d&&Xn(-1);const i=te(e),s=t(...n);return te(i),r._d&&Xn(1),s};return r._n=!0,r._c=!0,r._d=!0,r}function ie(t){const{type:e,vnode:n,proxy:i,withProxy:s,props:o,propsOptions:[a],slots:c,attrs:u,emit:l,render:h,renderCache:d,data:f,setupState:p,ctx:m,inheritAttrs:g}=t;let y,b;const v=te(t);try{if(4&n.shapeFlag){const t=s||i;y=pr(h.call(t,t,d,o,p,f,m)),b=u}else{const t=e;0,y=pr(t.length>1?t(o,{attrs:u,slots:c,emit:l}):t(o,null)),b=e.props?u:se(u)}}catch(_){Gn.length=0,Kr(_,t,1),y=cr(Kn)}let w=y;if(b&&!1!==g){const t=Object.keys(b),{shapeFlag:e}=w;t.length&&7&e&&(a&&t.some(r["u"])&&(b=oe(b,a)),w=hr(w,b))}return n.dirs&&(w.dirs=w.dirs?w.dirs.concat(n.dirs):n.dirs),n.transition&&(w.transition=n.transition),y=w,te(v),y}const se=t=>{let e;for(const n in t)("class"===n||"style"===n||Object(r["w"])(n))&&((e||(e={}))[n]=t[n]);return e},oe=(t,e)=>{const n={};for(const i in t)Object(r["u"])(i)&&i.slice(9)in e||(n[i]=t[i]);return n};function ae(t,e,n){const{props:r,children:i,component:s}=t,{props:o,children:a,patchFlag:c}=e,u=s.emitsOptions;if(e.dirs||e.transition)return!0;if(!(n&&c>=0))return!(!i&&!a||a&&a.$stable)||r!==o&&(r?!o||ce(r,o,u):!!o);if(1024&c)return!0;if(16&c)return r?ce(r,o,u):!!o;if(8&c){const t=e.dynamicProps;for(let e=0;e<t.length;e++){const n=t[e];if(o[n]!==r[n]&&!Jt(u,n))return!0}}return!1}function ce(t,e,n){const r=Object.keys(e);if(r.length!==Object.keys(t).length)return!0;for(let i=0;i<r.length;i++){const s=r[i];if(e[s]!==t[s]&&!Jt(n,s))return!0}return!1}function ue({vnode:t,parent:e},n){while(e&&e.subTree===t)(t=e.vnode).el=n,e=e.parent}const le=t=>t.__isSuspense;function he(t,e){e&&e.pendingBranch?Object(r["o"])(t)?e.effects.push(...t):e.effects.push(t):fi(t)}function de(t,e){if(kr){let n=kr.provides;const r=kr.parent&&kr.parent.provides;r===n&&(n=kr.provides=Object.create(r)),n[t]=e}else 0}function fe(t,e,n=!1){const i=kr||Xt;if(i){const s=null==i.parent?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides;if(s&&t in s)return s[t];if(arguments.length>1)return n&&Object(r["p"])(e)?e.call(i.proxy):e}else 0}function pe(){const t={isMounted:!1,isLeaving:!1,isUnmounting:!1,leavingVNodes:new Map};return Le(()=>{t.isMounted=!0}),Be(()=>{t.isUnmounting=!0}),t}const me=[Function,Array],ge={name:"BaseTransition",props:{mode:String,appear:Boolean,persisted:Boolean,onBeforeEnter:me,onEnter:me,onAfterEnter:me,onEnterCancelled:me,onBeforeLeave:me,onLeave:me,onAfterLeave:me,onLeaveCancelled:me,onBeforeAppear:me,onAppear:me,onAfterAppear:me,onAppearCancelled:me},setup(t,{slots:e}){const n=Sr(),r=pe();let i;return()=>{const s=e.default&&Ee(e.default(),!0);if(!s||!s.length)return;const o=Nt(t),{mode:a}=o;const c=s[0];if(r.isLeaving)return we(c);const u=_e(c);if(!u)return we(c);const l=ve(u,o,r,n);Ie(u,l);const h=n.subTree,d=h&&_e(h);let f=!1;const{getTransitionKey:p}=u.type;if(p){const t=p();void 0===i?i=t:t!==i&&(i=t,f=!0)}if(d&&d.type!==Kn&&(!rr(u,d)||f)){const t=ve(d,o,r,n);if(Ie(d,t),"out-in"===a)return r.isLeaving=!0,t.afterLeave=()=>{r.isLeaving=!1,n.update()},we(c);"in-out"===a&&u.type!==Kn&&(t.delayLeave=(t,e,n)=>{const i=be(r,d);i[String(d.key)]=d,t._leaveCb=()=>{e(),t._leaveCb=void 0,delete l.delayedLeave},l.delayedLeave=n})}return c}}},ye=ge;function be(t,e){const{leavingVNodes:n}=t;let r=n.get(e.type);return r||(r=Object.create(null),n.set(e.type,r)),r}function ve(t,e,n,r){const{appear:i,mode:s,persisted:o=!1,onBeforeEnter:a,onEnter:c,onAfterEnter:u,onEnterCancelled:l,onBeforeLeave:h,onLeave:d,onAfterLeave:f,onLeaveCancelled:p,onBeforeAppear:m,onAppear:g,onAfterAppear:y,onAppearCancelled:b}=e,v=String(t.key),w=be(n,t),_=(t,e)=>{t&&Hr(t,r,9,e)},I={mode:s,persisted:o,beforeEnter(e){let r=a;if(!n.isMounted){if(!i)return;r=m||a}e._leaveCb&&e._leaveCb(!0);const s=w[v];s&&rr(t,s)&&s.el._leaveCb&&s.el._leaveCb(),_(r,[e])},enter(t){let e=c,r=u,s=l;if(!n.isMounted){if(!i)return;e=g||c,r=y||u,s=b||l}let o=!1;const a=t._enterCb=e=>{o||(o=!0,_(e?s:r,[t]),I.delayedLeave&&I.delayedLeave(),t._enterCb=void 0)};e?(e(t,a),e.length<=1&&a()):a()},leave(e,r){const i=String(t.key);if(e._enterCb&&e._enterCb(!0),n.isUnmounting)return r();_(h,[e]);let s=!1;const o=e._leaveCb=n=>{s||(s=!0,r(),_(n?p:f,[e]),e._leaveCb=void 0,w[i]===t&&delete w[i])};w[i]=t,d?(d(e,o),d.length<=1&&o()):o()},clone(t){return ve(t,e,n,r)}};return I}function we(t){if(ke(t))return t=hr(t),t.children=null,t}function _e(t){return ke(t)?t.children?t.children[0]:void 0:t}function Ie(t,e){6&t.shapeFlag&&t.component?Ie(t.component.subTree,e):128&t.shapeFlag?(t.ssContent.transition=e.clone(t.ssContent),t.ssFallback.transition=e.clone(t.ssFallback)):t.transition=e}function Ee(t,e=!1){let n=[],r=0;for(let i=0;i<t.length;i++){const s=t[i];s.type===zn?(128&s.patchFlag&&r++,n=n.concat(Ee(s.children,e))):(e||s.type!==Kn)&&n.push(s)}if(r>1)for(let i=0;i<n.length;i++)n[i].patchFlag=-2;return n}function Oe(t){return Object(r["p"])(t)?{setup:t,name:t.name}:t}const Te=t=>!!t.type.__asyncLoader;const ke=t=>t.type.__isKeepAlive;RegExp,RegExp;function Se(t,e){return Object(r["o"])(t)?t.some(t=>Se(t,e)):Object(r["D"])(t)?t.split(",").indexOf(e)>-1:!!t.test&&t.test(e)}function Ae(t,e){Ne(t,"a",e)}function je(t,e){Ne(t,"da",e)}function Ne(t,e,n=kr){const r=t.__wdc||(t.__wdc=()=>{let e=n;while(e){if(e.isDeactivated)return;e=e.parent}t()});if(De(e,r,n),n){let t=n.parent;while(t&&t.parent)ke(t.parent.vnode)&&Ce(r,e,n,t),t=t.parent}}function Ce(t,e,n,i){const s=De(e,t,i,!0);qe(()=>{Object(r["K"])(i[e],s)},n)}function Re(t){let e=t.shapeFlag;256&e&&(e-=256),512&e&&(e-=512),t.shapeFlag=e}function xe(t){return 128&t.shapeFlag?t.ssContent:t}function De(t,e,n=kr,r=!1){if(n){const i=n[t]||(n[t]=[]),s=e.__weh||(e.__weh=(...r)=>{if(n.isUnmounted)return;T(),Ar(n);const i=Hr(e,n,t,r);return jr(),S(),i});return r?i.unshift(s):i.push(s),s}}const Pe=t=>(e,n=kr)=>(!xr||"sp"===t)&&De(t,e,n),Fe=Pe("bm"),Le=Pe("m"),Me=Pe("bu"),Ue=Pe("u"),Be=Pe("bum"),qe=Pe("um"),Ve=Pe("sp"),ze=Pe("rtg"),He=Pe("rtc");function Ke(t,e=kr){De("ec",t,e)}let $e=!0;function Ge(t){const e=Je(t),n=t.proxy,i=t.ctx;$e=!1,e.beforeCreate&&Ye(e.beforeCreate,t,"bc");const{data:s,computed:o,methods:a,watch:c,provide:u,inject:l,created:h,beforeMount:d,mounted:f,beforeUpdate:p,updated:m,activated:g,deactivated:y,beforeDestroy:b,beforeUnmount:v,destroyed:w,unmounted:_,render:I,renderTracked:E,renderTriggered:O,errorCaptured:T,serverPrefetch:k,expose:S,inheritAttrs:A,components:j,directives:N,filters:C}=e,R=null;if(l&&We(l,i,R,t.appContext.config.unwrapInjectedRef),a)for(const D in a){const t=a[D];Object(r["p"])(t)&&(i[D]=t.bind(n))}if(s){0;const e=s.call(n,n);0,Object(r["v"])(e)&&(t.data=Et(e))}if($e=!0,o)for(const D in o){const t=o[D],e=Object(r["p"])(t)?t.bind(n,n):Object(r["p"])(t.get)?t.get.bind(n,n):r["d"];0;const s=!Object(r["p"])(t)&&Object(r["p"])(t.set)?t.set.bind(n):r["d"],a=Wt({get:e,set:s});Object.defineProperty(i,D,{enumerable:!0,configurable:!0,get:()=>a.value,set:t=>a.value=t})}if(c)for(const r in c)Qe(c[r],i,n,r);if(u){const t=Object(r["p"])(u)?u.call(n):u;Reflect.ownKeys(t).forEach(e=>{de(e,t[e])})}function x(t,e){Object(r["o"])(e)?e.forEach(e=>t(e.bind(n))):e&&t(e.bind(n))}if(h&&Ye(h,t,"c"),x(Fe,d),x(Le,f),x(Me,p),x(Ue,m),x(Ae,g),x(je,y),x(Ke,T),x(He,E),x(ze,O),x(Be,v),x(qe,_),x(Ve,k),Object(r["o"])(S))if(S.length){const e=t.exposed||(t.exposed={});S.forEach(t=>{Object.defineProperty(e,t,{get:()=>n[t],set:e=>n[t]=e})})}else t.exposed||(t.exposed={});I&&t.render===r["d"]&&(t.render=I),null!=A&&(t.inheritAttrs=A),j&&(t.components=j),N&&(t.directives=N)}function We(t,e,n=r["d"],i=!1){Object(r["o"])(t)&&(t=nn(t));for(const s in t){const n=t[s];let o;o=Object(r["v"])(n)?"default"in n?fe(n.from||s,n.default,!0):fe(n.from||s):fe(n),Ft(o)&&i?Object.defineProperty(e,s,{enumerable:!0,configurable:!0,get:()=>o.value,set:t=>o.value=t}):e[s]=o}}function Ye(t,e,n){Hr(Object(r["o"])(t)?t.map(t=>t.bind(e.proxy)):t.bind(e.proxy),e,n)}function Qe(t,e,n,i){const s=i.includes(".")?Ei(n,i):()=>n[i];if(Object(r["D"])(t)){const n=e[t];Object(r["p"])(n)&&wi(s,n)}else if(Object(r["p"])(t))wi(s,t.bind(n));else if(Object(r["v"])(t))if(Object(r["o"])(t))t.forEach(t=>Qe(t,e,n,i));else{const i=Object(r["p"])(t.handler)?t.handler.bind(n):e[t.handler];Object(r["p"])(i)&&wi(s,i,t)}else 0}function Je(t){const e=t.type,{mixins:n,extends:r}=e,{mixins:i,optionsCache:s,config:{optionMergeStrategies:o}}=t.appContext,a=s.get(e);let c;return a?c=a:i.length||n||r?(c={},i.length&&i.forEach(t=>Xe(c,t,o,!0)),Xe(c,e,o)):c=e,s.set(e,c),c}function Xe(t,e,n,r=!1){const{mixins:i,extends:s}=e;s&&Xe(t,s,n,!0),i&&i.forEach(e=>Xe(t,e,n,!0));for(const o in e)if(r&&"expose"===o);else{const r=Ze[o]||n&&n[o];t[o]=r?r(t[o],e[o]):e[o]}return t}const Ze={data:tn,props:sn,emits:sn,methods:sn,computed:sn,beforeCreate:rn,created:rn,beforeMount:rn,mounted:rn,beforeUpdate:rn,updated:rn,beforeDestroy:rn,beforeUnmount:rn,destroyed:rn,unmounted:rn,activated:rn,deactivated:rn,errorCaptured:rn,serverPrefetch:rn,components:sn,directives:sn,watch:on,provide:tn,inject:en};function tn(t,e){return e?t?function(){return Object(r["h"])(Object(r["p"])(t)?t.call(this,this):t,Object(r["p"])(e)?e.call(this,this):e)}:e:t}function en(t,e){return sn(nn(t),nn(e))}function nn(t){if(Object(r["o"])(t)){const e={};for(let n=0;n<t.length;n++)e[t[n]]=t[n];return e}return t}function rn(t,e){return t?[...new Set([].concat(t,e))]:e}function sn(t,e){return t?Object(r["h"])(Object(r["h"])(Object.create(null),t),e):e}function on(t,e){if(!t)return e;if(!e)return t;const n=Object(r["h"])(Object.create(null),t);for(const r in e)n[r]=rn(t[r],e[r]);return n}function an(t,e,n,i=!1){const s={},o={};Object(r["g"])(o,ir,1),t.propsDefaults=Object.create(null),un(t,e,s,o);for(const r in t.propsOptions[0])r in s||(s[r]=void 0);n?t.props=i?s:Ot(s):t.type.props?t.props=s:t.props=o,t.attrs=o}function cn(t,e,n,i){const{props:s,attrs:o,vnode:{patchFlag:a}}=t,c=Nt(s),[u]=t.propsOptions;let l=!1;if(!(i||a>0)||16&a){let i;un(t,e,s,o)&&(l=!0);for(const o in c)e&&(Object(r["k"])(e,o)||(i=Object(r["l"])(o))!==o&&Object(r["k"])(e,i))||(u?!n||void 0===n[o]&&void 0===n[i]||(s[o]=ln(u,c,o,void 0,t,!0)):delete s[o]);if(o!==c)for(const t in o)e&&Object(r["k"])(e,t)||(delete o[t],l=!0)}else if(8&a){const n=t.vnode.dynamicProps;for(let i=0;i<n.length;i++){let a=n[i];const h=e[a];if(u)if(Object(r["k"])(o,a))h!==o[a]&&(o[a]=h,l=!0);else{const e=Object(r["e"])(a);s[e]=ln(u,c,e,h,t,!1)}else h!==o[a]&&(o[a]=h,l=!0)}}l&&C(t,"set","$attrs")}function un(t,e,n,i){const[s,o]=t.propsOptions;let a,c=!1;if(e)for(let u in e){if(Object(r["z"])(u))continue;const l=e[u];let h;s&&Object(r["k"])(s,h=Object(r["e"])(u))?o&&o.includes(h)?(a||(a={}))[h]=l:n[h]=l:Jt(t.emitsOptions,u)||l!==i[u]&&(i[u]=l,c=!0)}if(o){const e=Nt(n),i=a||r["b"];for(let a=0;a<o.length;a++){const c=o[a];n[c]=ln(s,e,c,i[c],t,!Object(r["k"])(i,c))}}return c}function ln(t,e,n,i,s,o){const a=t[n];if(null!=a){const t=Object(r["k"])(a,"default");if(t&&void 0===i){const t=a.default;if(a.type!==Function&&Object(r["p"])(t)){const{propsDefaults:r}=s;n in r?i=r[n]:(Ar(s),i=r[n]=t.call(null,e),jr())}else i=t}a[0]&&(o&&!t?i=!1:!a[1]||""!==i&&i!==Object(r["l"])(n)||(i=!0))}return i}function hn(t,e,n=!1){const i=e.propsCache,s=i.get(t);if(s)return s;const o=t.props,a={},c=[];let u=!1;if(!Object(r["p"])(t)){const i=t=>{u=!0;const[n,i]=hn(t,e,!0);Object(r["h"])(a,n),i&&c.push(...i)};!n&&e.mixins.length&&e.mixins.forEach(i),t.extends&&i(t.extends),t.mixins&&t.mixins.forEach(i)}if(!o&&!u)return i.set(t,r["a"]),r["a"];if(Object(r["o"])(o))for(let h=0;h<o.length;h++){0;const t=Object(r["e"])(o[h]);dn(t)&&(a[t]=r["b"])}else if(o){0;for(const t in o){const e=Object(r["e"])(t);if(dn(e)){const n=o[t],i=a[e]=Object(r["o"])(n)||Object(r["p"])(n)?{type:n}:n;if(i){const t=mn(Boolean,i.type),n=mn(String,i.type);i[0]=t>-1,i[1]=n<0||t<n,(t>-1||Object(r["k"])(i,"default"))&&c.push(e)}}}}const l=[a,c];return i.set(t,l),l}function dn(t){return"$"!==t[0]}function fn(t){const e=t&&t.toString().match(/^\s*function (\w+)/);return e?e[1]:null===t?"null":""}function pn(t,e){return fn(t)===fn(e)}function mn(t,e){return Object(r["o"])(e)?e.findIndex(e=>pn(e,t)):Object(r["p"])(e)&&pn(e,t)?0:-1}const gn=t=>"_"===t[0]||"$stable"===t,yn=t=>Object(r["o"])(t)?t.map(pr):[pr(t)],bn=(t,e,n)=>{const r=re((...t)=>yn(e(...t)),n);return r._c=!1,r},vn=(t,e,n)=>{const i=t._ctx;for(const s in t){if(gn(s))continue;const n=t[s];if(Object(r["p"])(n))e[s]=bn(s,n,i);else if(null!=n){0;const t=yn(n);e[s]=()=>t}}},wn=(t,e)=>{const n=yn(e);t.slots.default=()=>n},_n=(t,e)=>{if(32&t.vnode.shapeFlag){const n=e._;n?(t.slots=Nt(e),Object(r["g"])(e,"_",n)):vn(e,t.slots={})}else t.slots={},e&&wn(t,e);Object(r["g"])(t.slots,ir,1)},In=(t,e,n)=>{const{vnode:i,slots:s}=t;let o=!0,a=r["b"];if(32&i.shapeFlag){const t=e._;t?n&&1===t?o=!1:(Object(r["h"])(s,e),n||1!==t||delete s._):(o=!e.$stable,vn(e,s)),a=e}else e&&(wn(t,e),a={default:1});if(o)for(const r in s)gn(r)||r in a||delete s[r]};function En(t,e){const n=Xt;if(null===n)return t;const i=n.proxy,s=t.dirs||(t.dirs=[]);for(let o=0;o<e.length;o++){let[t,n,a,c=r["b"]]=e[o];Object(r["p"])(t)&&(t={mounted:t,updated:t}),t.deep&&Oi(n),s.push({dir:t,instance:i,value:n,oldValue:void 0,arg:a,modifiers:c})}return t}function On(t,e,n,r){const i=t.dirs,s=e&&e.dirs;for(let o=0;o<i.length;o++){const a=i[o];s&&(a.oldValue=s[o].value);let c=a.dir[r];c&&(T(),Hr(c,n,8,[t.el,a,t,e]),S())}}function Tn(){return{app:null,config:{isNativeTag:r["c"],performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let kn=0;function Sn(t,e){return function(n,i=null){null==i||Object(r["v"])(i)||(i=null);const s=Tn(),o=new Set;let a=!1;const c=s.app={_uid:kn++,_component:n,_props:i,_container:null,_context:s,_instance:null,version:ki,get config(){return s.config},set config(t){0},use(t,...e){return o.has(t)||(t&&Object(r["p"])(t.install)?(o.add(t),t.install(c,...e)):Object(r["p"])(t)&&(o.add(t),t(c,...e))),c},mixin(t){return s.mixins.includes(t)||s.mixins.push(t),c},component(t,e){return e?(s.components[t]=e,c):s.components[t]},directive(t,e){return e?(s.directives[t]=e,c):s.directives[t]},mount(r,o,u){if(!a){const l=cr(n,i);return l.appContext=s,o&&e?e(l,r):t(l,r,u),a=!0,c._container=r,r.__vue_app__=c,Br(l.component)||l.component.proxy}},unmount(){a&&(t(null,c._container),delete c._container.__vue_app__)},provide(t,e){return s.provides[t]=e,c}};return c}}function An(){}const jn=he;function Nn(t){return Cn(t)}function Cn(t,e){An();const n=Object(r["i"])();n.__VUE__=!0;const{insert:i,remove:s,patchProp:o,createElement:a,createText:c,createComment:u,setText:l,setElementText:h,parentNode:d,nextSibling:f,setScopeId:p=r["d"],cloneNode:m,insertStaticContent:g}=t,y=(t,e,n,r=null,i=null,s=null,o=!1,a=null,c=!!e.dynamicChildren)=>{if(t===e)return;t&&!rr(t,e)&&(r=W(t),z(t,i,s,!0),t=null),-2===e.patchFlag&&(c=!1,e.dynamicChildren=null);const{type:u,ref:l,shapeFlag:h}=e;switch(u){case Hn:b(t,e,n,r);break;case Kn:v(t,e,n,r);break;case $n:null==t&&w(e,n,r,o);break;case zn:x(t,e,n,r,i,s,o,a,c);break;default:1&h?O(t,e,n,r,i,s,o,a,c):6&h?D(t,e,n,r,i,s,o,a,c):(64&h||128&h)&&u.process(t,e,n,r,i,s,o,a,c,Q)}null!=l&&i&&Rn(l,t&&t.ref,s,e||t,!e)},b=(t,e,n,r)=>{if(null==t)i(e.el=c(e.children),n,r);else{const n=e.el=t.el;e.children!==t.children&&l(n,e.children)}},v=(t,e,n,r)=>{null==t?i(e.el=u(e.children||""),n,r):e.el=t.el},w=(t,e,n,r)=>{[t.el,t.anchor]=g(t.children,e,n,r)},I=({el:t,anchor:e},n,r)=>{let s;while(t&&t!==e)s=f(t),i(t,n,r),t=s;i(e,n,r)},E=({el:t,anchor:e})=>{let n;while(t&&t!==e)n=f(t),s(t),t=n;s(e)},O=(t,e,n,r,i,s,o,a,c)=>{o=o||"svg"===e.type,null==t?k(e,n,r,i,s,o,a,c):N(t,e,i,s,o,a,c)},k=(t,e,n,s,c,u,l,d)=>{let f,p;const{type:g,props:y,shapeFlag:b,transition:v,patchFlag:w,dirs:_}=t;if(t.el&&void 0!==m&&-1===w)f=t.el=m(t.el);else{if(f=t.el=a(t.type,u,y&&y.is,y),8&b?h(f,t.children):16&b&&j(t.children,f,null,s,c,u&&"foreignObject"!==g,l,d),_&&On(t,null,s,"created"),y){for(const e in y)"value"===e||Object(r["z"])(e)||o(f,e,null,y[e],u,t.children,s,c,G);"value"in y&&o(f,"value",null,y.value),(p=y.onVnodeBeforeMount)&&xn(p,s,t)}A(f,t,t.scopeId,l,s)}_&&On(t,null,s,"beforeMount");const I=(!c||c&&!c.pendingBranch)&&v&&!v.persisted;I&&v.beforeEnter(f),i(f,e,n),((p=y&&y.onVnodeMounted)||I||_)&&jn(()=>{p&&xn(p,s,t),I&&v.enter(f),_&&On(t,null,s,"mounted")},c)},A=(t,e,n,r,i)=>{if(n&&p(t,n),r)for(let s=0;s<r.length;s++)p(t,r[s]);if(i){let n=i.subTree;if(e===n){const e=i.vnode;A(t,e,e.scopeId,e.slotScopeIds,i.parent)}}},j=(t,e,n,r,i,s,o,a,c=0)=>{for(let u=c;u<t.length;u++){const c=t[u]=a?mr(t[u]):pr(t[u]);y(null,c,e,n,r,i,s,o,a)}},N=(t,e,n,i,s,a,c)=>{const u=e.el=t.el;let{patchFlag:l,dynamicChildren:d,dirs:f}=e;l|=16&t.patchFlag;const p=t.props||r["b"],m=e.props||r["b"];let g;(g=m.onVnodeBeforeUpdate)&&xn(g,n,e,t),f&&On(e,t,n,"beforeUpdate");const y=s&&"foreignObject"!==e.type;if(d?C(t.dynamicChildren,d,u,n,i,y,a):c||U(t,e,u,null,n,i,y,a,!1),l>0){if(16&l)R(u,e,p,m,n,i,s);else if(2&l&&p.class!==m.class&&o(u,"class",null,m.class,s),4&l&&o(u,"style",p.style,m.style,s),8&l){const r=e.dynamicProps;for(let e=0;e<r.length;e++){const a=r[e],c=p[a],l=m[a];l===c&&"value"!==a||o(u,a,c,l,s,t.children,n,i,G)}}1&l&&t.children!==e.children&&h(u,e.children)}else c||null!=d||R(u,e,p,m,n,i,s);((g=m.onVnodeUpdated)||f)&&jn(()=>{g&&xn(g,n,e,t),f&&On(e,t,n,"updated")},i)},C=(t,e,n,r,i,s,o)=>{for(let a=0;a<e.length;a++){const c=t[a],u=e[a],l=c.el&&(c.type===zn||!rr(c,u)||70&c.shapeFlag)?d(c.el):n;y(c,u,l,null,r,i,s,o,!0)}},R=(t,e,n,i,s,a,c)=>{if(n!==i){for(const u in i){if(Object(r["z"])(u))continue;const l=i[u],h=n[u];l!==h&&"value"!==u&&o(t,u,h,l,c,e.children,s,a,G)}if(n!==r["b"])for(const u in n)Object(r["z"])(u)||u in i||o(t,u,n[u],null,c,e.children,s,a,G);"value"in i&&o(t,"value",n.value,i.value)}},x=(t,e,n,r,s,o,a,u,l)=>{const h=e.el=t?t.el:c(""),d=e.anchor=t?t.anchor:c("");let{patchFlag:f,dynamicChildren:p,slotScopeIds:m}=e;m&&(u=u?u.concat(m):m),null==t?(i(h,n,r),i(d,n,r),j(e.children,n,d,s,o,a,u,l)):f>0&&64&f&&p&&t.dynamicChildren?(C(t.dynamicChildren,p,n,s,o,a,u),(null!=e.key||s&&e===s.subTree)&&Dn(t,e,!0)):U(t,e,n,d,s,o,a,u,l)},D=(t,e,n,r,i,s,o,a,c)=>{e.slotScopeIds=a,null==t?512&e.shapeFlag?i.ctx.activate(e,n,r,o,c):P(e,n,r,i,s,o,c):F(t,e,c)},P=(t,e,n,r,i,s,o)=>{const a=t.component=Tr(t,r,i);if(ke(t)&&(a.ctx.renderer=Q),Dr(a),a.asyncDep){if(i&&i.registerDep(a,L),!t.el){const t=a.subTree=cr(Kn);v(null,t,e,n)}}else L(a,t,e,n,i,s,o)},F=(t,e,n)=>{const r=e.component=t.component;if(ae(t,e,n)){if(r.asyncDep&&!r.asyncResolved)return void M(r,e,n);r.next=e,li(r.update),r.update()}else e.component=t.component,e.el=t.el,r.vnode=e},L=(t,e,n,i,s,o,a)=>{const c=()=>{if(t.isMounted){let e,{next:n,bu:i,u:c,parent:l,vnode:h}=t,f=n;0,u.allowRecurse=!1,n?(n.el=h.el,M(t,n,a)):n=h,i&&Object(r["n"])(i),(e=n.props&&n.props.onVnodeBeforeUpdate)&&xn(e,l,n,h),u.allowRecurse=!0;const p=ie(t);0;const m=t.subTree;t.subTree=p,y(m,p,d(m.el),W(m),t,s,o),n.el=p.el,null===f&&ue(t,p.el),c&&jn(c,s),(e=n.props&&n.props.onVnodeUpdated)&&jn(()=>xn(e,l,n,h),s)}else{let a;const{el:c,props:l}=e,{bm:h,m:d,parent:f}=t,p=Te(e);if(u.allowRecurse=!1,h&&Object(r["n"])(h),!p&&(a=l&&l.onVnodeBeforeMount)&&xn(a,f,e),u.allowRecurse=!0,c&&X){const n=()=>{t.subTree=ie(t),X(c,t.subTree,t,s,null)};p?e.type.__asyncLoader().then(()=>!t.isUnmounted&&n()):n()}else{0;const r=t.subTree=ie(t);0,y(null,r,n,i,t,s,o),e.el=r.el}if(d&&jn(d,s),!p&&(a=l&&l.onVnodeMounted)){const t=e;jn(()=>xn(a,f,t),s)}256&e.shapeFlag&&t.a&&jn(t.a,s),t.isMounted=!0,e=n=i=null}},u=new _(c,()=>ci(t.update),t.scope),l=t.update=u.run.bind(u);l.id=t.uid,u.allowRecurse=l.allowRecurse=!0,l()},M=(t,e,n)=>{e.component=t;const r=t.vnode.props;t.vnode=e,t.next=null,cn(t,e.props,r,n),In(t,e.children,n),T(),pi(void 0,t.update),S()},U=(t,e,n,r,i,s,o,a,c=!1)=>{const u=t&&t.children,l=t?t.shapeFlag:0,d=e.children,{patchFlag:f,shapeFlag:p}=e;if(f>0){if(128&f)return void q(u,d,n,r,i,s,o,a,c);if(256&f)return void B(u,d,n,r,i,s,o,a,c)}8&p?(16&l&&G(u,i,s),d!==u&&h(n,d)):16&l?16&p?q(u,d,n,r,i,s,o,a,c):G(u,i,s,!0):(8&l&&h(n,""),16&p&&j(d,n,r,i,s,o,a,c))},B=(t,e,n,i,s,o,a,c,u)=>{t=t||r["a"],e=e||r["a"];const l=t.length,h=e.length,d=Math.min(l,h);let f;for(f=0;f<d;f++){const r=e[f]=u?mr(e[f]):pr(e[f]);y(t[f],r,n,null,s,o,a,c,u)}l>h?G(t,s,o,!0,!1,d):j(e,n,i,s,o,a,c,u,d)},q=(t,e,n,i,s,o,a,c,u)=>{let l=0;const h=e.length;let d=t.length-1,f=h-1;while(l<=d&&l<=f){const r=t[l],i=e[l]=u?mr(e[l]):pr(e[l]);if(!rr(r,i))break;y(r,i,n,null,s,o,a,c,u),l++}while(l<=d&&l<=f){const r=t[d],i=e[f]=u?mr(e[f]):pr(e[f]);if(!rr(r,i))break;y(r,i,n,null,s,o,a,c,u),d--,f--}if(l>d){if(l<=f){const t=f+1,r=t<h?e[t].el:i;while(l<=f)y(null,e[l]=u?mr(e[l]):pr(e[l]),n,r,s,o,a,c,u),l++}}else if(l>f)while(l<=d)z(t[l],s,o,!0),l++;else{const p=l,m=l,g=new Map;for(l=m;l<=f;l++){const t=e[l]=u?mr(e[l]):pr(e[l]);null!=t.key&&g.set(t.key,l)}let b,v=0;const w=f-m+1;let _=!1,I=0;const E=new Array(w);for(l=0;l<w;l++)E[l]=0;for(l=p;l<=d;l++){const r=t[l];if(v>=w){z(r,s,o,!0);continue}let i;if(null!=r.key)i=g.get(r.key);else for(b=m;b<=f;b++)if(0===E[b-m]&&rr(r,e[b])){i=b;break}void 0===i?z(r,s,o,!0):(E[i-m]=l+1,i>=I?I=i:_=!0,y(r,e[i],n,null,s,o,a,c,u),v++)}const O=_?Pn(E):r["a"];for(b=O.length-1,l=w-1;l>=0;l--){const t=m+l,r=e[t],d=t+1<h?e[t+1].el:i;0===E[l]?y(null,r,n,d,s,o,a,c,u):_&&(b<0||l!==O[b]?V(r,n,d,2):b--)}}},V=(t,e,n,r,s=null)=>{const{el:o,type:a,transition:c,children:u,shapeFlag:l}=t;if(6&l)return void V(t.component.subTree,e,n,r);if(128&l)return void t.suspense.move(e,n,r);if(64&l)return void a.move(t,e,n,Q);if(a===zn){i(o,e,n);for(let t=0;t<u.length;t++)V(u[t],e,n,r);return void i(t.anchor,e,n)}if(a===$n)return void I(t,e,n);const h=2!==r&&1&l&&c;if(h)if(0===r)c.beforeEnter(o),i(o,e,n),jn(()=>c.enter(o),s);else{const{leave:t,delayLeave:r,afterLeave:s}=c,a=()=>i(o,e,n),u=()=>{t(o,()=>{a(),s&&s()})};r?r(o,a,u):u()}else i(o,e,n)},z=(t,e,n,r=!1,i=!1)=>{const{type:s,props:o,ref:a,children:c,dynamicChildren:u,shapeFlag:l,patchFlag:h,dirs:d}=t;if(null!=a&&Rn(a,null,n,t,!0),256&l)return void e.ctx.deactivate(t);const f=1&l&&d,p=!Te(t);let m;if(p&&(m=o&&o.onVnodeBeforeUnmount)&&xn(m,e,t),6&l)$(t.component,n,r);else{if(128&l)return void t.suspense.unmount(n,r);f&&On(t,null,e,"beforeUnmount"),64&l?t.type.remove(t,e,n,i,Q,r):u&&(s!==zn||h>0&&64&h)?G(u,e,n,!1,!0):(s===zn&&384&h||!i&&16&l)&&G(c,e,n),r&&H(t)}(p&&(m=o&&o.onVnodeUnmounted)||f)&&jn(()=>{m&&xn(m,e,t),f&&On(t,null,e,"unmounted")},n)},H=t=>{const{type:e,el:n,anchor:r,transition:i}=t;if(e===zn)return void K(n,r);if(e===$n)return void E(t);const o=()=>{s(n),i&&!i.persisted&&i.afterLeave&&i.afterLeave()};if(1&t.shapeFlag&&i&&!i.persisted){const{leave:e,delayLeave:r}=i,s=()=>e(n,o);r?r(t.el,o,s):s()}else o()},K=(t,e)=>{let n;while(t!==e)n=f(t),s(t),t=n;s(e)},$=(t,e,n)=>{const{bum:i,scope:s,update:o,subTree:a,um:c}=t;i&&Object(r["n"])(i),s.stop(),o&&(o.active=!1,z(a,t,e,n)),c&&jn(c,e),jn(()=>{t.isUnmounted=!0},e),e&&e.pendingBranch&&!e.isUnmounted&&t.asyncDep&&!t.asyncResolved&&t.suspenseId===e.pendingId&&(e.deps--,0===e.deps&&e.resolve())},G=(t,e,n,r=!1,i=!1,s=0)=>{for(let o=s;o<t.length;o++)z(t[o],e,n,r,i)},W=t=>6&t.shapeFlag?W(t.component.subTree):128&t.shapeFlag?t.suspense.next():f(t.anchor||t.el),Y=(t,e,n)=>{null==t?e._vnode&&z(e._vnode,null,null,!0):y(e._vnode||null,t,e,null,null,null,n),mi(),e._vnode=t},Q={p:y,um:z,m:V,r:H,mt:P,mc:j,pc:U,pbc:C,n:W,o:t};let J,X;return e&&([J,X]=e(Q)),{render:Y,hydrate:J,createApp:Sn(Y,J)}}function Rn(t,e,n,i,s=!1){if(Object(r["o"])(t))return void t.forEach((t,o)=>Rn(t,e&&(Object(r["o"])(e)?e[o]:e),n,i,s));if(Te(i)&&!s)return;const o=4&i.shapeFlag?Br(i.component)||i.component.proxy:i.el,a=s?null:o,{i:c,r:u}=t;const l=e&&e.r,h=c.refs===r["b"]?c.refs={}:c.refs,d=c.setupState;if(null!=l&&l!==u&&(Object(r["D"])(l)?(h[l]=null,Object(r["k"])(d,l)&&(d[l]=null)):Ft(l)&&(l.value=null)),Object(r["D"])(u)){const t=()=>{h[u]=a,Object(r["k"])(d,u)&&(d[u]=a)};a?(t.id=-1,jn(t,n)):t()}else if(Ft(u)){const t=()=>{u.value=a};a?(t.id=-1,jn(t,n)):t()}else Object(r["p"])(u)&&zr(u,c,12,[a,h])}function xn(t,e,n,r=null){Hr(t,e,7,[n,r])}function Dn(t,e,n=!1){const i=t.children,s=e.children;if(Object(r["o"])(i)&&Object(r["o"])(s))for(let r=0;r<i.length;r++){const t=i[r];let e=s[r];1&e.shapeFlag&&!e.dynamicChildren&&((e.patchFlag<=0||32===e.patchFlag)&&(e=s[r]=mr(s[r]),e.el=t.el),n||Dn(t,e))}}function Pn(t){const e=t.slice(),n=[0];let r,i,s,o,a;const c=t.length;for(r=0;r<c;r++){const c=t[r];if(0!==c){if(i=n[n.length-1],t[i]<c){e[r]=i,n.push(r);continue}s=0,o=n.length-1;while(s<o)a=s+o>>1,t[n[a]]<c?s=a+1:o=a;c<t[n[s]]&&(s>0&&(e[r]=n[s-1]),n[s]=r)}}s=n.length,o=n[s-1];while(s-- >0)n[s]=o,o=e[o];return n}const Fn=t=>t.__isTeleport;const Ln="components";function Mn(t,e){return qn(Ln,t,!0,e)||t}const Un=Symbol();function Bn(t){return Object(r["D"])(t)?qn(Ln,t,!1)||t:t||Un}function qn(t,e,n=!0,i=!1){const s=Xt||kr;if(s){const n=s.type;if(t===Ln){const t=qr(n);if(t&&(t===e||t===Object(r["e"])(e)||t===Object(r["f"])(Object(r["e"])(e))))return n}const o=Vn(s[t]||n[t],e)||Vn(s.appContext[t],e);return!o&&i?n:o}}function Vn(t,e){return t&&(t[e]||t[Object(r["e"])(e)]||t[Object(r["f"])(Object(r["e"])(e))])}const zn=Symbol(void 0),Hn=Symbol(void 0),Kn=Symbol(void 0),$n=Symbol(void 0),Gn=[];let Wn=null;function Yn(t=!1){Gn.push(Wn=t?null:[])}function Qn(){Gn.pop(),Wn=Gn[Gn.length-1]||null}let Jn=1;function Xn(t){Jn+=t}function Zn(t){return t.dynamicChildren=Jn>0?Wn||r["a"]:null,Qn(),Jn>0&&Wn&&Wn.push(t),t}function tr(t,e,n,r,i,s){return Zn(ar(t,e,n,r,i,s,!0))}function er(t,e,n,r,i){return Zn(cr(t,e,n,r,i,!0))}function nr(t){return!!t&&!0===t.__v_isVNode}function rr(t,e){return t.type===e.type&&t.key===e.key}const ir="__vInternal",sr=({key:t})=>null!=t?t:null,or=({ref:t})=>null!=t?Object(r["D"])(t)||Ft(t)||Object(r["p"])(t)?{i:Xt,r:t}:t:null;function ar(t,e=null,n=null,i=0,s=null,o=(t===zn?0:1),a=!1,c=!1){const u={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&sr(e),ref:e&&or(e),scopeId:Zt,slotScopeIds:null,children:n,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:i,dynamicProps:s,dynamicChildren:null,appContext:null};return c?(gr(u,n),128&o&&t.normalize(u)):n&&(u.shapeFlag|=Object(r["D"])(n)?8:16),Jn>0&&!a&&Wn&&(u.patchFlag>0||6&o)&&32!==u.patchFlag&&Wn.push(u),u}const cr=ur;function ur(t,e=null,n=null,i=0,s=null,o=!1){if(t&&t!==Un||(t=Kn),nr(t)){const r=hr(t,e,!0);return n&&gr(r,n),r}if(Vr(t)&&(t=t.__vccOpts),e){e=lr(e);let{class:t,style:n}=e;t&&!Object(r["D"])(t)&&(e.class=Object(r["I"])(t)),Object(r["v"])(n)&&(jt(n)&&!Object(r["o"])(n)&&(n=Object(r["h"])({},n)),e.style=Object(r["J"])(n))}const a=Object(r["D"])(t)?1:le(t)?128:Fn(t)?64:Object(r["v"])(t)?4:Object(r["p"])(t)?2:0;return ar(t,e,n,i,s,a,o,!0)}function lr(t){return t?jt(t)||ir in t?Object(r["h"])({},t):t:null}function hr(t,e,n=!1){const{props:i,ref:s,patchFlag:o,children:a}=t,c=e?yr(i||{},e):i,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&sr(c),ref:e&&e.ref?n&&s?Object(r["o"])(s)?s.concat(or(e)):[s,or(e)]:or(e):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:a,target:t.target,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==zn?-1===o?16:16|o:o,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:t.transition,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&hr(t.ssContent),ssFallback:t.ssFallback&&hr(t.ssFallback),el:t.el,anchor:t.anchor};return u}function dr(t=" ",e=0){return cr(Hn,null,t,e)}function fr(t="",e=!1){return e?(Yn(),er(Kn,null,t)):cr(Kn,null,t)}function pr(t){return null==t||"boolean"===typeof t?cr(Kn):Object(r["o"])(t)?cr(zn,null,t.slice()):"object"===typeof t?mr(t):cr(Hn,null,String(t))}function mr(t){return null===t.el||t.memo?t:hr(t)}function gr(t,e){let n=0;const{shapeFlag:i}=t;if(null==e)e=null;else if(Object(r["o"])(e))n=16;else if("object"===typeof e){if(65&i){const n=e.default;return void(n&&(n._c&&(n._d=!1),gr(t,n()),n._c&&(n._d=!0)))}{n=32;const r=e._;r||ir in e?3===r&&Xt&&(1===Xt.slots._?e._=1:(e._=2,t.patchFlag|=1024)):e._ctx=Xt}}else Object(r["p"])(e)?(e={default:e,_ctx:Xt},n=32):(e=String(e),64&i?(n=16,e=[dr(e)]):n=8);t.children=e,t.shapeFlag|=n}function yr(...t){const e={};for(let n=0;n<t.length;n++){const i=t[n];for(const t in i)if("class"===t)e.class!==i.class&&(e.class=Object(r["I"])([e.class,i.class]));else if("style"===t)e.style=Object(r["J"])([e.style,i.style]);else if(Object(r["w"])(t)){const n=e[t],s=i[t];n===s||Object(r["o"])(n)&&n.includes(s)||(e[t]=n?[].concat(n,s):s)}else""!==t&&(e[t]=i[t])}return e}function br(t,e,n={},r,i){if(Xt.isCE)return cr("slot","default"===e?null:{name:e},r&&r());let s=t[e];s&&s._c&&(s._d=!1),Yn();const o=s&&vr(s(n)),a=er(zn,{key:n.key||"_"+e},o||(r?r():[]),o&&1===t._?64:-2);return!i&&a.scopeId&&(a.slotScopeIds=[a.scopeId+"-s"]),s&&s._c&&(s._d=!0),a}function vr(t){return t.some(t=>!nr(t)||t.type!==Kn&&!(t.type===zn&&!vr(t.children)))?t:null}const wr=t=>t?Nr(t)?Br(t)||t.proxy:wr(t.parent):null,_r=Object(r["h"])(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>wr(t.parent),$root:t=>wr(t.root),$emit:t=>t.emit,$options:t=>Je(t),$forceUpdate:t=>()=>ci(t.update),$nextTick:t=>oi.bind(t.proxy),$watch:t=>Ii.bind(t)}),Ir={get({_:t},e){const{ctx:n,setupState:i,data:s,props:o,accessCache:a,type:c,appContext:u}=t;let l;if("$"!==e[0]){const c=a[e];if(void 0!==c)switch(c){case 0:return i[e];case 1:return s[e];case 3:return n[e];case 2:return o[e]}else{if(i!==r["b"]&&Object(r["k"])(i,e))return a[e]=0,i[e];if(s!==r["b"]&&Object(r["k"])(s,e))return a[e]=1,s[e];if((l=t.propsOptions[0])&&Object(r["k"])(l,e))return a[e]=2,o[e];if(n!==r["b"]&&Object(r["k"])(n,e))return a[e]=3,n[e];$e&&(a[e]=4)}}const h=_r[e];let d,f;return h?("$attrs"===e&&A(t,"get",e),h(t)):(d=c.__cssModules)&&(d=d[e])?d:n!==r["b"]&&Object(r["k"])(n,e)?(a[e]=3,n[e]):(f=u.config.globalProperties,Object(r["k"])(f,e)?f[e]:void 0)},set({_:t},e,n){const{data:i,setupState:s,ctx:o}=t;if(s!==r["b"]&&Object(r["k"])(s,e))s[e]=n;else if(i!==r["b"]&&Object(r["k"])(i,e))i[e]=n;else if(Object(r["k"])(t.props,e))return!1;return("$"!==e[0]||!(e.slice(1)in t))&&(o[e]=n,!0)},has({_:{data:t,setupState:e,accessCache:n,ctx:i,appContext:s,propsOptions:o}},a){let c;return void 0!==n[a]||t!==r["b"]&&Object(r["k"])(t,a)||e!==r["b"]&&Object(r["k"])(e,a)||(c=o[0])&&Object(r["k"])(c,a)||Object(r["k"])(i,a)||Object(r["k"])(_r,a)||Object(r["k"])(s.config.globalProperties,a)}};const Er=Tn();let Or=0;function Tr(t,e,n){const i=t.type,s=(e?e.appContext:t.appContext)||Er,a={uid:Or++,vnode:t,type:i,parent:e,appContext:s,root:null,next:null,subTree:null,update:null,scope:new o(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(s.provides),accessCache:null,renderCache:[],components:null,directives:null,propsOptions:hn(i,s),emitsOptions:Qt(i,s),emit:null,emitted:null,propsDefaults:r["b"],inheritAttrs:i.inheritAttrs,ctx:r["b"],data:r["b"],props:r["b"],attrs:r["b"],slots:r["b"],refs:r["b"],setupState:r["b"],setupContext:null,suspense:n,suspenseId:n?n.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return a.ctx={_:a},a.root=e?e.root:a,a.emit=Yt.bind(null,a),t.ce&&t.ce(a),a}let kr=null;const Sr=()=>kr||Xt,Ar=t=>{kr=t,t.scope.on()},jr=()=>{kr&&kr.scope.off(),kr=null};function Nr(t){return 4&t.vnode.shapeFlag}let Cr,Rr,xr=!1;function Dr(t,e=!1){xr=e;const{props:n,children:r}=t.vnode,i=Nr(t);an(t,n,i,e),_n(t,r);const s=i?Pr(t,e):void 0;return xr=!1,s}function Pr(t,e){const n=t.type;t.accessCache=Object.create(null),t.proxy=Ct(new Proxy(t.ctx,Ir));const{setup:i}=n;if(i){const n=t.setupContext=i.length>1?Ur(t):null;Ar(t),T();const s=zr(i,t,0,[t.props,n]);if(S(),jr(),Object(r["y"])(s)){if(s.then(jr,jr),e)return s.then(n=>{Fr(t,n,e)}).catch(e=>{Kr(e,t,0)});t.asyncDep=s}else Fr(t,s,e)}else Lr(t,e)}function Fr(t,e,n){Object(r["p"])(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:Object(r["v"])(e)&&(t.setupState=zt(e)),Lr(t,n)}function Lr(t,e,n){const i=t.type;if(!t.render){if(!e&&Cr&&!i.render){const e=i.template;if(e){0;const{isCustomElement:n,compilerOptions:s}=t.appContext.config,{delimiters:o,compilerOptions:a}=i,c=Object(r["h"])(Object(r["h"])({isCustomElement:n,delimiters:o},s),a);i.render=Cr(e,c)}}t.render=i.render||r["d"],Rr&&Rr(t)}Ar(t),T(),Ge(t),S(),jr()}function Mr(t){return new Proxy(t.attrs,{get(e,n){return A(t,"get","$attrs"),e[n]}})}function Ur(t){const e=e=>{t.exposed=e||{}};let n;return{get attrs(){return n||(n=Mr(t))},slots:t.slots,emit:t.emit,expose:e}}function Br(t){if(t.exposed)return t.exposeProxy||(t.exposeProxy=new Proxy(zt(Ct(t.exposed)),{get(e,n){return n in e?e[n]:n in _r?_r[n](t):void 0}}))}function qr(t){return Object(r["p"])(t)&&t.displayName||t.name}function Vr(t){return Object(r["p"])(t)&&"__vccOpts"in t}function zr(t,e,n,r){let i;try{i=r?t(...r):t()}catch(s){Kr(s,e,n)}return i}function Hr(t,e,n,i){if(Object(r["p"])(t)){const s=zr(t,e,n,i);return s&&Object(r["y"])(s)&&s.catch(t=>{Kr(t,e,n)}),s}const s=[];for(let r=0;r<t.length;r++)s.push(Hr(t[r],e,n,i));return s}function Kr(t,e,n,r=!0){const i=e?e.vnode:null;if(e){let r=e.parent;const i=e.proxy,s=n;while(r){const e=r.ec;if(e)for(let n=0;n<e.length;n++)if(!1===e[n](t,i,s))return;r=r.parent}const o=e.appContext.config.errorHandler;if(o)return void zr(o,null,10,[t,i,s])}$r(t,n,i,r)}function $r(t,e,n,r=!0){console.error(t)}let Gr=!1,Wr=!1;const Yr=[];let Qr=0;const Jr=[];let Xr=null,Zr=0;const ti=[];let ei=null,ni=0;const ri=Promise.resolve();let ii=null,si=null;function oi(t){const e=ii||ri;return t?e.then(this?t.bind(this):t):e}function ai(t){let e=Qr+1,n=Yr.length;while(e<n){const r=e+n>>>1,i=gi(Yr[r]);i<t?e=r+1:n=r}return e}function ci(t){Yr.length&&Yr.includes(t,Gr&&t.allowRecurse?Qr+1:Qr)||t===si||(null==t.id?Yr.push(t):Yr.splice(ai(t.id),0,t),ui())}function ui(){Gr||Wr||(Wr=!0,ii=ri.then(yi))}function li(t){const e=Yr.indexOf(t);e>Qr&&Yr.splice(e,1)}function hi(t,e,n,i){Object(r["o"])(t)?n.push(...t):e&&e.includes(t,t.allowRecurse?i+1:i)||n.push(t),ui()}function di(t){hi(t,Xr,Jr,Zr)}function fi(t){hi(t,ei,ti,ni)}function pi(t,e=null){if(Jr.length){for(si=e,Xr=[...new Set(Jr)],Jr.length=0,Zr=0;Zr<Xr.length;Zr++)Xr[Zr]();Xr=null,Zr=0,si=null,pi(t,e)}}function mi(t){if(ti.length){const t=[...new Set(ti)];if(ti.length=0,ei)return void ei.push(...t);for(ei=t,ei.sort((t,e)=>gi(t)-gi(e)),ni=0;ni<ei.length;ni++)ei[ni]();ei=null,ni=0}}const gi=t=>null==t.id?1/0:t.id;function yi(t){Wr=!1,Gr=!0,pi(t),Yr.sort((t,e)=>gi(t)-gi(e));r["d"];try{for(Qr=0;Qr<Yr.length;Qr++){const t=Yr[Qr];t&&!1!==t.active&&zr(t,null,14)}}finally{Qr=0,Yr.length=0,mi(t),Gr=!1,ii=null,(Yr.length||Jr.length||ti.length)&&yi(t)}}function bi(t,e){return _i(t,null,e)}const vi={};function wi(t,e,n){return _i(t,e,n)}function _i(t,e,{immediate:n,deep:i,flush:s,onTrack:o,onTrigger:a}=r["b"]){const c=kr;let u,l,h=!1,d=!1;if(Ft(t)?(u=()=>t.value,h=!!t._shallow):St(t)?(u=()=>t,i=!0):Object(r["o"])(t)?(d=!0,h=t.some(St),u=()=>t.map(t=>Ft(t)?t.value:St(t)?Oi(t):Object(r["p"])(t)?zr(t,c,2):void 0)):u=Object(r["p"])(t)?e?()=>zr(t,c,2):()=>{if(!c||!c.isUnmounted)return l&&l(),Hr(t,c,3,[f])}:r["d"],e&&i){const t=u;u=()=>Oi(t())}let f=t=>{l=y.onStop=()=>{zr(t,c,4)}};if(xr)return f=r["d"],e?n&&Hr(e,c,3,[u(),d?[]:void 0,f]):u(),r["d"];let p=d?[]:vi;const m=()=>{if(y.active)if(e){const t=y.run();(i||h||(d?t.some((t,e)=>Object(r["j"])(t,p[e])):Object(r["j"])(t,p)))&&(l&&l(),Hr(e,c,3,[t,p===vi?void 0:p,f]),p=t)}else y.run()};let g;m.allowRecurse=!!e,g="sync"===s?m:"post"===s?()=>jn(m,c&&c.suspense):()=>{!c||c.isMounted?di(m):m()};const y=new _(u,g);return e?n?m():p=y.run():"post"===s?jn(y.run.bind(y),c&&c.suspense):y.run(),()=>{y.stop(),c&&c.scope&&Object(r["K"])(c.scope.effects,y)}}function Ii(t,e,n){const i=this.proxy,s=Object(r["D"])(t)?t.includes(".")?Ei(i,t):()=>i[t]:t.bind(i,i);let o;Object(r["p"])(e)?o=e:(o=e.handler,n=e);const a=kr;Ar(this);const c=_i(s,o.bind(i),n);return a?Ar(a):jr(),c}function Ei(t,e){const n=e.split(".");return()=>{let e=t;for(let t=0;t<n.length&&e;t++)e=e[n[t]];return e}}function Oi(t,e){if(!Object(r["v"])(t)||t["__v_skip"])return t;if(e=e||new Set,e.has(t))return t;if(e.add(t),Ft(t))Oi(t.value,e);else if(Object(r["o"])(t))for(let n=0;n<t.length;n++)Oi(t[n],e);else if(Object(r["B"])(t)||Object(r["t"])(t))t.forEach(t=>{Oi(t,e)});else if(Object(r["x"])(t))for(const n in t)Oi(t[n],e);return t}function Ti(t,e,n){const i=arguments.length;return 2===i?Object(r["v"])(e)&&!Object(r["o"])(e)?nr(e)?cr(t,null,[e]):cr(t,e):cr(t,null,e):(i>3?n=Array.prototype.slice.call(arguments,2):3===i&&nr(n)&&(n=[n]),cr(t,e,n))}Symbol("");const ki="3.2.22",Si="http://www.w3.org/2000/svg",Ai="undefined"!==typeof document?document:null,ji=new Map,Ni={insert:(t,e,n)=>{e.insertBefore(t,n||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,n,r)=>{const i=e?Ai.createElementNS(Si,t):Ai.createElement(t,n?{is:n}:void 0);return"select"===t&&r&&null!=r.multiple&&i.setAttribute("multiple",r.multiple),i},createText:t=>Ai.createTextNode(t),createComment:t=>Ai.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ai.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},cloneNode(t){const e=t.cloneNode(!0);return"_value"in t&&(e._value=t._value),e},insertStaticContent(t,e,n,r){const i=n?n.previousSibling:e.lastChild;let s=ji.get(t);if(!s){const e=Ai.createElement("template");if(e.innerHTML=r?`<svg>${t}</svg>`:t,s=e.content,r){const t=s.firstChild;while(t.firstChild)s.appendChild(t.firstChild);s.removeChild(t)}ji.set(t,s)}return e.insertBefore(s.cloneNode(!0),n),[i?i.nextSibling:e.firstChild,n?n.previousSibling:e.lastChild]}};function Ci(t,e,n){const r=t._vtc;r&&(e=(e?[e,...r]:[...r]).join(" ")),null==e?t.removeAttribute("class"):n?t.setAttribute("class",e):t.className=e}function Ri(t,e,n){const i=t.style,s=Object(r["D"])(n);if(n&&!s){for(const t in n)Di(i,t,n[t]);if(e&&!Object(r["D"])(e))for(const t in e)null==n[t]&&Di(i,t,"")}else{const r=i.display;s?e!==n&&(i.cssText=n):e&&t.removeAttribute("style"),"_vod"in t&&(i.display=r)}}const xi=/\s*!important$/;function Di(t,e,n){if(Object(r["o"])(n))n.forEach(n=>Di(t,e,n));else if(e.startsWith("--"))t.setProperty(e,n);else{const i=Li(t,e);xi.test(n)?t.setProperty(Object(r["l"])(i),n.replace(xi,""),"important"):t[i]=n}}const Pi=["Webkit","Moz","ms"],Fi={};function Li(t,e){const n=Fi[e];if(n)return n;let i=Object(r["e"])(e);if("filter"!==i&&i in t)return Fi[e]=i;i=Object(r["f"])(i);for(let r=0;r<Pi.length;r++){const n=Pi[r]+i;if(n in t)return Fi[e]=n}return e}const Mi="http://www.w3.org/1999/xlink";function Ui(t,e,n,i,s){if(i&&e.startsWith("xlink:"))null==n?t.removeAttributeNS(Mi,e.slice(6,e.length)):t.setAttributeNS(Mi,e,n);else{const i=Object(r["C"])(e);null==n||i&&!Object(r["m"])(n)?t.removeAttribute(e):t.setAttribute(e,i?"":n)}}function Bi(t,e,n,i,s,o,a){if("innerHTML"===e||"textContent"===e)return i&&a(i,s,o),void(t[e]=null==n?"":n);if("value"===e&&"PROGRESS"!==t.tagName){t._value=n;const r=null==n?"":n;return t.value!==r&&(t.value=r),void(null==n&&t.removeAttribute(e))}if(""===n||null==n){const i=typeof t[e];if("boolean"===i)return void(t[e]=Object(r["m"])(n));if(null==n&&"string"===i)return t[e]="",void t.removeAttribute(e);if("number"===i){try{t[e]=0}catch(c){}return void t.removeAttribute(e)}}try{t[e]=n}catch(u){0}}let qi=Date.now,Vi=!1;if("undefined"!==typeof window){qi()>document.createEvent("Event").timeStamp&&(qi=()=>performance.now());const t=navigator.userAgent.match(/firefox\/(\d+)/i);Vi=!!(t&&Number(t[1])<=53)}let zi=0;const Hi=Promise.resolve(),Ki=()=>{zi=0},$i=()=>zi||(Hi.then(Ki),zi=qi());function Gi(t,e,n,r){t.addEventListener(e,n,r)}function Wi(t,e,n,r){t.removeEventListener(e,n,r)}function Yi(t,e,n,r,i=null){const s=t._vei||(t._vei={}),o=s[e];if(r&&o)o.value=r;else{const[n,a]=Ji(e);if(r){const o=s[e]=Xi(r,i);Gi(t,n,o,a)}else o&&(Wi(t,n,o,a),s[e]=void 0)}}const Qi=/(?:Once|Passive|Capture)$/;function Ji(t){let e;if(Qi.test(t)){let n;e={};while(n=t.match(Qi))t=t.slice(0,t.length-n[0].length),e[n[0].toLowerCase()]=!0}return[Object(r["l"])(t.slice(2)),e]}function Xi(t,e){const n=t=>{const r=t.timeStamp||qi();(Vi||r>=n.attached-1)&&Hr(Zi(t,n.value),e,5,[t])};return n.value=t,n.attached=$i(),n}function Zi(t,e){if(Object(r["o"])(e)){const n=t.stopImmediatePropagation;return t.stopImmediatePropagation=()=>{n.call(t),t._stopped=!0},e.map(t=>e=>!e._stopped&&t(e))}return e}const ts=/^on[a-z]/,es=(t,e,n,i,s=!1,o,a,c,u)=>{"class"===e?Ci(t,i,s):"style"===e?Ri(t,n,i):Object(r["w"])(e)?Object(r["u"])(e)||Yi(t,e,n,i,a):("."===e[0]?(e=e.slice(1),1):"^"===e[0]?(e=e.slice(1),0):ns(t,e,i,s))?Bi(t,e,i,o,a,c,u):("true-value"===e?t._trueValue=i:"false-value"===e&&(t._falseValue=i),Ui(t,e,i,s))};function ns(t,e,n,i){return i?"innerHTML"===e||"textContent"===e||!!(e in t&&ts.test(e)&&Object(r["p"])(n)):"spellcheck"!==e&&"draggable"!==e&&("form"!==e&&(("list"!==e||"INPUT"!==t.tagName)&&(("type"!==e||"TEXTAREA"!==t.tagName)&&((!ts.test(e)||!Object(r["D"])(n))&&e in t))))}"undefined"!==typeof HTMLElement&&HTMLElement;const rs="transition",is="animation",ss=(t,{slots:e})=>Ti(ye,us(t),e);ss.displayName="Transition";const os={name:String,type:String,css:{type:Boolean,default:!0},duration:[String,Number,Object],enterFromClass:String,enterActiveClass:String,enterToClass:String,appearFromClass:String,appearActiveClass:String,appearToClass:String,leaveFromClass:String,leaveActiveClass:String,leaveToClass:String},as=(ss.props=Object(r["h"])({},ye.props,os),(t,e=[])=>{Object(r["o"])(t)?t.forEach(t=>t(...e)):t&&t(...e)}),cs=t=>!!t&&(Object(r["o"])(t)?t.some(t=>t.length>1):t.length>1);function us(t){const e={};for(const r in t)r in os||(e[r]=t[r]);if(!1===t.css)return e;const{name:n="v",type:i,duration:s,enterFromClass:o=n+"-enter-from",enterActiveClass:a=n+"-enter-active",enterToClass:c=n+"-enter-to",appearFromClass:u=o,appearActiveClass:l=a,appearToClass:h=c,leaveFromClass:d=n+"-leave-from",leaveActiveClass:f=n+"-leave-active",leaveToClass:p=n+"-leave-to"}=t,m=ls(s),g=m&&m[0],y=m&&m[1],{onBeforeEnter:b,onEnter:v,onEnterCancelled:w,onLeave:_,onLeaveCancelled:I,onBeforeAppear:E=b,onAppear:O=v,onAppearCancelled:T=w}=e,k=(t,e,n)=>{fs(t,e?h:c),fs(t,e?l:a),n&&n()},S=(t,e)=>{fs(t,p),fs(t,f),e&&e()},A=t=>(e,n)=>{const r=t?O:v,s=()=>k(e,t,n);as(r,[e,s]),ps(()=>{fs(e,t?u:o),ds(e,t?h:c),cs(r)||gs(e,i,g,s)})};return Object(r["h"])(e,{onBeforeEnter(t){as(b,[t]),ds(t,o),ds(t,a)},onBeforeAppear(t){as(E,[t]),ds(t,u),ds(t,l)},onEnter:A(!1),onAppear:A(!0),onLeave(t,e){const n=()=>S(t,e);ds(t,d),ws(),ds(t,f),ps(()=>{fs(t,d),ds(t,p),cs(_)||gs(t,i,y,n)}),as(_,[t,n])},onEnterCancelled(t){k(t,!1),as(w,[t])},onAppearCancelled(t){k(t,!0),as(T,[t])},onLeaveCancelled(t){S(t),as(I,[t])}})}function ls(t){if(null==t)return null;if(Object(r["v"])(t))return[hs(t.enter),hs(t.leave)];{const e=hs(t);return[e,e]}}function hs(t){const e=Object(r["N"])(t);return e}function ds(t,e){e.split(/\s+/).forEach(e=>e&&t.classList.add(e)),(t._vtc||(t._vtc=new Set)).add(e)}function fs(t,e){e.split(/\s+/).forEach(e=>e&&t.classList.remove(e));const{_vtc:n}=t;n&&(n.delete(e),n.size||(t._vtc=void 0))}function ps(t){requestAnimationFrame(()=>{requestAnimationFrame(t)})}let ms=0;function gs(t,e,n,r){const i=t._endId=++ms,s=()=>{i===t._endId&&r()};if(n)return setTimeout(s,n);const{type:o,timeout:a,propCount:c}=ys(t,e);if(!o)return r();const u=o+"end";let l=0;const h=()=>{t.removeEventListener(u,d),s()},d=e=>{e.target===t&&++l>=c&&h()};setTimeout(()=>{l<c&&h()},a+1),t.addEventListener(u,d)}function ys(t,e){const n=window.getComputedStyle(t),r=t=>(n[t]||"").split(", "),i=r(rs+"Delay"),s=r(rs+"Duration"),o=bs(i,s),a=r(is+"Delay"),c=r(is+"Duration"),u=bs(a,c);let l=null,h=0,d=0;e===rs?o>0&&(l=rs,h=o,d=s.length):e===is?u>0&&(l=is,h=u,d=c.length):(h=Math.max(o,u),l=h>0?o>u?rs:is:null,d=l?l===rs?s.length:c.length:0);const f=l===rs&&/\b(transform|all)(,|$)/.test(n[rs+"Property"]);return{type:l,timeout:h,propCount:d,hasTransform:f}}function bs(t,e){while(t.length<e.length)t=t.concat(t);return Math.max(...e.map((e,n)=>vs(e)+vs(t[n])))}function vs(t){return 1e3*Number(t.slice(0,-1).replace(",","."))}function ws(){return document.body.offsetHeight}new WeakMap,new WeakMap;const _s=t=>{const e=t.props["onUpdate:modelValue"];return Object(r["o"])(e)?t=>Object(r["n"])(e,t):e};function Is(t){t.target.composing=!0}function Es(t){const e=t.target;e.composing&&(e.composing=!1,Os(e,"input"))}function Os(t,e){const n=document.createEvent("HTMLEvents");n.initEvent(e,!0,!0),t.dispatchEvent(n)}const Ts={created(t,{modifiers:{lazy:e,trim:n,number:i}},s){t._assign=_s(s);const o=i||s.props&&"number"===s.props.type;Gi(t,e?"change":"input",e=>{if(e.target.composing)return;let i=t.value;n?i=i.trim():o&&(i=Object(r["N"])(i)),t._assign(i)}),n&&Gi(t,"change",()=>{t.value=t.value.trim()}),e||(Gi(t,"compositionstart",Is),Gi(t,"compositionend",Es),Gi(t,"change",Es))},mounted(t,{value:e}){t.value=null==e?"":e},beforeUpdate(t,{value:e,modifiers:{lazy:n,trim:i,number:s}},o){if(t._assign=_s(o),t.composing)return;if(document.activeElement===t){if(n)return;if(i&&t.value.trim()===e)return;if((s||"number"===t.type)&&Object(r["N"])(t.value)===e)return}const a=null==e?"":e;t.value!==a&&(t.value=a)}},ks={deep:!0,created(t,e,n){t._assign=_s(n),Gi(t,"change",()=>{const e=t._modelValue,n=js(t),i=t.checked,s=t._assign;if(Object(r["o"])(e)){const t=Object(r["G"])(e,n),o=-1!==t;if(i&&!o)s(e.concat(n));else if(!i&&o){const n=[...e];n.splice(t,1),s(n)}}else if(Object(r["B"])(e)){const t=new Set(e);i?t.add(n):t.delete(n),s(t)}else s(Ns(t,i))})},mounted:Ss,beforeUpdate(t,e,n){t._assign=_s(n),Ss(t,e,n)}};function Ss(t,{value:e,oldValue:n},i){t._modelValue=e,Object(r["o"])(e)?t.checked=Object(r["G"])(e,i.props.value)>-1:Object(r["B"])(e)?t.checked=e.has(i.props.value):e!==n&&(t.checked=Object(r["F"])(e,Ns(t,!0)))}const As={created(t,{value:e},n){t.checked=Object(r["F"])(e,n.props.value),t._assign=_s(n),Gi(t,"change",()=>{t._assign(js(t))})},beforeUpdate(t,{value:e,oldValue:n},i){t._assign=_s(i),e!==n&&(t.checked=Object(r["F"])(e,i.props.value))}};function js(t){return"_value"in t?t._value:t.value}function Ns(t,e){const n=e?"_trueValue":"_falseValue";return n in t?t[n]:e}const Cs=Object(r["h"])({patchProp:es},Ni);let Rs;function xs(){return Rs||(Rs=Nn(Cs))}const Ds=(...t)=>{const e=xs().createApp(...t);const{mount:n}=e;return e.mount=t=>{const i=Ps(t);if(!i)return;const s=e._component;Object(r["p"])(s)||s.render||s.template||(s.template=i.innerHTML),i.innerHTML="";const o=n(i,!1,i instanceof SVGElement);return i instanceof Element&&(i.removeAttribute("v-cloak"),i.setAttribute("data-v-app","")),o},e};function Ps(t){if(Object(r["D"])(t)){const e=document.querySelector(t);return e}return t}},"7a77":function(t,e,n){"use strict";function r(t){this.message=t}r.prototype.toString=function(){return"Cancel"+(this.message?": "+this.message:"")},r.prototype.__CANCEL__=!0,t.exports=r},"7aac":function(t,e,n){"use strict";var r=n("c532");t.exports=r.isStandardBrowserEnv()?function(){return{write:function(t,e,n,i,s,o){var a=[];a.push(t+"="+encodeURIComponent(e)),r.isNumber(n)&&a.push("expires="+new Date(n).toGMTString()),r.isString(i)&&a.push("path="+i),r.isString(s)&&a.push("domain="+s),!0===o&&a.push("secure"),document.cookie=a.join("; ")},read:function(t){var e=document.cookie.match(new RegExp("(^|;\\s*)("+t+")=([^;]*)"));return e?decodeURIComponent(e[3]):null},remove:function(t){this.write(t,"",Date.now()-864e5)}}}():function(){return{write:function(){},read:function(){return null},remove:function(){}}}()},"7ded":function(t,e,n){"use strict";n.d(e,"a",(function(){return y}));var r=n("1fd5"),i=n("22e5"),s=n("589b"),o=n("e691");
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class a{constructor(t,e){this._delegate=t,this.firebase=e,Object(s["_addComponent"])(t,new i["a"]("app-compat",()=>this,"PUBLIC")),this.container=t.container}get automaticDataCollectionEnabled(){return this._delegate.automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this._delegate.automaticDataCollectionEnabled=t}get name(){return this._delegate.name}get options(){return this._delegate.options}delete(){return new Promise(t=>{this._delegate.checkDestroyed(),t()}).then(()=>(this.firebase.INTERNAL.removeApp(this.name),Object(s["deleteApp"])(this._delegate)))}_getService(t,e=s["_DEFAULT_ENTRY_NAME"]){var n;this._delegate.checkDestroyed();const r=this._delegate.container.getProvider(t);return r.isInitialized()||"EXPLICIT"!==(null===(n=r.getComponent())||void 0===n?void 0:n.instantiationMode)||r.initialize(),r.getImmediate({identifier:e})}_removeServiceInstance(t,e=s["_DEFAULT_ENTRY_NAME"]){this._delegate.container.getProvider(t).clearInstance(e)}_addComponent(t){Object(s["_addComponent"])(this._delegate,t)}_addOrOverwriteComponent(t){Object(s["_addOrOverwriteComponent"])(this._delegate,t)}toJSON(){return{name:this.name,automaticDataCollectionEnabled:this.automaticDataCollectionEnabled,options:this.options}}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const c={["no-app"]:"No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",["invalid-app-argument"]:"firebase.{$appName}() takes either no argument or a Firebase App instance."},u=new r["b"]("app-compat","Firebase",c);
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function l(t){const e={},n={__esModule:!0,initializeApp:a,app:o,registerVersion:s["registerVersion"],setLogLevel:s["setLogLevel"],onLog:s["onLog"],apps:null,SDK_VERSION:s["SDK_VERSION"],INTERNAL:{registerComponent:l,removeApp:i,useAsService:h,modularAPIs:s}};function i(t){delete e[t]}function o(t){if(t=t||s["_DEFAULT_ENTRY_NAME"],!Object(r["e"])(e,t))throw u.create("no-app",{appName:t});return e[t]}function a(i,o={}){const a=s["initializeApp"](i,o);if(Object(r["e"])(e,a.name))return e[a.name];const c=new t(a,n);return e[a.name]=c,c}function c(){return Object.keys(e).map(t=>e[t])}function l(e){const i=e.name,a=i.replace("-compat","");if(s["_registerComponent"](e)&&"PUBLIC"===e.type){const s=(t=o())=>{if("function"!==typeof t[a])throw u.create("invalid-app-argument",{appName:i});return t[a]()};void 0!==e.serviceProps&&Object(r["i"])(s,e.serviceProps),n[a]=s,t.prototype[a]=function(...t){const n=this._getService.bind(this,i);return n.apply(this,e.multipleInstances?t:[])}}return"PUBLIC"===e.type?n[a]:null}function h(t,e){if("serverAuth"===e)return null;const n=e;return n}return n["default"]=n,Object.defineProperty(n,"apps",{get:c}),o["App"]=t,n}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function h(){const t=l(a);function e(e){Object(r["i"])(t,e)}return t.INTERNAL=Object.assign(Object.assign({},t.INTERNAL),{createFirebaseNamespace:h,extendNamespace:e,createSubscribe:r["g"],ErrorFactory:r["b"],deepExtend:r["i"]}),t}const d=h(),f=new o["b"]("@firebase/app-compat"),p="@firebase/app-compat",m="0.1.10";
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function g(t){Object(s["registerVersion"])(p,m,t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */if(Object(r["m"])()&&void 0!==self.firebase){f.warn("\n    Warning: Firebase is already defined in the global scope. Please make sure\n    Firebase library is only loaded once.\n  ");const t=self.firebase.SDK_VERSION;t&&t.indexOf("LITE")>=0&&f.warn("\n    Warning: You are trying to load Firebase while using Firebase Performance standalone script.\n    You should load Firebase Performance with this instance of Firebase to avoid loading duplicate code.\n    ")}const y=d;g()},"83b9":function(t,e,n){"use strict";var r=n("d925"),i=n("e683");t.exports=function(t,e){return t&&!r(e)?i(t,e):e}},"848b":function(t,e,n){"use strict";var r=n("5cce").version,i={};["object","boolean","number","function","string","symbol"].forEach((function(t,e){i[t]=function(n){return typeof n===t||"a"+(e<1?"n ":" ")+t}}));var s={};function o(t,e,n){if("object"!==typeof t)throw new TypeError("options must be an object");var r=Object.keys(t),i=r.length;while(i-- >0){var s=r[i],o=e[s];if(o){var a=t[s],c=void 0===a||o(a,s,t);if(!0!==c)throw new TypeError("option "+s+" must be "+c)}else if(!0!==n)throw Error("Unknown option "+s)}}i.transitional=function(t,e,n){function i(t,e){return"[Axios v"+r+"] Transitional option '"+t+"'"+e+(n?". "+n:"")}return function(n,r,o){if(!1===t)throw new Error(i(r," has been removed"+(e?" in "+e:"")));return e&&!s[r]&&(s[r]=!0,console.warn(i(r," has been deprecated since v"+e+" and will be removed in the near future"))),!t||t(n,r,o)}},t.exports={assertOptions:o,validators:i}},"8df4":function(t,e,n){"use strict";var r=n("7a77");function i(t){if("function"!==typeof t)throw new TypeError("executor must be a function.");var e;this.promise=new Promise((function(t){e=t}));var n=this;this.promise.then((function(t){if(n._listeners){var e,r=n._listeners.length;for(e=0;e<r;e++)n._listeners[e](t);n._listeners=null}})),this.promise.then=function(t){var e,r=new Promise((function(t){n.subscribe(t),e=t})).then(t);return r.cancel=function(){n.unsubscribe(e)},r},t((function(t){n.reason||(n.reason=new r(t),e(n.reason))}))}i.prototype.throwIfRequested=function(){if(this.reason)throw this.reason},i.prototype.subscribe=function(t){this.reason?t(this.reason):this._listeners?this._listeners.push(t):this._listeners=[t]},i.prototype.unsubscribe=function(t){if(this._listeners){var e=this._listeners.indexOf(t);-1!==e&&this._listeners.splice(e,1)}},i.source=function(){var t,e=new i((function(e){t=e}));return{token:e,cancel:t}},t.exports=i},"8f6b":function(t,e,n){"use strict";(function(t){n.d(e,"a",(function(){return Ar})),n.d(e,"b",(function(){return Nr})),n.d(e,"c",(function(){return jr})),n.d(e,"d",(function(){return Rr})),n.d(e,"e",(function(){return Cr})),n.d(e,"f",(function(){return xr})),n.d(e,"g",(function(){return Dr})),n.d(e,"h",(function(){return kr})),n.d(e,"i",(function(){return Sr}));var r,i="undefined"!==typeof globalThis?globalThis:"undefined"!==typeof window?window:"undefined"!==typeof t?t:"undefined"!==typeof self?self:{},s={},o=o||{},a=i||self;function c(){}function u(t){var e=typeof t;return e="object"!=e?e:t?Array.isArray(t)?"array":e:"null","array"==e||"object"==e&&"number"==typeof t.length}function l(t){var e=typeof t;return"object"==e&&null!=t||"function"==e}function h(t){return Object.prototype.hasOwnProperty.call(t,d)&&t[d]||(t[d]=++f)}var d="closure_uid_"+(1e9*Math.random()>>>0),f=0;function p(t,e,n){return t.call.apply(t.bind,arguments)}function m(t,e,n){if(!t)throw Error();if(2<arguments.length){var r=Array.prototype.slice.call(arguments,2);return function(){var n=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(n,r),t.apply(e,n)}}return function(){return t.apply(e,arguments)}}function g(t,e,n){return g=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?p:m,g.apply(null,arguments)}function y(t,e){var n=Array.prototype.slice.call(arguments,1);return function(){var e=n.slice();return e.push.apply(e,arguments),t.apply(this,e)}}function b(t,e){function n(){}n.prototype=e.prototype,t.Z=e.prototype,t.prototype=new n,t.prototype.constructor=t,t.Vb=function(t,n,r){for(var i=Array(arguments.length-2),s=2;s<arguments.length;s++)i[s-2]=arguments[s];return e.prototype[n].apply(t,i)}}function v(){this.s=this.s,this.o=this.o}var w=0,_={};v.prototype.s=!1,v.prototype.na=function(){if(!this.s&&(this.s=!0,this.M(),0!=w)){var t=h(this);delete _[t]}},v.prototype.M=function(){if(this.o)for(;this.o.length;)this.o.shift()()};const I=Array.prototype.indexOf?function(t,e){return Array.prototype.indexOf.call(t,e,void 0)}:function(t,e){if("string"===typeof t)return"string"!==typeof e||1!=e.length?-1:t.indexOf(e,0);for(let n=0;n<t.length;n++)if(n in t&&t[n]===e)return n;return-1},E=Array.prototype.forEach?function(t,e,n){Array.prototype.forEach.call(t,e,n)}:function(t,e,n){const r=t.length,i="string"===typeof t?t.split(""):t;for(let s=0;s<r;s++)s in i&&e.call(n,i[s],s,t)};function O(t){t:{var e=Vn;const n=t.length,r="string"===typeof t?t.split(""):t;for(let i=0;i<n;i++)if(i in r&&e.call(void 0,r[i],i,t)){e=i;break t}e=-1}return 0>e?null:"string"===typeof t?t.charAt(e):t[e]}function T(t){return Array.prototype.concat.apply([],arguments)}function k(t){const e=t.length;if(0<e){const n=Array(e);for(let r=0;r<e;r++)n[r]=t[r];return n}return[]}function S(t){return/^[\s\xa0]*$/.test(t)}var A,j=String.prototype.trim?function(t){return t.trim()}:function(t){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(t)[1]};function N(t,e){return-1!=t.indexOf(e)}function C(t,e){return t<e?-1:t>e?1:0}t:{var R=a.navigator;if(R){var x=R.userAgent;if(x){A=x;break t}}A=""}function D(t,e,n){for(const r in t)e.call(n,t[r],r,t)}function P(t){const e={};for(const n in t)e[n]=t[n];return e}var F="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function L(t,e){let n,r;for(let i=1;i<arguments.length;i++){for(n in r=arguments[i],r)t[n]=r[n];for(let e=0;e<F.length;e++)n=F[e],Object.prototype.hasOwnProperty.call(r,n)&&(t[n]=r[n])}}function M(t){return M[" "](t),t}function U(t){var e=X;return Object.prototype.hasOwnProperty.call(e,9)?e[9]:e[9]=t(9)}M[" "]=c;var B,q=N(A,"Opera"),V=N(A,"Trident")||N(A,"MSIE"),z=N(A,"Edge"),H=z||V,K=N(A,"Gecko")&&!(N(A.toLowerCase(),"webkit")&&!N(A,"Edge"))&&!(N(A,"Trident")||N(A,"MSIE"))&&!N(A,"Edge"),$=N(A.toLowerCase(),"webkit")&&!N(A,"Edge");function G(){var t=a.document;return t?t.documentMode:void 0}t:{var W="",Y=function(){var t=A;return K?/rv:([^\);]+)(\)|;)/.exec(t):z?/Edge\/([\d\.]+)/.exec(t):V?/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(t):$?/WebKit\/(\S+)/.exec(t):q?/(?:Version)[ \/]?(\S+)/.exec(t):void 0}();if(Y&&(W=Y?Y[1]:""),V){var Q=G();if(null!=Q&&Q>parseFloat(W)){B=String(Q);break t}}B=W}var J,X={};function Z(){return U((function(){let t=0;const e=j(String(B)).split("."),n=j("9").split("."),r=Math.max(e.length,n.length);for(let o=0;0==t&&o<r;o++){var i=e[o]||"",s=n[o]||"";do{if(i=/(\d*)(\D*)(.*)/.exec(i)||["","","",""],s=/(\d*)(\D*)(.*)/.exec(s)||["","","",""],0==i[0].length&&0==s[0].length)break;t=C(0==i[1].length?0:parseInt(i[1],10),0==s[1].length?0:parseInt(s[1],10))||C(0==i[2].length,0==s[2].length)||C(i[2],s[2]),i=i[3],s=s[3]}while(0==t)}return 0<=t}))}if(a.document&&V){var tt=G();J=tt||(parseInt(B,10)||void 0)}else J=void 0;var et=J,nt=function(){if(!a.addEventListener||!Object.defineProperty)return!1;var t=!1,e=Object.defineProperty({},"passive",{get:function(){t=!0}});try{a.addEventListener("test",c,e),a.removeEventListener("test",c,e)}catch(n){}return t}();function rt(t,e){this.type=t,this.g=this.target=e,this.defaultPrevented=!1}function it(t,e){if(rt.call(this,t?t.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,t){var n=this.type=t.type,r=t.changedTouches&&t.changedTouches.length?t.changedTouches[0]:null;if(this.target=t.target||t.srcElement,this.g=e,e=t.relatedTarget){if(K){t:{try{M(e.nodeName);var i=!0;break t}catch(s){}i=!1}i||(e=null)}}else"mouseover"==n?e=t.fromElement:"mouseout"==n&&(e=t.toElement);this.relatedTarget=e,r?(this.clientX=void 0!==r.clientX?r.clientX:r.pageX,this.clientY=void 0!==r.clientY?r.clientY:r.pageY,this.screenX=r.screenX||0,this.screenY=r.screenY||0):(this.clientX=void 0!==t.clientX?t.clientX:t.pageX,this.clientY=void 0!==t.clientY?t.clientY:t.pageY,this.screenX=t.screenX||0,this.screenY=t.screenY||0),this.button=t.button,this.key=t.key||"",this.ctrlKey=t.ctrlKey,this.altKey=t.altKey,this.shiftKey=t.shiftKey,this.metaKey=t.metaKey,this.pointerId=t.pointerId||0,this.pointerType="string"===typeof t.pointerType?t.pointerType:st[t.pointerType]||"",this.state=t.state,this.i=t,t.defaultPrevented&&it.Z.h.call(this)}}rt.prototype.h=function(){this.defaultPrevented=!0},b(it,rt);var st={2:"touch",3:"pen",4:"mouse"};it.prototype.h=function(){it.Z.h.call(this);var t=this.i;t.preventDefault?t.preventDefault():t.returnValue=!1};var ot="closure_listenable_"+(1e6*Math.random()|0),at=0;function ct(t,e,n,r,i){this.listener=t,this.proxy=null,this.src=e,this.type=n,this.capture=!!r,this.ia=i,this.key=++at,this.ca=this.fa=!1}function ut(t){t.ca=!0,t.listener=null,t.proxy=null,t.src=null,t.ia=null}function lt(t){this.src=t,this.g={},this.h=0}function ht(t,e){var n=e.type;if(n in t.g){var r,i=t.g[n],s=I(i,e);(r=0<=s)&&Array.prototype.splice.call(i,s,1),r&&(ut(e),0==t.g[n].length&&(delete t.g[n],t.h--))}}function dt(t,e,n,r){for(var i=0;i<t.length;++i){var s=t[i];if(!s.ca&&s.listener==e&&s.capture==!!n&&s.ia==r)return i}return-1}lt.prototype.add=function(t,e,n,r,i){var s=t.toString();t=this.g[s],t||(t=this.g[s]=[],this.h++);var o=dt(t,e,r,i);return-1<o?(e=t[o],n||(e.fa=!1)):(e=new ct(e,this.src,s,!!r,i),e.fa=n,t.push(e)),e};var ft="closure_lm_"+(1e6*Math.random()|0),pt={};function mt(t,e,n,r,i){if(r&&r.once)return bt(t,e,n,r,i);if(Array.isArray(e)){for(var s=0;s<e.length;s++)mt(t,e[s],n,r,i);return null}return n=Tt(n),t&&t[ot]?t.N(e,n,l(r)?!!r.capture:!!r,i):gt(t,e,n,!1,r,i)}function gt(t,e,n,r,i,s){if(!e)throw Error("Invalid event type");var o=l(i)?!!i.capture:!!i,a=Et(t);if(a||(t[ft]=a=new lt(t)),n=a.add(e,n,r,o,s),n.proxy)return n;if(r=yt(),n.proxy=r,r.src=t,r.listener=n,t.addEventListener)nt||(i=o),void 0===i&&(i=!1),t.addEventListener(e.toString(),r,i);else if(t.attachEvent)t.attachEvent(_t(e.toString()),r);else{if(!t.addListener||!t.removeListener)throw Error("addEventListener and attachEvent are unavailable.");t.addListener(r)}return n}function yt(){function t(n){return e.call(t.src,t.listener,n)}var e=It;return t}function bt(t,e,n,r,i){if(Array.isArray(e)){for(var s=0;s<e.length;s++)bt(t,e[s],n,r,i);return null}return n=Tt(n),t&&t[ot]?t.O(e,n,l(r)?!!r.capture:!!r,i):gt(t,e,n,!0,r,i)}function vt(t,e,n,r,i){if(Array.isArray(e))for(var s=0;s<e.length;s++)vt(t,e[s],n,r,i);else r=l(r)?!!r.capture:!!r,n=Tt(n),t&&t[ot]?(t=t.i,e=String(e).toString(),e in t.g&&(s=t.g[e],n=dt(s,n,r,i),-1<n&&(ut(s[n]),Array.prototype.splice.call(s,n,1),0==s.length&&(delete t.g[e],t.h--)))):t&&(t=Et(t))&&(e=t.g[e.toString()],t=-1,e&&(t=dt(e,n,r,i)),(n=-1<t?e[t]:null)&&wt(n))}function wt(t){if("number"!==typeof t&&t&&!t.ca){var e=t.src;if(e&&e[ot])ht(e.i,t);else{var n=t.type,r=t.proxy;e.removeEventListener?e.removeEventListener(n,r,t.capture):e.detachEvent?e.detachEvent(_t(n),r):e.addListener&&e.removeListener&&e.removeListener(r),(n=Et(e))?(ht(n,t),0==n.h&&(n.src=null,e[ft]=null)):ut(t)}}}function _t(t){return t in pt?pt[t]:pt[t]="on"+t}function It(t,e){if(t.ca)t=!0;else{e=new it(e,this);var n=t.listener,r=t.ia||t.src;t.fa&&wt(t),t=n.call(r,e)}return t}function Et(t){return t=t[ft],t instanceof lt?t:null}var Ot="__closure_events_fn_"+(1e9*Math.random()>>>0);function Tt(t){return"function"===typeof t?t:(t[Ot]||(t[Ot]=function(e){return t.handleEvent(e)}),t[Ot])}function kt(){v.call(this),this.i=new lt(this),this.P=this,this.I=null}function St(t,e){var n,r=t.I;if(r)for(n=[];r;r=r.I)n.push(r);if(t=t.P,r=e.type||e,"string"===typeof e)e=new rt(e,t);else if(e instanceof rt)e.target=e.target||t;else{var i=e;e=new rt(r,t),L(e,i)}if(i=!0,n)for(var s=n.length-1;0<=s;s--){var o=e.g=n[s];i=At(o,r,!0,e)&&i}if(o=e.g=t,i=At(o,r,!0,e)&&i,i=At(o,r,!1,e)&&i,n)for(s=0;s<n.length;s++)o=e.g=n[s],i=At(o,r,!1,e)&&i}function At(t,e,n,r){if(e=t.i.g[String(e)],!e)return!0;e=e.concat();for(var i=!0,s=0;s<e.length;++s){var o=e[s];if(o&&!o.ca&&o.capture==n){var a=o.listener,c=o.ia||o.src;o.fa&&ht(t.i,o),i=!1!==a.call(c,r)&&i}}return i&&!r.defaultPrevented}b(kt,v),kt.prototype[ot]=!0,kt.prototype.removeEventListener=function(t,e,n,r){vt(this,t,e,n,r)},kt.prototype.M=function(){if(kt.Z.M.call(this),this.i){var t,e=this.i;for(t in e.g){for(var n=e.g[t],r=0;r<n.length;r++)ut(n[r]);delete e.g[t],e.h--}}this.I=null},kt.prototype.N=function(t,e,n,r){return this.i.add(String(t),e,!1,n,r)},kt.prototype.O=function(t,e,n,r){return this.i.add(String(t),e,!0,n,r)};var jt=a.JSON.stringify;function Nt(){var t=Ut;let e=null;return t.g&&(e=t.g,t.g=t.g.next,t.g||(t.h=null),e.next=null),e}class Ct{constructor(){this.h=this.g=null}add(t,e){const n=xt.get();n.set(t,e),this.h?this.h.next=n:this.g=n,this.h=n}}var Rt,xt=new class{constructor(t,e){this.i=t,this.j=e,this.h=0,this.g=null}get(){let t;return 0<this.h?(this.h--,t=this.g,this.g=t.next,t.next=null):t=this.i(),t}}(()=>new Dt,t=>t.reset());class Dt{constructor(){this.next=this.g=this.h=null}set(t,e){this.h=t,this.g=e,this.next=null}reset(){this.next=this.g=this.h=null}}function Pt(t){a.setTimeout(()=>{throw t},0)}function Ft(t,e){Rt||Lt(),Mt||(Rt(),Mt=!0),Ut.add(t,e)}function Lt(){var t=a.Promise.resolve(void 0);Rt=function(){t.then(Bt)}}var Mt=!1,Ut=new Ct;function Bt(){for(var t;t=Nt();){try{t.h.call(t.g)}catch(n){Pt(n)}var e=xt;e.j(t),100>e.h&&(e.h++,t.next=e.g,e.g=t)}Mt=!1}function qt(t,e){kt.call(this),this.h=t||1,this.g=e||a,this.j=g(this.kb,this),this.l=Date.now()}function Vt(t){t.da=!1,t.S&&(t.g.clearTimeout(t.S),t.S=null)}function zt(t,e,n){if("function"===typeof t)n&&(t=g(t,n));else{if(!t||"function"!=typeof t.handleEvent)throw Error("Invalid listener argument");t=g(t.handleEvent,t)}return 2147483647<Number(e)?-1:a.setTimeout(t,e||0)}function Ht(t){t.g=zt(()=>{t.g=null,t.i&&(t.i=!1,Ht(t))},t.j);const e=t.h;t.h=null,t.m.apply(null,e)}b(qt,kt),r=qt.prototype,r.da=!1,r.S=null,r.kb=function(){if(this.da){var t=Date.now()-this.l;0<t&&t<.8*this.h?this.S=this.g.setTimeout(this.j,this.h-t):(this.S&&(this.g.clearTimeout(this.S),this.S=null),St(this,"tick"),this.da&&(Vt(this),this.start()))}},r.start=function(){this.da=!0,this.S||(this.S=this.g.setTimeout(this.j,this.h),this.l=Date.now())},r.M=function(){qt.Z.M.call(this),Vt(this),delete this.g};class Kt extends v{constructor(t,e){super(),this.m=t,this.j=e,this.h=null,this.i=!1,this.g=null}l(t){this.h=arguments,this.g?this.i=!0:Ht(this)}M(){super.M(),this.g&&(a.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function $t(t){v.call(this),this.h=t,this.g={}}b($t,v);var Gt=[];function Wt(t,e,n,r){Array.isArray(n)||(n&&(Gt[0]=n.toString()),n=Gt);for(var i=0;i<n.length;i++){var s=mt(e,n[i],r||t.handleEvent,!1,t.h||t);if(!s)break;t.g[s.key]=s}}function Yt(t){D(t.g,(function(t,e){this.g.hasOwnProperty(e)&&wt(t)}),t),t.g={}}function Qt(){this.g=!0}function Jt(t,e,n,r,i,s){t.info((function(){if(t.g)if(s)for(var o="",a=s.split("&"),c=0;c<a.length;c++){var u=a[c].split("=");if(1<u.length){var l=u[0];u=u[1];var h=l.split("_");o=2<=h.length&&"type"==h[1]?o+(l+"=")+u+"&":o+(l+"=redacted&")}}else o=null;else o=s;return"XMLHTTP REQ ("+r+") [attempt "+i+"]: "+e+"\n"+n+"\n"+o}))}function Xt(t,e,n,r,i,s,o){t.info((function(){return"XMLHTTP RESP ("+r+") [ attempt "+i+"]: "+e+"\n"+n+"\n"+s+" "+o}))}function Zt(t,e,n,r){t.info((function(){return"XMLHTTP TEXT ("+e+"): "+ee(t,n)+(r?" "+r:"")}))}function te(t,e){t.info((function(){return"TIMEOUT: "+e}))}function ee(t,e){if(!t.g)return e;if(!e)return null;try{var n=JSON.parse(e);if(n)for(t=0;t<n.length;t++)if(Array.isArray(n[t])){var r=n[t];if(!(2>r.length)){var i=r[1];if(Array.isArray(i)&&!(1>i.length)){var s=i[0];if("noop"!=s&&"stop"!=s&&"close"!=s)for(var o=1;o<i.length;o++)i[o]=""}}}return jt(n)}catch(a){return e}}$t.prototype.M=function(){$t.Z.M.call(this),Yt(this)},$t.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")},Qt.prototype.Aa=function(){this.g=!1},Qt.prototype.info=function(){};var ne={},re=null;function ie(){return re=re||new kt}function se(t){rt.call(this,ne.Ma,t)}function oe(t){const e=ie();St(e,new se(e,t))}function ae(t,e){rt.call(this,ne.STAT_EVENT,t),this.stat=e}function ce(t){const e=ie();St(e,new ae(e,t))}function ue(t,e){rt.call(this,ne.Na,t),this.size=e}function le(t,e){if("function"!==typeof t)throw Error("Fn must not be null and must be a function");return a.setTimeout((function(){t()}),e)}ne.Ma="serverreachability",b(se,rt),ne.STAT_EVENT="statevent",b(ae,rt),ne.Na="timingevent",b(ue,rt);var he={NO_ERROR:0,lb:1,yb:2,xb:3,sb:4,wb:5,zb:6,Ja:7,TIMEOUT:8,Cb:9},de={qb:"complete",Mb:"success",Ka:"error",Ja:"abort",Eb:"ready",Fb:"readystatechange",TIMEOUT:"timeout",Ab:"incrementaldata",Db:"progress",tb:"downloadprogress",Ub:"uploadprogress"};function fe(){}function pe(t){return t.h||(t.h=t.i())}function me(){}fe.prototype.h=null;var ge,ye={OPEN:"a",pb:"b",Ka:"c",Bb:"d"};function be(){rt.call(this,"d")}function ve(){rt.call(this,"c")}function we(){}function _e(t,e,n,r){this.l=t,this.j=e,this.m=n,this.X=r||1,this.V=new $t(this),this.P=Ee,t=H?125:void 0,this.W=new qt(t),this.H=null,this.i=!1,this.s=this.A=this.v=this.K=this.F=this.Y=this.B=null,this.D=[],this.g=null,this.C=0,this.o=this.u=null,this.N=-1,this.I=!1,this.O=0,this.L=null,this.aa=this.J=this.$=this.U=!1,this.h=new Ie}function Ie(){this.i=null,this.g="",this.h=!1}b(be,rt),b(ve,rt),b(we,fe),we.prototype.g=function(){return new XMLHttpRequest},we.prototype.i=function(){return{}},ge=new we;var Ee=45e3,Oe={},Te={};function ke(t,e,n){t.K=1,t.v=Je(Ke(e)),t.s=n,t.U=!0,Se(t,null)}function Se(t,e){t.F=Date.now(),Ce(t),t.A=Ke(t.v);var n=t.A,r=t.X;Array.isArray(r)||(r=[String(r)]),fn(n.h,"t",r),t.C=0,n=t.l.H,t.h=new Ie,t.g=vr(t.l,n?e:null,!t.s),0<t.O&&(t.L=new Kt(g(t.Ia,t,t.g),t.O)),Wt(t.V,t.g,"readystatechange",t.gb),e=t.H?P(t.H):{},t.s?(t.u||(t.u="POST"),e["Content-Type"]="application/x-www-form-urlencoded",t.g.ea(t.A,t.u,t.s,e)):(t.u="GET",t.g.ea(t.A,t.u,null,e)),oe(1),Jt(t.j,t.u,t.A,t.m,t.X,t.s)}function Ae(t){return!!t.g&&("GET"==t.u&&2!=t.K&&t.l.Ba)}function je(t,e,n){let r,i=!0;for(;!t.I&&t.C<n.length;){if(r=Ne(t,n),r==Te){4==e&&(t.o=4,ce(14),i=!1),Zt(t.j,t.m,null,"[Incomplete Response]");break}if(r==Oe){t.o=4,ce(15),Zt(t.j,t.m,n,"[Invalid Chunk]"),i=!1;break}Zt(t.j,t.m,r,null),Fe(t,r)}Ae(t)&&r!=Te&&r!=Oe&&(t.h.g="",t.C=0),4!=e||0!=n.length||t.h.h||(t.o=1,ce(16),i=!1),t.i=t.i&&i,i?0<n.length&&!t.aa&&(t.aa=!0,e=t.l,e.g==t&&e.$&&!e.L&&(e.h.info("Great, no buffering proxy detected. Bytes received: "+n.length),hr(e),e.L=!0,ce(11))):(Zt(t.j,t.m,n,"[Invalid Chunked Response]"),Pe(t),De(t))}function Ne(t,e){var n=t.C,r=e.indexOf("\n",n);return-1==r?Te:(n=Number(e.substring(n,r)),isNaN(n)?Oe:(r+=1,r+n>e.length?Te:(e=e.substr(r,n),t.C=r+n,e)))}function Ce(t){t.Y=Date.now()+t.P,Re(t,t.P)}function Re(t,e){if(null!=t.B)throw Error("WatchDog timer not null");t.B=le(g(t.eb,t),e)}function xe(t){t.B&&(a.clearTimeout(t.B),t.B=null)}function De(t){0==t.l.G||t.I||pr(t.l,t)}function Pe(t){xe(t);var e=t.L;e&&"function"==typeof e.na&&e.na(),t.L=null,Vt(t.W),Yt(t.V),t.g&&(e=t.g,t.g=null,e.abort(),e.na())}function Fe(t,e){try{var n=t.l;if(0!=n.G&&(n.g==t||_n(n.i,t)))if(n.I=t.N,!t.J&&_n(n.i,t)&&3==n.G){try{var r=n.Ca.g.parse(e)}catch(u){r=null}if(Array.isArray(r)&&3==r.length){var i=r;if(0==i[0]){t:if(!n.u){if(n.g){if(!(n.g.F+3e3<t.F))break t;fr(n),er(n)}lr(n),ce(18)}}else n.ta=i[1],0<n.ta-n.U&&37500>i[2]&&n.N&&0==n.A&&!n.v&&(n.v=le(g(n.ab,n),6e3));if(1>=wn(n.i)&&n.ka){try{n.ka()}catch(u){}n.ka=void 0}}else gr(n,11)}else if((t.J||n.g==t)&&fr(n),!S(e))for(i=n.Ca.g.parse(e),e=0;e<i.length;e++){let u=i[e];if(n.U=u[0],u=u[1],2==n.G)if("c"==u[0]){n.J=u[1],n.la=u[2];const e=u[3];null!=e&&(n.ma=e,n.h.info("VER="+n.ma));const i=u[4];null!=i&&(n.za=i,n.h.info("SVER="+n.za));const l=u[5];null!=l&&"number"===typeof l&&0<l&&(r=1.5*l,n.K=r,n.h.info("backChannelRequestTimeoutMs_="+r)),r=n;const h=t.g;if(h){const t=h.g?h.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(t){var s=r.i;!s.g&&(N(t,"spdy")||N(t,"quic")||N(t,"h2"))&&(s.j=s.l,s.g=new Set,s.h&&(In(s,s.h),s.h=null))}if(r.D){const t=h.g?h.g.getResponseHeader("X-HTTP-Session-Id"):null;t&&(r.sa=t,Qe(r.F,r.D,t))}}n.G=3,n.j&&n.j.xa(),n.$&&(n.O=Date.now()-t.F,n.h.info("Handshake RTT: "+n.O+"ms")),r=n;var o=t;if(r.oa=br(r,r.H?r.la:null,r.W),o.J){En(r.i,o);var a=o,c=r.K;c&&a.setTimeout(c),a.B&&(xe(a),Ce(a)),r.g=o}else ur(r);0<n.l.length&&ir(n)}else"stop"!=u[0]&&"close"!=u[0]||gr(n,7);else 3==n.G&&("stop"==u[0]||"close"==u[0]?"stop"==u[0]?gr(n,7):tr(n):"noop"!=u[0]&&n.j&&n.j.wa(u),n.A=0)}oe(4)}catch(u){}}function Le(t){if(t.R&&"function"==typeof t.R)return t.R();if("string"===typeof t)return t.split("");if(u(t)){for(var e=[],n=t.length,r=0;r<n;r++)e.push(t[r]);return e}for(r in e=[],n=0,t)e[n++]=t[r];return e}function Me(t,e){if(t.forEach&&"function"==typeof t.forEach)t.forEach(e,void 0);else if(u(t)||"string"===typeof t)E(t,e,void 0);else{if(t.T&&"function"==typeof t.T)var n=t.T();else if(t.R&&"function"==typeof t.R)n=void 0;else if(u(t)||"string"===typeof t){n=[];for(var r=t.length,i=0;i<r;i++)n.push(i)}else for(i in n=[],r=0,t)n[r++]=i;r=Le(t),i=r.length;for(var s=0;s<i;s++)e.call(void 0,r[s],n&&n[s],t)}}function Ue(t,e){this.h={},this.g=[],this.i=0;var n=arguments.length;if(1<n){if(n%2)throw Error("Uneven number of arguments");for(var r=0;r<n;r+=2)this.set(arguments[r],arguments[r+1])}else if(t)if(t instanceof Ue)for(n=t.T(),r=0;r<n.length;r++)this.set(n[r],t.get(n[r]));else for(r in t)this.set(r,t[r])}function Be(t){if(t.i!=t.g.length){for(var e=0,n=0;e<t.g.length;){var r=t.g[e];qe(t.h,r)&&(t.g[n++]=r),e++}t.g.length=n}if(t.i!=t.g.length){var i={};for(n=e=0;e<t.g.length;)r=t.g[e],qe(i,r)||(t.g[n++]=r,i[r]=1),e++;t.g.length=n}}function qe(t,e){return Object.prototype.hasOwnProperty.call(t,e)}r=_e.prototype,r.setTimeout=function(t){this.P=t},r.gb=function(t){t=t.target;const e=this.L;e&&3==Wn(t)?e.l():this.Ia(t)},r.Ia=function(t){try{if(t==this.g)t:{const h=Wn(this.g);var e=this.g.Da();const d=this.g.ba();if(!(3>h)&&(3!=h||H||this.g&&(this.h.h||this.g.ga()||Yn(this.g)))){this.I||4!=h||7==e||oe(8==e||0>=d?3:2),xe(this);var n=this.g.ba();this.N=n;e:if(Ae(this)){var r=Yn(this.g);t="";var i=r.length,s=4==Wn(this.g);if(!this.h.i){if("undefined"===typeof TextDecoder){Pe(this),De(this);var o="";break e}this.h.i=new a.TextDecoder}for(e=0;e<i;e++)this.h.h=!0,t+=this.h.i.decode(r[e],{stream:s&&e==i-1});r.splice(0,i),this.h.g+=t,this.C=0,o=this.h.g}else o=this.g.ga();if(this.i=200==n,Xt(this.j,this.u,this.A,this.m,this.X,h,n),this.i){if(this.$&&!this.J){e:{if(this.g){var c,u=this.g;if((c=u.g?u.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!S(c)){var l=c;break e}}l=null}if(!(n=l)){this.i=!1,this.o=3,ce(12),Pe(this),De(this);break t}Zt(this.j,this.m,n,"Initial handshake response via X-HTTP-Initial-Response"),this.J=!0,Fe(this,n)}this.U?(je(this,h,o),H&&this.i&&3==h&&(Wt(this.V,this.W,"tick",this.fb),this.W.start())):(Zt(this.j,this.m,o,null),Fe(this,o)),4==h&&Pe(this),this.i&&!this.I&&(4==h?pr(this.l,this):(this.i=!1,Ce(this)))}else 400==n&&0<o.indexOf("Unknown SID")?(this.o=3,ce(12)):(this.o=0,ce(13)),Pe(this),De(this)}}}catch(h){}},r.fb=function(){if(this.g){var t=Wn(this.g),e=this.g.ga();this.C<e.length&&(xe(this),je(this,t,e),this.i&&4!=t&&Ce(this))}},r.cancel=function(){this.I=!0,Pe(this)},r.eb=function(){this.B=null;const t=Date.now();0<=t-this.Y?(te(this.j,this.A),2!=this.K&&(oe(3),ce(17)),Pe(this),this.o=2,De(this)):Re(this,this.Y-t)},r=Ue.prototype,r.R=function(){Be(this);for(var t=[],e=0;e<this.g.length;e++)t.push(this.h[this.g[e]]);return t},r.T=function(){return Be(this),this.g.concat()},r.get=function(t,e){return qe(this.h,t)?this.h[t]:e},r.set=function(t,e){qe(this.h,t)||(this.i++,this.g.push(t)),this.h[t]=e},r.forEach=function(t,e){for(var n=this.T(),r=0;r<n.length;r++){var i=n[r],s=this.get(i);t.call(e,s,i,this)}};var Ve=/^(?:([^:/?#.]+):)?(?:\/\/(?:([^\\/?#]*)@)?([^\\/?#]*?)(?::([0-9]+))?(?=[\\/?#]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/;function ze(t,e){if(t){t=t.split("&");for(var n=0;n<t.length;n++){var r=t[n].indexOf("="),i=null;if(0<=r){var s=t[n].substring(0,r);i=t[n].substring(r+1)}else s=t[n];e(s,i?decodeURIComponent(i.replace(/\+/g," ")):"")}}}function He(t,e){if(this.i=this.s=this.j="",this.m=null,this.o=this.l="",this.g=!1,t instanceof He){this.g=void 0!==e?e:t.g,$e(this,t.j),this.s=t.s,Ge(this,t.i),We(this,t.m),this.l=t.l,e=t.h;var n=new un;n.i=e.i,e.g&&(n.g=new Ue(e.g),n.h=e.h),Ye(this,n),this.o=t.o}else t&&(n=String(t).match(Ve))?(this.g=!!e,$e(this,n[1]||"",!0),this.s=tn(n[2]||""),Ge(this,n[3]||"",!0),We(this,n[4]),this.l=tn(n[5]||"",!0),Ye(this,n[6]||"",!0),this.o=tn(n[7]||"")):(this.g=!!e,this.h=new un(null,this.g))}function Ke(t){return new He(t)}function $e(t,e,n){t.j=n?tn(e,!0):e,t.j&&(t.j=t.j.replace(/:$/,""))}function Ge(t,e,n){t.i=n?tn(e,!0):e}function We(t,e){if(e){if(e=Number(e),isNaN(e)||0>e)throw Error("Bad port number "+e);t.m=e}else t.m=null}function Ye(t,e,n){e instanceof un?(t.h=e,mn(t.h,t.g)):(n||(e=en(e,an)),t.h=new un(e,t.g))}function Qe(t,e,n){t.h.set(e,n)}function Je(t){return Qe(t,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),t}function Xe(t){return t instanceof He?Ke(t):new He(t,void 0)}function Ze(t,e,n,r){var i=new He(null,void 0);return t&&$e(i,t),e&&Ge(i,e),n&&We(i,n),r&&(i.l=r),i}function tn(t,e){return t?e?decodeURI(t.replace(/%25/g,"%2525")):decodeURIComponent(t):""}function en(t,e,n){return"string"===typeof t?(t=encodeURI(t).replace(e,nn),n&&(t=t.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),t):null}function nn(t){return t=t.charCodeAt(0),"%"+(t>>4&15).toString(16)+(15&t).toString(16)}He.prototype.toString=function(){var t=[],e=this.j;e&&t.push(en(e,rn,!0),":");var n=this.i;return(n||"file"==e)&&(t.push("//"),(e=this.s)&&t.push(en(e,rn,!0),"@"),t.push(encodeURIComponent(String(n)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),n=this.m,null!=n&&t.push(":",String(n))),(n=this.l)&&(this.i&&"/"!=n.charAt(0)&&t.push("/"),t.push(en(n,"/"==n.charAt(0)?on:sn,!0))),(n=this.h.toString())&&t.push("?",n),(n=this.o)&&t.push("#",en(n,cn)),t.join("")};var rn=/[#\/\?@]/g,sn=/[#\?:]/g,on=/[#\?]/g,an=/[#\?@]/g,cn=/#/g;function un(t,e){this.h=this.g=null,this.i=t||null,this.j=!!e}function ln(t){t.g||(t.g=new Ue,t.h=0,t.i&&ze(t.i,(function(e,n){t.add(decodeURIComponent(e.replace(/\+/g," ")),n)})))}function hn(t,e){ln(t),e=pn(t,e),qe(t.g.h,e)&&(t.i=null,t.h-=t.g.get(e).length,t=t.g,qe(t.h,e)&&(delete t.h[e],t.i--,t.g.length>2*t.i&&Be(t)))}function dn(t,e){return ln(t),e=pn(t,e),qe(t.g.h,e)}function fn(t,e,n){hn(t,e),0<n.length&&(t.i=null,t.g.set(pn(t,e),k(n)),t.h+=n.length)}function pn(t,e){return e=String(e),t.j&&(e=e.toLowerCase()),e}function mn(t,e){e&&!t.j&&(ln(t),t.i=null,t.g.forEach((function(t,e){var n=e.toLowerCase();e!=n&&(hn(this,e),fn(this,n,t))}),t)),t.j=e}r=un.prototype,r.add=function(t,e){ln(this),this.i=null,t=pn(this,t);var n=this.g.get(t);return n||this.g.set(t,n=[]),n.push(e),this.h+=1,this},r.forEach=function(t,e){ln(this),this.g.forEach((function(n,r){E(n,(function(n){t.call(e,n,r,this)}),this)}),this)},r.T=function(){ln(this);for(var t=this.g.R(),e=this.g.T(),n=[],r=0;r<e.length;r++)for(var i=t[r],s=0;s<i.length;s++)n.push(e[r]);return n},r.R=function(t){ln(this);var e=[];if("string"===typeof t)dn(this,t)&&(e=T(e,this.g.get(pn(this,t))));else{t=this.g.R();for(var n=0;n<t.length;n++)e=T(e,t[n])}return e},r.set=function(t,e){return ln(this),this.i=null,t=pn(this,t),dn(this,t)&&(this.h-=this.g.get(t).length),this.g.set(t,[e]),this.h+=1,this},r.get=function(t,e){return t?(t=this.R(t),0<t.length?String(t[0]):e):e},r.toString=function(){if(this.i)return this.i;if(!this.g)return"";for(var t=[],e=this.g.T(),n=0;n<e.length;n++){var r=e[n],i=encodeURIComponent(String(r));r=this.R(r);for(var s=0;s<r.length;s++){var o=i;""!==r[s]&&(o+="="+encodeURIComponent(String(r[s]))),t.push(o)}}return this.i=t.join("&")};var gn=class{constructor(t,e){this.h=t,this.g=e}};function yn(t){this.l=t||bn,a.PerformanceNavigationTiming?(t=a.performance.getEntriesByType("navigation"),t=0<t.length&&("hq"==t[0].nextHopProtocol||"h2"==t[0].nextHopProtocol)):t=!!(a.g&&a.g.Ea&&a.g.Ea()&&a.g.Ea().Zb),this.j=t?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}var bn=10;function vn(t){return!!t.h||!!t.g&&t.g.size>=t.j}function wn(t){return t.h?1:t.g?t.g.size:0}function _n(t,e){return t.h?t.h==e:!!t.g&&t.g.has(e)}function In(t,e){t.g?t.g.add(e):t.h=e}function En(t,e){t.h&&t.h==e?t.h=null:t.g&&t.g.has(e)&&t.g.delete(e)}function On(t){if(null!=t.h)return t.i.concat(t.h.D);if(null!=t.g&&0!==t.g.size){let e=t.i;for(const n of t.g.values())e=e.concat(n.D);return e}return k(t.i)}function Tn(){}function kn(){this.g=new Tn}function Sn(t,e,n){const r=n||"";try{Me(t,(function(t,n){let i=t;l(t)&&(i=jt(t)),e.push(r+n+"="+encodeURIComponent(i))}))}catch(i){throw e.push(r+"type="+encodeURIComponent("_badmap")),i}}function An(t,e){const n=new Qt;if(a.Image){const r=new Image;r.onload=y(jn,n,r,"TestLoadImage: loaded",!0,e),r.onerror=y(jn,n,r,"TestLoadImage: error",!1,e),r.onabort=y(jn,n,r,"TestLoadImage: abort",!1,e),r.ontimeout=y(jn,n,r,"TestLoadImage: timeout",!1,e),a.setTimeout((function(){r.ontimeout&&r.ontimeout()}),1e4),r.src=t}else e(!1)}function jn(t,e,n,r,i){try{e.onload=null,e.onerror=null,e.onabort=null,e.ontimeout=null,i(r)}catch(s){}}function Nn(t){this.l=t.$b||null,this.j=t.ib||!1}function Cn(t,e){kt.call(this),this.D=t,this.u=e,this.m=void 0,this.readyState=Rn,this.status=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.v=new Headers,this.h=null,this.C="GET",this.B="",this.g=!1,this.A=this.j=this.l=null}yn.prototype.cancel=function(){if(this.i=On(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&0!==this.g.size){for(const t of this.g.values())t.cancel();this.g.clear()}},Tn.prototype.stringify=function(t){return a.JSON.stringify(t,void 0)},Tn.prototype.parse=function(t){return a.JSON.parse(t,void 0)},b(Nn,fe),Nn.prototype.g=function(){return new Cn(this.l,this.j)},Nn.prototype.i=function(t){return function(){return t}}({}),b(Cn,kt);var Rn=0;function xn(t){t.j.read().then(t.Sa.bind(t)).catch(t.ha.bind(t))}function Dn(t){t.readyState=4,t.l=null,t.j=null,t.A=null,Pn(t)}function Pn(t){t.onreadystatechange&&t.onreadystatechange.call(t)}r=Cn.prototype,r.open=function(t,e){if(this.readyState!=Rn)throw this.abort(),Error("Error reopening a connection");this.C=t,this.B=e,this.readyState=1,Pn(this)},r.send=function(t){if(1!=this.readyState)throw this.abort(),Error("need to call open() first. ");this.g=!0;const e={headers:this.v,method:this.C,credentials:this.m,cache:void 0};t&&(e.body=t),(this.D||a).fetch(new Request(this.B,e)).then(this.Va.bind(this),this.ha.bind(this))},r.abort=function(){this.response=this.responseText="",this.v=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted."),1<=this.readyState&&this.g&&4!=this.readyState&&(this.g=!1,Dn(this)),this.readyState=Rn},r.Va=function(t){if(this.g&&(this.l=t,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=t.headers,this.readyState=2,Pn(this)),this.g&&(this.readyState=3,Pn(this),this.g)))if("arraybuffer"===this.responseType)t.arrayBuffer().then(this.Ta.bind(this),this.ha.bind(this));else if("undefined"!==typeof a.ReadableStream&&"body"in t){if(this.j=t.body.getReader(),this.u){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.A=new TextDecoder;xn(this)}else t.text().then(this.Ua.bind(this),this.ha.bind(this))},r.Sa=function(t){if(this.g){if(this.u&&t.value)this.response.push(t.value);else if(!this.u){var e=t.value?t.value:new Uint8Array(0);(e=this.A.decode(e,{stream:!t.done}))&&(this.response=this.responseText+=e)}t.done?Dn(this):Pn(this),3==this.readyState&&xn(this)}},r.Ua=function(t){this.g&&(this.response=this.responseText=t,Dn(this))},r.Ta=function(t){this.g&&(this.response=t,Dn(this))},r.ha=function(){this.g&&Dn(this)},r.setRequestHeader=function(t,e){this.v.append(t,e)},r.getResponseHeader=function(t){return this.h&&this.h.get(t.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const t=[],e=this.h.entries();for(var n=e.next();!n.done;)n=n.value,t.push(n[0]+": "+n[1]),n=e.next();return t.join("\r\n")},Object.defineProperty(Cn.prototype,"withCredentials",{get:function(){return"include"===this.m},set:function(t){this.m=t?"include":"same-origin"}});var Fn=a.JSON.parse;function Ln(t){kt.call(this),this.headers=new Ue,this.u=t||null,this.h=!1,this.C=this.g=null,this.H="",this.m=0,this.j="",this.l=this.F=this.v=this.D=!1,this.B=0,this.A=null,this.J=Mn,this.K=this.L=!1}b(Ln,kt);var Mn="",Un=/^https?$/i,Bn=["POST","PUT"];function qn(t){return V&&Z()&&"number"===typeof t.timeout&&void 0!==t.ontimeout}function Vn(t){return"content-type"==t.toLowerCase()}function zn(t,e){t.h=!1,t.g&&(t.l=!0,t.g.abort(),t.l=!1),t.j=e,t.m=5,Hn(t),$n(t)}function Hn(t){t.D||(t.D=!0,St(t,"complete"),St(t,"error"))}function Kn(t){if(t.h&&"undefined"!=typeof o&&(!t.C[1]||4!=Wn(t)||2!=t.ba()))if(t.v&&4==Wn(t))zt(t.Fa,0,t);else if(St(t,"readystatechange"),4==Wn(t)){t.h=!1;try{const o=t.ba();t:switch(o){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var e=!0;break t;default:e=!1}var n;if(!(n=e)){var r;if(r=0===o){var i=String(t.H).match(Ve)[1]||null;if(!i&&a.self&&a.self.location){var s=a.self.location.protocol;i=s.substr(0,s.length-1)}r=!Un.test(i?i.toLowerCase():"")}n=r}if(n)St(t,"complete"),St(t,"success");else{t.m=6;try{var c=2<Wn(t)?t.g.statusText:""}catch(u){c=""}t.j=c+" ["+t.ba()+"]",Hn(t)}}finally{$n(t)}}}function $n(t,e){if(t.g){Gn(t);const r=t.g,i=t.C[0]?c:null;t.g=null,t.C=null,e||St(t,"ready");try{r.onreadystatechange=i}catch(n){}}}function Gn(t){t.g&&t.K&&(t.g.ontimeout=null),t.A&&(a.clearTimeout(t.A),t.A=null)}function Wn(t){return t.g?t.g.readyState:0}function Yn(t){try{if(!t.g)return null;if("response"in t.g)return t.g.response;switch(t.J){case Mn:case"text":return t.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in t.g)return t.g.mozResponseArrayBuffer}return null}catch(e){return null}}function Qn(t){let e="";return D(t,(function(t,n){e+=n,e+=":",e+=t,e+="\r\n"})),e}function Jn(t,e,n){t:{for(r in n){var r=!1;break t}r=!0}r||(n=Qn(n),"string"===typeof t?null!=n&&encodeURIComponent(String(n)):Qe(t,e,n))}function Xn(t,e,n){return n&&n.internalChannelParams&&n.internalChannelParams[t]||e}function Zn(t){this.za=0,this.l=[],this.h=new Qt,this.la=this.oa=this.F=this.W=this.g=this.sa=this.D=this.aa=this.o=this.P=this.s=null,this.Za=this.V=0,this.Xa=Xn("failFast",!1,t),this.N=this.v=this.u=this.m=this.j=null,this.X=!0,this.I=this.ta=this.U=-1,this.Y=this.A=this.C=0,this.Pa=Xn("baseRetryDelayMs",5e3,t),this.$a=Xn("retryDelaySeedMs",1e4,t),this.Ya=Xn("forwardChannelMaxRetries",2,t),this.ra=Xn("forwardChannelRequestTimeoutMs",2e4,t),this.qa=t&&t.xmlHttpFactory||void 0,this.Ba=t&&t.Yb||!1,this.K=void 0,this.H=t&&t.supportsCrossDomainXhr||!1,this.J="",this.i=new yn(t&&t.concurrentRequestLimit),this.Ca=new kn,this.ja=t&&t.fastHandshake||!1,this.Ra=t&&t.Wb||!1,t&&t.Aa&&this.h.Aa(),t&&t.forceLongPolling&&(this.X=!1),this.$=!this.ja&&this.X&&t&&t.detectBufferingProxy||!1,this.ka=void 0,this.O=0,this.L=!1,this.B=null,this.Wa=!t||!1!==t.Xb}function tr(t){if(nr(t),3==t.G){var e=t.V++,n=Ke(t.F);Qe(n,"SID",t.J),Qe(n,"RID",e),Qe(n,"TYPE","terminate"),ar(t,n),e=new _e(t,t.h,e,void 0),e.K=2,e.v=Je(Ke(n)),n=!1,a.navigator&&a.navigator.sendBeacon&&(n=a.navigator.sendBeacon(e.v.toString(),"")),!n&&a.Image&&((new Image).src=e.v,n=!0),n||(e.g=vr(e.l,null),e.g.ea(e.v)),e.F=Date.now(),Ce(e)}yr(t)}function er(t){t.g&&(hr(t),t.g.cancel(),t.g=null)}function nr(t){er(t),t.u&&(a.clearTimeout(t.u),t.u=null),fr(t),t.i.cancel(),t.m&&("number"===typeof t.m&&a.clearTimeout(t.m),t.m=null)}function rr(t,e){t.l.push(new gn(t.Za++,e)),3==t.G&&ir(t)}function ir(t){vn(t.i)||t.m||(t.m=!0,Ft(t.Ha,t),t.C=0)}function sr(t,e){return!(wn(t.i)>=t.i.j-(t.m?1:0))&&(t.m?(t.l=e.D.concat(t.l),!0):!(1==t.G||2==t.G||t.C>=(t.Xa?0:t.Ya))&&(t.m=le(g(t.Ha,t,e),mr(t,t.C)),t.C++,!0))}function or(t,e){var n;n=e?e.m:t.V++;const r=Ke(t.F);Qe(r,"SID",t.J),Qe(r,"RID",n),Qe(r,"AID",t.U),ar(t,r),t.o&&t.s&&Jn(r,t.o,t.s),n=new _e(t,t.h,n,t.C+1),null===t.o&&(n.H=t.s),e&&(t.l=e.D.concat(t.l)),e=cr(t,n,1e3),n.setTimeout(Math.round(.5*t.ra)+Math.round(.5*t.ra*Math.random())),In(t.i,n),ke(n,r,e)}function ar(t,e){t.j&&Me({},(function(t,n){Qe(e,n,t)}))}function cr(t,e,n){n=Math.min(t.l.length,n);var r=t.j?g(t.j.Oa,t.j,t):null;t:{var i=t.l;let e=-1;for(;;){const t=["count="+n];-1==e?0<n?(e=i[0].h,t.push("ofs="+e)):e=0:t.push("ofs="+e);let o=!0;for(let a=0;a<n;a++){let n=i[a].h;const c=i[a].g;if(n-=e,0>n)e=Math.max(0,i[a].h-100),o=!1;else try{Sn(c,t,"req"+n+"_")}catch(s){r&&r(c)}}if(o){r=t.join("&");break t}}}return t=t.l.splice(0,n),e.D=t,r}function ur(t){t.g||t.u||(t.Y=1,Ft(t.Ga,t),t.A=0)}function lr(t){return!(t.g||t.u||3<=t.A)&&(t.Y++,t.u=le(g(t.Ga,t),mr(t,t.A)),t.A++,!0)}function hr(t){null!=t.B&&(a.clearTimeout(t.B),t.B=null)}function dr(t){t.g=new _e(t,t.h,"rpc",t.Y),null===t.o&&(t.g.H=t.s),t.g.O=0;var e=Ke(t.oa);Qe(e,"RID","rpc"),Qe(e,"SID",t.J),Qe(e,"CI",t.N?"0":"1"),Qe(e,"AID",t.U),ar(t,e),Qe(e,"TYPE","xmlhttp"),t.o&&t.s&&Jn(e,t.o,t.s),t.K&&t.g.setTimeout(t.K);var n=t.g;t=t.la,n.K=1,n.v=Je(Ke(e)),n.s=null,n.U=!0,Se(n,t)}function fr(t){null!=t.v&&(a.clearTimeout(t.v),t.v=null)}function pr(t,e){var n=null;if(t.g==e){fr(t),hr(t),t.g=null;var r=2}else{if(!_n(t.i,e))return;n=e.D,En(t.i,e),r=1}if(t.I=e.N,0!=t.G)if(e.i)if(1==r){n=e.s?e.s.length:0,e=Date.now()-e.F;var i=t.C;r=ie(),St(r,new ue(r,n,e,i)),ir(t)}else ur(t);else if(i=e.o,3==i||0==i&&0<t.I||!(1==r&&sr(t,e)||2==r&&lr(t)))switch(n&&0<n.length&&(e=t.i,e.i=e.i.concat(n)),i){case 1:gr(t,5);break;case 4:gr(t,10);break;case 3:gr(t,6);break;default:gr(t,2)}}function mr(t,e){let n=t.Pa+Math.floor(Math.random()*t.$a);return t.j||(n*=2),n*e}function gr(t,e){if(t.h.info("Error code "+e),2==e){var n=null;t.j&&(n=null);var r=g(t.jb,t);n||(n=new He("//www.google.com/images/cleardot.gif"),a.location&&"http"==a.location.protocol||$e(n,"https"),Je(n)),An(n.toString(),r)}else ce(2);t.G=0,t.j&&t.j.va(e),yr(t),nr(t)}function yr(t){t.G=0,t.I=-1,t.j&&(0==On(t.i).length&&0==t.l.length||(t.i.i.length=0,k(t.l),t.l.length=0),t.j.ua())}function br(t,e,n){let r=Xe(n);if(""!=r.i)e&&Ge(r,e+"."+r.i),We(r,r.m);else{const t=a.location;r=Ze(t.protocol,e?e+"."+t.hostname:t.hostname,+t.port,n)}return t.aa&&D(t.aa,(function(t,e){Qe(r,e,t)})),e=t.D,n=t.sa,e&&n&&Qe(r,e,n),Qe(r,"VER",t.ma),ar(t,r),r}function vr(t,e,n){if(e&&!t.H)throw Error("Can't create secondary domain capable XhrIo object.");return e=n&&t.Ba&&!t.qa?new Ln(new Nn({ib:!0})):new Ln(t.qa),e.L=t.H,e}function wr(){}function _r(){if(V&&!(10<=Number(et)))throw Error("Environmental error: no available transport.")}function Ir(t,e){kt.call(this),this.g=new Zn(e),this.l=t,this.h=e&&e.messageUrlParams||null,t=e&&e.messageHeaders||null,e&&e.clientProtocolHeaderRequired&&(t?t["X-Client-Protocol"]="webchannel":t={"X-Client-Protocol":"webchannel"}),this.g.s=t,t=e&&e.initMessageHeaders||null,e&&e.messageContentType&&(t?t["X-WebChannel-Content-Type"]=e.messageContentType:t={"X-WebChannel-Content-Type":e.messageContentType}),e&&e.ya&&(t?t["X-WebChannel-Client-Profile"]=e.ya:t={"X-WebChannel-Client-Profile":e.ya}),this.g.P=t,(t=e&&e.httpHeadersOverwriteParam)&&!S(t)&&(this.g.o=t),this.A=e&&e.supportsCrossDomainXhr||!1,this.v=e&&e.sendRawJson||!1,(e=e&&e.httpSessionIdParam)&&!S(e)&&(this.g.D=e,t=this.h,null!==t&&e in t&&(t=this.h,e in t&&delete t[e])),this.j=new Tr(this)}function Er(t){be.call(this);var e=t.__sm__;if(e){t:{for(const n in e){t=n;break t}t=void 0}(this.i=t)&&(t=this.i,e=null!==e&&t in e?e[t]:void 0),this.data=e}else this.data=t}function Or(){ve.call(this),this.status=1}function Tr(t){this.g=t}r=Ln.prototype,r.ea=function(t,e,n,r){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.H+"; newUri="+t);e=e?e.toUpperCase():"GET",this.H=t,this.j="",this.m=0,this.D=!1,this.h=!0,this.g=this.u?this.u.g():ge.g(),this.C=this.u?pe(this.u):pe(ge),this.g.onreadystatechange=g(this.Fa,this);try{this.F=!0,this.g.open(e,String(t),!0),this.F=!1}catch(s){return void zn(this,s)}t=n||"";const i=new Ue(this.headers);r&&Me(r,(function(t,e){i.set(e,t)})),r=O(i.T()),n=a.FormData&&t instanceof a.FormData,!(0<=I(Bn,e))||r||n||i.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8"),i.forEach((function(t,e){this.g.setRequestHeader(e,t)}),this),this.J&&(this.g.responseType=this.J),"withCredentials"in this.g&&this.g.withCredentials!==this.L&&(this.g.withCredentials=this.L);try{Gn(this),0<this.B&&((this.K=qn(this.g))?(this.g.timeout=this.B,this.g.ontimeout=g(this.pa,this)):this.A=zt(this.pa,this.B,this)),this.v=!0,this.g.send(t),this.v=!1}catch(s){zn(this,s)}},r.pa=function(){"undefined"!=typeof o&&this.g&&(this.j="Timed out after "+this.B+"ms, aborting",this.m=8,St(this,"timeout"),this.abort(8))},r.abort=function(t){this.g&&this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1,this.m=t||7,St(this,"complete"),St(this,"abort"),$n(this))},r.M=function(){this.g&&(this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1),$n(this,!0)),Ln.Z.M.call(this)},r.Fa=function(){this.s||(this.F||this.v||this.l?Kn(this):this.cb())},r.cb=function(){Kn(this)},r.ba=function(){try{return 2<Wn(this)?this.g.status:-1}catch(t){return-1}},r.ga=function(){try{return this.g?this.g.responseText:""}catch(t){return""}},r.Qa=function(t){if(this.g){var e=this.g.responseText;return t&&0==e.indexOf(t)&&(e=e.substring(t.length)),Fn(e)}},r.Da=function(){return this.m},r.La=function(){return"string"===typeof this.j?this.j:String(this.j)},r=Zn.prototype,r.ma=8,r.G=1,r.hb=function(t){try{this.h.info("Origin Trials invoked: "+t)}catch(e){}},r.Ha=function(t){if(this.m)if(this.m=null,1==this.G){if(!t){this.V=Math.floor(1e5*Math.random()),t=this.V++;const i=new _e(this,this.h,t,void 0);let s=this.s;if(this.P&&(s?(s=P(s),L(s,this.P)):s=this.P),null===this.o&&(i.H=s),this.ja)t:{for(var e=0,n=0;n<this.l.length;n++){var r=this.l[n];if(r="__data__"in r.g&&(r=r.g.__data__,"string"===typeof r)?r.length:void 0,void 0===r)break;if(e+=r,4096<e){e=n;break t}if(4096===e||n===this.l.length-1){e=n+1;break t}}e=1e3}else e=1e3;e=cr(this,i,e),n=Ke(this.F),Qe(n,"RID",t),Qe(n,"CVER",22),this.D&&Qe(n,"X-HTTP-Session-Id",this.D),ar(this,n),this.o&&s&&Jn(n,this.o,s),In(this.i,i),this.Ra&&Qe(n,"TYPE","init"),this.ja?(Qe(n,"$req",e),Qe(n,"SID","null"),i.$=!0,ke(i,n,null)):ke(i,n,e),this.G=2}}else 3==this.G&&(t?or(this,t):0==this.l.length||vn(this.i)||or(this))},r.Ga=function(){if(this.u=null,dr(this),this.$&&!(this.L||null==this.g||0>=this.O)){var t=2*this.O;this.h.info("BP detection timer enabled: "+t),this.B=le(g(this.bb,this),t)}},r.bb=function(){this.B&&(this.B=null,this.h.info("BP detection timeout reached."),this.h.info("Buffering proxy detected and switch to long-polling!"),this.N=!1,this.L=!0,ce(10),er(this),dr(this))},r.ab=function(){null!=this.v&&(this.v=null,er(this),lr(this),ce(19))},r.jb=function(t){t?(this.h.info("Successfully pinged google.com"),ce(2)):(this.h.info("Failed to ping google.com"),ce(1))},r=wr.prototype,r.xa=function(){},r.wa=function(){},r.va=function(){},r.ua=function(){},r.Oa=function(){},_r.prototype.g=function(t,e){return new Ir(t,e)},b(Ir,kt),Ir.prototype.m=function(){this.g.j=this.j,this.A&&(this.g.H=!0);var t=this.g,e=this.l,n=this.h||void 0;t.Wa&&(t.h.info("Origin Trials enabled."),Ft(g(t.hb,t,e))),ce(0),t.W=e,t.aa=n||{},t.N=t.X,t.F=br(t,null,t.W),ir(t)},Ir.prototype.close=function(){tr(this.g)},Ir.prototype.u=function(t){if("string"===typeof t){var e={};e.__data__=t,rr(this.g,e)}else this.v?(e={},e.__data__=jt(t),rr(this.g,e)):rr(this.g,t)},Ir.prototype.M=function(){this.g.j=null,delete this.j,tr(this.g),delete this.g,Ir.Z.M.call(this)},b(Er,be),b(Or,ve),b(Tr,wr),Tr.prototype.xa=function(){St(this.g,"a")},Tr.prototype.wa=function(t){St(this.g,new Er(t))},Tr.prototype.va=function(t){St(this.g,new Or(t))},Tr.prototype.ua=function(){St(this.g,"b")},_r.prototype.createWebChannel=_r.prototype.g,Ir.prototype.send=Ir.prototype.u,Ir.prototype.open=Ir.prototype.m,Ir.prototype.close=Ir.prototype.close,he.NO_ERROR=0,he.TIMEOUT=8,he.HTTP_ERROR=6,de.COMPLETE="complete",me.EventType=ye,ye.OPEN="a",ye.CLOSE="b",ye.ERROR="c",ye.MESSAGE="d",kt.prototype.listen=kt.prototype.N,Ln.prototype.listenOnce=Ln.prototype.O,Ln.prototype.getLastError=Ln.prototype.La,Ln.prototype.getLastErrorCode=Ln.prototype.Da,Ln.prototype.getStatus=Ln.prototype.ba,Ln.prototype.getResponseJson=Ln.prototype.Qa,Ln.prototype.getResponseText=Ln.prototype.ga,Ln.prototype.send=Ln.prototype.ea;var kr=s.createWebChannelTransport=function(){return new _r},Sr=s.getStatEventTarget=function(){return ie()},Ar=s.ErrorCode=he,jr=s.EventType=de,Nr=s.Event=ne,Cr=s.Stat={rb:0,ub:1,vb:2,Ob:3,Tb:4,Qb:5,Rb:6,Pb:7,Nb:8,Sb:9,PROXY:10,NOPROXY:11,Lb:12,Hb:13,Ib:14,Gb:15,Jb:16,Kb:17,nb:18,mb:19,ob:20},Rr=s.FetchXmlHttpFactory=Nn,xr=s.WebChannel=me,Dr=s.XhrIo=Ln}).call(this,n("c8ba"))},9152:function(t,e){
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
e.read=function(t,e,n,r,i){var s,o,a=8*i-r-1,c=(1<<a)-1,u=c>>1,l=-7,h=n?i-1:0,d=n?-1:1,f=t[e+h];for(h+=d,s=f&(1<<-l)-1,f>>=-l,l+=a;l>0;s=256*s+t[e+h],h+=d,l-=8);for(o=s&(1<<-l)-1,s>>=-l,l+=r;l>0;o=256*o+t[e+h],h+=d,l-=8);if(0===s)s=1-u;else{if(s===c)return o?NaN:1/0*(f?-1:1);o+=Math.pow(2,r),s-=u}return(f?-1:1)*o*Math.pow(2,s-r)},e.write=function(t,e,n,r,i,s){var o,a,c,u=8*s-i-1,l=(1<<u)-1,h=l>>1,d=23===i?Math.pow(2,-24)-Math.pow(2,-77):0,f=r?0:s-1,p=r?1:-1,m=e<0||0===e&&1/e<0?1:0;for(e=Math.abs(e),isNaN(e)||e===1/0?(a=isNaN(e)?1:0,o=l):(o=Math.floor(Math.log(e)/Math.LN2),e*(c=Math.pow(2,-o))<1&&(o--,c*=2),e+=o+h>=1?d/c:d*Math.pow(2,1-h),e*c>=2&&(o++,c/=2),o+h>=l?(a=0,o=l):o+h>=1?(a=(e*c-1)*Math.pow(2,i),o+=h):(a=e*Math.pow(2,h-1)*Math.pow(2,i),o=0));i>=8;t[n+f]=255&a,f+=p,a/=256,i-=8);for(o=o<<i|a,u+=i;u>0;t[n+f]=255&o,f+=p,o/=256,u-=8);t[n+f-p]|=128*m}},"94f8":function(t,e,n){(function(e,r){t.exports=r(n("21bf"))})(0,(function(t){return function(e){var n=t,r=n.lib,i=r.WordArray,s=r.Hasher,o=n.algo,a=[],c=[];(function(){function t(t){for(var n=e.sqrt(t),r=2;r<=n;r++)if(!(t%r))return!1;return!0}function n(t){return 4294967296*(t-(0|t))|0}var r=2,i=0;while(i<64)t(r)&&(i<8&&(a[i]=n(e.pow(r,.5))),c[i]=n(e.pow(r,1/3)),i++),r++})();var u=[],l=o.SHA256=s.extend({_doReset:function(){this._hash=new i.init(a.slice(0))},_doProcessBlock:function(t,e){for(var n=this._hash.words,r=n[0],i=n[1],s=n[2],o=n[3],a=n[4],l=n[5],h=n[6],d=n[7],f=0;f<64;f++){if(f<16)u[f]=0|t[e+f];else{var p=u[f-15],m=(p<<25|p>>>7)^(p<<14|p>>>18)^p>>>3,g=u[f-2],y=(g<<15|g>>>17)^(g<<13|g>>>19)^g>>>10;u[f]=m+u[f-7]+y+u[f-16]}var b=a&l^~a&h,v=r&i^r&s^i&s,w=(r<<30|r>>>2)^(r<<19|r>>>13)^(r<<10|r>>>22),_=(a<<26|a>>>6)^(a<<21|a>>>11)^(a<<7|a>>>25),I=d+_+b+c[f]+u[f],E=w+v;d=h,h=l,l=a,a=o+I|0,o=s,s=i,i=r,r=I+E|0}n[0]=n[0]+r|0,n[1]=n[1]+i|0,n[2]=n[2]+s|0,n[3]=n[3]+o|0,n[4]=n[4]+a|0,n[5]=n[5]+l|0,n[6]=n[6]+h|0,n[7]=n[7]+d|0},_doFinalize:function(){var t=this._data,n=t.words,r=8*this._nDataBytes,i=8*t.sigBytes;return n[i>>>5]|=128<<24-i%32,n[14+(i+64>>>9<<4)]=e.floor(r/4294967296),n[15+(i+64>>>9<<4)]=r,t.sigBytes=4*n.length,this._process(),this._hash},clone:function(){var t=s.clone.call(this);return t._hash=this._hash.clone(),t}});n.SHA256=s._createHelper(l),n.HmacSHA256=s._createHmacHelper(l)}(Math),t.SHA256}))},"9ff4":function(t,e,n){"use strict";(function(t){function r(t,e){const n=Object.create(null),r=t.split(",");for(let i=0;i<r.length;i++)n[r[i]]=!0;return e?t=>!!n[t.toLowerCase()]:t=>!!n[t]}n.d(e,"a",(function(){return O})),n.d(e,"b",(function(){return E})),n.d(e,"c",(function(){return k})),n.d(e,"d",(function(){return T})),n.d(e,"e",(function(){return J})),n.d(e,"f",(function(){return tt})),n.d(e,"g",(function(){return it})),n.d(e,"h",(function(){return N})),n.d(e,"i",(function(){return at})),n.d(e,"j",(function(){return nt})),n.d(e,"k",(function(){return x})),n.d(e,"l",(function(){return Z})),n.d(e,"m",(function(){return c})),n.d(e,"n",(function(){return rt})),n.d(e,"o",(function(){return D})),n.d(e,"p",(function(){return M})),n.d(e,"q",(function(){return s})),n.d(e,"r",(function(){return g})),n.d(e,"s",(function(){return G})),n.d(e,"t",(function(){return P})),n.d(e,"u",(function(){return j})),n.d(e,"v",(function(){return q})),n.d(e,"w",(function(){return A})),n.d(e,"x",(function(){return $})),n.d(e,"y",(function(){return V})),n.d(e,"z",(function(){return W})),n.d(e,"A",(function(){return y})),n.d(e,"B",(function(){return F})),n.d(e,"C",(function(){return a})),n.d(e,"D",(function(){return U})),n.d(e,"E",(function(){return B})),n.d(e,"F",(function(){return v})),n.d(e,"G",(function(){return w})),n.d(e,"H",(function(){return r})),n.d(e,"I",(function(){return f})),n.d(e,"J",(function(){return u})),n.d(e,"K",(function(){return C})),n.d(e,"L",(function(){return _})),n.d(e,"M",(function(){return et})),n.d(e,"N",(function(){return st})),n.d(e,"O",(function(){return K}));const i="Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt",s=r(i);const o="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",a=r(o);function c(t){return!!t||""===t}function u(t){if(D(t)){const e={};for(let n=0;n<t.length;n++){const r=t[n],i=U(r)?d(r):u(r);if(i)for(const t in i)e[t]=i[t]}return e}return U(t)||q(t)?t:void 0}const l=/;(?![^(]*\))/g,h=/:(.+)/;function d(t){const e={};return t.split(l).forEach(t=>{if(t){const n=t.split(h);n.length>1&&(e[n[0].trim()]=n[1].trim())}}),e}function f(t){let e="";if(U(t))e=t;else if(D(t))for(let n=0;n<t.length;n++){const r=f(t[n]);r&&(e+=r+" ")}else if(q(t))for(const n in t)t[n]&&(e+=n+" ");return e.trim()}const p="html,body,base,head,link,meta,style,title,address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot",m="svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistanceLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view",g=r(p),y=r(m);function b(t,e){if(t.length!==e.length)return!1;let n=!0;for(let r=0;n&&r<t.length;r++)n=v(t[r],e[r]);return n}function v(t,e){if(t===e)return!0;let n=L(t),r=L(e);if(n||r)return!(!n||!r)&&t.getTime()===e.getTime();if(n=D(t),r=D(e),n||r)return!(!n||!r)&&b(t,e);if(n=q(t),r=q(e),n||r){if(!n||!r)return!1;const i=Object.keys(t).length,s=Object.keys(e).length;if(i!==s)return!1;for(const n in t){const r=t.hasOwnProperty(n),i=e.hasOwnProperty(n);if(r&&!i||!r&&i||!v(t[n],e[n]))return!1}}return String(t)===String(e)}function w(t,e){return t.findIndex(t=>v(t,e))}const _=t=>null==t?"":D(t)||q(t)&&(t.toString===z||!M(t.toString))?JSON.stringify(t,I,2):String(t),I=(t,e)=>e&&e.__v_isRef?I(t,e.value):P(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((t,[e,n])=>(t[e+" =>"]=n,t),{})}:F(e)?{[`Set(${e.size})`]:[...e.values()]}:!q(e)||D(e)||$(e)?e:String(e),E={},O=[],T=()=>{},k=()=>!1,S=/^on[^a-z]/,A=t=>S.test(t),j=t=>t.startsWith("onUpdate:"),N=Object.assign,C=(t,e)=>{const n=t.indexOf(e);n>-1&&t.splice(n,1)},R=Object.prototype.hasOwnProperty,x=(t,e)=>R.call(t,e),D=Array.isArray,P=t=>"[object Map]"===H(t),F=t=>"[object Set]"===H(t),L=t=>t instanceof Date,M=t=>"function"===typeof t,U=t=>"string"===typeof t,B=t=>"symbol"===typeof t,q=t=>null!==t&&"object"===typeof t,V=t=>q(t)&&M(t.then)&&M(t.catch),z=Object.prototype.toString,H=t=>z.call(t),K=t=>H(t).slice(8,-1),$=t=>"[object Object]"===H(t),G=t=>U(t)&&"NaN"!==t&&"-"!==t[0]&&""+parseInt(t,10)===t,W=r(",key,ref,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Y=t=>{const e=Object.create(null);return n=>{const r=e[n];return r||(e[n]=t(n))}},Q=/-(\w)/g,J=Y(t=>t.replace(Q,(t,e)=>e?e.toUpperCase():"")),X=/\B([A-Z])/g,Z=Y(t=>t.replace(X,"-$1").toLowerCase()),tt=Y(t=>t.charAt(0).toUpperCase()+t.slice(1)),et=Y(t=>t?"on"+tt(t):""),nt=(t,e)=>!Object.is(t,e),rt=(t,e)=>{for(let n=0;n<t.length;n++)t[n](e)},it=(t,e,n)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,value:n})},st=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let ot;const at=()=>ot||(ot="undefined"!==typeof globalThis?globalThis:"undefined"!==typeof self?self:"undefined"!==typeof window?window:"undefined"!==typeof t?t:{})}).call(this,n("c8ba"))},a5fa:function(t,e,n){"use strict";n.d(e,"b",(function(){return di})),n.d(e,"c",(function(){return fi}));var r={};n.r(r),n.d(r,"protocol",(function(){return hr})),n.d(r,"PacketType",(function(){return dr})),n.d(r,"Encoder",(function(){return fr})),n.d(r,"Decoder",(function(){return pr}));n("cc87");var i=n("7a23"),s=n("3f4e");
/*!
  * vue-router v4.0.12
  * (c) 2021 Eduardo San Martin Morote
  * @license MIT
  */
const o="function"===typeof Symbol&&"symbol"===typeof Symbol.toStringTag,a=t=>o?Symbol(t):"_vr_"+t,c=a("rvlm"),u=a("rvd"),l=a("r"),h=a("rl"),d=a("rvl"),f="undefined"!==typeof window;function p(t){return t.__esModule||o&&"Module"===t[Symbol.toStringTag]}const m=Object.assign;function g(t,e){const n={};for(const r in e){const i=e[r];n[r]=Array.isArray(i)?i.map(t):t(i)}return n}const y=()=>{};const b=/\/$/,v=t=>t.replace(b,"");function w(t,e,n="/"){let r,i={},s="",o="";const a=e.indexOf("?"),c=e.indexOf("#",a>-1?a:0);return a>-1&&(r=e.slice(0,a),s=e.slice(a+1,c>-1?c:e.length),i=t(s)),c>-1&&(r=r||e.slice(0,c),o=e.slice(c,e.length)),r=A(null!=r?r:e,n),{fullPath:r+(s&&"?")+s+o,path:r,query:i,hash:o}}function _(t,e){const n=e.query?t(e.query):"";return e.path+(n&&"?")+n+(e.hash||"")}function I(t,e){return e&&t.toLowerCase().startsWith(e.toLowerCase())?t.slice(e.length)||"/":t}function E(t,e,n){const r=e.matched.length-1,i=n.matched.length-1;return r>-1&&r===i&&O(e.matched[r],n.matched[i])&&T(e.params,n.params)&&t(e.query)===t(n.query)&&e.hash===n.hash}function O(t,e){return(t.aliasOf||t)===(e.aliasOf||e)}function T(t,e){if(Object.keys(t).length!==Object.keys(e).length)return!1;for(const n in t)if(!k(t[n],e[n]))return!1;return!0}function k(t,e){return Array.isArray(t)?S(t,e):Array.isArray(e)?S(e,t):t===e}function S(t,e){return Array.isArray(e)?t.length===e.length&&t.every((t,n)=>t===e[n]):1===t.length&&t[0]===e}function A(t,e){if(t.startsWith("/"))return t;if(!t)return e;const n=e.split("/"),r=t.split("/");let i,s,o=n.length-1;for(i=0;i<r.length;i++)if(s=r[i],1!==o&&"."!==s){if(".."!==s)break;o--}return n.slice(0,o).join("/")+"/"+r.slice(i-(i===r.length?1:0)).join("/")}var j,N;(function(t){t["pop"]="pop",t["push"]="push"})(j||(j={})),function(t){t["back"]="back",t["forward"]="forward",t["unknown"]=""}(N||(N={}));function C(t){if(!t)if(f){const e=document.querySelector("base");t=e&&e.getAttribute("href")||"/",t=t.replace(/^\w+:\/\/[^\/]+/,"")}else t="/";return"/"!==t[0]&&"#"!==t[0]&&(t="/"+t),v(t)}const R=/^[^#]+#/;function x(t,e){return t.replace(R,"#")+e}function D(t,e){const n=document.documentElement.getBoundingClientRect(),r=t.getBoundingClientRect();return{behavior:e.behavior,left:r.left-n.left-(e.left||0),top:r.top-n.top-(e.top||0)}}const P=()=>({left:window.pageXOffset,top:window.pageYOffset});function F(t){let e;if("el"in t){const n=t.el,r="string"===typeof n&&n.startsWith("#");0;const i="string"===typeof n?r?document.getElementById(n.slice(1)):document.querySelector(n):n;if(!i)return;e=D(i,t)}else e=t;"scrollBehavior"in document.documentElement.style?window.scrollTo(e):window.scrollTo(null!=e.left?e.left:window.pageXOffset,null!=e.top?e.top:window.pageYOffset)}function L(t,e){const n=history.state?history.state.position-e:-1;return n+t}const M=new Map;function U(t,e){M.set(t,e)}function B(t){const e=M.get(t);return M.delete(t),e}let q=()=>location.protocol+"//"+location.host;function V(t,e){const{pathname:n,search:r,hash:i}=e,s=t.indexOf("#");if(s>-1){let e=i.includes(t.slice(s))?t.slice(s).length:1,n=i.slice(e);return"/"!==n[0]&&(n="/"+n),I(n,"")}const o=I(n,t);return o+r+i}function z(t,e,n,r){let i=[],s=[],o=null;const a=({state:s})=>{const a=V(t,location),c=n.value,u=e.value;let l=0;if(s){if(n.value=a,e.value=s,o&&o===c)return void(o=null);l=u?s.position-u.position:0}else r(a);i.forEach(t=>{t(n.value,c,{delta:l,type:j.pop,direction:l?l>0?N.forward:N.back:N.unknown})})};function c(){o=n.value}function u(t){i.push(t);const e=()=>{const e=i.indexOf(t);e>-1&&i.splice(e,1)};return s.push(e),e}function l(){const{history:t}=window;t.state&&t.replaceState(m({},t.state,{scroll:P()}),"")}function h(){for(const t of s)t();s=[],window.removeEventListener("popstate",a),window.removeEventListener("beforeunload",l)}return window.addEventListener("popstate",a),window.addEventListener("beforeunload",l),{pauseListeners:c,listen:u,destroy:h}}function H(t,e,n,r=!1,i=!1){return{back:t,current:e,forward:n,replaced:r,position:window.history.length,scroll:i?P():null}}function K(t){const{history:e,location:n}=window,r={value:V(t,n)},i={value:e.state};function s(r,s,o){const a=t.indexOf("#"),c=a>-1?(n.host&&document.querySelector("base")?t:t.slice(a))+r:q()+t+r;try{e[o?"replaceState":"pushState"](s,"",c),i.value=s}catch(u){console.error(u),n[o?"replace":"assign"](c)}}function o(t,n){const o=m({},e.state,H(i.value.back,t,i.value.forward,!0),n,{position:i.value.position});s(t,o,!0),r.value=t}function a(t,n){const o=m({},i.value,e.state,{forward:t,scroll:P()});s(o.current,o,!0);const a=m({},H(r.value,t,null),{position:o.position+1},n);s(t,a,!1),r.value=t}return i.value||s(r.value,{back:null,current:r.value,forward:null,position:e.length-1,replaced:!0,scroll:null},!0),{location:r,state:i,push:a,replace:o}}function $(t){t=C(t);const e=K(t),n=z(t,e.state,e.location,e.replace);function r(t,e=!0){e||n.pauseListeners(),history.go(t)}const i=m({location:"",base:t,go:r,createHref:x.bind(null,t)},e,n);return Object.defineProperty(i,"location",{enumerable:!0,get:()=>e.location.value}),Object.defineProperty(i,"state",{enumerable:!0,get:()=>e.state.value}),i}function G(t){return t=location.host?t||location.pathname+location.search:"",t.includes("#")||(t+="#"),$(t)}function W(t){return"string"===typeof t||t&&"object"===typeof t}function Y(t){return"string"===typeof t||"symbol"===typeof t}const Q={path:"/",name:void 0,params:{},query:{},hash:"",fullPath:"/",matched:[],meta:{},redirectedFrom:void 0},J=a("nf");var X;(function(t){t[t["aborted"]=4]="aborted",t[t["cancelled"]=8]="cancelled",t[t["duplicated"]=16]="duplicated"})(X||(X={}));function Z(t,e){return m(new Error,{type:t,[J]:!0},e)}function tt(t,e){return t instanceof Error&&J in t&&(null==e||!!(t.type&e))}const et="[^/]+?",nt={sensitive:!1,strict:!1,start:!0,end:!0},rt=/[.+*?^${}()[\]/\\]/g;function it(t,e){const n=m({},nt,e),r=[];let i=n.start?"^":"";const s=[];for(const l of t){const t=l.length?[]:[90];n.strict&&!l.length&&(i+="/");for(let e=0;e<l.length;e++){const r=l[e];let o=40+(n.sensitive?.25:0);if(0===r.type)e||(i+="/"),i+=r.value.replace(rt,"\\$&"),o+=40;else if(1===r.type){const{value:t,repeatable:n,optional:a,regexp:c}=r;s.push({name:t,repeatable:n,optional:a});const h=c||et;if(h!==et){o+=10;try{new RegExp(`(${h})`)}catch(u){throw new Error(`Invalid custom RegExp for param "${t}" (${h}): `+u.message)}}let d=n?`((?:${h})(?:/(?:${h}))*)`:`(${h})`;e||(d=a&&l.length<2?`(?:/${d})`:"/"+d),a&&(d+="?"),i+=d,o+=20,a&&(o+=-8),n&&(o+=-20),".*"===h&&(o+=-50)}t.push(o)}r.push(t)}if(n.strict&&n.end){const t=r.length-1;r[t][r[t].length-1]+=.7000000000000001}n.strict||(i+="/?"),n.end?i+="$":n.strict&&(i+="(?:/|$)");const o=new RegExp(i,n.sensitive?"":"i");function a(t){const e=t.match(o),n={};if(!e)return null;for(let r=1;r<e.length;r++){const t=e[r]||"",i=s[r-1];n[i.name]=t&&i.repeatable?t.split("/"):t}return n}function c(e){let n="",r=!1;for(const i of t){r&&n.endsWith("/")||(n+="/"),r=!1;for(const t of i)if(0===t.type)n+=t.value;else if(1===t.type){const{value:s,repeatable:o,optional:a}=t,c=s in e?e[s]:"";if(Array.isArray(c)&&!o)throw new Error(`Provided param "${s}" is an array but it is not repeatable (* or + modifiers)`);const u=Array.isArray(c)?c.join("/"):c;if(!u){if(!a)throw new Error(`Missing required param "${s}"`);i.length<2&&(n.endsWith("/")?n=n.slice(0,-1):r=!0)}n+=u}}return n}return{re:o,score:r,keys:s,parse:a,stringify:c}}function st(t,e){let n=0;while(n<t.length&&n<e.length){const r=e[n]-t[n];if(r)return r;n++}return t.length<e.length?1===t.length&&80===t[0]?-1:1:t.length>e.length?1===e.length&&80===e[0]?1:-1:0}function ot(t,e){let n=0;const r=t.score,i=e.score;while(n<r.length&&n<i.length){const t=st(r[n],i[n]);if(t)return t;n++}return i.length-r.length}const at={type:0,value:""},ct=/[a-zA-Z0-9_]/;function ut(t){if(!t)return[[]];if("/"===t)return[[at]];if(!t.startsWith("/"))throw new Error(`Invalid path "${t}"`);function e(t){throw new Error(`ERR (${n})/"${u}": ${t}`)}let n=0,r=n;const i=[];let s;function o(){s&&i.push(s),s=[]}let a,c=0,u="",l="";function h(){u&&(0===n?s.push({type:0,value:u}):1===n||2===n||3===n?(s.length>1&&("*"===a||"+"===a)&&e(`A repeatable param (${u}) must be alone in its segment. eg: '/:ids+.`),s.push({type:1,value:u,regexp:l,repeatable:"*"===a||"+"===a,optional:"*"===a||"?"===a})):e("Invalid state to consume buffer"),u="")}function d(){u+=a}while(c<t.length)if(a=t[c++],"\\"!==a||2===n)switch(n){case 0:"/"===a?(u&&h(),o()):":"===a?(h(),n=1):d();break;case 4:d(),n=r;break;case 1:"("===a?n=2:ct.test(a)?d():(h(),n=0,"*"!==a&&"?"!==a&&"+"!==a&&c--);break;case 2:")"===a?"\\"==l[l.length-1]?l=l.slice(0,-1)+a:n=3:l+=a;break;case 3:h(),n=0,"*"!==a&&"?"!==a&&"+"!==a&&c--,l="";break;default:e("Unknown state");break}else r=n,n=4;return 2===n&&e(`Unfinished custom RegExp for param "${u}"`),h(),o(),i}function lt(t,e,n){const r=it(ut(t.path),n);const i=m(r,{record:t,parent:e,children:[],alias:[]});return e&&!i.record.aliasOf===!e.record.aliasOf&&e.children.push(i),i}function ht(t,e){const n=[],r=new Map;function i(t){return r.get(t)}function s(t,n,r){const i=!r,a=ft(t);a.aliasOf=r&&r.record;const u=yt(e,t),l=[a];if("alias"in t){const e="string"===typeof t.alias?[t.alias]:t.alias;for(const t of e)l.push(m({},a,{components:r?r.record.components:a.components,path:t,aliasOf:r?r.record:a}))}let h,d;for(const e of l){const{path:l}=e;if(n&&"/"!==l[0]){const t=n.record.path,r="/"===t[t.length-1]?"":"/";e.path=n.record.path+(l&&r+l)}if(h=lt(e,n,u),r?r.alias.push(h):(d=d||h,d!==h&&d.alias.push(h),i&&t.name&&!mt(h)&&o(t.name)),"children"in a){const t=a.children;for(let e=0;e<t.length;e++)s(t[e],h,r&&r.children[e])}r=r||h,c(h)}return d?()=>{o(d)}:y}function o(t){if(Y(t)){const e=r.get(t);e&&(r.delete(t),n.splice(n.indexOf(e),1),e.children.forEach(o),e.alias.forEach(o))}else{const e=n.indexOf(t);e>-1&&(n.splice(e,1),t.record.name&&r.delete(t.record.name),t.children.forEach(o),t.alias.forEach(o))}}function a(){return n}function c(t){let e=0;while(e<n.length&&ot(t,n[e])>=0)e++;n.splice(e,0,t),t.record.name&&!mt(t)&&r.set(t.record.name,t)}function u(t,e){let i,s,o,a={};if("name"in t&&t.name){if(i=r.get(t.name),!i)throw Z(1,{location:t});o=i.record.name,a=m(dt(e.params,i.keys.filter(t=>!t.optional).map(t=>t.name)),t.params),s=i.stringify(a)}else if("path"in t)s=t.path,i=n.find(t=>t.re.test(s)),i&&(a=i.parse(s),o=i.record.name);else{if(i=e.name?r.get(e.name):n.find(t=>t.re.test(e.path)),!i)throw Z(1,{location:t,currentLocation:e});o=i.record.name,a=m({},e.params,t.params),s=i.stringify(a)}const c=[];let u=i;while(u)c.unshift(u.record),u=u.parent;return{name:o,path:s,params:a,matched:c,meta:gt(c)}}return e=yt({strict:!1,end:!0,sensitive:!1},e),t.forEach(t=>s(t)),{addRoute:s,resolve:u,removeRoute:o,getRoutes:a,getRecordMatcher:i}}function dt(t,e){const n={};for(const r of e)r in t&&(n[r]=t[r]);return n}function ft(t){return{path:t.path,redirect:t.redirect,name:t.name,meta:t.meta||{},aliasOf:void 0,beforeEnter:t.beforeEnter,props:pt(t),children:t.children||[],instances:{},leaveGuards:new Set,updateGuards:new Set,enterCallbacks:{},components:"components"in t?t.components||{}:{default:t.component}}}function pt(t){const e={},n=t.props||!1;if("component"in t)e.default=n;else for(const r in t.components)e[r]="boolean"===typeof n?n:n[r];return e}function mt(t){while(t){if(t.record.aliasOf)return!0;t=t.parent}return!1}function gt(t){return t.reduce((t,e)=>m(t,e.meta),{})}function yt(t,e){const n={};for(const r in t)n[r]=r in e?e[r]:t[r];return n}const bt=/#/g,vt=/&/g,wt=/\//g,_t=/=/g,It=/\?/g,Et=/\+/g,Ot=/%5B/g,Tt=/%5D/g,kt=/%5E/g,St=/%60/g,At=/%7B/g,jt=/%7C/g,Nt=/%7D/g,Ct=/%20/g;function Rt(t){return encodeURI(""+t).replace(jt,"|").replace(Ot,"[").replace(Tt,"]")}function xt(t){return Rt(t).replace(At,"{").replace(Nt,"}").replace(kt,"^")}function Dt(t){return Rt(t).replace(Et,"%2B").replace(Ct,"+").replace(bt,"%23").replace(vt,"%26").replace(St,"`").replace(At,"{").replace(Nt,"}").replace(kt,"^")}function Pt(t){return Dt(t).replace(_t,"%3D")}function Ft(t){return Rt(t).replace(bt,"%23").replace(It,"%3F")}function Lt(t){return null==t?"":Ft(t).replace(wt,"%2F")}function Mt(t){try{return decodeURIComponent(""+t)}catch(e){}return""+t}function Ut(t){const e={};if(""===t||"?"===t)return e;const n="?"===t[0],r=(n?t.slice(1):t).split("&");for(let i=0;i<r.length;++i){const t=r[i].replace(Et," "),n=t.indexOf("="),s=Mt(n<0?t:t.slice(0,n)),o=n<0?null:Mt(t.slice(n+1));if(s in e){let t=e[s];Array.isArray(t)||(t=e[s]=[t]),t.push(o)}else e[s]=o}return e}function Bt(t){let e="";for(let n in t){const r=t[n];if(n=Pt(n),null==r){void 0!==r&&(e+=(e.length?"&":"")+n);continue}const i=Array.isArray(r)?r.map(t=>t&&Dt(t)):[r&&Dt(r)];i.forEach(t=>{void 0!==t&&(e+=(e.length?"&":"")+n,null!=t&&(e+="="+t))})}return e}function qt(t){const e={};for(const n in t){const r=t[n];void 0!==r&&(e[n]=Array.isArray(r)?r.map(t=>null==t?null:""+t):null==r?r:""+r)}return e}function Vt(){let t=[];function e(e){return t.push(e),()=>{const n=t.indexOf(e);n>-1&&t.splice(n,1)}}function n(){t=[]}return{add:e,list:()=>t,reset:n}}function zt(t,e,n,r,i){const s=r&&(r.enterCallbacks[i]=r.enterCallbacks[i]||[]);return()=>new Promise((o,a)=>{const c=t=>{!1===t?a(Z(4,{from:n,to:e})):t instanceof Error?a(t):W(t)?a(Z(2,{from:e,to:t})):(s&&r.enterCallbacks[i]===s&&"function"===typeof t&&s.push(t),o())},u=t.call(r&&r.instances[i],e,n,c);let l=Promise.resolve(u);t.length<3&&(l=l.then(c)),l.catch(t=>a(t))})}function Ht(t,e,n,r){const i=[];for(const s of t)for(const t in s.components){let o=s.components[t];if("beforeRouteEnter"===e||s.instances[t])if(Kt(o)){const a=o.__vccOpts||o,c=a[e];c&&i.push(zt(c,n,r,s,t))}else{let a=o();0,i.push(()=>a.then(i=>{if(!i)return Promise.reject(new Error(`Couldn't resolve component "${t}" at "${s.path}"`));const o=p(i)?i.default:i;s.components[t]=o;const a=o.__vccOpts||o,c=a[e];return c&&zt(c,n,r,s,t)()}))}}return i}function Kt(t){return"object"===typeof t||"displayName"in t||"props"in t||"__vccOpts"in t}function $t(t){const e=Object(i["m"])(l),n=Object(i["m"])(h),r=Object(i["b"])(()=>e.resolve(Object(i["G"])(t.to))),s=Object(i["b"])(()=>{const{matched:t}=r.value,{length:e}=t,i=t[e-1],s=n.matched;if(!i||!s.length)return-1;const o=s.findIndex(O.bind(null,i));if(o>-1)return o;const a=Jt(t[e-2]);return e>1&&Jt(i)===a&&s[s.length-1].path!==a?s.findIndex(O.bind(null,t[e-2])):o}),o=Object(i["b"])(()=>s.value>-1&&Qt(n.params,r.value.params)),a=Object(i["b"])(()=>s.value>-1&&s.value===n.matched.length-1&&T(n.params,r.value.params));function c(n={}){return Yt(n)?e[Object(i["G"])(t.replace)?"replace":"push"](Object(i["G"])(t.to)).catch(y):Promise.resolve()}return{route:r,href:Object(i["b"])(()=>r.value.href),isActive:o,isExactActive:a,navigate:c}}const Gt=Object(i["j"])({name:"RouterLink",props:{to:{type:[String,Object],required:!0},replace:Boolean,activeClass:String,exactActiveClass:String,custom:Boolean,ariaCurrentValue:{type:String,default:"page"}},useLink:$t,setup(t,{slots:e}){const n=Object(i["y"])($t(t)),{options:r}=Object(i["m"])(l),s=Object(i["b"])(()=>({[Xt(t.activeClass,r.linkActiveClass,"router-link-active")]:n.isActive,[Xt(t.exactActiveClass,r.linkExactActiveClass,"router-link-exact-active")]:n.isExactActive}));return()=>{const r=e.default&&e.default(n);return t.custom?r:Object(i["l"])("a",{"aria-current":n.isExactActive?t.ariaCurrentValue:null,href:n.href,onClick:n.navigate,class:s.value},r)}}}),Wt=Gt;function Yt(t){if(!(t.metaKey||t.altKey||t.ctrlKey||t.shiftKey)&&!t.defaultPrevented&&(void 0===t.button||0===t.button)){if(t.currentTarget&&t.currentTarget.getAttribute){const e=t.currentTarget.getAttribute("target");if(/\b_blank\b/i.test(e))return}return t.preventDefault&&t.preventDefault(),!0}}function Qt(t,e){for(const n in e){const r=e[n],i=t[n];if("string"===typeof r){if(r!==i)return!1}else if(!Array.isArray(i)||i.length!==r.length||r.some((t,e)=>t!==i[e]))return!1}return!0}function Jt(t){return t?t.aliasOf?t.aliasOf.path:t.path:""}const Xt=(t,e,n)=>null!=t?t:null!=e?e:n,Zt=Object(i["j"])({name:"RouterView",inheritAttrs:!1,props:{name:{type:String,default:"default"},route:Object},setup(t,{attrs:e,slots:n}){const r=Object(i["m"])(d),s=Object(i["b"])(()=>t.route||r.value),o=Object(i["m"])(u,0),a=Object(i["b"])(()=>s.value.matched[o]);Object(i["w"])(u,o+1),Object(i["w"])(c,a),Object(i["w"])(d,s);const l=Object(i["z"])();return Object(i["K"])(()=>[l.value,a.value,t.name],([t,e,n],[r,i,s])=>{e&&(e.instances[n]=t,i&&i!==e&&t&&t===r&&(e.leaveGuards.size||(e.leaveGuards=i.leaveGuards),e.updateGuards.size||(e.updateGuards=i.updateGuards))),!t||!e||i&&O(e,i)&&r||(e.enterCallbacks[n]||[]).forEach(e=>e(t))},{flush:"post"}),()=>{const r=s.value,o=a.value,c=o&&o.components[t.name],u=t.name;if(!c)return te(n.default,{Component:c,route:r});const h=o.props[t.name],d=h?!0===h?r.params:"function"===typeof h?h(r):h:null,f=t=>{t.component.isUnmounted&&(o.instances[u]=null)},p=Object(i["l"])(c,m({},d,e,{onVnodeUnmounted:f,ref:l}));return te(n.default,{Component:p,route:r})||p}}});function te(t,e){if(!t)return null;const n=t(e);return 1===n.length?n[0]:n}const ee=Zt;function ne(t){const e=ht(t.routes,t),n=t.parseQuery||Ut,r=t.stringifyQuery||Bt,s=t.history;const o=Vt(),a=Vt(),c=Vt(),u=Object(i["D"])(Q);let p=Q;f&&t.scrollBehavior&&"scrollRestoration"in history&&(history.scrollRestoration="manual");const b=g.bind(null,t=>""+t),v=g.bind(null,Lt),I=g.bind(null,Mt);function O(t,n){let r,i;return Y(t)?(r=e.getRecordMatcher(t),i=n):i=t,e.addRoute(i,r)}function T(t){const n=e.getRecordMatcher(t);n&&e.removeRoute(n)}function k(){return e.getRoutes().map(t=>t.record)}function S(t){return!!e.getRecordMatcher(t)}function A(t,i){if(i=m({},i||u.value),"string"===typeof t){const r=w(n,t,i.path),o=e.resolve({path:r.path},i),a=s.createHref(r.fullPath);return m(r,o,{params:I(o.params),hash:Mt(r.hash),redirectedFrom:void 0,href:a})}let o;if("path"in t)o=m({},t,{path:w(n,t.path,i.path).path});else{const e=m({},t.params);for(const t in e)null==e[t]&&delete e[t];o=m({},t,{params:v(t.params)}),i.params=v(i.params)}const a=e.resolve(o,i),c=t.hash||"";a.params=b(I(a.params));const l=_(r,m({},t,{hash:xt(c),path:a.path})),h=s.createHref(l);return m({fullPath:l,hash:c,query:r===Bt?qt(t.query):t.query||{}},a,{redirectedFrom:void 0,href:h})}function N(t){return"string"===typeof t?w(n,t,u.value.path):m({},t)}function C(t,e){if(p!==t)return Z(8,{from:e,to:t})}function R(t){return M(t)}function x(t){return R(m(N(t),{replace:!0}))}function D(t){const e=t.matched[t.matched.length-1];if(e&&e.redirect){const{redirect:n}=e;let r="function"===typeof n?n(t):n;return"string"===typeof r&&(r=r.includes("?")||r.includes("#")?r=N(r):{path:r},r.params={}),m({query:t.query,hash:t.hash,params:t.params},r)}}function M(t,e){const n=p=A(t),i=u.value,s=t.state,o=t.force,a=!0===t.replace,c=D(n);if(c)return M(m(N(c),{state:s,force:o,replace:a}),e||n);const l=n;let h;return l.redirectedFrom=e,!o&&E(r,i,n)&&(h=Z(16,{to:l,from:i}),rt(i,i,!0,!1)),(h?Promise.resolve(h):V(l,i)).catch(t=>tt(t)?t:X(t,l,i)).then(t=>{if(t){if(tt(t,2))return M(m(N(t.to),{state:s,force:o,replace:a}),e||l)}else t=H(l,i,!0,a,s);return z(l,i,t),t})}function q(t,e){const n=C(t,e);return n?Promise.reject(n):Promise.resolve()}function V(t,e){let n;const[r,i,s]=ie(t,e);n=Ht(r.reverse(),"beforeRouteLeave",t,e);for(const o of r)o.leaveGuards.forEach(r=>{n.push(zt(r,t,e))});const c=q.bind(null,t,e);return n.push(c),re(n).then(()=>{n=[];for(const r of o.list())n.push(zt(r,t,e));return n.push(c),re(n)}).then(()=>{n=Ht(i,"beforeRouteUpdate",t,e);for(const r of i)r.updateGuards.forEach(r=>{n.push(zt(r,t,e))});return n.push(c),re(n)}).then(()=>{n=[];for(const r of t.matched)if(r.beforeEnter&&!e.matched.includes(r))if(Array.isArray(r.beforeEnter))for(const i of r.beforeEnter)n.push(zt(i,t,e));else n.push(zt(r.beforeEnter,t,e));return n.push(c),re(n)}).then(()=>(t.matched.forEach(t=>t.enterCallbacks={}),n=Ht(s,"beforeRouteEnter",t,e),n.push(c),re(n))).then(()=>{n=[];for(const r of a.list())n.push(zt(r,t,e));return n.push(c),re(n)}).catch(t=>tt(t,8)?t:Promise.reject(t))}function z(t,e,n){for(const r of c.list())r(t,e,n)}function H(t,e,n,r,i){const o=C(t,e);if(o)return o;const a=e===Q,c=f?history.state:{};n&&(r||a?s.replace(t.fullPath,m({scroll:a&&c&&c.scroll},i)):s.push(t.fullPath,i)),u.value=t,rt(t,e,n,a),nt()}let K;function $(){K=s.listen((t,e,n)=>{const r=A(t),i=D(r);if(i)return void M(m(i,{replace:!0}),r).catch(y);p=r;const o=u.value;f&&U(L(o.fullPath,n.delta),P()),V(r,o).catch(t=>tt(t,12)?t:tt(t,2)?(M(t.to,r).then(t=>{tt(t,20)&&!n.delta&&n.type===j.pop&&s.go(-1,!1)}).catch(y),Promise.reject()):(n.delta&&s.go(-n.delta,!1),X(t,r,o))).then(t=>{t=t||H(r,o,!1),t&&(n.delta?s.go(-n.delta,!1):n.type===j.pop&&tt(t,20)&&s.go(-1,!1)),z(r,o,t)}).catch(y)})}let G,W=Vt(),J=Vt();function X(t,e,n){nt(t);const r=J.list();return r.length?r.forEach(r=>r(t,e,n)):console.error(t),Promise.reject(t)}function et(){return G&&u.value!==Q?Promise.resolve():new Promise((t,e)=>{W.add([t,e])})}function nt(t){G||(G=!0,$(),W.list().forEach(([e,n])=>t?n(t):e()),W.reset())}function rt(e,n,r,s){const{scrollBehavior:o}=t;if(!f||!o)return Promise.resolve();const a=!r&&B(L(e.fullPath,0))||(s||!r)&&history.state&&history.state.scroll||null;return Object(i["n"])().then(()=>o(e,n,a)).then(t=>t&&F(t)).catch(t=>X(t,e,n))}const it=t=>s.go(t);let st;const ot=new Set,at={currentRoute:u,addRoute:O,removeRoute:T,hasRoute:S,getRoutes:k,resolve:A,options:t,push:R,replace:x,go:it,back:()=>it(-1),forward:()=>it(1),beforeEach:o.add,beforeResolve:a.add,afterEach:c.add,onError:J.add,isReady:et,install(t){const e=this;t.component("RouterLink",Wt),t.component("RouterView",ee),t.config.globalProperties.$router=e,Object.defineProperty(t.config.globalProperties,"$route",{enumerable:!0,get:()=>Object(i["G"])(u)}),f&&!st&&u.value===Q&&(st=!0,R(s.location).catch(t=>{0}));const n={};for(const s in Q)n[s]=Object(i["b"])(()=>u.value[s]);t.provide(l,e),t.provide(h,Object(i["y"])(n)),t.provide(d,u);const r=t.unmount;ot.add(t),t.unmount=function(){ot.delete(t),ot.size<1&&(p=Q,K&&K(),u.value=Q,st=!1,G=!1),r()}}};return at}function re(t){return t.reduce((t,e)=>t.then(()=>e()),Promise.resolve())}function ie(t,e){const n=[],r=[],i=[],s=Math.max(e.matched.length,t.matched.length);for(let o=0;o<s;o++){const s=e.matched[o];s&&(t.matched.find(t=>O(t,s))?r.push(s):n.push(s));const a=t.matched[o];a&&(e.matched.find(t=>O(t,a))||i.push(a))}return[n,r,i]}function se(){return Object(i["m"])(l)}function oe(){return Object(i["m"])(h)}
/*!
 * vuex v4.0.2
 * (c) 2021 Evan You
 * @license MIT
 */var ae="store";function ce(t){return void 0===t&&(t=null),Object(i["m"])(null!==t?t:ae)}function ue(t,e){Object.keys(t).forEach((function(n){return e(t[n],n)}))}function le(t){return null!==t&&"object"===typeof t}function he(t){return t&&"function"===typeof t.then}function de(t,e){if(!t)throw new Error("[vuex] "+e)}function fe(t,e){return function(){return t(e)}}function pe(t,e,n){return e.indexOf(t)<0&&(n&&n.prepend?e.unshift(t):e.push(t)),function(){var n=e.indexOf(t);n>-1&&e.splice(n,1)}}function me(t,e){t._actions=Object.create(null),t._mutations=Object.create(null),t._wrappedGetters=Object.create(null),t._modulesNamespaceMap=Object.create(null);var n=t.state;ye(t,n,[],t._modules.root,!0),ge(t,n,e)}function ge(t,e,n){var r=t._state;t.getters={},t._makeLocalGettersCache=Object.create(null);var s=t._wrappedGetters,o={};ue(s,(function(e,n){o[n]=fe(e,t),Object.defineProperty(t.getters,n,{get:function(){return o[n]()},enumerable:!0})})),t._state=Object(i["y"])({data:e}),t.strict&&Ee(t),r&&n&&t._withCommit((function(){r.data=null}))}function ye(t,e,n,r,i){var s=!n.length,o=t._modules.getNamespace(n);if(r.namespaced&&(t._modulesNamespaceMap[o]&&console.error("[vuex] duplicate namespace "+o+" for the namespaced module "+n.join("/")),t._modulesNamespaceMap[o]=r),!s&&!i){var a=Oe(e,n.slice(0,-1)),c=n[n.length-1];t._withCommit((function(){c in a&&console.warn('[vuex] state field "'+c+'" was overridden by a module with the same name at "'+n.join(".")+'"'),a[c]=r.state}))}var u=r.context=be(t,o,n);r.forEachMutation((function(e,n){var r=o+n;we(t,r,e,u)})),r.forEachAction((function(e,n){var r=e.root?n:o+n,i=e.handler||e;_e(t,r,i,u)})),r.forEachGetter((function(e,n){var r=o+n;Ie(t,r,e,u)})),r.forEachChild((function(r,s){ye(t,e,n.concat(s),r,i)}))}function be(t,e,n){var r=""===e,i={dispatch:r?t.dispatch:function(n,r,i){var s=Te(n,r,i),o=s.payload,a=s.options,c=s.type;if(a&&a.root||(c=e+c,t._actions[c]))return t.dispatch(c,o);console.error("[vuex] unknown local action type: "+s.type+", global type: "+c)},commit:r?t.commit:function(n,r,i){var s=Te(n,r,i),o=s.payload,a=s.options,c=s.type;a&&a.root||(c=e+c,t._mutations[c])?t.commit(c,o,a):console.error("[vuex] unknown local mutation type: "+s.type+", global type: "+c)}};return Object.defineProperties(i,{getters:{get:r?function(){return t.getters}:function(){return ve(t,e)}},state:{get:function(){return Oe(t.state,n)}}}),i}function ve(t,e){if(!t._makeLocalGettersCache[e]){var n={},r=e.length;Object.keys(t.getters).forEach((function(i){if(i.slice(0,r)===e){var s=i.slice(r);Object.defineProperty(n,s,{get:function(){return t.getters[i]},enumerable:!0})}})),t._makeLocalGettersCache[e]=n}return t._makeLocalGettersCache[e]}function we(t,e,n,r){var i=t._mutations[e]||(t._mutations[e]=[]);i.push((function(e){n.call(t,r.state,e)}))}function _e(t,e,n,r){var i=t._actions[e]||(t._actions[e]=[]);i.push((function(e){var i=n.call(t,{dispatch:r.dispatch,commit:r.commit,getters:r.getters,state:r.state,rootGetters:t.getters,rootState:t.state},e);return he(i)||(i=Promise.resolve(i)),t._devtoolHook?i.catch((function(e){throw t._devtoolHook.emit("vuex:error",e),e})):i}))}function Ie(t,e,n,r){t._wrappedGetters[e]?console.error("[vuex] duplicate getter key: "+e):t._wrappedGetters[e]=function(t){return n(r.state,r.getters,t.state,t.getters)}}function Ee(t){Object(i["K"])((function(){return t._state.data}),(function(){de(t._committing,"do not mutate vuex store state outside mutation handlers.")}),{deep:!0,flush:"sync"})}function Oe(t,e){return e.reduce((function(t,e){return t[e]}),t)}function Te(t,e,n){return le(t)&&t.type&&(n=e,e=t,t=t.type),de("string"===typeof t,"expects string as the type, but found "+typeof t+"."),{type:t,payload:e,options:n}}var ke="vuex bindings",Se="vuex:mutations",Ae="vuex:actions",je="vuex",Ne=0;function Ce(t,e){Object(s["setupDevtoolsPlugin"])({id:"org.vuejs.vuex",app:t,label:"Vuex",homepage:"https://next.vuex.vuejs.org/",logo:"https://vuejs.org/images/icons/favicon-96x96.png",packageName:"vuex",componentStateTypes:[ke]},(function(n){n.addTimelineLayer({id:Se,label:"Vuex Mutations",color:Re}),n.addTimelineLayer({id:Ae,label:"Vuex Actions",color:Re}),n.addInspector({id:je,label:"Vuex",icon:"storage",treeFilterPlaceholder:"Filter stores..."}),n.on.getInspectorTree((function(n){if(n.app===t&&n.inspectorId===je)if(n.filter){var r=[];Me(r,e._modules.root,n.filter,""),n.rootNodes=r}else n.rootNodes=[Le(e._modules.root,"")]})),n.on.getInspectorState((function(n){if(n.app===t&&n.inspectorId===je){var r=n.nodeId;ve(e,r),n.state=Ue(qe(e._modules,r),"root"===r?e.getters:e._makeLocalGettersCache,r)}})),n.on.editInspectorState((function(n){if(n.app===t&&n.inspectorId===je){var r=n.nodeId,i=n.path;"root"!==r&&(i=r.split("/").filter(Boolean).concat(i)),e._withCommit((function(){n.set(e._state.data,i,n.state.value)}))}})),e.subscribe((function(t,e){var r={};t.payload&&(r.payload=t.payload),r.state=e,n.notifyComponentUpdate(),n.sendInspectorTree(je),n.sendInspectorState(je),n.addTimelineEvent({layerId:Se,event:{time:Date.now(),title:t.type,data:r}})})),e.subscribeAction({before:function(t,e){var r={};t.payload&&(r.payload=t.payload),t._id=Ne++,t._time=Date.now(),r.state=e,n.addTimelineEvent({layerId:Ae,event:{time:t._time,title:t.type,groupId:t._id,subtitle:"start",data:r}})},after:function(t,e){var r={},i=Date.now()-t._time;r.duration={_custom:{type:"duration",display:i+"ms",tooltip:"Action duration",value:i}},t.payload&&(r.payload=t.payload),r.state=e,n.addTimelineEvent({layerId:Ae,event:{time:Date.now(),title:t.type,groupId:t._id,subtitle:"end",data:r}})}})}))}var Re=8702998,xe=6710886,De=16777215,Pe={label:"namespaced",textColor:De,backgroundColor:xe};function Fe(t){return t&&"root"!==t?t.split("/").slice(-2,-1)[0]:"Root"}function Le(t,e){return{id:e||"root",label:Fe(e),tags:t.namespaced?[Pe]:[],children:Object.keys(t._children).map((function(n){return Le(t._children[n],e+n+"/")}))}}function Me(t,e,n,r){r.includes(n)&&t.push({id:r||"root",label:r.endsWith("/")?r.slice(0,r.length-1):r||"Root",tags:e.namespaced?[Pe]:[]}),Object.keys(e._children).forEach((function(i){Me(t,e._children[i],n,r+i+"/")}))}function Ue(t,e,n){e="root"===n?e:e[n];var r=Object.keys(e),i={state:Object.keys(t.state).map((function(e){return{key:e,editable:!0,value:t.state[e]}}))};if(r.length){var s=Be(e);i.getters=Object.keys(s).map((function(t){return{key:t.endsWith("/")?Fe(t):t,editable:!1,value:Ve((function(){return s[t]}))}}))}return i}function Be(t){var e={};return Object.keys(t).forEach((function(n){var r=n.split("/");if(r.length>1){var i=e,s=r.pop();r.forEach((function(t){i[t]||(i[t]={_custom:{value:{},display:t,tooltip:"Module",abstract:!0}}),i=i[t]._custom.value})),i[s]=Ve((function(){return t[n]}))}else e[n]=Ve((function(){return t[n]}))})),e}function qe(t,e){var n=e.split("/").filter((function(t){return t}));return n.reduce((function(t,r,i){var s=t[r];if(!s)throw new Error('Missing module "'+r+'" for path "'+e+'".');return i===n.length-1?s:s._children}),"root"===e?t:t.root._children)}function Ve(t){try{return t()}catch(e){return e}}var ze=function(t,e){this.runtime=e,this._children=Object.create(null),this._rawModule=t;var n=t.state;this.state=("function"===typeof n?n():n)||{}},He={namespaced:{configurable:!0}};He.namespaced.get=function(){return!!this._rawModule.namespaced},ze.prototype.addChild=function(t,e){this._children[t]=e},ze.prototype.removeChild=function(t){delete this._children[t]},ze.prototype.getChild=function(t){return this._children[t]},ze.prototype.hasChild=function(t){return t in this._children},ze.prototype.update=function(t){this._rawModule.namespaced=t.namespaced,t.actions&&(this._rawModule.actions=t.actions),t.mutations&&(this._rawModule.mutations=t.mutations),t.getters&&(this._rawModule.getters=t.getters)},ze.prototype.forEachChild=function(t){ue(this._children,t)},ze.prototype.forEachGetter=function(t){this._rawModule.getters&&ue(this._rawModule.getters,t)},ze.prototype.forEachAction=function(t){this._rawModule.actions&&ue(this._rawModule.actions,t)},ze.prototype.forEachMutation=function(t){this._rawModule.mutations&&ue(this._rawModule.mutations,t)},Object.defineProperties(ze.prototype,He);var Ke=function(t){this.register([],t,!1)};function $e(t,e,n){if(Qe(t,n),e.update(n),n.modules)for(var r in n.modules){if(!e.getChild(r))return void console.warn("[vuex] trying to add a new module '"+r+"' on hot reloading, manual reload is needed");$e(t.concat(r),e.getChild(r),n.modules[r])}}Ke.prototype.get=function(t){return t.reduce((function(t,e){return t.getChild(e)}),this.root)},Ke.prototype.getNamespace=function(t){var e=this.root;return t.reduce((function(t,n){return e=e.getChild(n),t+(e.namespaced?n+"/":"")}),"")},Ke.prototype.update=function(t){$e([],this.root,t)},Ke.prototype.register=function(t,e,n){var r=this;void 0===n&&(n=!0),Qe(t,e);var i=new ze(e,n);if(0===t.length)this.root=i;else{var s=this.get(t.slice(0,-1));s.addChild(t[t.length-1],i)}e.modules&&ue(e.modules,(function(e,i){r.register(t.concat(i),e,n)}))},Ke.prototype.unregister=function(t){var e=this.get(t.slice(0,-1)),n=t[t.length-1],r=e.getChild(n);r?r.runtime&&e.removeChild(n):console.warn("[vuex] trying to unregister module '"+n+"', which is not registered")},Ke.prototype.isRegistered=function(t){var e=this.get(t.slice(0,-1)),n=t[t.length-1];return!!e&&e.hasChild(n)};var Ge={assert:function(t){return"function"===typeof t},expected:"function"},We={assert:function(t){return"function"===typeof t||"object"===typeof t&&"function"===typeof t.handler},expected:'function or object with "handler" function'},Ye={getters:Ge,mutations:Ge,actions:We};function Qe(t,e){Object.keys(Ye).forEach((function(n){if(e[n]){var r=Ye[n];ue(e[n],(function(e,i){de(r.assert(e),Je(t,n,i,e,r.expected))}))}}))}function Je(t,e,n,r,i){var s=e+" should be "+i+' but "'+e+"."+n+'"';return t.length>0&&(s+=' in module "'+t.join(".")+'"'),s+=" is "+JSON.stringify(r)+".",s}function Xe(t){return new Ze(t)}var Ze=function t(e){var n=this;void 0===e&&(e={}),de("undefined"!==typeof Promise,"vuex requires a Promise polyfill in this browser."),de(this instanceof t,"store must be called with the new operator.");var r=e.plugins;void 0===r&&(r=[]);var i=e.strict;void 0===i&&(i=!1);var s=e.devtools;this._committing=!1,this._actions=Object.create(null),this._actionSubscribers=[],this._mutations=Object.create(null),this._wrappedGetters=Object.create(null),this._modules=new Ke(e),this._modulesNamespaceMap=Object.create(null),this._subscribers=[],this._makeLocalGettersCache=Object.create(null),this._devtools=s;var o=this,a=this,c=a.dispatch,u=a.commit;this.dispatch=function(t,e){return c.call(o,t,e)},this.commit=function(t,e,n){return u.call(o,t,e,n)},this.strict=i;var l=this._modules.root.state;ye(this,l,[],this._modules.root),ge(this,l),r.forEach((function(t){return t(n)}))},tn={state:{configurable:!0}};Ze.prototype.install=function(t,e){t.provide(e||ae,this),t.config.globalProperties.$store=this;var n=void 0===this._devtools||this._devtools;n&&Ce(t,this)},tn.state.get=function(){return this._state.data},tn.state.set=function(t){de(!1,"use store.replaceState() to explicit replace store state.")},Ze.prototype.commit=function(t,e,n){var r=this,i=Te(t,e,n),s=i.type,o=i.payload,a=i.options,c={type:s,payload:o},u=this._mutations[s];u?(this._withCommit((function(){u.forEach((function(t){t(o)}))})),this._subscribers.slice().forEach((function(t){return t(c,r.state)})),a&&a.silent&&console.warn("[vuex] mutation type: "+s+". Silent option has been removed. Use the filter functionality in the vue-devtools")):console.error("[vuex] unknown mutation type: "+s)},Ze.prototype.dispatch=function(t,e){var n=this,r=Te(t,e),i=r.type,s=r.payload,o={type:i,payload:s},a=this._actions[i];if(a){try{this._actionSubscribers.slice().filter((function(t){return t.before})).forEach((function(t){return t.before(o,n.state)}))}catch(u){console.warn("[vuex] error in before action subscribers: "),console.error(u)}var c=a.length>1?Promise.all(a.map((function(t){return t(s)}))):a[0](s);return new Promise((function(t,e){c.then((function(e){try{n._actionSubscribers.filter((function(t){return t.after})).forEach((function(t){return t.after(o,n.state)}))}catch(u){console.warn("[vuex] error in after action subscribers: "),console.error(u)}t(e)}),(function(t){try{n._actionSubscribers.filter((function(t){return t.error})).forEach((function(e){return e.error(o,n.state,t)}))}catch(u){console.warn("[vuex] error in error action subscribers: "),console.error(u)}e(t)}))}))}console.error("[vuex] unknown action type: "+i)},Ze.prototype.subscribe=function(t,e){return pe(t,this._subscribers,e)},Ze.prototype.subscribeAction=function(t,e){var n="function"===typeof t?{before:t}:t;return pe(n,this._actionSubscribers,e)},Ze.prototype.watch=function(t,e,n){var r=this;return de("function"===typeof t,"store.watch only accepts a function."),Object(i["K"])((function(){return t(r.state,r.getters)}),e,Object.assign({},n))},Ze.prototype.replaceState=function(t){var e=this;this._withCommit((function(){e._state.data=t}))},Ze.prototype.registerModule=function(t,e,n){void 0===n&&(n={}),"string"===typeof t&&(t=[t]),de(Array.isArray(t),"module path must be a string or an Array."),de(t.length>0,"cannot register the root module by using registerModule."),this._modules.register(t,e),ye(this,this.state,t,this._modules.get(t),n.preserveState),ge(this,this.state)},Ze.prototype.unregisterModule=function(t){var e=this;"string"===typeof t&&(t=[t]),de(Array.isArray(t),"module path must be a string or an Array."),this._modules.unregister(t),this._withCommit((function(){var n=Oe(e.state,t.slice(0,-1));delete n[t[t.length-1]]})),me(this)},Ze.prototype.hasModule=function(t){return"string"===typeof t&&(t=[t]),de(Array.isArray(t),"module path must be a string or an Array."),this._modules.isRegistered(t)},Ze.prototype.hotUpdate=function(t){this._modules.update(t),me(this,!0)},Ze.prototype._withCommit=function(t){var e=this._committing;this._committing=!0,t(),this._committing=e},Object.defineProperties(Ze.prototype,tn);rn((function(t,e){var n={};return nn(e)||console.error("[vuex] mapState: mapper parameter must be either an Array or an Object"),en(e).forEach((function(e){var r=e.key,i=e.val;n[r]=function(){var e=this.$store.state,n=this.$store.getters;if(t){var r=sn(this.$store,"mapState",t);if(!r)return;e=r.context.state,n=r.context.getters}return"function"===typeof i?i.call(this,e,n):e[i]},n[r].vuex=!0})),n})),rn((function(t,e){var n={};return nn(e)||console.error("[vuex] mapMutations: mapper parameter must be either an Array or an Object"),en(e).forEach((function(e){var r=e.key,i=e.val;n[r]=function(){var e=[],n=arguments.length;while(n--)e[n]=arguments[n];var r=this.$store.commit;if(t){var s=sn(this.$store,"mapMutations",t);if(!s)return;r=s.context.commit}return"function"===typeof i?i.apply(this,[r].concat(e)):r.apply(this.$store,[i].concat(e))}})),n})),rn((function(t,e){var n={};return nn(e)||console.error("[vuex] mapGetters: mapper parameter must be either an Array or an Object"),en(e).forEach((function(e){var r=e.key,i=e.val;i=t+i,n[r]=function(){if(!t||sn(this.$store,"mapGetters",t)){if(i in this.$store.getters)return this.$store.getters[i];console.error("[vuex] unknown getter: "+i)}},n[r].vuex=!0})),n})),rn((function(t,e){var n={};return nn(e)||console.error("[vuex] mapActions: mapper parameter must be either an Array or an Object"),en(e).forEach((function(e){var r=e.key,i=e.val;n[r]=function(){var e=[],n=arguments.length;while(n--)e[n]=arguments[n];var r=this.$store.dispatch;if(t){var s=sn(this.$store,"mapActions",t);if(!s)return;r=s.context.dispatch}return"function"===typeof i?i.apply(this,[r].concat(e)):r.apply(this.$store,[i].concat(e))}})),n}));function en(t){return nn(t)?Array.isArray(t)?t.map((function(t){return{key:t,val:t}})):Object.keys(t).map((function(e){return{key:e,val:t[e]}})):[]}function nn(t){return Array.isArray(t)||le(t)}function rn(t){return function(e,n){return"string"!==typeof e?(n=e,e=""):"/"!==e.charAt(e.length-1)&&(e+="/"),t(e,n)}}function sn(t,e,n){var r=t._modulesNamespaceMap[n];return r||console.error("[vuex] module namespace not found in "+e+"(): "+n),r}var on=n("bc3a"),an=n.n(on);function cn(){return oe()}function un(){return se()}function ln(t,...e){if(Function.on&&Function.on[t])for(var n in Function.on[t])Function.on[t][n].call(null,...e)}function hn(t,e){return"mount"===t?Object(i["r"])(e):"un:mount"===t?Object(i["s"])(e):"update"===t?Object(i["t"])(e):void(Function.on&&(t in Function.on===!1&&(Function.on[t]=[]),Function.on[t].push(e)))}function dn(t,e,n){t.config.globalProperties[e]=n}function fn(t){return t.$slots}function pn(...t){return new pn.__(...t)}function mn(...t){return new mn.__(...t)}function gn(){}function yn(){}function bn(){}function vn(t=null){return Object(i["z"])(t)}function wn(t,e){for(var n in e)t[n]=e[n]}function _n(t){return Xe({strict:t.strict||!0,state:t.state||{},mutations:t.mutation||{},actions:t.action||{}})}un.create=ne,un.history=$,un.hash={tag:G},un.try={catch:"/:catchAll(.*)"},bn.get=function(...t){return an.a.get(...t)},bn.post=function(...t){return an.a.post(...t)},bn.url="",wn.clear=function(t){for(var e in t)delete t[e]},_n.create=Xe,_n.use=ce;var In={application:i["c"],properties:dn,to:{reference:i["F"]},reference:vn,react:wn,reactive:function(t={}){return Object(i["y"])(t)},compute:i["b"],watch:i["K"],watching:i["L"],inject:i["m"],store:_n,route:cn,router:un,on:hn,emit:ln,process:{mode:"production"},request:bn,response:yn,respond:gn,slot:fn,component:pn,element:mn,next:function(t){return{name:t.name||"",props:t.properties||[],data(t){return{}},setup(e){if(t.setup)return t.setup.call(this,e)},mounted(){t.mount&&t.mount.call(this)},unmounted(){t.eject&&t.eject.call(this)},created(){t.create&&t.create.call(this)},updated(){t.update&&t.update.call(this)},methods:t.method}}},En=(n("5567"),n("72fe")),On=n.n(En),Tn=n("df2f"),kn=n.n(Tn),Sn=n("94f8"),An=n.n(Sn);Function.define(Function,"hash",(function(){})),Function.define(Function.hash,"md",(function(t){return On()(t.toString()).toString()})),Function.define(Function.hash,"sha",(function(t){return kn()(t.toString()).toString()})),Function.define(Function.hash.sha,"s",(function(t){return An()(t.toString()).toString()})),Function.define(Function.hash,"password",(function(t){return Function.hash.md(t)+Function.hash.sha(t)+Function.hash.sha.s(t)})),Function.define(Function.hash,"s",(function(t,e){e=e||{separator:"-"};var n=Function.hash.md(t),r=Function.hash.sha(t),i=Function.hash.sha.s(t);return[n,r,i].join(e.separator).substr(e.offset,e.length)})),Function.define(Function.hash,"shuffle",(function(...t){var e=[],n=String.char.alpha.numeric,r=Function.hash.shuffle.length;for(var i in t)Object.is.string(t[i])?n=t[i]:Object.is.integer(t[i])&&(r=t[i]);for(i=0;i<r;i++)e.push(n.rand());return e.join("")})),Function.define(Function.hash.shuffle,"length",24);n("fa1c");var jn=n("5317"),Nn=n.n(jn);function Cn(t,e="",n){let r=t;n=n||"undefined"!==typeof location&&location,null==t&&(t=n.protocol+"//"+n.host),"string"===typeof t&&("/"===t.charAt(0)&&(t="/"===t.charAt(1)?n.protocol+t:n.host+t),/^(https?|wss?):\/\//.test(t)||(t="undefined"!==typeof n?n.protocol+"//"+t:"https://"+t),r=Nn()(t)),r.port||(/^(http|ws)$/.test(r.protocol)?r.port="80":/^(http|ws)s$/.test(r.protocol)&&(r.port="443")),r.path=r.path||"/";const i=-1!==r.host.indexOf(":"),s=i?"["+r.host+"]":r.host;return r.id=r.protocol+"://"+s+":"+r.port+e,r.href=r.protocol+"://"+s+(n&&n.port===r.port?"":":"+r.port),r}var Rn=n("c9eb"),xn=n.n(Rn),Dn=n("20a4"),Pn=function(t){const e=t.xdomain;try{if("undefined"!==typeof XMLHttpRequest&&(!e||xn.a))return new XMLHttpRequest}catch(n){}if(!e)try{return new(Dn["a"][["Active"].concat("Object").join("X")])("Microsoft.XMLHTTP")}catch(n){}},Fn=n("af7f"),Ln=n("b19d"),Mn=n("34ba"),Un=n("0299"),Bn=n.n(Un),qn=n("4f2a"),Vn=n.n(qn),zn=n("33e8");class Hn extends Mn["a"]{constructor(){super(...arguments),this.polling=!1}get name(){return"polling"}doOpen(){this.poll()}pause(t){this.readyState="pausing";const e=()=>{this.readyState="paused",t()};if(this.polling||!this.writable){let t=0;this.polling&&(t++,this.once("pollComplete",(function(){--t||e()}))),this.writable||(t++,this.once("drain",(function(){--t||e()})))}else e()}poll(){this.polling=!0,this.doPoll(),this.emit("poll")}onData(t){const e=t=>{if("opening"===this.readyState&&"open"===t.type&&this.onOpen(),"close"===t.type)return this.onClose(),!1;this.onPacket(t)};Object(zn["b"])(t,this.socket.binaryType).forEach(e),"closed"!==this.readyState&&(this.polling=!1,this.emit("pollComplete"),"open"===this.readyState&&this.poll())}doClose(){const t=()=>{this.write([{type:"close"}])};"open"===this.readyState?t():this.once("open",t)}write(t){this.writable=!1,Object(zn["d"])(t,t=>{this.doWrite(t,()=>{this.writable=!0,this.emit("drain")})})}uri(){let t=this.query||{};const e=this.opts.secure?"https":"http";let n="";!1!==this.opts.timestampRequests&&(t[this.opts.timestampParam]=Bn()()),this.supportsBinary||t.sid||(t.b64=1),this.opts.port&&("https"===e&&443!==Number(this.opts.port)||"http"===e&&80!==Number(this.opts.port))&&(n=":"+this.opts.port);const r=Vn.a.encode(t),i=-1!==this.opts.hostname.indexOf(":");return e+"://"+(i?"["+this.opts.hostname+"]":this.opts.hostname)+n+this.opts.path+(r.length?"?"+r:"")}}function Kn(){}const $n=function(){const t=new Pn({xdomain:!1});return null!=t.responseType}();class Gn extends Hn{constructor(t){if(super(t),"undefined"!==typeof location){const e="https:"===location.protocol;let n=location.port;n||(n=e?"443":"80"),this.xd="undefined"!==typeof location&&t.hostname!==location.hostname||n!==t.port,this.xs=t.secure!==e}const e=t&&t.forceBase64;this.supportsBinary=$n&&!e}request(t={}){return Object.assign(t,{xd:this.xd,xs:this.xs},this.opts),new Wn(this.uri(),t)}doWrite(t,e){const n=this.request({method:"POST",data:t});n.on("success",e),n.on("error",t=>{this.onError("xhr post error",t)})}doPoll(){const t=this.request();t.on("data",this.onData.bind(this)),t.on("error",t=>{this.onError("xhr poll error",t)}),this.pollXhr=t}}class Wn extends Ln["Emitter"]{constructor(t,e){super(),Object(Fn["a"])(this,e),this.opts=e,this.method=e.method||"GET",this.uri=t,this.async=!1!==e.async,this.data=void 0!==e.data?e.data:null,this.create()}create(){const t=Object(Fn["b"])(this.opts,"agent","pfx","key","passphrase","cert","ca","ciphers","rejectUnauthorized","autoUnref");t.xdomain=!!this.opts.xd,t.xscheme=!!this.opts.xs;const e=this.xhr=new Pn(t);try{e.open(this.method,this.uri,this.async);try{if(this.opts.extraHeaders){e.setDisableHeaderCheck&&e.setDisableHeaderCheck(!0);for(let t in this.opts.extraHeaders)this.opts.extraHeaders.hasOwnProperty(t)&&e.setRequestHeader(t,this.opts.extraHeaders[t])}}catch(n){}if("POST"===this.method)try{e.setRequestHeader("Content-type","text/plain;charset=UTF-8")}catch(n){}try{e.setRequestHeader("Accept","*/*")}catch(n){}"withCredentials"in e&&(e.withCredentials=this.opts.withCredentials),this.opts.requestTimeout&&(e.timeout=this.opts.requestTimeout),e.onreadystatechange=()=>{4===e.readyState&&(200===e.status||1223===e.status?this.onLoad():this.setTimeoutFn(()=>{this.onError("number"===typeof e.status?e.status:0)},0))},e.send(this.data)}catch(n){return void this.setTimeoutFn(()=>{this.onError(n)},0)}"undefined"!==typeof document&&(this.index=Wn.requestsCount++,Wn.requests[this.index]=this)}onSuccess(){this.emit("success"),this.cleanup()}onData(t){this.emit("data",t),this.onSuccess()}onError(t){this.emit("error",t),this.cleanup(!0)}cleanup(t){if("undefined"!==typeof this.xhr&&null!==this.xhr){if(this.xhr.onreadystatechange=Kn,t)try{this.xhr.abort()}catch(e){}"undefined"!==typeof document&&delete Wn.requests[this.index],this.xhr=null}}onLoad(){const t=this.xhr.responseText;null!==t&&this.onData(t)}abort(){this.cleanup()}}if(Wn.requestsCount=0,Wn.requests={},"undefined"!==typeof document)if("function"===typeof attachEvent)attachEvent("onunload",Yn);else if("function"===typeof addEventListener){const t="onpagehide"in Dn["a"]?"pagehide":"unload";addEventListener(t,Yn,!1)}function Yn(){for(let t in Wn.requests)Wn.requests.hasOwnProperty(t)&&Wn.requests[t].abort()}var Qn=n("1f49");const Jn={websocket:Qn["a"],polling:Gn};class Xn extends Ln["Emitter"]{constructor(t,e={}){super(),t&&"object"===typeof t&&(e=t,t=null),t?(t=Nn()(t),e.hostname=t.host,e.secure="https"===t.protocol||"wss"===t.protocol,e.port=t.port,t.query&&(e.query=t.query)):e.host&&(e.hostname=Nn()(e.host).host),Object(Fn["a"])(this,e),this.secure=null!=e.secure?e.secure:"undefined"!==typeof location&&"https:"===location.protocol,e.hostname&&!e.port&&(e.port=this.secure?"443":"80"),this.hostname=e.hostname||("undefined"!==typeof location?location.hostname:"localhost"),this.port=e.port||("undefined"!==typeof location&&location.port?location.port:this.secure?"443":"80"),this.transports=e.transports||["polling","websocket"],this.readyState="",this.writeBuffer=[],this.prevBufferLen=0,this.opts=Object.assign({path:"/engine.io",agent:!1,withCredentials:!1,upgrade:!0,timestampParam:"t",rememberUpgrade:!1,rejectUnauthorized:!0,perMessageDeflate:{threshold:1024},transportOptions:{},closeOnBeforeunload:!0},e),this.opts.path=this.opts.path.replace(/\/$/,"")+"/","string"===typeof this.opts.query&&(this.opts.query=Vn.a.decode(this.opts.query)),this.id=null,this.upgrades=null,this.pingInterval=null,this.pingTimeout=null,this.pingTimeoutTimer=null,"function"===typeof addEventListener&&(this.opts.closeOnBeforeunload&&addEventListener("beforeunload",()=>{this.transport&&(this.transport.removeAllListeners(),this.transport.close())},!1),"localhost"!==this.hostname&&(this.offlineEventListener=()=>{this.onClose("transport close")},addEventListener("offline",this.offlineEventListener,!1))),this.open()}createTransport(t){const e=Zn(this.opts.query);e.EIO=zn["e"],e.transport=t,this.id&&(e.sid=this.id);const n=Object.assign({},this.opts.transportOptions[t],this.opts,{query:e,socket:this,hostname:this.hostname,secure:this.secure,port:this.port});return new Jn[t](n)}open(){let t;if(this.opts.rememberUpgrade&&Xn.priorWebsocketSuccess&&-1!==this.transports.indexOf("websocket"))t="websocket";else{if(0===this.transports.length)return void this.setTimeoutFn(()=>{this.emitReserved("error","No transports available")},0);t=this.transports[0]}this.readyState="opening";try{t=this.createTransport(t)}catch(e){return this.transports.shift(),void this.open()}t.open(),this.setTransport(t)}setTransport(t){this.transport&&this.transport.removeAllListeners(),this.transport=t,t.on("drain",this.onDrain.bind(this)).on("packet",this.onPacket.bind(this)).on("error",this.onError.bind(this)).on("close",()=>{this.onClose("transport close")})}probe(t){let e=this.createTransport(t),n=!1;Xn.priorWebsocketSuccess=!1;const r=()=>{n||(e.send([{type:"ping",data:"probe"}]),e.once("packet",t=>{if(!n)if("pong"===t.type&&"probe"===t.data){if(this.upgrading=!0,this.emitReserved("upgrading",e),!e)return;Xn.priorWebsocketSuccess="websocket"===e.name,this.transport.pause(()=>{n||"closed"!==this.readyState&&(u(),this.setTransport(e),e.send([{type:"upgrade"}]),this.emitReserved("upgrade",e),e=null,this.upgrading=!1,this.flush())})}else{const t=new Error("probe error");t.transport=e.name,this.emitReserved("upgradeError",t)}}))};function i(){n||(n=!0,u(),e.close(),e=null)}const s=t=>{const n=new Error("probe error: "+t);n.transport=e.name,i(),this.emitReserved("upgradeError",n)};function o(){s("transport closed")}function a(){s("socket closed")}function c(t){e&&t.name!==e.name&&i()}const u=()=>{e.removeListener("open",r),e.removeListener("error",s),e.removeListener("close",o),this.off("close",a),this.off("upgrading",c)};e.once("open",r),e.once("error",s),e.once("close",o),this.once("close",a),this.once("upgrading",c),e.open()}onOpen(){if(this.readyState="open",Xn.priorWebsocketSuccess="websocket"===this.transport.name,this.emitReserved("open"),this.flush(),"open"===this.readyState&&this.opts.upgrade&&this.transport.pause){let t=0;const e=this.upgrades.length;for(;t<e;t++)this.probe(this.upgrades[t])}}onPacket(t){if("opening"===this.readyState||"open"===this.readyState||"closing"===this.readyState)switch(this.emitReserved("packet",t),this.emitReserved("heartbeat"),t.type){case"open":this.onHandshake(JSON.parse(t.data));break;case"ping":this.resetPingTimeout(),this.sendPacket("pong"),this.emitReserved("ping"),this.emitReserved("pong");break;case"error":const e=new Error("server error");e.code=t.data,this.onError(e);break;case"message":this.emitReserved("data",t.data),this.emitReserved("message",t.data);break}}onHandshake(t){this.emitReserved("handshake",t),this.id=t.sid,this.transport.query.sid=t.sid,this.upgrades=this.filterUpgrades(t.upgrades),this.pingInterval=t.pingInterval,this.pingTimeout=t.pingTimeout,this.onOpen(),"closed"!==this.readyState&&this.resetPingTimeout()}resetPingTimeout(){this.clearTimeoutFn(this.pingTimeoutTimer),this.pingTimeoutTimer=this.setTimeoutFn(()=>{this.onClose("ping timeout")},this.pingInterval+this.pingTimeout),this.opts.autoUnref&&this.pingTimeoutTimer.unref()}onDrain(){this.writeBuffer.splice(0,this.prevBufferLen),this.prevBufferLen=0,0===this.writeBuffer.length?this.emitReserved("drain"):this.flush()}flush(){"closed"!==this.readyState&&this.transport.writable&&!this.upgrading&&this.writeBuffer.length&&(this.transport.send(this.writeBuffer),this.prevBufferLen=this.writeBuffer.length,this.emitReserved("flush"))}write(t,e,n){return this.sendPacket("message",t,e,n),this}send(t,e,n){return this.sendPacket("message",t,e,n),this}sendPacket(t,e,n,r){if("function"===typeof e&&(r=e,e=void 0),"function"===typeof n&&(r=n,n=null),"closing"===this.readyState||"closed"===this.readyState)return;n=n||{},n.compress=!1!==n.compress;const i={type:t,data:e,options:n};this.emitReserved("packetCreate",i),this.writeBuffer.push(i),r&&this.once("flush",r),this.flush()}close(){const t=()=>{this.onClose("forced close"),this.transport.close()},e=()=>{this.off("upgrade",e),this.off("upgradeError",e),t()},n=()=>{this.once("upgrade",e),this.once("upgradeError",e)};return"opening"!==this.readyState&&"open"!==this.readyState||(this.readyState="closing",this.writeBuffer.length?this.once("drain",()=>{this.upgrading?n():t()}):this.upgrading?n():t()),this}onError(t){Xn.priorWebsocketSuccess=!1,this.emitReserved("error",t),this.onClose("transport error",t)}onClose(t,e){"opening"!==this.readyState&&"open"!==this.readyState&&"closing"!==this.readyState||(this.clearTimeoutFn(this.pingTimeoutTimer),this.transport.removeAllListeners("close"),this.transport.close(),this.transport.removeAllListeners(),"function"===typeof removeEventListener&&removeEventListener("offline",this.offlineEventListener,!1),this.readyState="closed",this.id=null,this.emitReserved("close",t,e),this.writeBuffer=[],this.prevBufferLen=0)}filterUpgrades(t){const e=[];let n=0;const r=t.length;for(;n<r;n++)~this.transports.indexOf(t[n])&&e.push(t[n]);return e}}function Zn(t){const e={};for(let n in t)t.hasOwnProperty(n)&&(e[n]=t[n]);return e}Xn.protocol=zn["e"];Xn.protocol;const tr="function"===typeof ArrayBuffer,er=t=>"function"===typeof ArrayBuffer.isView?ArrayBuffer.isView(t):t.buffer instanceof ArrayBuffer,nr=Object.prototype.toString,rr="function"===typeof Blob||"undefined"!==typeof Blob&&"[object BlobConstructor]"===nr.call(Blob),ir="function"===typeof File||"undefined"!==typeof File&&"[object FileConstructor]"===nr.call(File);function sr(t){return tr&&(t instanceof ArrayBuffer||er(t))||rr&&t instanceof Blob||ir&&t instanceof File}function or(t,e){if(!t||"object"!==typeof t)return!1;if(Array.isArray(t)){for(let e=0,n=t.length;e<n;e++)if(or(t[e]))return!0;return!1}if(sr(t))return!0;if(t.toJSON&&"function"===typeof t.toJSON&&1===arguments.length)return or(t.toJSON(),!0);for(const n in t)if(Object.prototype.hasOwnProperty.call(t,n)&&or(t[n]))return!0;return!1}function ar(t){const e=[],n=t.data,r=t;return r.data=cr(n,e),r.attachments=e.length,{packet:r,buffers:e}}function cr(t,e){if(!t)return t;if(sr(t)){const n={_placeholder:!0,num:e.length};return e.push(t),n}if(Array.isArray(t)){const n=new Array(t.length);for(let r=0;r<t.length;r++)n[r]=cr(t[r],e);return n}if("object"===typeof t&&!(t instanceof Date)){const n={};for(const r in t)t.hasOwnProperty(r)&&(n[r]=cr(t[r],e));return n}return t}function ur(t,e){return t.data=lr(t.data,e),t.attachments=void 0,t}function lr(t,e){if(!t)return t;if(t&&t._placeholder)return e[t.num];if(Array.isArray(t))for(let n=0;n<t.length;n++)t[n]=lr(t[n],e);else if("object"===typeof t)for(const n in t)t.hasOwnProperty(n)&&(t[n]=lr(t[n],e));return t}const hr=5;var dr;(function(t){t[t["CONNECT"]=0]="CONNECT",t[t["DISCONNECT"]=1]="DISCONNECT",t[t["EVENT"]=2]="EVENT",t[t["ACK"]=3]="ACK",t[t["CONNECT_ERROR"]=4]="CONNECT_ERROR",t[t["BINARY_EVENT"]=5]="BINARY_EVENT",t[t["BINARY_ACK"]=6]="BINARY_ACK"})(dr||(dr={}));class fr{encode(t){return t.type!==dr.EVENT&&t.type!==dr.ACK||!or(t)?[this.encodeAsString(t)]:(t.type=t.type===dr.EVENT?dr.BINARY_EVENT:dr.BINARY_ACK,this.encodeAsBinary(t))}encodeAsString(t){let e=""+t.type;return t.type!==dr.BINARY_EVENT&&t.type!==dr.BINARY_ACK||(e+=t.attachments+"-"),t.nsp&&"/"!==t.nsp&&(e+=t.nsp+","),null!=t.id&&(e+=t.id),null!=t.data&&(e+=JSON.stringify(t.data)),e}encodeAsBinary(t){const e=ar(t),n=this.encodeAsString(e.packet),r=e.buffers;return r.unshift(n),r}}class pr extends Ln["Emitter"]{constructor(){super()}add(t){let e;if("string"===typeof t)e=this.decodeString(t),e.type===dr.BINARY_EVENT||e.type===dr.BINARY_ACK?(this.reconstructor=new gr(e),0===e.attachments&&super.emitReserved("decoded",e)):super.emitReserved("decoded",e);else{if(!sr(t)&&!t.base64)throw new Error("Unknown type: "+t);if(!this.reconstructor)throw new Error("got binary data when not reconstructing a packet");e=this.reconstructor.takeBinaryData(t),e&&(this.reconstructor=null,super.emitReserved("decoded",e))}}decodeString(t){let e=0;const n={type:Number(t.charAt(0))};if(void 0===dr[n.type])throw new Error("unknown packet type "+n.type);if(n.type===dr.BINARY_EVENT||n.type===dr.BINARY_ACK){const r=e+1;while("-"!==t.charAt(++e)&&e!=t.length);const i=t.substring(r,e);if(i!=Number(i)||"-"!==t.charAt(e))throw new Error("Illegal attachments");n.attachments=Number(i)}if("/"===t.charAt(e+1)){const r=e+1;while(++e){const n=t.charAt(e);if(","===n)break;if(e===t.length)break}n.nsp=t.substring(r,e)}else n.nsp="/";const r=t.charAt(e+1);if(""!==r&&Number(r)==r){const r=e+1;while(++e){const n=t.charAt(e);if(null==n||Number(n)!=n){--e;break}if(e===t.length)break}n.id=Number(t.substring(r,e+1))}if(t.charAt(++e)){const r=mr(t.substr(e));if(!pr.isPayloadValid(n.type,r))throw new Error("invalid payload");n.data=r}return n}static isPayloadValid(t,e){switch(t){case dr.CONNECT:return"object"===typeof e;case dr.DISCONNECT:return void 0===e;case dr.CONNECT_ERROR:return"string"===typeof e||"object"===typeof e;case dr.EVENT:case dr.BINARY_EVENT:return Array.isArray(e)&&e.length>0;case dr.ACK:case dr.BINARY_ACK:return Array.isArray(e)}}destroy(){this.reconstructor&&this.reconstructor.finishedReconstruction()}}function mr(t){try{return JSON.parse(t)}catch(e){return!1}}class gr{constructor(t){this.packet=t,this.buffers=[],this.reconPack=t}takeBinaryData(t){if(this.buffers.push(t),this.buffers.length===this.reconPack.attachments){const t=ur(this.reconPack,this.buffers);return this.finishedReconstruction(),t}return null}finishedReconstruction(){this.reconPack=null,this.buffers=[]}}function yr(t,e,n){return t.on(e,n),function(){t.off(e,n)}}const br=Object.freeze({connect:1,connect_error:1,disconnect:1,disconnecting:1,newListener:1,removeListener:1});class vr extends Ln["Emitter"]{constructor(t,e,n){super(),this.connected=!1,this.disconnected=!0,this.receiveBuffer=[],this.sendBuffer=[],this.ids=0,this.acks={},this.flags={},this.io=t,this.nsp=e,n&&n.auth&&(this.auth=n.auth),this.io._autoConnect&&this.open()}subEvents(){if(this.subs)return;const t=this.io;this.subs=[yr(t,"open",this.onopen.bind(this)),yr(t,"packet",this.onpacket.bind(this)),yr(t,"error",this.onerror.bind(this)),yr(t,"close",this.onclose.bind(this))]}get active(){return!!this.subs}connect(){return this.connected||(this.subEvents(),this.io["_reconnecting"]||this.io.open(),"open"===this.io._readyState&&this.onopen()),this}open(){return this.connect()}send(...t){return t.unshift("message"),this.emit.apply(this,t),this}emit(t,...e){if(br.hasOwnProperty(t))throw new Error('"'+t+'" is a reserved event name');e.unshift(t);const n={type:dr.EVENT,data:e,options:{}};n.options.compress=!1!==this.flags.compress,"function"===typeof e[e.length-1]&&(this.acks[this.ids]=e.pop(),n.id=this.ids++);const r=this.io.engine&&this.io.engine.transport&&this.io.engine.transport.writable,i=this.flags.volatile&&(!r||!this.connected);return i||(this.connected?this.packet(n):this.sendBuffer.push(n)),this.flags={},this}packet(t){t.nsp=this.nsp,this.io._packet(t)}onopen(){"function"==typeof this.auth?this.auth(t=>{this.packet({type:dr.CONNECT,data:t})}):this.packet({type:dr.CONNECT,data:this.auth})}onerror(t){this.connected||this.emitReserved("connect_error",t)}onclose(t){this.connected=!1,this.disconnected=!0,delete this.id,this.emitReserved("disconnect",t)}onpacket(t){const e=t.nsp===this.nsp;if(e)switch(t.type){case dr.CONNECT:if(t.data&&t.data.sid){const e=t.data.sid;this.onconnect(e)}else this.emitReserved("connect_error",new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));break;case dr.EVENT:this.onevent(t);break;case dr.BINARY_EVENT:this.onevent(t);break;case dr.ACK:this.onack(t);break;case dr.BINARY_ACK:this.onack(t);break;case dr.DISCONNECT:this.ondisconnect();break;case dr.CONNECT_ERROR:const e=new Error(t.data.message);e.data=t.data.data,this.emitReserved("connect_error",e);break}}onevent(t){const e=t.data||[];null!=t.id&&e.push(this.ack(t.id)),this.connected?this.emitEvent(e):this.receiveBuffer.push(Object.freeze(e))}emitEvent(t){if(this._anyListeners&&this._anyListeners.length){const e=this._anyListeners.slice();for(const n of e)n.apply(this,t)}super.emit.apply(this,t)}ack(t){const e=this;let n=!1;return function(...r){n||(n=!0,e.packet({type:dr.ACK,id:t,data:r}))}}onack(t){const e=this.acks[t.id];"function"===typeof e&&(e.apply(this,t.data),delete this.acks[t.id])}onconnect(t){this.id=t,this.connected=!0,this.disconnected=!1,this.emitBuffered(),this.emitReserved("connect")}emitBuffered(){this.receiveBuffer.forEach(t=>this.emitEvent(t)),this.receiveBuffer=[],this.sendBuffer.forEach(t=>this.packet(t)),this.sendBuffer=[]}ondisconnect(){this.destroy(),this.onclose("io server disconnect")}destroy(){this.subs&&(this.subs.forEach(t=>t()),this.subs=void 0),this.io["_destroy"](this)}disconnect(){return this.connected&&this.packet({type:dr.DISCONNECT}),this.destroy(),this.connected&&this.onclose("io client disconnect"),this}close(){return this.disconnect()}compress(t){return this.flags.compress=t,this}get volatile(){return this.flags.volatile=!0,this}onAny(t){return this._anyListeners=this._anyListeners||[],this._anyListeners.push(t),this}prependAny(t){return this._anyListeners=this._anyListeners||[],this._anyListeners.unshift(t),this}offAny(t){if(!this._anyListeners)return this;if(t){const e=this._anyListeners;for(let n=0;n<e.length;n++)if(t===e[n])return e.splice(n,1),this}else this._anyListeners=[];return this}listenersAny(){return this._anyListeners||[]}}var wr=n("0b64"),_r=n.n(wr);class Ir extends Ln["Emitter"]{constructor(t,e){var n;super(),this.nsps={},this.subs=[],t&&"object"===typeof t&&(e=t,t=void 0),e=e||{},e.path=e.path||"/socket.io",this.opts=e,Object(Fn["a"])(this,e),this.reconnection(!1!==e.reconnection),this.reconnectionAttempts(e.reconnectionAttempts||1/0),this.reconnectionDelay(e.reconnectionDelay||1e3),this.reconnectionDelayMax(e.reconnectionDelayMax||5e3),this.randomizationFactor(null!==(n=e.randomizationFactor)&&void 0!==n?n:.5),this.backoff=new _r.a({min:this.reconnectionDelay(),max:this.reconnectionDelayMax(),jitter:this.randomizationFactor()}),this.timeout(null==e.timeout?2e4:e.timeout),this._readyState="closed",this.uri=t;const i=e.parser||r;this.encoder=new i.Encoder,this.decoder=new i.Decoder,this._autoConnect=!1!==e.autoConnect,this._autoConnect&&this.open()}reconnection(t){return arguments.length?(this._reconnection=!!t,this):this._reconnection}reconnectionAttempts(t){return void 0===t?this._reconnectionAttempts:(this._reconnectionAttempts=t,this)}reconnectionDelay(t){var e;return void 0===t?this._reconnectionDelay:(this._reconnectionDelay=t,null===(e=this.backoff)||void 0===e||e.setMin(t),this)}randomizationFactor(t){var e;return void 0===t?this._randomizationFactor:(this._randomizationFactor=t,null===(e=this.backoff)||void 0===e||e.setJitter(t),this)}reconnectionDelayMax(t){var e;return void 0===t?this._reconnectionDelayMax:(this._reconnectionDelayMax=t,null===(e=this.backoff)||void 0===e||e.setMax(t),this)}timeout(t){return arguments.length?(this._timeout=t,this):this._timeout}maybeReconnectOnOpen(){!this._reconnecting&&this._reconnection&&0===this.backoff.attempts&&this.reconnect()}open(t){if(~this._readyState.indexOf("open"))return this;this.engine=new Xn(this.uri,this.opts);const e=this.engine,n=this;this._readyState="opening",this.skipReconnect=!1;const r=yr(e,"open",(function(){n.onopen(),t&&t()})),i=yr(e,"error",e=>{n.cleanup(),n._readyState="closed",this.emitReserved("error",e),t?t(e):n.maybeReconnectOnOpen()});if(!1!==this._timeout){const t=this._timeout;0===t&&r();const n=this.setTimeoutFn(()=>{r(),e.close(),e.emit("error",new Error("timeout"))},t);this.opts.autoUnref&&n.unref(),this.subs.push((function(){clearTimeout(n)}))}return this.subs.push(r),this.subs.push(i),this}connect(t){return this.open(t)}onopen(){this.cleanup(),this._readyState="open",this.emitReserved("open");const t=this.engine;this.subs.push(yr(t,"ping",this.onping.bind(this)),yr(t,"data",this.ondata.bind(this)),yr(t,"error",this.onerror.bind(this)),yr(t,"close",this.onclose.bind(this)),yr(this.decoder,"decoded",this.ondecoded.bind(this)))}onping(){this.emitReserved("ping")}ondata(t){this.decoder.add(t)}ondecoded(t){this.emitReserved("packet",t)}onerror(t){this.emitReserved("error",t)}socket(t,e){let n=this.nsps[t];return n||(n=new vr(this,t,e),this.nsps[t]=n),n}_destroy(t){const e=Object.keys(this.nsps);for(const n of e){const t=this.nsps[n];if(t.active)return}this._close()}_packet(t){const e=this.encoder.encode(t);for(let n=0;n<e.length;n++)this.engine.write(e[n],t.options)}cleanup(){this.subs.forEach(t=>t()),this.subs.length=0,this.decoder.destroy()}_close(){this.skipReconnect=!0,this._reconnecting=!1,"opening"===this._readyState&&this.cleanup(),this.backoff.reset(),this._readyState="closed",this.engine&&this.engine.close()}disconnect(){return this._close()}onclose(t){this.cleanup(),this.backoff.reset(),this._readyState="closed",this.emitReserved("close",t),this._reconnection&&!this.skipReconnect&&this.reconnect()}reconnect(){if(this._reconnecting||this.skipReconnect)return this;const t=this;if(this.backoff.attempts>=this._reconnectionAttempts)this.backoff.reset(),this.emitReserved("reconnect_failed"),this._reconnecting=!1;else{const e=this.backoff.duration();this._reconnecting=!0;const n=this.setTimeoutFn(()=>{t.skipReconnect||(this.emitReserved("reconnect_attempt",t.backoff.attempts),t.skipReconnect||t.open(e=>{e?(t._reconnecting=!1,t.reconnect(),this.emitReserved("reconnect_error",e)):t.onreconnect()}))},e);this.opts.autoUnref&&n.unref(),this.subs.push((function(){clearTimeout(n)}))}}onreconnect(){const t=this.backoff.attempts;this._reconnecting=!1,this.backoff.reset(),this.emitReserved("reconnect",t)}}const Er={};function Or(t,e){"object"===typeof t&&(e=t,t=void 0),e=e||{};const n=Cn(t,e.path||"/socket.io"),r=n.source,i=n.id,s=n.path,o=Er[i]&&s in Er[i]["nsps"],a=e.forceNew||e["force new connection"]||!1===e.multiplex||o;let c;return a?c=new Ir(r,e):(Er[i]||(Er[i]=new Ir(r,e)),c=Er[i]),n.query&&!e.query&&(e.query=n.queryKey),c.socket(n.path,e)}Object.assign(Or,{Manager:Ir,Socket:vr,io:Or,connect:Or}),Function.define(Function.web.socket.io,"client",Or,{configurable:!0,enumerable:!0,writable:!0});var Tr=n("7ded"),kr="firebase",Sr="9.5.0";
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
Tr["a"].registerVersion(kr,Sr,"app-compat");n("5994");var Ar=n("0829"),jr=n("1fd5"),Nr=n("22e5");const Cr="@firebase/firestore-compat",Rr="0.1.8";
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xr(t,e){if(void 0===e)return{merge:!1};if(void 0!==e.mergeFields&&void 0!==e.merge)throw new Ar["g"]("invalid-argument",`Invalid options passed to function ${t}(): You cannot specify both "merge" and "mergeFields".`);return e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dr(){if("undefined"===typeof Uint8Array)throw new Ar["g"]("unimplemented","Uint8Arrays are not available in this environment.")}function Pr(){if(!Object(Ar["r"])())throw new Ar["g"]("unimplemented","Blobs are unavailable in Firestore in this environment.")}class Fr{constructor(t){this._delegate=t}static fromBase64String(t){return Pr(),new Fr(Ar["b"].fromBase64String(t))}static fromUint8Array(t){return Dr(),new Fr(Ar["b"].fromUint8Array(t))}toBase64(){return Pr(),this._delegate.toBase64()}toUint8Array(){return Dr(),this._delegate.toUint8Array()}isEqual(t){return this._delegate.isEqual(t._delegate)}toString(){return"Blob(base64: "+this.toBase64()+")"}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lr(t){return Mr(t,["next","error","complete"])}function Mr(t,e){if("object"!==typeof t||null===t)return!1;const n=t;for(const r of e)if(r in n&&"function"===typeof n[r])return!0;return!1}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ur{enableIndexedDbPersistence(t,e){return Object(Ar["F"])(t._delegate,{forceOwnership:e})}enableMultiTabIndexedDbPersistence(t){return Object(Ar["G"])(t._delegate)}clearIndexedDbPersistence(t){return Object(Ar["x"])(t._delegate)}}class Br{constructor(t,e,n){this._delegate=e,this._persistenceProvider=n,this.INTERNAL={delete:()=>this.terminate()},t instanceof Ar["m"]||(this._appCompat=t)}get _databaseId(){return this._delegate._databaseId}settings(t){const e=this._delegate._getSettings();t.merge||e.host===t.host||Object(Ar["s"])("You are overriding the original host. If you did not intend to override your settings, use {merge: true}."),t.merge&&(t=Object.assign(Object.assign({},e),t),delete t.merge),this._delegate._setSettings(t)}useEmulator(t,e,n={}){Object(Ar["A"])(this._delegate,t,e,n)}enableNetwork(){return Object(Ar["H"])(this._delegate)}disableNetwork(){return Object(Ar["D"])(this._delegate)}enablePersistence(t){let e=!1,n=!1;return t&&(e=!!t.synchronizeTabs,n=!!t.experimentalForceOwningTab,Object(Ar["t"])("synchronizeTabs",e,"experimentalForceOwningTab",n)),e?this._persistenceProvider.enableMultiTabIndexedDbPersistence(this):this._persistenceProvider.enableIndexedDbPersistence(this,n)}clearPersistence(){return this._persistenceProvider.clearIndexedDbPersistence(this)}terminate(){return this._appCompat&&(this._appCompat._removeServiceInstance("firestore-compat"),this._appCompat._removeServiceInstance("firestore")),this._delegate._delete()}waitForPendingWrites(){return Object(Ar["lb"])(this._delegate)}onSnapshotsInSync(t){return Object(Ar["Y"])(this._delegate,t)}get app(){if(!this._appCompat)throw new Ar["g"]("failed-precondition","Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._appCompat}collection(t){try{return new ei(this,Object(Ar["y"])(this._delegate,t))}catch(e){throw Gr(e,"collection()","Firestore.collection()")}}doc(t){try{return new $r(this,Object(Ar["E"])(this._delegate,t))}catch(e){throw Gr(e,"doc()","Firestore.doc()")}}collectionGroup(t){try{return new Xr(this,Object(Ar["z"])(this._delegate,t))}catch(e){throw Gr(e,"collectionGroup()","Firestore.collectionGroup()")}}runTransaction(t){return Object(Ar["db"])(this._delegate,e=>t(new zr(this,e)))}batch(){return Object(Ar["K"])(this._delegate),new Hr(new Ar["l"](this._delegate,t=>Object(Ar["L"])(this._delegate,t)))}loadBundle(t){return Object(Ar["V"])(this._delegate,t)}namedQuery(t){return Object(Ar["W"])(this._delegate,t).then(t=>t?new Xr(this,t):null)}}class qr extends Ar["a"]{constructor(t){super(),this.firestore=t}convertBytes(t){return new Fr(new Ar["b"](t))}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return $r.forKey(e,this.firestore,null)}}function Vr(t){Object(Ar["gb"])(t)}class zr{constructor(t,e){this._firestore=t,this._delegate=e,this._userDataWriter=new qr(t)}get(t){const e=ni(t);return this._delegate.get(e).then(t=>new Qr(this._firestore,new Ar["e"](this._firestore._delegate,this._userDataWriter,t._key,t._document,t.metadata,e.converter)))}set(t,e,n){const r=ni(t);return n?(xr("Transaction.set",n),this._delegate.set(r,e,n)):this._delegate.set(r,e),this}update(t,e,n,...r){const i=ni(t);return 2===arguments.length?this._delegate.update(i,e):this._delegate.update(i,e,n,...r),this}delete(t){const e=ni(t);return this._delegate.delete(e),this}}class Hr{constructor(t){this._delegate=t}set(t,e,n){const r=ni(t);return n?(xr("WriteBatch.set",n),this._delegate.set(r,e,n)):this._delegate.set(r,e),this}update(t,e,n,...r){const i=ni(t);return 2===arguments.length?this._delegate.update(i,e):this._delegate.update(i,e,n,...r),this}delete(t){const e=ni(t);return this._delegate.delete(e),this}commit(){return this._delegate.commit()}}class Kr{constructor(t,e,n){this._firestore=t,this._userDataWriter=e,this._delegate=n}fromFirestore(t,e){const n=new Ar["i"](this._firestore._delegate,this._userDataWriter,t._key,t._document,t.metadata,null);return this._delegate.fromFirestore(new Jr(this._firestore,n),null!==e&&void 0!==e?e:{})}toFirestore(t,e){return e?this._delegate.toFirestore(t,e):this._delegate.toFirestore(t)}static getInstance(t,e){const n=Kr.INSTANCES;let r=n.get(t);r||(r=new WeakMap,n.set(t,r));let i=r.get(e);return i||(i=new Kr(t,new qr(t),e),r.set(e,i)),i}}Kr.INSTANCES=new WeakMap;class $r{constructor(t,e){this.firestore=t,this._delegate=e,this._userDataWriter=new qr(t)}static forPath(t,e,n){if(t.length%2!==0)throw new Ar["g"]("invalid-argument",`Invalid document reference. Document references must have an even number of segments, but ${t.canonicalString()} has ${t.length}`);return new $r(e,new Ar["d"](e._delegate,n,new Ar["n"](t)))}static forKey(t,e,n){return new $r(e,new Ar["d"](e._delegate,n,t))}get id(){return this._delegate.id}get parent(){return new ei(this.firestore,this._delegate.parent)}get path(){return this._delegate.path}collection(t){try{return new ei(this.firestore,Object(Ar["y"])(this._delegate,t))}catch(e){throw Gr(e,"collection()","DocumentReference.collection()")}}isEqual(t){return t=Object(jr["k"])(t),t instanceof Ar["d"]&&Object(Ar["cb"])(this._delegate,t)}set(t,e){e=xr("DocumentReference.set",e);try{return e?Object(Ar["fb"])(this._delegate,t,e):Object(Ar["fb"])(this._delegate,t)}catch(n){throw Gr(n,"setDoc()","DocumentReference.set()")}}update(t,e,...n){try{return 1===arguments.length?Object(Ar["kb"])(this._delegate,t):Object(Ar["kb"])(this._delegate,t,e,...n)}catch(r){throw Gr(r,"updateDoc()","DocumentReference.update()")}}delete(){return Object(Ar["B"])(this._delegate)}onSnapshot(...t){const e=Wr(t),n=Yr(t,t=>new Qr(this.firestore,new Ar["e"](this.firestore._delegate,this._userDataWriter,t._key,t._document,t.metadata,this._delegate.converter)));return Object(Ar["X"])(this._delegate,e,n)}get(t){let e;return e="cache"===(null===t||void 0===t?void 0:t.source)?Object(Ar["N"])(this._delegate):"server"===(null===t||void 0===t?void 0:t.source)?Object(Ar["O"])(this._delegate):Object(Ar["M"])(this._delegate),e.then(t=>new Qr(this.firestore,new Ar["e"](this.firestore._delegate,this._userDataWriter,t._key,t._document,t.metadata,this._delegate.converter)))}withConverter(t){return new $r(this.firestore,t?this._delegate.withConverter(Kr.getInstance(this.firestore,t)):this._delegate.withConverter(null))}}function Gr(t,e,n){return t.message=t.message.replace(e,n),t}function Wr(t){for(const e of t)if("object"===typeof e&&!Lr(e))return e;return{}}function Yr(t,e){var n,r;let i;return i=Lr(t[0])?t[0]:Lr(t[1])?t[1]:"function"===typeof t[0]?{next:t[0],error:t[1],complete:t[2]}:{next:t[1],error:t[2],complete:t[3]},{next:t=>{i.next&&i.next(e(t))},error:null===(n=i.error)||void 0===n?void 0:n.bind(i),complete:null===(r=i.complete)||void 0===r?void 0:r.bind(i)}}class Qr{constructor(t,e){this._firestore=t,this._delegate=e}get ref(){return new $r(this._firestore,this._delegate.ref)}get id(){return this._delegate.id}get metadata(){return this._delegate.metadata}get exists(){return this._delegate.exists()}data(t){return this._delegate.data(t)}get(t,e){return this._delegate.get(t,e)}isEqual(t){return Object(Ar["hb"])(this._delegate,t._delegate)}}class Jr extends Qr{data(t){const e=this._delegate.data(t);return Object(Ar["q"])(void 0!==e,"Document in a QueryDocumentSnapshot should exist"),e}}class Xr{constructor(t,e){this.firestore=t,this._delegate=e,this._userDataWriter=new qr(t)}where(t,e,n){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["mb"])(t,e,n)))}catch(r){throw Gr(r,/(orderBy|where)\(\)/,"Query.$1()")}}orderBy(t,e){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["Z"])(t,e)))}catch(n){throw Gr(n,/(orderBy|where)\(\)/,"Query.$1()")}}limit(t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["T"])(t)))}catch(e){throw Gr(e,"limit()","Query.limit()")}}limitToLast(t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["U"])(t)))}catch(e){throw Gr(e,"limitToLast()","Query.limitToLast()")}}startAt(...t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["jb"])(...t)))}catch(e){throw Gr(e,"startAt()","Query.startAt()")}}startAfter(...t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["ib"])(...t)))}catch(e){throw Gr(e,"startAfter()","Query.startAfter()")}}endBefore(...t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["J"])(...t)))}catch(e){throw Gr(e,"endBefore()","Query.endBefore()")}}endAt(...t){try{return new Xr(this.firestore,Object(Ar["ab"])(this._delegate,Object(Ar["I"])(...t)))}catch(e){throw Gr(e,"endAt()","Query.endAt()")}}isEqual(t){return Object(Ar["bb"])(this._delegate,t._delegate)}get(t){let e;return e="cache"===(null===t||void 0===t?void 0:t.source)?Object(Ar["Q"])(this._delegate):"server"===(null===t||void 0===t?void 0:t.source)?Object(Ar["R"])(this._delegate):Object(Ar["P"])(this._delegate),e.then(t=>new ti(this.firestore,new Ar["j"](this.firestore._delegate,this._userDataWriter,this._delegate,t._snapshot)))}onSnapshot(...t){const e=Wr(t),n=Yr(t,t=>new ti(this.firestore,new Ar["j"](this.firestore._delegate,this._userDataWriter,this._delegate,t._snapshot)));return Object(Ar["X"])(this._delegate,e,n)}withConverter(t){return new Xr(this.firestore,t?this._delegate.withConverter(Kr.getInstance(this.firestore,t)):this._delegate.withConverter(null))}}class Zr{constructor(t,e){this._firestore=t,this._delegate=e}get type(){return this._delegate.type}get doc(){return new Jr(this._firestore,this._delegate.doc)}get oldIndex(){return this._delegate.oldIndex}get newIndex(){return this._delegate.newIndex}}class ti{constructor(t,e){this._firestore=t,this._delegate=e}get query(){return new Xr(this._firestore,this._delegate.query)}get metadata(){return this._delegate.metadata}get size(){return this._delegate.size}get empty(){return this._delegate.empty}get docs(){return this._delegate.docs.map(t=>new Jr(this._firestore,t))}docChanges(t){return this._delegate.docChanges(t).map(t=>new Zr(this._firestore,t))}forEach(t,e){this._delegate.forEach(n=>{t.call(e,new Jr(this._firestore,n))})}isEqual(t){return Object(Ar["hb"])(this._delegate,t._delegate)}}class ei extends Xr{constructor(t,e){super(t,e),this.firestore=t,this._delegate=e}get id(){return this._delegate.id}get path(){return this._delegate.path}get parent(){const t=this._delegate.parent;return t?new $r(this.firestore,t):null}doc(t){try{return new $r(this.firestore,void 0===t?Object(Ar["E"])(this._delegate):Object(Ar["E"])(this._delegate,t))}catch(e){throw Gr(e,"doc()","CollectionReference.doc()")}}add(t){return Object(Ar["u"])(this._delegate,t).then(t=>new $r(this.firestore,t))}isEqual(t){return Object(Ar["cb"])(this._delegate,t._delegate)}withConverter(t){return new ei(this.firestore,t?this._delegate.withConverter(Kr.getInstance(this.firestore,t)):this._delegate.withConverter(null))}}function ni(t){return Object(Ar["p"])(t,Ar["d"])}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ri{constructor(...t){this._delegate=new Ar["f"](...t)}static documentId(){return new ri(Ar["o"].keyField().canonicalString())}isEqual(t){return t=Object(jr["k"])(t),t instanceof Ar["f"]&&this._delegate._internalPath.isEqual(t._internalPath)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ii{constructor(t){this._delegate=t}static serverTimestamp(){const t=Object(Ar["eb"])();return t._methodName="FieldValue.serverTimestamp",new ii(t)}static delete(){const t=Object(Ar["C"])();return t._methodName="FieldValue.delete",new ii(t)}static arrayUnion(...t){const e=Object(Ar["w"])(...t);return e._methodName="FieldValue.arrayUnion",new ii(e)}static arrayRemove(...t){const e=Object(Ar["v"])(...t);return e._methodName="FieldValue.arrayRemove",new ii(e)}static increment(t){const e=Object(Ar["S"])(t);return e._methodName="FieldValue.increment",new ii(e)}isEqual(t){return this._delegate.isEqual(t._delegate)}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const si={Firestore:Br,GeoPoint:Ar["h"],Timestamp:Ar["k"],Blob:Fr,Transaction:zr,WriteBatch:Hr,DocumentReference:$r,DocumentSnapshot:Qr,Query:Xr,QueryDocumentSnapshot:Jr,QuerySnapshot:ti,CollectionReference:ei,FieldPath:ri,FieldValue:ii,setLogLevel:Vr,CACHE_SIZE_UNLIMITED:Ar["c"]};function oi(t,e){t.INTERNAL.registerComponent(new Nr["a"]("firestore-compat",t=>{const n=t.getProvider("app-compat").getImmediate(),r=t.getProvider("firestore").getImmediate();return e(n,r)},"PUBLIC").setServiceProps(Object.assign({},si)))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ai(t){oi(t,(t,e)=>new Br(t,e,new Ur)),t.registerVersion(Cr,Rr)}ai(Tr["a"]);var ci=function t(e,n){if(e===n)return!0;if(e&&n&&"object"==typeof e&&"object"==typeof n){if(e.constructor!==n.constructor)return!1;var r,i,s;if(Array.isArray(e)){if(r=e.length,r!=n.length)return!1;for(i=r;0!==i--;)if(!t(e[i],n[i]))return!1;return!0}if(e.constructor===RegExp)return e.source===n.source&&e.flags===n.flags;if(e.valueOf!==Object.prototype.valueOf)return e.valueOf()===n.valueOf();if(e.toString!==Object.prototype.toString)return e.toString()===n.toString();if(s=Object.keys(e),r=s.length,r!==Object.keys(n).length)return!1;for(i=r;0!==i--;)if(!Object.prototype.hasOwnProperty.call(n,s[i]))return!1;for(i=r;0!==i--;){var o=s[i];if(!t(e[o],n[o]))return!1}return!0}return e!==e&&n!==n};const ui="__googleMapsScriptId";class li{constructor({apiKey:t,channel:e,client:n,id:r=ui,libraries:i=[],language:s,region:o,version:a,mapIds:c,nonce:u,retries:l=3,url:h="https://maps.googleapis.com/maps/api/js"}){if(this.CALLBACK="__googleMapsCallback",this.callbacks=[],this.done=!1,this.loading=!1,this.errors=[],this.version=a,this.apiKey=t,this.channel=e,this.client=n,this.id=r||ui,this.libraries=i,this.language=s,this.region=o,this.mapIds=c,this.nonce=u,this.retries=l,this.url=h,li.instance){if(!ci(this.options,li.instance.options))throw new Error(`Loader must not be called again with different options. ${JSON.stringify(this.options)} !== ${JSON.stringify(li.instance.options)}`);return li.instance}li.instance=this}get options(){return{version:this.version,apiKey:this.apiKey,channel:this.channel,client:this.client,id:this.id,libraries:this.libraries,language:this.language,region:this.region,mapIds:this.mapIds,nonce:this.nonce,url:this.url}}get failed(){return this.done&&!this.loading&&this.errors.length>=this.retries+1}createUrl(){let t=this.url;return t+="?callback="+this.CALLBACK,this.apiKey&&(t+="&key="+this.apiKey),this.channel&&(t+="&channel="+this.channel),this.client&&(t+="&client="+this.client),this.libraries.length>0&&(t+="&libraries="+this.libraries.join(",")),this.language&&(t+="&language="+this.language),this.region&&(t+="&region="+this.region),this.version&&(t+="&v="+this.version),this.mapIds&&(t+="&map_ids="+this.mapIds.join(",")),t}deleteScript(){const t=document.getElementById(this.id);t&&t.remove()}load(){return this.loadPromise()}loadPromise(){return new Promise((t,e)=>{this.loadCallback(n=>{n?e(n.error):t(window.google)})})}loadCallback(t){this.callbacks.push(t),this.execute()}setScript(){if(document.getElementById(this.id))return void this.callback();const t=this.createUrl(),e=document.createElement("script");e.id=this.id,e.type="text/javascript",e.src=t,e.onerror=this.loadErrorCallback.bind(this),e.defer=!0,e.async=!0,this.nonce&&(e.nonce=this.nonce),document.head.appendChild(e)}reset(){this.deleteScript(),this.done=!1,this.loading=!1,this.errors=[],this.onerrorEvent=null}resetIfRetryingFailed(){this.failed&&this.reset()}loadErrorCallback(t){if(this.errors.push(t),this.errors.length<=this.retries){const t=this.errors.length*Math.pow(2,this.errors.length);console.log(`Failed to load Google Maps script, retrying in ${t} ms.`),setTimeout(()=>{this.deleteScript(),this.setScript()},t)}else this.onerrorEvent=t,this.callback()}setCallback(){window.__googleMapsCallback=this.callback.bind(this)}callback(){this.done=!0,this.loading=!1,this.callbacks.forEach(t=>{t(this.onerrorEvent)}),this.callbacks=[]}execute(){if(this.resetIfRetryingFailed(),this.done)this.callback();else{if(window.google&&window.google.maps&&window.google.maps.version)return console.warn("Google Maps already loaded outside @googlemaps/js-api-loader.This may result in undesirable behavior as options and script parameters may not match."),void this.callback();this.loading||(this.loading=!0,this.setCallback(),this.setScript())}}}Function.define(Function.plugin.google.fire.base,"link",Tr["a"],{configurable:!0,enumerable:!0,writable:!0}),Function.define(Function.plugin.google.map,"loader",(function(t){return new li({apiKey:t})})),Function.promise.start();var hi={define:Function.define,is:Object.is,un:Object.un,object:Object,array:Array,string:String,math:Math,number:Number,regex:RegExp,function:Function,date:Date,time:{stamp:Date.stamp,sleep:Date.sleep,interval:Date.interval,zone:Date.Time.zone},url:URL,http:Function.http,serialize:Function.serialize,xml:Function.xml,json:JSON,path:Function.path,file:Function.file,dir:Function.dir,diagnostic:Function.diagnostic,event:Function.event,util:Function.util,promise:Promise,cpu:Function.cpu,compress:Function.compress,hash:Function.hash,network:Function.network,stream:Function.stream,data:Function.data,db:Function.db,sql:Function.sql,store:Function.store,storage:Function.storage,session:Function.session,cookie:Function.cookie,audio:Function.audio,dom:Function.dom,component:Function.component,element:Function.element,query:Function.query,attribute:Function.attribute,mobile:Function.mobile,visitor:Function.visitor,scroll:Function.scroll,user:Function.user,email:Function.email,phone:Function.phone,system:Function.system,plugin:Function.plugin,web:Function.web,express:Function.express,geo:Function.geo,map:Function.map,context:Function.context,argument:Function.argument,option:Function.option,optional:Function.optional,zero:0,one:1};hi.route=In.route,hi.router=In.router;const di=hi,fi=function(){};e["a"]={__:In.reactive(),var:In.reactive(),log:{},cache:{},app:In.reactive(),application:In.application,properties:In.properties,to:In.to,reference:In.reference,reactive:In.reactive,react:In.react,compute:In.compute,watch:In.watch,watching:In.watching,inject:In.inject,store:In.store,on:In.on,emit:In.emit,process:In.process,request:In.request,slot:In.slot,view:{},layout:{},component:In.component,element:In.element,next:In.next}},abc5:function(t,e,n){"use strict";(function(t){function r(){return i().__VUE_DEVTOOLS_GLOBAL_HOOK__}function i(){return"undefined"!==typeof navigator&&"undefined"!==typeof window?window:"undefined"!==typeof t?t:{}}n.d(e,"a",(function(){return r})),n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return s}));const s="function"===typeof Proxy}).call(this,n("c8ba"))},af7f:function(t,e,n){"use strict";n.d(e,"b",(function(){return i})),n.d(e,"a",(function(){return a}));var r=n("20a4");function i(t,...e){return e.reduce((e,n)=>(t.hasOwnProperty(n)&&(e[n]=t[n]),e),{})}const s=setTimeout,o=clearTimeout;function a(t,e){e.useNativeTimers?(t.setTimeoutFn=s.bind(r["a"]),t.clearTimeoutFn=o.bind(r["a"])):(t.setTimeoutFn=setTimeout.bind(r["a"]),t.clearTimeoutFn=clearTimeout.bind(r["a"]))}},b19d:function(t,e){function n(t){if(t)return r(t)}function r(t){for(var e in n.prototype)t[e]=n.prototype[e];return t}e.Emitter=n,n.prototype.on=n.prototype.addEventListener=function(t,e){return this._callbacks=this._callbacks||{},(this._callbacks["$"+t]=this._callbacks["$"+t]||[]).push(e),this},n.prototype.once=function(t,e){function n(){this.off(t,n),e.apply(this,arguments)}return n.fn=e,this.on(t,n),this},n.prototype.off=n.prototype.removeListener=n.prototype.removeAllListeners=n.prototype.removeEventListener=function(t,e){if(this._callbacks=this._callbacks||{},0==arguments.length)return this._callbacks={},this;var n,r=this._callbacks["$"+t];if(!r)return this;if(1==arguments.length)return delete this._callbacks["$"+t],this;for(var i=0;i<r.length;i++)if(n=r[i],n===e||n.fn===e){r.splice(i,1);break}return 0===r.length&&delete this._callbacks["$"+t],this},n.prototype.emit=function(t){this._callbacks=this._callbacks||{};for(var e=new Array(arguments.length-1),n=this._callbacks["$"+t],r=1;r<arguments.length;r++)e[r-1]=arguments[r];if(n){n=n.slice(0);r=0;for(var i=n.length;r<i;++r)n[r].apply(this,e)}return this},n.prototype.emitReserved=n.prototype.emit,n.prototype.listeners=function(t){return this._callbacks=this._callbacks||{},this._callbacks["$"+t]||[]},n.prototype.hasListeners=function(t){return!!this.listeners(t).length}},b50d:function(t,e,n){"use strict";var r=n("c532"),i=n("467f"),s=n("7aac"),o=n("30b5"),a=n("83b9"),c=n("c345"),u=n("3934"),l=n("2d83"),h=n("2444"),d=n("7a77");t.exports=function(t){return new Promise((function(e,n){var f,p=t.data,m=t.headers,g=t.responseType;function y(){t.cancelToken&&t.cancelToken.unsubscribe(f),t.signal&&t.signal.removeEventListener("abort",f)}r.isFormData(p)&&delete m["Content-Type"];var b=new XMLHttpRequest;if(t.auth){var v=t.auth.username||"",w=t.auth.password?unescape(encodeURIComponent(t.auth.password)):"";m.Authorization="Basic "+btoa(v+":"+w)}var _=a(t.baseURL,t.url);function I(){if(b){var r="getAllResponseHeaders"in b?c(b.getAllResponseHeaders()):null,s=g&&"text"!==g&&"json"!==g?b.response:b.responseText,o={data:s,status:b.status,statusText:b.statusText,headers:r,config:t,request:b};i((function(t){e(t),y()}),(function(t){n(t),y()}),o),b=null}}if(b.open(t.method.toUpperCase(),o(_,t.params,t.paramsSerializer),!0),b.timeout=t.timeout,"onloadend"in b?b.onloadend=I:b.onreadystatechange=function(){b&&4===b.readyState&&(0!==b.status||b.responseURL&&0===b.responseURL.indexOf("file:"))&&setTimeout(I)},b.onabort=function(){b&&(n(l("Request aborted",t,"ECONNABORTED",b)),b=null)},b.onerror=function(){n(l("Network Error",t,null,b)),b=null},b.ontimeout=function(){var e=t.timeout?"timeout of "+t.timeout+"ms exceeded":"timeout exceeded",r=t.transitional||h.transitional;t.timeoutErrorMessage&&(e=t.timeoutErrorMessage),n(l(e,t,r.clarifyTimeoutError?"ETIMEDOUT":"ECONNABORTED",b)),b=null},r.isStandardBrowserEnv()){var E=(t.withCredentials||u(_))&&t.xsrfCookieName?s.read(t.xsrfCookieName):void 0;E&&(m[t.xsrfHeaderName]=E)}"setRequestHeader"in b&&r.forEach(m,(function(t,e){"undefined"===typeof p&&"content-type"===e.toLowerCase()?delete m[e]:b.setRequestHeader(e,t)})),r.isUndefined(t.withCredentials)||(b.withCredentials=!!t.withCredentials),g&&"json"!==g&&(b.responseType=t.responseType),"function"===typeof t.onDownloadProgress&&b.addEventListener("progress",t.onDownloadProgress),"function"===typeof t.onUploadProgress&&b.upload&&b.upload.addEventListener("progress",t.onUploadProgress),(t.cancelToken||t.signal)&&(f=function(t){b&&(n(!t||t&&t.type?new d("canceled"):t),b.abort(),b=null)},t.cancelToken&&t.cancelToken.subscribe(f),t.signal&&(t.signal.aborted?f():t.signal.addEventListener("abort",f))),p||(p=null),b.send(p)}))}},b639:function(t,e,n){"use strict";(function(t){
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <http://feross.org>
 * @license  MIT
 */
var r=n("1fb5"),i=n("9152"),s=n("e3db");function o(){try{var t=new Uint8Array(1);return t.__proto__={__proto__:Uint8Array.prototype,foo:function(){return 42}},42===t.foo()&&"function"===typeof t.subarray&&0===t.subarray(1,1).byteLength}catch(e){return!1}}function a(){return u.TYPED_ARRAY_SUPPORT?2147483647:1073741823}function c(t,e){if(a()<e)throw new RangeError("Invalid typed array length");return u.TYPED_ARRAY_SUPPORT?(t=new Uint8Array(e),t.__proto__=u.prototype):(null===t&&(t=new u(e)),t.length=e),t}function u(t,e,n){if(!u.TYPED_ARRAY_SUPPORT&&!(this instanceof u))return new u(t,e,n);if("number"===typeof t){if("string"===typeof e)throw new Error("If encoding is specified then the first argument must be a string");return f(this,t)}return l(this,t,e,n)}function l(t,e,n,r){if("number"===typeof e)throw new TypeError('"value" argument must not be a number');return"undefined"!==typeof ArrayBuffer&&e instanceof ArrayBuffer?g(t,e,n,r):"string"===typeof e?p(t,e,n):y(t,e)}function h(t){if("number"!==typeof t)throw new TypeError('"size" argument must be a number');if(t<0)throw new RangeError('"size" argument must not be negative')}function d(t,e,n,r){return h(e),e<=0?c(t,e):void 0!==n?"string"===typeof r?c(t,e).fill(n,r):c(t,e).fill(n):c(t,e)}function f(t,e){if(h(e),t=c(t,e<0?0:0|b(e)),!u.TYPED_ARRAY_SUPPORT)for(var n=0;n<e;++n)t[n]=0;return t}function p(t,e,n){if("string"===typeof n&&""!==n||(n="utf8"),!u.isEncoding(n))throw new TypeError('"encoding" must be a valid string encoding');var r=0|w(e,n);t=c(t,r);var i=t.write(e,n);return i!==r&&(t=t.slice(0,i)),t}function m(t,e){var n=e.length<0?0:0|b(e.length);t=c(t,n);for(var r=0;r<n;r+=1)t[r]=255&e[r];return t}function g(t,e,n,r){if(e.byteLength,n<0||e.byteLength<n)throw new RangeError("'offset' is out of bounds");if(e.byteLength<n+(r||0))throw new RangeError("'length' is out of bounds");return e=void 0===n&&void 0===r?new Uint8Array(e):void 0===r?new Uint8Array(e,n):new Uint8Array(e,n,r),u.TYPED_ARRAY_SUPPORT?(t=e,t.__proto__=u.prototype):t=m(t,e),t}function y(t,e){if(u.isBuffer(e)){var n=0|b(e.length);return t=c(t,n),0===t.length?t:(e.copy(t,0,0,n),t)}if(e){if("undefined"!==typeof ArrayBuffer&&e.buffer instanceof ArrayBuffer||"length"in e)return"number"!==typeof e.length||et(e.length)?c(t,0):m(t,e);if("Buffer"===e.type&&s(e.data))return m(t,e.data)}throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")}function b(t){if(t>=a())throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+a().toString(16)+" bytes");return 0|t}function v(t){return+t!=t&&(t=0),u.alloc(+t)}function w(t,e){if(u.isBuffer(t))return t.length;if("undefined"!==typeof ArrayBuffer&&"function"===typeof ArrayBuffer.isView&&(ArrayBuffer.isView(t)||t instanceof ArrayBuffer))return t.byteLength;"string"!==typeof t&&(t=""+t);var n=t.length;if(0===n)return 0;for(var r=!1;;)switch(e){case"ascii":case"latin1":case"binary":return n;case"utf8":case"utf-8":case void 0:return Q(t).length;case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return 2*n;case"hex":return n>>>1;case"base64":return Z(t).length;default:if(r)return Q(t).length;e=(""+e).toLowerCase(),r=!0}}function _(t,e,n){var r=!1;if((void 0===e||e<0)&&(e=0),e>this.length)return"";if((void 0===n||n>this.length)&&(n=this.length),n<=0)return"";if(n>>>=0,e>>>=0,n<=e)return"";t||(t="utf8");while(1)switch(t){case"hex":return L(this,e,n);case"utf8":case"utf-8":return R(this,e,n);case"ascii":return P(this,e,n);case"latin1":case"binary":return F(this,e,n);case"base64":return C(this,e,n);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return M(this,e,n);default:if(r)throw new TypeError("Unknown encoding: "+t);t=(t+"").toLowerCase(),r=!0}}function I(t,e,n){var r=t[e];t[e]=t[n],t[n]=r}function E(t,e,n,r,i){if(0===t.length)return-1;if("string"===typeof n?(r=n,n=0):n>2147483647?n=2147483647:n<-2147483648&&(n=-2147483648),n=+n,isNaN(n)&&(n=i?0:t.length-1),n<0&&(n=t.length+n),n>=t.length){if(i)return-1;n=t.length-1}else if(n<0){if(!i)return-1;n=0}if("string"===typeof e&&(e=u.from(e,r)),u.isBuffer(e))return 0===e.length?-1:O(t,e,n,r,i);if("number"===typeof e)return e&=255,u.TYPED_ARRAY_SUPPORT&&"function"===typeof Uint8Array.prototype.indexOf?i?Uint8Array.prototype.indexOf.call(t,e,n):Uint8Array.prototype.lastIndexOf.call(t,e,n):O(t,[e],n,r,i);throw new TypeError("val must be string, number or Buffer")}function O(t,e,n,r,i){var s,o=1,a=t.length,c=e.length;if(void 0!==r&&(r=String(r).toLowerCase(),"ucs2"===r||"ucs-2"===r||"utf16le"===r||"utf-16le"===r)){if(t.length<2||e.length<2)return-1;o=2,a/=2,c/=2,n/=2}function u(t,e){return 1===o?t[e]:t.readUInt16BE(e*o)}if(i){var l=-1;for(s=n;s<a;s++)if(u(t,s)===u(e,-1===l?0:s-l)){if(-1===l&&(l=s),s-l+1===c)return l*o}else-1!==l&&(s-=s-l),l=-1}else for(n+c>a&&(n=a-c),s=n;s>=0;s--){for(var h=!0,d=0;d<c;d++)if(u(t,s+d)!==u(e,d)){h=!1;break}if(h)return s}return-1}function T(t,e,n,r){n=Number(n)||0;var i=t.length-n;r?(r=Number(r),r>i&&(r=i)):r=i;var s=e.length;if(s%2!==0)throw new TypeError("Invalid hex string");r>s/2&&(r=s/2);for(var o=0;o<r;++o){var a=parseInt(e.substr(2*o,2),16);if(isNaN(a))return o;t[n+o]=a}return o}function k(t,e,n,r){return tt(Q(e,t.length-n),t,n,r)}function S(t,e,n,r){return tt(J(e),t,n,r)}function A(t,e,n,r){return S(t,e,n,r)}function j(t,e,n,r){return tt(Z(e),t,n,r)}function N(t,e,n,r){return tt(X(e,t.length-n),t,n,r)}function C(t,e,n){return 0===e&&n===t.length?r.fromByteArray(t):r.fromByteArray(t.slice(e,n))}function R(t,e,n){n=Math.min(t.length,n);var r=[],i=e;while(i<n){var s,o,a,c,u=t[i],l=null,h=u>239?4:u>223?3:u>191?2:1;if(i+h<=n)switch(h){case 1:u<128&&(l=u);break;case 2:s=t[i+1],128===(192&s)&&(c=(31&u)<<6|63&s,c>127&&(l=c));break;case 3:s=t[i+1],o=t[i+2],128===(192&s)&&128===(192&o)&&(c=(15&u)<<12|(63&s)<<6|63&o,c>2047&&(c<55296||c>57343)&&(l=c));break;case 4:s=t[i+1],o=t[i+2],a=t[i+3],128===(192&s)&&128===(192&o)&&128===(192&a)&&(c=(15&u)<<18|(63&s)<<12|(63&o)<<6|63&a,c>65535&&c<1114112&&(l=c))}null===l?(l=65533,h=1):l>65535&&(l-=65536,r.push(l>>>10&1023|55296),l=56320|1023&l),r.push(l),i+=h}return D(r)}e.Buffer=u,e.SlowBuffer=v,e.INSPECT_MAX_BYTES=50,u.TYPED_ARRAY_SUPPORT=void 0!==t.TYPED_ARRAY_SUPPORT?t.TYPED_ARRAY_SUPPORT:o(),e.kMaxLength=a(),u.poolSize=8192,u._augment=function(t){return t.__proto__=u.prototype,t},u.from=function(t,e,n){return l(null,t,e,n)},u.TYPED_ARRAY_SUPPORT&&(u.prototype.__proto__=Uint8Array.prototype,u.__proto__=Uint8Array,"undefined"!==typeof Symbol&&Symbol.species&&u[Symbol.species]===u&&Object.defineProperty(u,Symbol.species,{value:null,configurable:!0})),u.alloc=function(t,e,n){return d(null,t,e,n)},u.allocUnsafe=function(t){return f(null,t)},u.allocUnsafeSlow=function(t){return f(null,t)},u.isBuffer=function(t){return!(null==t||!t._isBuffer)},u.compare=function(t,e){if(!u.isBuffer(t)||!u.isBuffer(e))throw new TypeError("Arguments must be Buffers");if(t===e)return 0;for(var n=t.length,r=e.length,i=0,s=Math.min(n,r);i<s;++i)if(t[i]!==e[i]){n=t[i],r=e[i];break}return n<r?-1:r<n?1:0},u.isEncoding=function(t){switch(String(t).toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return!0;default:return!1}},u.concat=function(t,e){if(!s(t))throw new TypeError('"list" argument must be an Array of Buffers');if(0===t.length)return u.alloc(0);var n;if(void 0===e)for(e=0,n=0;n<t.length;++n)e+=t[n].length;var r=u.allocUnsafe(e),i=0;for(n=0;n<t.length;++n){var o=t[n];if(!u.isBuffer(o))throw new TypeError('"list" argument must be an Array of Buffers');o.copy(r,i),i+=o.length}return r},u.byteLength=w,u.prototype._isBuffer=!0,u.prototype.swap16=function(){var t=this.length;if(t%2!==0)throw new RangeError("Buffer size must be a multiple of 16-bits");for(var e=0;e<t;e+=2)I(this,e,e+1);return this},u.prototype.swap32=function(){var t=this.length;if(t%4!==0)throw new RangeError("Buffer size must be a multiple of 32-bits");for(var e=0;e<t;e+=4)I(this,e,e+3),I(this,e+1,e+2);return this},u.prototype.swap64=function(){var t=this.length;if(t%8!==0)throw new RangeError("Buffer size must be a multiple of 64-bits");for(var e=0;e<t;e+=8)I(this,e,e+7),I(this,e+1,e+6),I(this,e+2,e+5),I(this,e+3,e+4);return this},u.prototype.toString=function(){var t=0|this.length;return 0===t?"":0===arguments.length?R(this,0,t):_.apply(this,arguments)},u.prototype.equals=function(t){if(!u.isBuffer(t))throw new TypeError("Argument must be a Buffer");return this===t||0===u.compare(this,t)},u.prototype.inspect=function(){var t="",n=e.INSPECT_MAX_BYTES;return this.length>0&&(t=this.toString("hex",0,n).match(/.{2}/g).join(" "),this.length>n&&(t+=" ... ")),"<Buffer "+t+">"},u.prototype.compare=function(t,e,n,r,i){if(!u.isBuffer(t))throw new TypeError("Argument must be a Buffer");if(void 0===e&&(e=0),void 0===n&&(n=t?t.length:0),void 0===r&&(r=0),void 0===i&&(i=this.length),e<0||n>t.length||r<0||i>this.length)throw new RangeError("out of range index");if(r>=i&&e>=n)return 0;if(r>=i)return-1;if(e>=n)return 1;if(e>>>=0,n>>>=0,r>>>=0,i>>>=0,this===t)return 0;for(var s=i-r,o=n-e,a=Math.min(s,o),c=this.slice(r,i),l=t.slice(e,n),h=0;h<a;++h)if(c[h]!==l[h]){s=c[h],o=l[h];break}return s<o?-1:o<s?1:0},u.prototype.includes=function(t,e,n){return-1!==this.indexOf(t,e,n)},u.prototype.indexOf=function(t,e,n){return E(this,t,e,n,!0)},u.prototype.lastIndexOf=function(t,e,n){return E(this,t,e,n,!1)},u.prototype.write=function(t,e,n,r){if(void 0===e)r="utf8",n=this.length,e=0;else if(void 0===n&&"string"===typeof e)r=e,n=this.length,e=0;else{if(!isFinite(e))throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");e|=0,isFinite(n)?(n|=0,void 0===r&&(r="utf8")):(r=n,n=void 0)}var i=this.length-e;if((void 0===n||n>i)&&(n=i),t.length>0&&(n<0||e<0)||e>this.length)throw new RangeError("Attempt to write outside buffer bounds");r||(r="utf8");for(var s=!1;;)switch(r){case"hex":return T(this,t,e,n);case"utf8":case"utf-8":return k(this,t,e,n);case"ascii":return S(this,t,e,n);case"latin1":case"binary":return A(this,t,e,n);case"base64":return j(this,t,e,n);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return N(this,t,e,n);default:if(s)throw new TypeError("Unknown encoding: "+r);r=(""+r).toLowerCase(),s=!0}},u.prototype.toJSON=function(){return{type:"Buffer",data:Array.prototype.slice.call(this._arr||this,0)}};var x=4096;function D(t){var e=t.length;if(e<=x)return String.fromCharCode.apply(String,t);var n="",r=0;while(r<e)n+=String.fromCharCode.apply(String,t.slice(r,r+=x));return n}function P(t,e,n){var r="";n=Math.min(t.length,n);for(var i=e;i<n;++i)r+=String.fromCharCode(127&t[i]);return r}function F(t,e,n){var r="";n=Math.min(t.length,n);for(var i=e;i<n;++i)r+=String.fromCharCode(t[i]);return r}function L(t,e,n){var r=t.length;(!e||e<0)&&(e=0),(!n||n<0||n>r)&&(n=r);for(var i="",s=e;s<n;++s)i+=Y(t[s]);return i}function M(t,e,n){for(var r=t.slice(e,n),i="",s=0;s<r.length;s+=2)i+=String.fromCharCode(r[s]+256*r[s+1]);return i}function U(t,e,n){if(t%1!==0||t<0)throw new RangeError("offset is not uint");if(t+e>n)throw new RangeError("Trying to access beyond buffer length")}function B(t,e,n,r,i,s){if(!u.isBuffer(t))throw new TypeError('"buffer" argument must be a Buffer instance');if(e>i||e<s)throw new RangeError('"value" argument is out of bounds');if(n+r>t.length)throw new RangeError("Index out of range")}function q(t,e,n,r){e<0&&(e=65535+e+1);for(var i=0,s=Math.min(t.length-n,2);i<s;++i)t[n+i]=(e&255<<8*(r?i:1-i))>>>8*(r?i:1-i)}function V(t,e,n,r){e<0&&(e=4294967295+e+1);for(var i=0,s=Math.min(t.length-n,4);i<s;++i)t[n+i]=e>>>8*(r?i:3-i)&255}function z(t,e,n,r,i,s){if(n+r>t.length)throw new RangeError("Index out of range");if(n<0)throw new RangeError("Index out of range")}function H(t,e,n,r,s){return s||z(t,e,n,4,34028234663852886e22,-34028234663852886e22),i.write(t,e,n,r,23,4),n+4}function K(t,e,n,r,s){return s||z(t,e,n,8,17976931348623157e292,-17976931348623157e292),i.write(t,e,n,r,52,8),n+8}u.prototype.slice=function(t,e){var n,r=this.length;if(t=~~t,e=void 0===e?r:~~e,t<0?(t+=r,t<0&&(t=0)):t>r&&(t=r),e<0?(e+=r,e<0&&(e=0)):e>r&&(e=r),e<t&&(e=t),u.TYPED_ARRAY_SUPPORT)n=this.subarray(t,e),n.__proto__=u.prototype;else{var i=e-t;n=new u(i,void 0);for(var s=0;s<i;++s)n[s]=this[s+t]}return n},u.prototype.readUIntLE=function(t,e,n){t|=0,e|=0,n||U(t,e,this.length);var r=this[t],i=1,s=0;while(++s<e&&(i*=256))r+=this[t+s]*i;return r},u.prototype.readUIntBE=function(t,e,n){t|=0,e|=0,n||U(t,e,this.length);var r=this[t+--e],i=1;while(e>0&&(i*=256))r+=this[t+--e]*i;return r},u.prototype.readUInt8=function(t,e){return e||U(t,1,this.length),this[t]},u.prototype.readUInt16LE=function(t,e){return e||U(t,2,this.length),this[t]|this[t+1]<<8},u.prototype.readUInt16BE=function(t,e){return e||U(t,2,this.length),this[t]<<8|this[t+1]},u.prototype.readUInt32LE=function(t,e){return e||U(t,4,this.length),(this[t]|this[t+1]<<8|this[t+2]<<16)+16777216*this[t+3]},u.prototype.readUInt32BE=function(t,e){return e||U(t,4,this.length),16777216*this[t]+(this[t+1]<<16|this[t+2]<<8|this[t+3])},u.prototype.readIntLE=function(t,e,n){t|=0,e|=0,n||U(t,e,this.length);var r=this[t],i=1,s=0;while(++s<e&&(i*=256))r+=this[t+s]*i;return i*=128,r>=i&&(r-=Math.pow(2,8*e)),r},u.prototype.readIntBE=function(t,e,n){t|=0,e|=0,n||U(t,e,this.length);var r=e,i=1,s=this[t+--r];while(r>0&&(i*=256))s+=this[t+--r]*i;return i*=128,s>=i&&(s-=Math.pow(2,8*e)),s},u.prototype.readInt8=function(t,e){return e||U(t,1,this.length),128&this[t]?-1*(255-this[t]+1):this[t]},u.prototype.readInt16LE=function(t,e){e||U(t,2,this.length);var n=this[t]|this[t+1]<<8;return 32768&n?4294901760|n:n},u.prototype.readInt16BE=function(t,e){e||U(t,2,this.length);var n=this[t+1]|this[t]<<8;return 32768&n?4294901760|n:n},u.prototype.readInt32LE=function(t,e){return e||U(t,4,this.length),this[t]|this[t+1]<<8|this[t+2]<<16|this[t+3]<<24},u.prototype.readInt32BE=function(t,e){return e||U(t,4,this.length),this[t]<<24|this[t+1]<<16|this[t+2]<<8|this[t+3]},u.prototype.readFloatLE=function(t,e){return e||U(t,4,this.length),i.read(this,t,!0,23,4)},u.prototype.readFloatBE=function(t,e){return e||U(t,4,this.length),i.read(this,t,!1,23,4)},u.prototype.readDoubleLE=function(t,e){return e||U(t,8,this.length),i.read(this,t,!0,52,8)},u.prototype.readDoubleBE=function(t,e){return e||U(t,8,this.length),i.read(this,t,!1,52,8)},u.prototype.writeUIntLE=function(t,e,n,r){if(t=+t,e|=0,n|=0,!r){var i=Math.pow(2,8*n)-1;B(this,t,e,n,i,0)}var s=1,o=0;this[e]=255&t;while(++o<n&&(s*=256))this[e+o]=t/s&255;return e+n},u.prototype.writeUIntBE=function(t,e,n,r){if(t=+t,e|=0,n|=0,!r){var i=Math.pow(2,8*n)-1;B(this,t,e,n,i,0)}var s=n-1,o=1;this[e+s]=255&t;while(--s>=0&&(o*=256))this[e+s]=t/o&255;return e+n},u.prototype.writeUInt8=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,1,255,0),u.TYPED_ARRAY_SUPPORT||(t=Math.floor(t)),this[e]=255&t,e+1},u.prototype.writeUInt16LE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,2,65535,0),u.TYPED_ARRAY_SUPPORT?(this[e]=255&t,this[e+1]=t>>>8):q(this,t,e,!0),e+2},u.prototype.writeUInt16BE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,2,65535,0),u.TYPED_ARRAY_SUPPORT?(this[e]=t>>>8,this[e+1]=255&t):q(this,t,e,!1),e+2},u.prototype.writeUInt32LE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,4,4294967295,0),u.TYPED_ARRAY_SUPPORT?(this[e+3]=t>>>24,this[e+2]=t>>>16,this[e+1]=t>>>8,this[e]=255&t):V(this,t,e,!0),e+4},u.prototype.writeUInt32BE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,4,4294967295,0),u.TYPED_ARRAY_SUPPORT?(this[e]=t>>>24,this[e+1]=t>>>16,this[e+2]=t>>>8,this[e+3]=255&t):V(this,t,e,!1),e+4},u.prototype.writeIntLE=function(t,e,n,r){if(t=+t,e|=0,!r){var i=Math.pow(2,8*n-1);B(this,t,e,n,i-1,-i)}var s=0,o=1,a=0;this[e]=255&t;while(++s<n&&(o*=256))t<0&&0===a&&0!==this[e+s-1]&&(a=1),this[e+s]=(t/o>>0)-a&255;return e+n},u.prototype.writeIntBE=function(t,e,n,r){if(t=+t,e|=0,!r){var i=Math.pow(2,8*n-1);B(this,t,e,n,i-1,-i)}var s=n-1,o=1,a=0;this[e+s]=255&t;while(--s>=0&&(o*=256))t<0&&0===a&&0!==this[e+s+1]&&(a=1),this[e+s]=(t/o>>0)-a&255;return e+n},u.prototype.writeInt8=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,1,127,-128),u.TYPED_ARRAY_SUPPORT||(t=Math.floor(t)),t<0&&(t=255+t+1),this[e]=255&t,e+1},u.prototype.writeInt16LE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,2,32767,-32768),u.TYPED_ARRAY_SUPPORT?(this[e]=255&t,this[e+1]=t>>>8):q(this,t,e,!0),e+2},u.prototype.writeInt16BE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,2,32767,-32768),u.TYPED_ARRAY_SUPPORT?(this[e]=t>>>8,this[e+1]=255&t):q(this,t,e,!1),e+2},u.prototype.writeInt32LE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,4,2147483647,-2147483648),u.TYPED_ARRAY_SUPPORT?(this[e]=255&t,this[e+1]=t>>>8,this[e+2]=t>>>16,this[e+3]=t>>>24):V(this,t,e,!0),e+4},u.prototype.writeInt32BE=function(t,e,n){return t=+t,e|=0,n||B(this,t,e,4,2147483647,-2147483648),t<0&&(t=4294967295+t+1),u.TYPED_ARRAY_SUPPORT?(this[e]=t>>>24,this[e+1]=t>>>16,this[e+2]=t>>>8,this[e+3]=255&t):V(this,t,e,!1),e+4},u.prototype.writeFloatLE=function(t,e,n){return H(this,t,e,!0,n)},u.prototype.writeFloatBE=function(t,e,n){return H(this,t,e,!1,n)},u.prototype.writeDoubleLE=function(t,e,n){return K(this,t,e,!0,n)},u.prototype.writeDoubleBE=function(t,e,n){return K(this,t,e,!1,n)},u.prototype.copy=function(t,e,n,r){if(n||(n=0),r||0===r||(r=this.length),e>=t.length&&(e=t.length),e||(e=0),r>0&&r<n&&(r=n),r===n)return 0;if(0===t.length||0===this.length)return 0;if(e<0)throw new RangeError("targetStart out of bounds");if(n<0||n>=this.length)throw new RangeError("sourceStart out of bounds");if(r<0)throw new RangeError("sourceEnd out of bounds");r>this.length&&(r=this.length),t.length-e<r-n&&(r=t.length-e+n);var i,s=r-n;if(this===t&&n<e&&e<r)for(i=s-1;i>=0;--i)t[i+e]=this[i+n];else if(s<1e3||!u.TYPED_ARRAY_SUPPORT)for(i=0;i<s;++i)t[i+e]=this[i+n];else Uint8Array.prototype.set.call(t,this.subarray(n,n+s),e);return s},u.prototype.fill=function(t,e,n,r){if("string"===typeof t){if("string"===typeof e?(r=e,e=0,n=this.length):"string"===typeof n&&(r=n,n=this.length),1===t.length){var i=t.charCodeAt(0);i<256&&(t=i)}if(void 0!==r&&"string"!==typeof r)throw new TypeError("encoding must be a string");if("string"===typeof r&&!u.isEncoding(r))throw new TypeError("Unknown encoding: "+r)}else"number"===typeof t&&(t&=255);if(e<0||this.length<e||this.length<n)throw new RangeError("Out of range index");if(n<=e)return this;var s;if(e>>>=0,n=void 0===n?this.length:n>>>0,t||(t=0),"number"===typeof t)for(s=e;s<n;++s)this[s]=t;else{var o=u.isBuffer(t)?t:Q(new u(t,r).toString()),a=o.length;for(s=0;s<n-e;++s)this[s+e]=o[s%a]}return this};var $=/[^+\/0-9A-Za-z-_]/g;function G(t){if(t=W(t).replace($,""),t.length<2)return"";while(t.length%4!==0)t+="=";return t}function W(t){return t.trim?t.trim():t.replace(/^\s+|\s+$/g,"")}function Y(t){return t<16?"0"+t.toString(16):t.toString(16)}function Q(t,e){var n;e=e||1/0;for(var r=t.length,i=null,s=[],o=0;o<r;++o){if(n=t.charCodeAt(o),n>55295&&n<57344){if(!i){if(n>56319){(e-=3)>-1&&s.push(239,191,189);continue}if(o+1===r){(e-=3)>-1&&s.push(239,191,189);continue}i=n;continue}if(n<56320){(e-=3)>-1&&s.push(239,191,189),i=n;continue}n=65536+(i-55296<<10|n-56320)}else i&&(e-=3)>-1&&s.push(239,191,189);if(i=null,n<128){if((e-=1)<0)break;s.push(n)}else if(n<2048){if((e-=2)<0)break;s.push(n>>6|192,63&n|128)}else if(n<65536){if((e-=3)<0)break;s.push(n>>12|224,n>>6&63|128,63&n|128)}else{if(!(n<1114112))throw new Error("Invalid code point");if((e-=4)<0)break;s.push(n>>18|240,n>>12&63|128,n>>6&63|128,63&n|128)}}return s}function J(t){for(var e=[],n=0;n<t.length;++n)e.push(255&t.charCodeAt(n));return e}function X(t,e){for(var n,r,i,s=[],o=0;o<t.length;++o){if((e-=2)<0)break;n=t.charCodeAt(o),r=n>>8,i=n%256,s.push(i),s.push(r)}return s}function Z(t){return r.toByteArray(G(t))}function tt(t,e,n,r){for(var i=0;i<r;++i){if(i+n>=e.length||i>=t.length)break;e[i+n]=t[i]}return i}function et(t){return t!==t}}).call(this,n("c8ba"))},b774:function(t,e,n){"use strict";n.d(e,"b",(function(){return r})),n.d(e,"a",(function(){return i}));const r="devtools-plugin:setup",i="plugin:settings:set"},bc3a:function(t,e,n){t.exports=n("cee4")},c345:function(t,e,n){"use strict";var r=n("c532"),i=["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"];t.exports=function(t){var e,n,s,o={};return t?(r.forEach(t.split("\n"),(function(t){if(s=t.indexOf(":"),e=r.trim(t.substr(0,s)).toLowerCase(),n=r.trim(t.substr(s+1)),e){if(o[e]&&i.indexOf(e)>=0)return;o[e]="set-cookie"===e?(o[e]?o[e]:[]).concat([n]):o[e]?o[e]+", "+n:n}})),o):o}},c401:function(t,e,n){"use strict";var r=n("c532"),i=n("2444");t.exports=function(t,e,n){var s=this||i;return r.forEach(n,(function(n){t=n.call(s,t,e)})),t}},c532:function(t,e,n){"use strict";var r=n("1d2b"),i=Object.prototype.toString;function s(t){return"[object Array]"===i.call(t)}function o(t){return"undefined"===typeof t}function a(t){return null!==t&&!o(t)&&null!==t.constructor&&!o(t.constructor)&&"function"===typeof t.constructor.isBuffer&&t.constructor.isBuffer(t)}function c(t){return"[object ArrayBuffer]"===i.call(t)}function u(t){return"undefined"!==typeof FormData&&t instanceof FormData}function l(t){var e;return e="undefined"!==typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(t):t&&t.buffer&&t.buffer instanceof ArrayBuffer,e}function h(t){return"string"===typeof t}function d(t){return"number"===typeof t}function f(t){return null!==t&&"object"===typeof t}function p(t){if("[object Object]"!==i.call(t))return!1;var e=Object.getPrototypeOf(t);return null===e||e===Object.prototype}function m(t){return"[object Date]"===i.call(t)}function g(t){return"[object File]"===i.call(t)}function y(t){return"[object Blob]"===i.call(t)}function b(t){return"[object Function]"===i.call(t)}function v(t){return f(t)&&b(t.pipe)}function w(t){return"undefined"!==typeof URLSearchParams&&t instanceof URLSearchParams}function _(t){return t.trim?t.trim():t.replace(/^\s+|\s+$/g,"")}function I(){return("undefined"===typeof navigator||"ReactNative"!==navigator.product&&"NativeScript"!==navigator.product&&"NS"!==navigator.product)&&("undefined"!==typeof window&&"undefined"!==typeof document)}function E(t,e){if(null!==t&&"undefined"!==typeof t)if("object"!==typeof t&&(t=[t]),s(t))for(var n=0,r=t.length;n<r;n++)e.call(null,t[n],n,t);else for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&e.call(null,t[i],i,t)}function O(){var t={};function e(e,n){p(t[n])&&p(e)?t[n]=O(t[n],e):p(e)?t[n]=O({},e):s(e)?t[n]=e.slice():t[n]=e}for(var n=0,r=arguments.length;n<r;n++)E(arguments[n],e);return t}function T(t,e,n){return E(e,(function(e,i){t[i]=n&&"function"===typeof e?r(e,n):e})),t}function k(t){return 65279===t.charCodeAt(0)&&(t=t.slice(1)),t}t.exports={isArray:s,isArrayBuffer:c,isBuffer:a,isFormData:u,isArrayBufferView:l,isString:h,isNumber:d,isObject:f,isPlainObject:p,isUndefined:o,isDate:m,isFile:g,isBlob:y,isFunction:b,isStream:v,isURLSearchParams:w,isStandardBrowserEnv:I,forEach:E,merge:O,extend:T,trim:_,stripBOM:k}},c8af:function(t,e,n){"use strict";var r=n("c532");t.exports=function(t,e){r.forEach(t,(function(n,r){r!==e&&r.toUpperCase()===e.toUpperCase()&&(t[e]=n,delete t[r])}))}},c8ba:function(t,e){var n;n=function(){return this}();try{n=n||new Function("return this")()}catch(r){"object"===typeof window&&(n=window)}t.exports=n},c9eb:function(t,e){try{t.exports="undefined"!==typeof XMLHttpRequest&&"withCredentials"in new XMLHttpRequest}catch(n){t.exports=!1}},cc87:function(t,e,n){(function(t){function e(t,n,r,i){if(!Array.isArray(n))return n?e.value(t,n,r,i):"__"in t?t["__"]:e.value(t,"__",new e.properties(t),i);for(var s in n)e.value(t,n[s],r,i)}function n(t,e){var n;return Number.format(r(t,n=i(t)),e=Number.properties(e)).concat(e.delimiter,Number.BYTE.unit[n])}function r(t,e){return t/Math.BYTE.log[e]}function i(t){for(var e in Math.BYTE.unit)if(t>Math.BYTE.log[Math.BYTE.unit[e]]-1)return Math.BYTE.unit[e];return 0}e.properties=class{constructor(t){e.value(this,"__",t)}function(t,e,n){return this.apply(t,e,n)}class(t,e,n){return this.apply(t,e,n)}clone(t,e,n){return this.apply(t,e,n)}on(t,e,n){return this.apply(t,e,n)}set(t,e,n){return this.apply(t,e,n)}apply(t,n,r){if(Array.isArray(t))for(var i in t)e.value(this["__"],t[i],n,r);else e.value(this["__"],t,n,r);return n}export(t){return arguments.length?this["__"].exports=t:this["__"].exports}},e.property=function(t,n,r,i){return e.value(t,n,r,i)},e.get=function(t,e,n,r){return Object.defineProperty(t,e,Object.assign({get:n},r)),n},e.set=function(t,e,n,r){return Object.defineProperty(t,e,Object.assign({set:n},r)),n},e.value=function(t,e,n,r){return Object.defineProperty(t,e,Object.assign({value:n},r)),n},e.function=function(t,n,r,i){return e.value(t,n,r,i)},e.class=function(t,n,r,i){return e.value(t,n,r,i)},e.descriptor=function(t,n,r){return e.property(e.properties.prototype,t,n,r)},e.value(Object,"on",{}),e.property(Function,"indexOf",(function(t){if(t>=0)return t})),e(Object,"type",(function(t){return typeof t})),e(Object.type,"array",(function(){return arguments.length?arguments[0]instanceof Array:Array})),e(Object.type,"boolean",(function(){return arguments.length?arguments[0]instanceof Boolean:Boolean})),e(Object.type,"date",(function(){return arguments.length?arguments[0]instanceof Date:Date})),e(Object.type,"error",(function(){return arguments.length?arguments[0]instanceof Error:Error})),e(Object.type,"function",(function(){return arguments.length?arguments[0]instanceof Function:Function})),e(Object.type,"number",(function(){return arguments.length?arguments[0]instanceof Number:Number})),e(Object.type,"object",(function(){return arguments.length?arguments[0]instanceof Object:Object})),e(Object.type,"regex",(function(){return arguments.length?arguments[0]instanceof RegExp:RegExp})),e(Object.type,"promise",(function(){return arguments.length?arguments[0]instanceof Promise:Promise})),e(Object.type,"string",(function(){return arguments.length?arguments[0]instanceof String:String})),e(Object.type,"of",(function(t){return Object.prototype.toString.call(t)})),e(Object.type.of,"array",(function(){return arguments.length?"[object Array]"===Object.type.of(arguments[0]):"[object Array]"})),e(Object.type.of,"boolean",(function(){return arguments.length?"[object Boolean]"===Object.type.of(arguments[0]):"[object Boolean]"})),e(Object.type.of,"date",(function(){return arguments.length?"[object Date]"===Object.type.of(arguments[0]):"[object Date]"})),e(Object.type.of,"function",(function(){return arguments.length?"[object Function]"===Object.type.of(arguments[0]):"[object Function]"})),e(Object.type.of,"null",(function(){return arguments.length?"[object Null]"===Object.type.of(arguments[0]):"[object Null]"})),e(Object.type.of,"number",(function(){return arguments.length?"[object Number]"===Object.type.of(arguments[0]):"[object Number]"})),e(Object.type.of,"object",(function(){return arguments.length?"[object Object]"===Object.type.of(arguments[0]):"[object Object]"})),e(Object.type.of,"regex",(function(){return arguments.length?"[object RegExp]"===Object.type.of(arguments[0]):"[object RegExp]"})),e(Object.type.of,"string",(function(){return arguments.length?"[object String]"===Object.type.of(arguments[0]):"[object String]"})),e(Object.is,"array",(function(t){return Array.isArray(t)})),e(Object.is,"boolean",(function(t){return!!Object.type.of.boolean(t)||Object.type.boolean(t)})),e(Object.is,"buffer",(function(e){return t.isBuffer(e)})),e(Object.is,"date",(function(t){return!!Object.type.of.date(t)||Object.type.date(t)})),e(Object.is,"decimal",(function(t){return Object.is.float(t)})),e(Object.is,"double",(function(t){return Object.is.float(t)})),e(Object.is,"finite",(function(t){return Number.isFinite(t)})),e(Object.is,"float",(function(t){return!!Object.is.number(t)&&2===t.toString().split(".").length})),e(Object.is,"function",(function(t){return!!Object.type.of.function(t)||Object.type.function(t)})),e(Object.is,"integer",(function(t){return Number.isInteger(t)})),e(Object.is,"nan",(function(t){return Number.isNaN(t)})),e(Object.is,"null",(function(t){return!!Object.type.of.null(t)||null===t})),e(Object.is,"number",(function(t){return!1===Object.is.nan(Number(t))?!!Object.type.of.number(t)||!!Object.type.of.string(t)&&!!t:Object.type.number(t)})),e(Object.is,"object",(function(t){return!Object.is.function(t)&&(!Object.is.array(t)&&(!!Object.type.of.object(t)||Object.type.object(t)))})),e(Object.is,"regex",(function(t){return!!Object.type.of.regex(t)||Object.type.regex(t)})),e(Object.is,"promise",(function(t){return Object.type.promise(t)})),e(Object.is,"stream",(function(t){return Object.type.stream(t)})),e(Object.is,"string",(function(t){return!!Object.type.of.string(t)||Object.type.string(t)})),e(Object.is,"define",(function(t){return!Object.un.define(t)})),e(Object.is,"set",(function(t,e){return arguments.length>1?Object.is.set(t)?t:e:!Object.un.set(t)})),e(Object.is,"value",(function(t){return!(t===Object.un.define()||null===t)})),e(Object.is,"scalar",(function(t){return"function"===Object.type(t)||"object"===Object.type(t)||"array"===Object.type(t)})),e(Object.is,"stringify",(function(t){return"string"===Object.type(t)||"number"===Object.type(t)})),e(Object.is,"option",(function(t){return Object.is.object(t)})),e(Object.is,"empty",(function(t){return Object.is.string(t)||Object.is.integer(t)?""===t.toString().trim():Object.is.array(t)?0===t.length:!1===(Object.is.define(t)||Object.is.null(t))})),e(Object.is,"json",(function(t){try{return JSON.parse(t),!0}catch(e){return!1}})),e(Object.is,"url",(function(t){try{return!!new URL(t)}catch(e){return!1}})),e(Object.is,"ip",(function(t){if(Object.is.string(t)&&4===(t=t.split(".")).length){for(var e in t){if(!1===Object.is.number(t[e]))return!1;if(Number(t[e])<1)return!1;if(Number(t[e])>255)return!1}return!0}return!1})),e(Object,"un",(function(t){return!t})),e(Object.un,"define",(function(t){return arguments.length?void 0===t:void 0})),e(Object.un,"set",(function(t){return!!Object.un.define(t)||!!Object.is.null(t)})),e(Object.un,"value",(function(t){return!Object.is.value(t)})),e(Object,"to",(function(t){})),e(Object.to,"string",(function(t){return Object.is.set(t)?t.toString():""})),e(Object.to,"number",(function(t){return Object.is.number(t)?Number(t):0})),e(Object.to,"integer",(function(t){return Object.is.nan(t=parseInt(t))?0:t})),e(Object.to,"float",(function(t){return Object.is.nan(t=parseFloat(t))?0:t})),e(Object.to,"boolean",(function(t){return!!t&&!["false","null","undefined","off","no"].includes(t)})),e(Object.is,"true",(function(t){return!0===t||"true"===t||"on"===t||"yes"===t})),e(Object.is,"false",(function(t){return!1===t||"false"===t||"off"===t||"no"===t})),e(Object,"to_boolean",(function(t){return Object.is.true(t)?"true":(Object.is.false(t),"false")})),e(Object,"to_bool",(function(t){return Object.is.true(t)?"on":(Object.is.false(t),"off")})),e(Object,"descriptor",(function(){return e.property(Object.prototype,key,value,option)})),e(Object,"concat",(function(...t){return Object.assign({},...t)})),e(Object,"exist",(function(t,e,n){return Object.values(e).includes(t,n)})),e(Object,"find",(function(){})),e(Object,"flip",(function(t){var e={};for(var n in t)e[t[n]]=n;return e})),e(Object,"format",(function(t={},e,n){if(e=e.toString())for(var r in t=Object.keys.format(t,n))e=e.replace(r,t[r]);return e})),e(Object,"get",(function(t,e,n){return e in t?t[e]:n})),e(Object,"has",(function(t,e){return t in e})),e(Object,"length",(function(t){var e=0;for(var n in t)e++;return e})),e(Object,"merge",(function(t,e,n){if(Object.un.set(t))return Object.assign({},e);if(n)return Object.merge(t,e);for(var r in e)r in t&&Object.is.object(t[r])?t[r]=Object.merge(t[r],e[r],!0):t[r]=e[r];return t})),e(Object,"normalize",(function(t){var e={};for(var n in t)e[n]=t[n];return e})),e(Object,"replace",(function(t,e){if(e=e.toString())for(var n in t)e=e.replace(n,t[n]);return e})),e(Object,"filter",(function(t,e){var n={};for(var r in t)!0===e(t[r])&&(n[r]=t[r]);return n})),e(Object,"join",(function(t,e){for(var n in e)t[n]=e[n];return t})),e(Object.keys,"exist",(function(t,e,n){return Object.keys(e).includes(t,n)})),e(Object.keys,"find",(function(t,e){for(var n in e)if(e[n]===t)return n})),e(Object.keys,"format",(function(t,e="%s"){var n={};for(var r in t)n[e.format(r)]=t[r];return n})),Object.key=Object.keys,Object.value=Object.values,e(Array,"descriptor",(function(t,n,r){return e.property(Array.prototype,t,n,r)})),e(Array.prototype,"string",(function(){return this.toString()})),e(Array.prototype,"begin",(function(t=""){for(var e in this)return this[e];return t})),e(Array.prototype,"count",(function(t,e){if(arguments.length){var n=this.slice(e),r=0;for(var i in n)n[i]===t&&r++;return r}return this.length-1})),e(Array.prototype,"delete",(function(t,e=1){return this.splice(t,e)})),e(Array.prototype,"each",(function(t){this.forEach(t)})),e(Array.prototype,"end",(function(t=""){for(var e in this)t=this[e];return t})),e(Array.prototype,"exist",(function(t,e){return this.includes(t,e)})),e(Array.prototype,"format",(function(t,e){var n;if(t=t.toString())for(var r in n=Array.keys.format(this,e))t=t.replace(n[r],e);return t})),e(Array.prototype,"include",(function(t,e){for(var n in t)if(!1===this.includes(t[n],e))return!1;return!0})),e(Array.prototype,"index",(function(t,e){var n;return n=Object.is.function(t)?this.slice(e).findIndex(t):this.indexOf(t,e),Function.indexOf(n)})),e(Array.prototype,"insert",(function(t,...e){return this.splice(t,0,...e)})),e(Array.prototype,"key",(function(){var t=[];for(var[e]of this.entries())t.push(e);return t})),e(Array.prototype,"max",(function(){return Math.max(...this)})),e(Array.prototype,"min",(function(){return Math.min(...this)})),e(Array.prototype,"rand",(function(){return this[(this.length-1).random()]})),e(Array.prototype,"replace",(function(t,e){if(e=e.toString())for(var n in this)e=e.replace(this[n],t);return e})),e(Array.prototype,"shuffle",(function(t){var e=this.slice(t),n=(this.length-1).decrease();for(var r in n){var i=n[r].random(),s=e[n[r]];e[n[r]]=e[i],e[i]=s}return e})),e(Array.prototype,"trim",(function(){var t=[];for(var e in this)t.push(this[e].toString().trim());return t})),e(Array.prototype,"unique",(function(){return Array.from(new Set(this))})),e(Array.prototype,"update",(function(t,...e){return this.splice(t,1,...e)})),e(Array.prototype,"value",(function(){return this})),e(Array.prototype,"next",(function(t){return this[Number(t)+1]})),e(Array.prototype,"previous",(function(t){return this[Number(t)-1]})),e(Array,"keys",(function(){})),e(Array.keys,"exist",(function(t,e){return t in e})),e(Array.keys,"find",(function(t,e){return e.findIndex(t)})),e(Array.keys,"format",(function(t,e="{%s}"){var n=[];for(var r in t)n.push(e.format(t[r]));return n})),e(String,"descriptor",(function(t,n,r){return e.property(String.prototype,t,n,r)})),e(String.prototype,"string",(function(){return this.toString()})),e(String.prototype,"number",(function(){return Object.to.number(this)})),e(String.prototype,"integer",(function(){return Object.to.integer(this)})),e(String.prototype,"float",(function(){return Object.to.float(this)})),e(String.prototype,"char",(function(){return this.charCodeAt()})),e(String.prototype,"md",(function(){return Function.hash.md(this)})),e(String.prototype,"sha",(function(){return Function.hash.sha(this)})),e(String.prototype,"sha_s",(function(){return Function.hash.sha.s(this)})),e(String.prototype,"after",(function(t,e){return(e=this.indexOf(t,e))>=0?this.substr(e+t.length):""})),e(String.prototype,"begin",(function(t=1,e){return Object.is.string(t)?this.startsWith(t,e):this.substr(0,t)})),e(String.prototype,"before",(function(t,e){return(e=this.indexOf(t,e))>=0?this.substr(0,e):""})),e(String.prototype,"big",(function(){return this.toUpperCase()})),e(String.prototype,"count",(function(t,e){return arguments.length?this.substr(e).split(t).length-1:this.length-1})),e(String.prototype,"decode",(function(){return String.decode(this)})),e(String.prototype,"delete",(function(t){return this.split(t).join("")})),e(String.prototype,"encode",(function(t){return"base"===t?this.encode("base64"):"md"===t?this.md():"sex"===t?this.sex():"sexy"===t?this.sexy():String.encode(this)})),e(String.prototype,"end",(function(t=1,e){return Object.is.string(t)?this.endsWith(t,e):this.substr(-t)})),e(String.prototype,"exist",(function(t,e){return this.includes(t,e)})),e(String.prototype,"format",(function(...t){return Function.util.format(this.toString(),...t)})),e(String.prototype,"include",(function(t,e){for(var n in t)if(!1===this.includes(t[n],e))return!1;return!0})),e(String.prototype,"index",(function(t,e){return Function.indexOf(this.indexOf(t,e))})),e(String.prototype,"pad",(function(t,e,n="begin"){return"begin"===n?this.padStart(e,t):"end"===n?this.padEnd(e,t):this})),e(String.prototype,"pop",(function(t=1){return Object.is.string(t)?this.substr(0,this.length-t.length)===t:this.substr(0,this.length-t)})),e(String.prototype,"pos",(function(t,e=1){return this.substr(t,e)})),e(String.prototype,"rand",(function(){return this[(this.length-1).random()]})),e(String.prototype,"replace",(function(t,e){return Object.is.regex(t)?t[Symbol.replace](this,e):this.split(t).join(Object.is.set(e,""))})),e(String.prototype,"reverse",(function(){return this.split("").reverse().join("")})),e(String.prototype,"shift",(function(t=1){return Object.is.string(t)?this.substr(t.length)===t:this.substr(t)})),e(String.prototype,"shuffle",(function(){return this.split("").shuffle().join("")})),e(String.prototype,"small",(function(){return this.toLowerCase()})),e(String.prototype,"splice",(function(t=1){var e=[],n=[],r=t;for(var i in this)n.push(this[i]),i==r-1&&(e.push(n.join("")),n=[],r+=t);return n.length&&e.push(n.join("")),e})),e(String.prototype,"trim",(function(t){if("begin"===t)return this.trimStart();if("end"===t)return this.trimEnd();var e=this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"");if(t){for(var n in t=[],e=e.split(" "))e[n].trim()&&t.push(e[n]);return t.join(" ")}return e})),e(String.prototype,"uc_begin",(function(){return this.substr(0,1).toUpperCase()+this.substr(1)})),e(String.prototype,"uc_word",(function(){var t=this.split(" "),e=[];for(var n in t)e.push(t[n].uc_begin());return e.join(" ")})),e(String,"replace",(function(t,e,n){return n.split(t).join(e)})),e(String,"char",(function(){})),e(String.char,"alpha",{small:"abcdefghijklmnopqrstuvwxyz",big:"ABCDEFGHIJKLMNOPQRSTUVWXYZ",number:"0123456789",numeric:"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"}),e(String.char,"separator",{eol:"; ",c:", "}),e(String.char,"under",{score:"_"}),e(String.char,"c",","),e(String.char,"s"," "),e(String.char,"equal","="),e(String.char,"ls",":"),e(String.char,"eol",";"),e(String.char,"ln",{s:"\n",r:"\r",tab:"\t"}),e(String.char,"line",{r:"\r\n"}),e(Math,"BYTE",(function(){})),e(Math.BYTE,"log",[],{configurable:!0,enumerable:!0,writable:!0}),e(Math.BYTE,"unit",[],{configurable:!0,enumerable:!0,writable:!0}),e.get(Number.prototype,"length",(function(){return this.toString().length})),e(Number,"descriptor",(function(t,n,r){return e.property(Number.prototype,t,n,r)})),e(Number.prototype,"string",(function(){return this.toString()})),e(Number.prototype,"number",(function(){return Number(this)})),e(Number.prototype,"integer",(function(){return parseInt(this)})),e(Number.prototype,"float",(function(){return parseFloat(this)})),e(Number.prototype,"char",(function(){return String.fromCharCode(this)})),e(Number.prototype,"second",(function(){return 1e3*this})),e(Number.prototype,"absolute",(function(){return Math.abs(this)})),e(Number.prototype,"ceil",(function(){return Math.ceil(this)})),e(Number.prototype,"decrease",(function(t=0,e=1){var n=[];if(this>=t)for(var r=this;r>=t;r-=e)n.push(r);return n})),e(Number.prototype,"exponent",(function(t){return Math.pow(this,t)})),e(Number.prototype,"floor",(function(){return Math.floor(this)})),e(Number.prototype,"increase",(function(t,e=1){var n=[];if(this<=t)for(var r=this;r<=t;r+=e)n.push(r);return n})),e(Number.prototype,"log",(function(){return Math.log(this)})),e(Number.prototype,"rand",(function(t=0){var e=[this,t],n=Math.min(...e),r=Math.max(...e);return(r-n).absolute().random()+n})),e(Number.prototype,"random",(function(){return Math.floor(Math.random()*(this+1))})),e(Number.prototype,"round",(function(){return Math.round(this)})),e(Number.prototype,"percent",(function(t){return this/100})),e(Number.prototype,"percentage",(function(t){return this/t*100})),e(Number.prototype,"format",(function(t){return Number.format(this,t)})),e(Number,"format",(function(t,e){if(!0===(e=Number.properties(e)).byte)return e.byte=!1,n(t,e);t=t.toString().split(Number.float);var r=t[0],i=t[1],s=r.reverse().splice(e.thousand).join(e.separator).reverse();return i&&(s=s.concat(e.float,i.begin(e.decimal))),s})),e(Number.format,"extra",(function(t,e){return Number.format(String.replace(",","",String.replace(".","",Object.to.string(t))),e)})),e(Number.format,"clear",(function(t){return Number(String.replace(",","",String.replace(".","",Object.to.string(t))))})),e(Number,"char",String.char.alpha.number),e(Number,"BYTE",class{constructor(){for(var[t]of(Math.BYTE.log=[],Math.BYTE.unit=Number.BYTE.unit.key().reverse(),Number.BYTE.unit.entries()))Math.BYTE.log.push(Number.BYTE.log.exponent(t))}}),e(Number.BYTE,"log",1024),e(Number.BYTE,"unit",["B","KB","MB","GB","TB","PB","XB"]),e(Number,"properties",(function(t){return Object.assign({thousand:Number.thousand,decimal:Number.decimal,separator:Number.separator,delimiter:Number.delimiter,float:Number.float,byte:!1},t)})),e(Number,"thousand",3,{configurable:!0,enumerable:!0,writable:!0}),e(Number,"decimal",3,{configurable:!0,enumerable:!0,writable:!0}),e(Number,"separator",",",{configurable:!0,enumerable:!0,writable:!0}),e(Number,"delimiter"," ",{configurable:!0,enumerable:!0,writable:!0}),e(Number,"float",.5.toString().substr(1,1),{configurable:!0,enumerable:!0,writable:!0}),new Number.BYTE,e(Function,"define",e),e(Function,"context",(function(){var t=Function.argument.of(arguments),e=t.object,n=t.function;return e?n.bind(e):n})),e(Function,"argument",(function(){var t={length:arguments.length};for(var e in arguments)Object.is.object(arguments[e])?t.object=arguments[e]:Object.is.array(arguments[e])?t.array=arguments[e]:Object.is.string(arguments[e])?t.string=arguments[e]:Object.is.integer(arguments[e])?t.integer=arguments[e]:Object.is.number(arguments[e])?t.number=arguments[e]:Object.is.function(arguments[e])?t.function=arguments[e]:t.of=arguments[e];return t})),e(Function.argument,"of",(function(t){var e={length:t.length};for(var n in t)Object.is.object(t[n])?e.object=t[n]:Object.is.array(t[n])?e.array=t[n]:Object.is.string(t[n])?e.string=t[n]:Object.is.integer(t[n])?e.integer=t[n]:Object.is.number(t[n])?e.number=t[n]:Object.is.function(t[n])?e.function=t[n]:e.of=t[n];return e})),e(Function,"option",(function(t,e,n=!0){return n?Object.concat(e,t):Object.concat(t,e)})),e(Function.option,"of",(function(t,e,n=!0){return n?Object.merge(e,t):Object.merge(t,e)})),e(Function,"optional",(function(t,e={},n){if(n={})for(var r in t)r in e?n[e[r]]=t[r]:n[r]=t[r];return n})),e(Function.optional,"of",(function(t,e={},n){if((n={})&&(e=Object.flip(e)))for(var r in t)r in e?n[e[r]]=t[r]:n[r]=t[r];return n})),e.property(Function,"system",(function(){})),e.property(Function,"plugin",(function(){})),e.property(Date,"Time",class{constructor(t,e){this.option={zone:{year:0,month:0,day:0,hour:0,minute:0,second:0,ms:0},month:{name:Date.month.name},day:{name:Date.day.name}},this.get={year:0,month:0,day:0,hour:0,minute:0,second:0,ms:0},this.date={input:t},this.zone(e.zone)}use(t,e){"month:name"===t&&e&&(this.option.month.name=e),"day:name"===t&&e&&(this.option.day.name=e)}zone(t){if(t)for(var e in t)this.option.zone[e]=t[e];return this.set()}input(){return this.date.input=arguments,this.set()}offset(){var t,e;for(var n in arguments)"object"===typeof arguments[n]&&(t=arguments[n]),"number"===typeof arguments[n]&&(e=arguments[n]);return e?new Date.Time([e],this.option).set(t):this}set(t){if(null===t)return{year:{s:this.get.year,pad:this.get.year.toString()},month:{s:this.get.month,name:this.option.month.name[this.get.month],pad:Date.pad(this.get.month+1)},day:{s:this.get.day,name:this.option.day.name[this.get.week],pad:Date.pad(this.get.day)},hour:{s:this.get.hour,pad:Date.pad(this.get.hour),suffix:{pad:Date.pad(this.get.hour>12?this.get.hour-12:this.get.hour)},map:this.get.hour>12?"PM":"AM"},minute:{s:this.get.minute,pad:Date.pad(this.get.minute)},second:{s:this.get.second,pad:Date.pad(this.get.second)},ms:this.get.ms,week:this.get.week,stamp:this.get.stamp,query:{stamp:this.get.query.stamp}};t=Date.offset(t);var e=new Date(...this.date.input),n=e.getTime();return e=Date.property(new Date(n-Date.universal.offset),n),e=new Date(e.year+t.year+this.option.zone.year,e.month+t.month+this.option.zone.month,e.day+t.day+this.option.zone.day,e.hour+t.hour+this.option.zone.hour,e.minute+t.minute+this.option.zone.minute,e.second+t.second+this.option.zone.second,e.ms+t.ms+this.option.zone.ms),this.get=Date.property(e,n),this}object(){var t=this.set(null);return{Y:t.year.pad,M:t.month.pad,F:t.month.name,D:t.day.pad,L:t.day.name,H:t.hour.pad,I:t.minute.pad,S:t.second.pad,Q:t.ms,A:t.hour.map,J:t.hour.suffix.pad,W:t.week,X:t.stamp,Z:t.query.stamp}}format(){var t,e,n="default";for(var r in arguments)arguments[r]&&(Object.is.number(arguments[r])&&(e=arguments[r]),"string"===typeof arguments[r]&&(n=arguments[r]),"object"===typeof arguments[r]&&(t=arguments[r]));if(e)return this.offset(e,t).format(n);if(t)return this.offset(this.get.stamp,t).format(n);var i=[],s=this.object();for(var r in n=Date.format[n||"default"]||n,n=n.split(""),n)i.push(s[n[r]]||n[r]);return i.join("")}}),e.property(Date,"create",(function(t){return function(...e){return new Date.Time(e,t)}})),e.property(Date,"universal",(function(t){var e=new Date;if(t=Date.offset(t))return Date.universal.offset=Date.now()-new Date(e.getUTCFullYear()+t.year,e.getUTCMonth()+t.month,e.getUTCDate()+t.day,e.getUTCHours()+t.hour,e.getUTCMinutes()+t.minute,e.getUTCSeconds()+t.second,e.getUTCMilliseconds()+t.ms).getTime()})),e.value(Date.universal,"offset",0,{configurable:!0,enumerable:!0,writable:!0}),e.property(Date,"zone",(function(t){if(t)for(var e in t)Date.zone.offset[e]=t[e]})),e.value(Date.zone,"universal",{name:"Universal",base:{name:"UTC"},c:{name:"Universal"},offset:{hour:0,minute:0}},{configurable:!0,enumerable:!0,writable:!0}),e.property(Date,"stamp",(function(t,e){return t?(t=new Date(t))&&e&&(e=Date.offset(e))?new Date(t.getFullYear()+e.year,t.getMonth()+e.month,t.getDate()+e.day,t.getHours()+e.hour,t.getMinutes()+e.minute,t.getSeconds()+e.second,t.getMilliseconds()+e.ms).getTime():t.getTime():Date.now()})),e.property(Date,"sleep",(function(t,e=1,...n){return setTimeout(t,1e3*e,...n)})),e.property(Date.sleep,"clear",(function(t){clearTimeout(t)})),e.property(Date,"interval",(function(t,e=1,...n){return setInterval(t,1e3*e,...n)})),e.property(Date.interval,"clear",(function(t){clearInterval(t)})),e.property(Date,"expire",(function(t,e,n){return new Date(...Date.properties(new Date(e),n)).getTime()<t})),e.property(Date,"offset",(function(t){return Object.assign({year:0,month:0,day:0,hour:0,minute:0,second:0,ms:0},t)})),e.property(Date,"pad",(function(t,e=2){return t.toString().padStart(e,"0")})),e.value(Date,"month",{name:["January","February","March","April","May","June","July","August","September","October","November","December"]}),e.value(Date,"day",{name:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]}),e.value(Date,"format",{default:"L, F D, Y - H:I:S A",date:"Y-M-D","date:s":"Y-M","date:x":"YMD","date:c":"YM","date:time":"Y-M-D H:I:S",time:"H:I:S","time:s":"H:I","time:x":"HIS","time:c":"HI",factory:"D/M/Y"}),e.property(Date.Time,"zone",(function(t,n){if(!n)return t in Date.Time.zone?Date.Time.zone[t]:Date.zone.universal;e.value(Date.Time.zone,t,n,{configurable:!0,enumerable:!0,writable:!0})})),Date.Time.zone("asia/jakarta",{name:"",base:{name:"Asia/Jakarta"},c:{name:"Indonesia"},offset:{hour:7,minute:0}}),Date.Time.zone("asia/seoul",{name:"",base:{name:"Asia/Seoul"},c:{name:"South Korea"},offset:{hour:9,minute:0}}),Date.Time.zone("asia/tokyo",{name:"",base:{name:"Asia/Tokyo"},c:{name:"Japan"},offset:{hour:9,minute:0}}),Date.Time.zone("asia/singapore",{name:"",base:{name:"Asia/Singapore"},c:{name:"Singapore"},offset:{hour:8,minute:0}}),Date.Time.zone("asia/shanghai",{name:"",base:{name:"Asia/Shanghai"},c:{name:"China"},offset:{hour:8,minute:0}}),Date.Time.zone("asia/hong-kong",{name:"",base:{name:"Asia/Hong_Kong"},c:{name:"Hong Kong"},offset:{hour:8,minute:0}}),Date.Time.zone("asia/taipei",{name:"",base:{name:"Asia/Taipei"},c:{name:"Taiwan"},offset:{hour:8,minute:0}}),Date.Time.zone("asia/kuala-lumpur",{name:"",base:{name:"Asia/Kuala_Lumpur"},c:{name:"Malaysia"},offset:{hour:8,minute:0}}),Date.Time.zone("asia/qatar",{name:"",base:{name:"Asia/Qatar"},c:{name:"Qatar"},offset:{hour:3,minute:0}}),Date.Time.zone("asia/dubai",{name:"",base:{name:"Asia/Dubai"},c:{name:"United Arab Emirate (UAE)"},offset:{hour:4,minute:0}}),e.property(Date,"property",(function(t,e){return e=e||t.getTime(),{year:t.getFullYear(),month:t.getMonth(),day:t.getDate(),hour:t.getHours(),minute:t.getMinutes(),second:t.getSeconds(),ms:t.getUTCMilliseconds(),week:t.getDay(),query:{stamp:t.getTime()},stamp:e}})),e.property(Date,"properties",(function(t,e){return e=Date.offset(e),[t.getFullYear()+e.year,t.getMonth()+e.month,t.getDate()+e.day,t.getHours()+e.hour,t.getMinutes()+e.minute,t.getSeconds()+e.second,t.getUTCMilliseconds()+e.ms]})),e.value(URL,"host",{all:"0.0.0.0",local:"127.0.0.1"}),e.value(URL,"path","/"),e.value(URL,"protocol",{scheme:"http",secure:"https",file:{scheme:"ftp",secure:"ftps"}}),e.value(URL,"scheme",["http","https","ftp","ftps"]),e.value(URL,"favorite.ico","/favicon.ico"),e.value(URL,"package.json","./package.json"),e.value(URL,"/","./"),e.property(URL,"decode",(function(t){return decodeURIComponent(t)})),e.property(URL,"encode",(function(t){return encodeURIComponent(t)})),e.property(URL,"begin",(function(t){if(t){var e=[URL.protocol.scheme,URL.protocol.secure,URL.protocol.file.scheme,URL.protocol.file.secure];for(var n in e.push("file"),e)if(!1===t.startsWith(e[n]+"://"))return!1;return!0}})),e.property(URL,"end",(function(t){})),e.property(URL,"format",(function(t,e){Object.is.object(t)&&(e=t),e=Object.assign({protocol:URL.protocol.scheme,host:URL.host.all,path:URL.path},e);var n=e.protocol,r=e.host,i=e.path,s=URL.query.format(e.query);return e.secure&&(n=n.concat("s")),Object.is.string(t)?(t=t.concat(s)).begin("//")?n.concat(":").concat(t):t.begin("/")?n.concat("://",r,t):n.concat("://",t):n.concat("://",r,i.concat(s))})),e.property(URL,"parse",(function(t,e,n=!0){var r=URL.parse.component(t);return e=Object.assign({strict:!1,protocol:{s:URL.scheme,scheme:URL.protocol.scheme},host:URL.host.all,path:URL.path},e),r?(r.location=r.protocol.concat("://").concat(r.host.base.name),host=URL.parse.element(r.host.name,e.domain),(r.domain={name:"",base:{name:""},extension:"",sub:URL.domain.sub(),reverse:""})&&host&&(r.host["*"]="."+(r.domain.name=host.domain),r.domain.base.name=host.name,r.domain.extension=host.extension,r.domain.sub=host.sub,r.domain.reverse=host.reverse),r.name=r.domain.name||r.host.name,r.search&&(r.query=URL.query.parse(r.search,e.query)),r.port&&(r.port=Number(r.port)),(!0!==e.strict||!1!==e.protocol.s.includes(r.protocol))&&r):!(!0!==n||!(t=URL.parse(URL.format(t,{protocol:e.protocol.scheme,host:e.host}),e,!1)))&&t})),e.property(URL.parse,"component",(function(t){try{if(t.includes("://")&&(t=new URL(t)))return{reference:t.href,location:"",protocol:t.protocol.pop(),host:{name:t.hostname,base:{name:t.host},"*":t.hostname},port:t.port,user:t.username,password:t.password,search:t.search.shift(),query:{},path:URL.decode(t.pathname),tag:t.hash.shift()}}catch(e){}})),e.property(URL.parse,"element",(function(t,e){var n,r,i,s,o;if(t)for(var a in e=Object.assign({extension:URL.domain.extension(),sub:URL.domain.sub()},e),e.extension)if(t.end(o=(i=e.extension[a]).length)===i)return""===(s=t.pop((r=(n=t.pop(o).split(".").end()).concat(i)).length+1))&&(s=e.sub),{name:n,domain:r,extension:i,sub:s,reverse:s.split(".").reverse().join(".")}})),e.property(URL,"query",(function(){})),e.property(URL.query,"separator",(function(t){return t?URL.query.separator.value=t:URL.query.separator.value})),e.value(URL.query.separator,"value","&",{configurable:!0,enumerable:!0,writable:!0}),e.property(URL.query,"delimiter",(function(t){return t?URL.query.delimiter.value=t:URL.query.delimiter.value})),e.value(URL.query.delimiter,"value","=",{configurable:!0,enumerable:!0,writable:!0}),e.property(URL.query,"format",(function(t,e=!0){var n=[];if(t)for(var r in t)Array.isArray()?n.push(r.concat(URL.query.delimiter.value).concat("["+t[r].join(",")+"]")):n.push(r.concat(URL.query.delimiter.value).concat(t[r]));return n.length?e?"?"+n.join(URL.query.separator.value):n.join(URL.query.separator.value):""})),e.property(URL.query,"parse",(function(t){var e,n={};for(var r in t=t.split(URL.query.separator.value))for(var i in e=t[r].split(URL.query.delimiter.value))n[e[0]]=e[1];return n})),e.property(URL,"domain",(function(){})),e.property(URL.domain,"sub",(function(t){return t?URL.domain.sub.value=t:URL.domain.sub.value})),e.value(URL.domain.sub,"value","www",{configurable:!0,enumerable:!0,writable:!0}),e.property(URL.domain,"extension",(function(t){return t?URL.domain.extension.value=URL.domain.extension.sort(t):URL.domain.extension.value})),e.value(URL.domain.extension,"value",[".com",".net",".org"],{configurable:!0,enumerable:!0,writable:!0}),e.property(URL.domain.extension,"sort",(function(t){var e=[],n=[],r=t.sort();for(var i in r)r[i].count(".")>1?n.push(r[i]):e.push(r[i]);return n.concat(e)})),URL.domain.extension([".com",".net",".org",".info",".mobi",".tv",".co",".io",".me",".ninja",".blog",".site",".store",".shop",".live",".life",".cloud",".online",".app",".dev",".club",".id",".co.id",".xyz",".xxx",".local",".host"]),e.property(Function,"http",(function(){})),e.property(Function.http,"request",(function(){})),e.property(Function.http.request,"time",(function(){})),e.value(Function.http.request.time,"out",30,{configurable:!0,enumerable:!0,writable:!0}),e.value(Function.http.request,"method",{get:"GET",post:"POST",header:"HEAD",put:"PUT",delete:"DELETE",option:"OPTIONS"}),e.property(Function.http,"header",(function(){})),e.value(Function.http.header,"status",{OK:200,success:200,error:{request:400,forbidden:403,found:404,legal:451,s:500},message:{},code:{100:"Continue",101:"Switching Protocols",102:"Processing",200:"OK",201:"Created",202:"Accepted",203:"Non-authoritative Information",204:"No Content",205:"Reset Content",206:"Partial Content",207:"Multi-Status",208:"Already Reported",226:"IM Used",300:"Multiple Choices",301:"Moved Permanently",302:"Found",303:"See Other",304:"Not Modified",305:"Use Proxy",307:"Temporary Redirect",308:"Permanent Redirect",400:"Bad Request",401:"Unauthorized",402:"Payment Required",403:"Forbidden",404:"Not Found",405:"Method Not Allowed",406:"Not Acceptable",407:"Proxy Authentication Required",408:"Request Timeout",409:"Conflict",410:"Gone",411:"Length Required",412:"Precondition Failed",413:"Payload Too Large",414:"Request-URI Too Long",415:"Unsupported Media Type",416:"Requested Range Not Satisfiable",417:"Expectation Failed",418:"I'm a teapot",421:"Misdirected Request",422:"Unprocessable Entity",423:"Locked",424:"Failed Dependency",426:"Upgrade Required",428:"Precondition Required",429:"Too Many Requests",431:"Request Header Fields Too Large",444:"Connection Closed Without Response",451:"Unavailable For Legal Reasons",499:"Client Closed Request",500:"Internal Server Error",501:"Not Implemented",502:"Bad Gateway",503:"Service Unavailable",504:"Gateway Timeout",505:"HTTP Version Not Supported",506:"Variant Also Negotiates",507:"Insufficient Storage",508:"Loop Detected",510:"Not Extended",511:"Network Authentication Required",599:"Network Connect Timeout Error"}}),e.property(Function,"store",class{}),e.property(Function,"storage",class{constructor(){}static clear(){localStorage.clear()}static delete(t){localStorage.removeItem(t)}static set(t,e,n){return n&&t in localStorage?localStorage.getItem(t)||e:(arguments.length>1&&localStorage.setItem(t,e),e)}static get(t,e){if(t)return e=localStorage.getItem(t)||e,"null"===e?null:"true"===e||"false"!==e&&("undefined"===e?void 0:e);var n={},r=Object.keys(localStorage);for(var i in r)n[r[i]]=localStorage.getItem(r[i]);return n}static json(t,e,n){var r=localStorage.getItem(t);return n&&r?JSON.parse(r):(arguments.length>1&&localStorage.setItem(t,r=JSON.stringify(e)),r?JSON.parse(r):void 0)}}),e.property(Function,"session",class{constructor(){}static clear(){sessionStorage.clear()}static delete(t){sessionStorage.removeItem(t)}static set(t,e){return sessionStorage.setItem(t,e),e}static get(t,e){if(t)return e=sessionStorage.getItem(t)||e,"null"===e?null:"true"===e||"false"!==e&&("undefined"===e?void 0:e);var n={},r=Object.keys(sessionStorage);for(var i in r)n[r[i]]=sessionStorage.getItem(r[i]);return n}static json(t,e,n){var r=sessionStorage.getItem(t);return n&&r?JSON.parse(r):(arguments.length>1&&sessionStorage.setItem(t,r=JSON.stringify(e)),r?JSON.parse(r):void 0)}}),e.property(Function.session,"shuffle",(function(){return Date.now().toString().concat("-").concat(Function.hash.shuffle(Number.char))})),e.property(Function.session,"manager",class{constructor(t,e,n){this.data={},(this.proto=t)?this.proto.cookie=new Function.cookie(window.url.host["*"]):this.proto={cookie:new Function.cookie(window.url.host["*"])},e&&this.start(e,n)}start(t,e){if((this.option=Object.assign({name:"session",signature:"session.signature",secure:!1},t))&&(this.name=this.option.name,this.signature=this.option.signature,this.secure=this.option.secure,this.shuffle=this.option.id||Function.hash.shuffle()),this.proto.cookie.start()&&Object.is.empty(this.id=this.proto.cookie.get(this.name))&&(this.id=this.proto.cookie.set(this.name,this.shuffle,this.option),this.proto.cookie.set(this.signature,JSON.stringify({}).encode(),this.option)),(this.session=this.proto.cookie.get(this.signature).decode())&&(this.session=JSON.parse(this.session)))for(var n in this.session)this.data[n]=this.session[n];e&&e.call(this,this.id)}set(t,e,n){return n&&this.data[t]?this.data[t]:(this.data[t]=e,this.proto.cookie.set(this.signature,JSON.stringify(this.data).encode(),this.option),e)}get(t,e){return t?t in this.data?this.data[t]||e:"":this.data}delete(t){"*"===t?this.data={}:delete this.data[t],this.proto.cookie.set(this.signature,JSON.stringify(this.data).encode())}exist(t){return t in this.data}apply(t){return t&&(this.data=Object.merge(this.data,t)),this.data}}),e.property(Function,"cookie",class{constructor(t){(this.data={})&&(this.domain=t)}start(){var t=document.cookie.split(";");for(var e in t){var n=t[e].split("="),r=n[0].trim(),i=n[1];i&&(this.data[r]=i)}return this}set(t,e,n){var r=[];n=Object.assign({path:this.path||"/",domain:this.domain,expire:this.expire,mode:this.mode||"lax"},n);return r.push(t+"="+e),n.expire&&r.push("expire="+n.expire),n.domain&&r.push("domain="+n.domain),n.path&&r.push("path="+n.path),"lax"===n.mode&&r.push("samesite=lax"),!0===n.secure&&r.push("secure"),document.cookie=r.join(";"),this.data[t]=e}get(t,e){return t?t in this.data?this.data[t]||e:"":this.data}delete(t,e){if(t)this.set(t,"",e);else for(var n in this.data)delete this.data[n]&&this.set(n,"",e)}}),e.property(Function,"web",(function(){})),e.property(Function.web,"socket",class{constructor(t){this.socket=new WebSocket(this.url=t)}on(t,e){"open"===t&&(this.socket.onopen=e),"message"===t&&(this.socket.onmessage=e)}emit(t,e){arguments.length>1?this.socket.send(JSON.stringify({key:t,value:e})):this.socket.send(t)}}),e.property(Function.web.socket,"io",class{constructor(t,e){Object.is.function(t)?t.call(this):this.url=Function.web.socket.url(t),e&&this.start(e)}error(t){this.socket.on("connect_failed",t)}on(t,e){this.socket.on(t,e)}start(t){(this.ready=!0)&&(this.socket=Function.web.socket.io.client(this.url,{extraHeaders:{session:this.session,token:this.token}}))&&t&&t.call(this)}connect(){var t=this;t.on("connect",(function(){t.ready=!0})),t.on("disconnect",(function(){t.ready=null})),t.on("tokenizer",(function(e){t.tokenizer=e}))}emit(t,e,n){return this.ready&&(this.socket.emit(t,e={context:{id:Function.hash.shuffle(),session:this.session,tokenizer:this.tokenizer},data:e}),n?this.on(t,(function(t){Object.is.object(t)&&t.context&&t.context.id===e.context.id&&n&&n.call(t,t.data)})):(this.key=t,this.value=e)),this}catch(){}then(t){var e=this.key,n=this.value;this.on(e,(function(e){Object.is.object(e)&&e.context&&e.context.id===n.context.id&&t&&t.call(e,e.data)}))}}),e.property(Function.web.socket,"url",(function(t){return t=String.replace("http://","ws://",t),t=String.replace("https://","wss://",t),t})),e.property(Function,"data"),e.property(Function,"db",class{constructor(t,e){(this.file=t)&&(this.data=null,this.option=Object.assign({type:"json"},e),this.option.data&&(this.data=this.option.data),!1===Error.native(t=Function.file.read(this.file,this.option))&&!1===Object.is.buffer(t)&&(Object.is.object(t)?this.data=Object.merge(this.option.data,t):this.data=t))}start(t){(this.adapter=(t=Object.assign({slot:"query"},t)).adapter||Function.db.adapter("mongo"))&&("query"===(this.slot=t.slot)&&(this.option={host:t.host,user:t.user,password:t.password,database:t.name,namedPlaceholders:!0},this.param=Function.db.adapter[this.adapter].param,this.parameter=Function.db.adapter[this.adapter].parameter,"limit"in t&&(this.option.connectionLimit=t.limit),"pool"===t.type?this.pool():this.connection()),this.socket=t.socket),this.collection=new Function.db[this.slot].collection(this),this.view=new Function.db[this.slot].view(this)}connection(){return this.link=Function.db.adapter[this.adapter].connection(this.option),this}pool(){return this.link=Function.db.adapter[this.adapter].connection.pool(this.option),this}on(t,e){return this.link.on(t,e),this}query(...t){return Function.db.adapter[this.adapter].query(this.link,...t)}select(t,e){return new Function.db[this.slot].select(this,t,e)}insert(t,e){return new Function.db[this.slot].insert(this,t,e)}update(t,e){return new Function.db[this.slot].update(this,t,e)}delete(t,e){return this.file?(delete this.data[data],this.write()):new Function.db[this.slot].delete(this,t,e)}get(t,e){return t&&Object.is.object(this.data)?this.data[t]||e:this.data}set(t,e){return Object.is.object(this.data)?e?Object.is.object(e)&&Object.is.object(this.data[t])?this.data[t]=Object.merge(this.data[t],e):this.data[t]=e:Object.is.object(t)&&(this.data=Object.merge(this.data,t)):this.data=arguments.length>1?{[t]:e}:t,this}write(...t){t=Function.argument(...t);var e=Object.assign({type:this.option.type,pretty:!0},t.object),n=t.function;return Function.file.write(this.file,this.data,e,n),this}listen(t){t.call(this)}}),e.property(Function.db,"catch",(function(){return function(t){}})),e.property(Function.db,"query",(function(t,...e){return this.db.query(t.sql,t.param).then(...e)})),e.property(Function.db.query,"deprecate",(function(t,e,...n){return n.length?this.db.query(t.sql,t.param,...n):this.db.query(t.sql,t.param).then(e)})),e.property(Function.db.query,"collection",class{__(t,e,n){return this.command=t,this.collection=e,this.context=n,this}constructor(t){this.db=t,this.data={},this.option={on:[],sort:[],limit:[]},this.prefix=Function.db.adapter[this.db.adapter].query.collection.prefix}create(t,e){return this.__("create",t,e)}list(t,e){return this.__("list",t,e)}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}then(...t){return"list"===this.command?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.list(this.data.base),...t):"create"===this.command?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.create(this.data.base,this.collection,this.data.entry),...t):void 0}__then(t,...e){return"list"===this.command?t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.list(this.data.base),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.list(this.data.base),this.context,...[t].concat(e)):"create"===this.command?t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.create(this.data.base,this.collection,this.data.entry),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.collection.create(this.data.base,this.collection,this.data.entry),this.context,...[t].concat(e)):void 0}}),e.property(Function.db.query,"view",class{__(t,e,n){return this.command=t,this.collection=e,this.context=n,this}constructor(t){this.db=t,this.data={},this.option={on:[],sort:[],limit:[]},this.prefix=Function.db.adapter[this.db.adapter].query.view.prefix}create(t,e){return this.__("create",t,e)}select(t,e){return this.__("select",t,e)}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}meta(t){return this.data.meta=t,this}on(...t){return this.option.on=t,this}sort(...t){return this.option.sort=t,this}limit(...t){return this.option.limit=t,this}then(...t){return"create"===this.command?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view.create(this.data.base,this.collection,this.data.entry),...t):"select"===this.command?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),...t):void 0}__then(t,...e){return"create"===this.command?t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view.create(this.data.base,this.collection,this.data.entry),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view.create(this.data.base,this.collection,this.data.entry),this.context,...[t].concat(e)):"select"===this.command?t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.view(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),this.context,...[t].concat(e)):void 0}}),e.property(Function.db.query,"select",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={on:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}meta(t){return this.data.meta=t,this}parent(t){return this.data.parent=t,this}on(...t){return this.option.on=t,this}sort(...t){return this.option.sort=t,this}limit(...t){return this.option.limit=t,this}then(...t){return this.context?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.select(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),...[this.context].concat(t)):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.select(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),...t)}__then(t,...e){if(this.data.parent){var n={db:this.db,collection:this.collection,context:this.context,option:this.option};return this.promise=new Promise((function(t,e){var r=new Function.db.query.select(n.db,n.collection,n.context).on(...n.option.on).sort(...n.option.sort).limit(...n.option.limit).then((function(e){var r={all:[]};for(var i in e.data)r.function=function(t,i){return r.meta=function(n){e.data[this.index].child=n.data,t(e.data[this.index])},new Function.db.query.select(n.db,n.collection,n.context).on({parent:e.data[this.index].id}).then(r.meta.bind({index:this.index})).catch((function(){}))},r.all.push(new Promise(r.function.bind({index:i})));Promise.all(r.all).then((function(e){t({data:e,length:e.length})})).catch((function(){}))}));return r.catch((function(t){e(t)}))})),this.promise.then(t)}if(this.data.meta){n={db:this.db,collection:this.collection,context:this.context,option:this.option};return this.promise=new Promise((function(t,e){var r=new Function.db.query.select(n.db,n.collection,n.context).on(...n.option.on).sort(...n.option.sort).limit(...n.option.limit).then((function(e){var r={all:[]};for(var i in e.data)r.function=function(t,i){return r.meta=function(n){n.length;var r={};for(var i in n.data)r[n.data[i].name]=n.data[i].content;e.data[this.index].meta=r,t(e.data[this.index])},new Function.db.query.select(n.db,n.collection.concat("_").concat("meta"),n.context).on({parent:e.data[this.index].id}).then(r.meta.bind({index:this.index})).catch((function(){}))},r.all.push(new Promise(r.function.bind({index:i})));Promise.all(r.all).then((function(e){t({data:e,length:e.length})})).catch((function(){}))}));return r.catch((function(t){e(t)}))})),this.promise.then(t)}return t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.select(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.select(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),this.context,...[t].concat(e))}}),e.property(Function.db.query,"insert",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={on:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}then(...t){return Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.insert(this.data.base,this.collection,this.data.entry),...t)}__then(t,...e){return t?Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.insert(this.data.base,this.collection,this.data.entry),t,...e):Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.insert(this.data.base,this.collection,this.data.entry),this.context,...[t].concat(e))}}),e.property(Function.db.query,"update",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={on:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}set(t){return this.data.entry=t,this}on(...t){return this.option.on=t,this}sort(...t){return this.option.sort=t,this}limit(...t){return this.option.limit=t,this}then(...t){return Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.update(this.data.base,this.collection,this.data.entry,this.option.on,this.option.sort,this.option.limit),...t)}}),e.property(Function.db.query,"delete",class{constructor(t,e,n){this.db=t,this.collection=e,this.context=n,this.data={},this.option={on:[],sort:[],limit:[]}}from(t){return this.data.base=t,this}on(...t){return this.option.on=t,this}sort(...t){return this.option.sort=t,this}limit(...t){return this.option.limit=t,this}then(...t){return Function.db.query.call(this,Function.db.adapter[this.db.adapter].query.delete(this.data.base,this.collection,this.option.on,this.option.sort,this.option.limit),...t)}}),e.property(Function.db,"adapter",(function(t){return e.value(Function.db.adapter,"name",t,{configurable:!0,enumerable:!0,writable:!0}),t})),e.property(Function.db,"promise",(function(t){return Object.is.define(t)&&(Function.db.promise.value=t),Function.db.promise.value})),e.property(Function.db,"socket",(function(){})),e.property(Function,"sql",(function(){})),e.property(Function.sql,"eol",String.char.eol),e.property(Function.sql,"delimiter",String.char.separator.delimiter),e.property(Function.sql,"parse",(function(t){var e=[];for(var n in t=t.split(Function.sql.eol))t[n].trim()&&e.push(t[n].trim().concat(Function.sql.eol));return e})),e.property(Function.sql,"format",(function(t,e){for(var n in e)t=t.replace(n,e[n]);return t})),e.property(Function.sql,"debug",(function(t){return Object.is.define(t)&&(Function.sql.debug.value=t),Function.sql.debug.value})),e.property(Function,"promise",(function(t){return new Promise(t)})),e.property(Function.promise,"synchronous",(function(t){return new Promise((function(e,n){e(t)}))})),e.property(Function.promise,"context",class{constructor(...t){this.promise=new Promise(Function.context(...t))}then(...t){return this.promise=this.promise.then(Function.context(...t))}catch(t){return this.promise.catch(t)}}),e.property(Function.promise,"all",(function(...t){return Promise.all(...t)})),e.property(Function.promise,"resolve",(function(...t){return Promise.resolve(...t)})),e.property(Function.promise,"reject",(function(...t){return Promise.reject(...t)})),e.property(Function.promise,"start",(function(){e.property(Promise,"synchronous",Function.promise.synchronous),e.property(Promise,"context",Function.promise.context)})),e.property(Function,"serialize",(function(){})),e.property(Function,"xml",(function(){})),e.property(JSON,"format",(function(...t){return JSON.stringify(...t)})),e.property(JSON,"encode",(function(t,...e){try{return Object.is.define(t)?JSON.stringify(t,...e):new Error}catch(n){return new Error}})),e.property(JSON,"decode",(function(t){try{return Object.is.string(t)&&t?JSON.parse(t):new Error}catch(e){return new Error}})),e.property(JSON,"pretty",[null,4]),e.property(Function,"dom",(function(t){return new Function.dom.document(t)})),e.property(Function.dom,"document",class{constructor(t){Object.is.string(t)?this.dom=Function.dom.query.selector(t):this.dom=t,this.class=new Function.dom.class(this.dom)}content(t){if(this.dom)return Object.is.set(t)?this.dom.innerHTML=t:this.dom.innerHTML}text(t){return this.dom&&(this.dom.innerHTML=t),this}enable(t){return this.dom&&(this.dom.disabled=!t),this}focus(){return this.dom&&this.dom.focus(),this}value(t){if(null===t&&(this.dom.value=""),this.dom)return this.dom.value}attribute(t,e){if(this.dom)if(arguments.length>1)Object.is.set(e)?Function.dom.attribute.set(t,e,this.dom):Function.dom.attribute.delete(t,this.dom);else if(t)return Function.dom.attribute.get(t,this.dom);return this}remove(){return this.dom&&this.dom.remove(),this}play(){this.dom.play()}}),e.property(Function.dom,"class",class{constructor(t){this.dom=t}list(){return this.dom?this.dom.className.split(" "):[]}set(t){return this.dom&&(this.dom.className=t),this}insert(t){return this.dom&&!1===this.list().includes(t)&&(this.dom.className=this.dom.className+" "+t),this}delete(t){if(this.dom){var e=[],n=this.list();for(var r in n)t===n[r]===!1&&e.push(n[r]);this.dom.className=e.join(" ")}return this}}),e.property(Function.dom,"parse",(function(t,e,n){var r=n||{component:[],element:[]};t=t.toString((e=Object.assign({depth:!1},e)).encoding);if(null===n){var i=t.match(Function.dom.pattern.element);for(var s in i){var o=new RegExp(Function.dom.pattern.element).exec(i[s]),a=o[0],c=o[1],u={},l=o[2].match(Function.dom.pattern.attribute);for(var h in l){var d=new RegExp(Function.dom.pattern.attribute).exec(l[h]);u[d[1].trim()]=d[2]}r.element.push({tag:c,attribute:u,source:a})}}var f=t.match(Function.dom.pattern.component);for(var s in f){o=new RegExp(Function.dom.pattern.component).exec(f[s]),a=o[0],c=o[1],u={};var p=o[3];l=o[2].match(Function.dom.pattern.attribute);for(var h in l){d=new RegExp(Function.dom.pattern.attribute).exec(l[h]);u[d[1].trim()]=d[2]}r.component.push({tag:c,attribute:u,content:p,source:a}),!0===e.depth&&Function.dom.parse(p,e,r)}return r})),e.property(Function.dom,"component",(function(t,e,n){var r=[],i=Function.dom.pattern.tag.component(e),s=(t=t.toString((n=Object.assign({attribute:!1},n)).encoding)).match(new RegExp(i,"sig"));for(var o in s){var a=new RegExp(i,"sig").exec(s[o]),c=a[0],u=a[2],l={},h=a[1].match(Function.dom.pattern.attribute);for(var d in h){var f,p=new RegExp(Function.dom.pattern.attribute).exec(h[d]),m=p[1].trim(),g=p[2];n.attribute&&m.includes(":")?(f=m.split(":"),l[f[0]]||(l[f[0]]={}),l[f[0]][f[1]]=g):l[m]=g}r.push({attribute:l,content:u,source:c})}return r})),e.property(Function.dom,"element",(function(t,e,n){var r=[],i=Function.dom.pattern.tag.element(e),s=(t=t.toString((n=Object.assign({attribute:!1},n)).encoding)).match(new RegExp(i,"g"));for(var o in s){var a=new RegExp(i,"g").exec(s[o]),c=a[0],u={},l=a[1].match(Function.dom.pattern.attribute);for(var h in l){var d,f=new RegExp(Function.dom.pattern.attribute).exec(l[h]),p=f[1].trim(),m=f[2];n.attribute&&p.includes(":")?(d=p.split(":"),u[d[0]]||(u[d[0]]={}),u[d[0]][d[1]]=m):u[p]=m}r.push({attribute:u,source:c})}return r})),e.property(Function.dom.element,"get",(function(t){return document.getElementById(t.id)})),e.value(Function.dom,"pattern",{attribute:/(.*?)="(.*?)"/gis,component:/<([a-z:0-9]+)\s*(.*?)>\s*(.*?)\s*<\/\1>/gis,element:/<([a-z:0-9]+)\s*(.*?)\/>/g,tag:{component:function(t){return"<"+t+"s*(.*?)>s*(.*?)s*</"+t+">"},element:function(t){return"<"+t+"+s*(.*?)/>"}}}),e.property(Function.dom,"attribute",(function(t,e,n){return arguments.length>2?Function.dom.attribute.set(e,n,Function.dom.query.selector(t)):Function.dom.attribute.get(e,Function.dom.query.selector(t))})),e.property(Function.dom.attribute,"get",(function(t,e){if(e)return e.getAttribute(t)||""})),e.property(Function.dom.attribute,"set",(function(t,e,n){if(n)return n.setAttribute(t,e)})),e.property(Function.dom.attribute,"delete",(function(t,e){if(e)return e.removeAttribute(t)})),e.property(Function.dom,"query",(function(){})),e.property(Function.dom.query,"selector",(function(t){return document.querySelector(t.split(":").join("\\:"))})),e.property(Function,"query",(function(){})),e.property(Function.query,"selector",(function(...t){var e=[];for(var n in t)if("string"===typeof t[n]&&e.push("["+t[n]+"]"),"object"===typeof t[n]){var r=[];for(var i in t[n])null===t[n][i]?r.push("["+i+"]"):r.push("["+i+"='"+t[n][i]+"']");e.push(r.join(", "))}return e.join(" > ")})),e.property(Function,"scroll",(function(t,e){t=t||0,e=e||0,window.scrollTo(t,e)})),e.property(Function.scroll,"on",(function(t){window.onscroll=t})),e.property(Function.scroll.on,"top",(function(){return 0===window.scrollY})),e.property(Function.scroll,"top",(function(){return window.scrollY})),e.property(Function,"visitor",(function(t){var e={browser:{name:t||window.navigator.userAgent},device:{name:"computer"}};t=e.browser.name.toLowerCase();return t.includes("android")&&(t.includes("wv")&&(e.browser.model="web-view"),t.includes("mobile")?e.device.name="phone":e.device.name="tablet",t.includes("android")&&(e.device.model="a")),t.includes("mac")&&(t.includes("iphone")?e.device.name="phone":t.includes("ipad")?e.device.name="tablet":e.device.name="computer",t.includes("iphone")&&(e.device.model="i")),e})),e.property(Function.visitor,"__",(function(t){var n=Function.visitor();for(var r in n)e.value(Function.visitor,r,n[r])})),e.property(Function,"user",(function(){})),e.property(Function.user,"name",(function(t,e){Function.user.name[t]=e})),Function.user.name("length",6),e(Object.is,"user",(function(){})),e(Object.is.user,"name",(function(t){var e=["-","_","."];if((t=Object.to.string(t).trim().toLowerCase())&&String.char.alpha.small.split("").includes(t.begin())&&String.char.alpha.numeric.split("").concat(e).include(t.split(""))&&!1===e.includes(t.end())){for(var n in e)if(t.includes(e[n].repeat(2)))return!1;if(t.length>Function.user.name.length-1)return!0}return!1})),e.property(Function,"email",(function(){})),e.property(Function.email,"format",(function(t,e){return t.concat("@",e)})),e(Object.is,"email",(function(t){if(t=Object.to.string(t).trim().toLowerCase()){t.before("@").trim();var e,n=t.after("@").trim();if((e=URL.parse(n))&&e.domain.name)return!0}return!1})),e.property(Function,"phone",(function(){})),e(Object.is,"phone",(function(t){if((t=Object.to.string(t).trim().toLowerCase())&&("+"===t.substr(0,1)||"0"===t.substr(0,1)))return Object.is.number(t.substr(1))})),e.property(Function,"mobile",(function(){})),e.property(Function.mobile,"i",(function(){})),e.property(Function.mobile,"a",(function(){})),e.property(Function.mobile.a,"exit",(function(){Android.exit()})),e.property(Function.mobile.a,"toast",(function(t){Android.toast(t)})),e.property(Function.mobile.a,"notification",(function(t,e,n,r,i){Android.notification(t,e,n,r,i)})),e.property(Function.mobile.a,"audio",(function(t){Android.audio(t)})),e.property(Function.mobile.a,"printhermal",(function(t){Android.printhermal(t)})),e.property(Function,"audio",(function(t,e){return URL.begin(t=t||"audio")?new Function.audio.player(t):(t in Function.audio.play.list&&(t=Function.audio.play.list[t]),"web-view"===Function.visitor.browser.model?Function.mobile[Function.visitor.device.model].audio(t):(e&&(t=e(t)),new Function.audio.player(t)))})),e.property(Function.audio,"player",class{constructor(t){this.audio=new Audio(t)}play(){this.audio.play()}}),e.property(Function.audio,"play",(function(){})),e.property(Function.audio.play,"list",(function(t,n){e.value(Function.audio.play.list,t,n,{configurable:!0,enumerable:!0,writable:!0})})),e.property(Function,"geo",(function(){return this})),e.property(Function.geo,"location",class{constructor(){}start(t,e){return(this.navigator=window.navigator.geolocation)&&t?t.call():e?e.call():void 0}watch(t,e,n){return this.id=this.navigator.watchPosition((function(e){t.call(null,e.coords)}),e,n)}clear(t){this.navigator.clearWatch(t||this.id)}}),e.property(Function.geo.location,"coordinate",(function(...t){return t.length>1?{latitude:t[0],longitude:t[1]}:t.length?{latitude:t[0].latitude,longitude:t[0].longitude}:{latitude:0,longitude:0}})),e.property(Function,"map",class{constructor(t,e,n="google"){this.provider=n,this.icon=Function.plugin[this.provider].map.icon,this.instance=Function.plugin[this.provider].map(t,e)}marker(t){return new Function.map.marker(this,t)}center(...t){return this.instance.setCenter(this.coordinate(...t)),this}coordinate(...t){return Function.plugin[this.provider].map.coordinate(...t)}}),e.property(Function.map,"marker",class{constructor(t,e){this.marker=Function.plugin[(this.map=t).provider].map.marker(this.map.instance,e)}coordinate(...t){return this.marker.setPosition(this.map.coordinate(...t)),this}info_window(t){Function.plugin[this.map.provider].map.marker.info_window(this.map.instance,this.marker,Function.plugin[this.map.provider].map.info_window(t))}}),e.property(Function.plugin,"google",(function(){})),e.property(Function.plugin.google,"map",(function(t,e){return new google.maps.Map(t,e)})),e.property(Function.plugin.google.map,"marker",(function(t,e){return new google.maps.Marker(Object.assign({map:t},e))})),e.property(Function.plugin.google.map.marker,"info_window",(function(t,e,n){e.addListener("click",(function(){n.open(t,e)}))})),e.property(Function.plugin.google.map,"info_window",(function(t){return new google.maps.InfoWindow({content:t})})),e.property(Function.plugin.google.map,"coordinate",(function(...t){return new google.maps.LatLng(Number((t=Function.geo.location.coordinate(...t)).latitude),Number(t.longitude))})),e.value(Function.plugin.google.map,"icon",{base:{url:"https://maps.google.com/mapfiles/kml/shapes/"}}),Function.plugin.google.map.icon.base.src={library:Function.plugin.google.map.icon.base.url+"library_maps.png",parking:Function.plugin.google.map.icon.base.url+"parking_lot_maps.png",info:Function.plugin.google.map.icon.base.url+"info-i_maps.png"},Function.plugin.google.map.icon.src={"flag-beach":"https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png"},e.property(Function.plugin.google,"fire",(function(){})),e.property(Function.plugin.google.fire,"base",class{constructor(t){this.link=t||Function.plugin.google.fire.base.link}start(t,e){this.url=URL.parse(e),this.link=this.link.initializeApp(Function.plugin.google.fire.base.config(this.config=t)),this.account=new Function.plugin.google.fire.base.account(this)}}),e.property(Function.plugin.google.fire.base,"config",(function(t){return{appId:t.id,apiKey:t.key,messagingSenderId:t.messaging,projectId:t.project,authDomain:t.domain,storageBucket:t.bucket}})),e.property(Function.plugin.google.fire.base,"account",class{constructor(t){this.fire={base:t},this.sign=new Function.plugin.google.fire.base.account.sign(t,this)}state(t){this.fire.base.link.auth().onAuthStateChanged((function(e){t&&t.call(null,e)}))}profile(t){return{name:t.displayName,phone:t.phoneNumber,photo:t.photoURL}}catch(){}then(){}}),e.property(Function.plugin.google.fire.base.account,"sign",class{constructor(t,e){this.fire={base:t},this.account=e}up(t,e="email"){return"email"===e?this.fire.base.link.auth().createUserWithEmailAndPassword(t.email,t.password):this}in(t,e="email"){return"email"===e?this.fire.base.link.auth().signInWithEmailAndPassword(t.email,t.password):this}out(){return this.fire.base.link.auth().signOut()}catch(){}then(){}})}).call(this,n("b639").Buffer)},cee4:function(t,e,n){"use strict";var r=n("c532"),i=n("1d2b"),s=n("0a06"),o=n("4a7b"),a=n("2444");function c(t){var e=new s(t),n=i(s.prototype.request,e);return r.extend(n,s.prototype,e),r.extend(n,e),n.create=function(e){return c(o(t,e))},n}var u=c(a);u.Axios=s,u.Cancel=n("7a77"),u.CancelToken=n("8df4"),u.isCancel=n("2e67"),u.VERSION=n("5cce").version,u.all=function(t){return Promise.all(t)},u.spread=n("0df6"),u.isAxiosError=n("5f02"),t.exports=u,t.exports.default=u},d925:function(t,e,n){"use strict";t.exports=function(t){return/^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(t)}},df2f:function(t,e,n){(function(e,r){t.exports=r(n("21bf"))})(0,(function(t){return function(){var e=t,n=e.lib,r=n.WordArray,i=n.Hasher,s=e.algo,o=[],a=s.SHA1=i.extend({_doReset:function(){this._hash=new r.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(t,e){for(var n=this._hash.words,r=n[0],i=n[1],s=n[2],a=n[3],c=n[4],u=0;u<80;u++){if(u<16)o[u]=0|t[e+u];else{var l=o[u-3]^o[u-8]^o[u-14]^o[u-16];o[u]=l<<1|l>>>31}var h=(r<<5|r>>>27)+c+o[u];h+=u<20?1518500249+(i&s|~i&a):u<40?1859775393+(i^s^a):u<60?(i&s|i&a|s&a)-1894007588:(i^s^a)-899497514,c=a,a=s,s=i<<30|i>>>2,i=r,r=h}n[0]=n[0]+r|0,n[1]=n[1]+i|0,n[2]=n[2]+s|0,n[3]=n[3]+a|0,n[4]=n[4]+c|0},_doFinalize:function(){var t=this._data,e=t.words,n=8*this._nDataBytes,r=8*t.sigBytes;return e[r>>>5]|=128<<24-r%32,e[14+(r+64>>>9<<4)]=Math.floor(n/4294967296),e[15+(r+64>>>9<<4)]=n,t.sigBytes=4*e.length,this._process(),this._hash},clone:function(){var t=i.clone.call(this);return t._hash=this._hash.clone(),t}});e.SHA1=i._createHelper(a),e.HmacSHA1=i._createHmacHelper(a)}(),t.SHA1}))},df7c:function(t,e,n){(function(t){function n(t,e){for(var n=0,r=t.length-1;r>=0;r--){var i=t[r];"."===i?t.splice(r,1):".."===i?(t.splice(r,1),n++):n&&(t.splice(r,1),n--)}if(e)for(;n--;n)t.unshift("..");return t}function r(t){"string"!==typeof t&&(t+="");var e,n=0,r=-1,i=!0;for(e=t.length-1;e>=0;--e)if(47===t.charCodeAt(e)){if(!i){n=e+1;break}}else-1===r&&(i=!1,r=e+1);return-1===r?"":t.slice(n,r)}function i(t,e){if(t.filter)return t.filter(e);for(var n=[],r=0;r<t.length;r++)e(t[r],r,t)&&n.push(t[r]);return n}e.resolve=function(){for(var e="",r=!1,s=arguments.length-1;s>=-1&&!r;s--){var o=s>=0?arguments[s]:t.cwd();if("string"!==typeof o)throw new TypeError("Arguments to path.resolve must be strings");o&&(e=o+"/"+e,r="/"===o.charAt(0))}return e=n(i(e.split("/"),(function(t){return!!t})),!r).join("/"),(r?"/":"")+e||"."},e.normalize=function(t){var r=e.isAbsolute(t),o="/"===s(t,-1);return t=n(i(t.split("/"),(function(t){return!!t})),!r).join("/"),t||r||(t="."),t&&o&&(t+="/"),(r?"/":"")+t},e.isAbsolute=function(t){return"/"===t.charAt(0)},e.join=function(){var t=Array.prototype.slice.call(arguments,0);return e.normalize(i(t,(function(t,e){if("string"!==typeof t)throw new TypeError("Arguments to path.join must be strings");return t})).join("/"))},e.relative=function(t,n){function r(t){for(var e=0;e<t.length;e++)if(""!==t[e])break;for(var n=t.length-1;n>=0;n--)if(""!==t[n])break;return e>n?[]:t.slice(e,n-e+1)}t=e.resolve(t).substr(1),n=e.resolve(n).substr(1);for(var i=r(t.split("/")),s=r(n.split("/")),o=Math.min(i.length,s.length),a=o,c=0;c<o;c++)if(i[c]!==s[c]){a=c;break}var u=[];for(c=a;c<i.length;c++)u.push("..");return u=u.concat(s.slice(a)),u.join("/")},e.sep="/",e.delimiter=":",e.dirname=function(t){if("string"!==typeof t&&(t+=""),0===t.length)return".";for(var e=t.charCodeAt(0),n=47===e,r=-1,i=!0,s=t.length-1;s>=1;--s)if(e=t.charCodeAt(s),47===e){if(!i){r=s;break}}else i=!1;return-1===r?n?"/":".":n&&1===r?"/":t.slice(0,r)},e.basename=function(t,e){var n=r(t);return e&&n.substr(-1*e.length)===e&&(n=n.substr(0,n.length-e.length)),n},e.extname=function(t){"string"!==typeof t&&(t+="");for(var e=-1,n=0,r=-1,i=!0,s=0,o=t.length-1;o>=0;--o){var a=t.charCodeAt(o);if(47!==a)-1===r&&(i=!1,r=o+1),46===a?-1===e?e=o:1!==s&&(s=1):-1!==e&&(s=-1);else if(!i){n=o+1;break}}return-1===e||-1===r||0===s||1===s&&e===r-1&&e===n+1?"":t.slice(e,r)};var s="b"==="ab".substr(-1)?function(t,e,n){return t.substr(e,n)}:function(t,e,n){return e<0&&(e=t.length+e),t.substr(e,n)}}).call(this,n("4362"))},e3db:function(t,e){var n={}.toString;t.exports=Array.isArray||function(t){return"[object Array]"==n.call(t)}},e683:function(t,e,n){"use strict";t.exports=function(t,e){return e?t.replace(/\/+$/,"")+"/"+e.replace(/^\/+/,""):t}},e691:function(t,e,n){"use strict";n.d(e,"a",(function(){return i})),n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return l})),n.d(e,"d",(function(){return h}));
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r=[];var i;(function(t){t[t["DEBUG"]=0]="DEBUG",t[t["VERBOSE"]=1]="VERBOSE",t[t["INFO"]=2]="INFO",t[t["WARN"]=3]="WARN",t[t["ERROR"]=4]="ERROR",t[t["SILENT"]=5]="SILENT"})(i||(i={}));const s={debug:i.DEBUG,verbose:i.VERBOSE,info:i.INFO,warn:i.WARN,error:i.ERROR,silent:i.SILENT},o=i.INFO,a={[i.DEBUG]:"log",[i.VERBOSE]:"log",[i.INFO]:"info",[i.WARN]:"warn",[i.ERROR]:"error"},c=(t,e,...n)=>{if(e<t.logLevel)return;const r=(new Date).toISOString(),i=a[e];if(!i)throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`);console[i](`[${r}]  ${t.name}:`,...n)};class u{constructor(t){this.name=t,this._logLevel=o,this._logHandler=c,this._userLogHandler=null,r.push(this)}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in i))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel="string"===typeof t?s[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if("function"!==typeof t)throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,i.DEBUG,...t),this._logHandler(this,i.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,i.VERBOSE,...t),this._logHandler(this,i.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,i.INFO,...t),this._logHandler(this,i.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,i.WARN,...t),this._logHandler(this,i.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,i.ERROR,...t),this._logHandler(this,i.ERROR,...t)}}function l(t){r.forEach(e=>{e.setLogLevel(t)})}function h(t,e){for(const n of r){let r=null;e&&e.level&&(r=s[e.level]),n.userLogHandler=null===t?null:(e,n,...s)=>{const o=s.map(t=>{if(null==t)return null;if("string"===typeof t)return t;if("number"===typeof t||"boolean"===typeof t)return t.toString();if(t instanceof Error)return t.message;try{return JSON.stringify(t)}catch(e){return null}}).filter(t=>t).join(" ");n>=(null!==r&&void 0!==r?r:e.logLevel)&&t({level:i[n].toLowerCase(),message:o,args:s,type:e.name})}}}},f30a:function(t,e,n){"use strict";n.d(e,"a",(function(){return i}));var r=n("b774");class i{constructor(t,e){this.target=null,this.targetQueue=[],this.onQueue=[],this.plugin=t,this.hook=e;const n={};if(t.settings)for(const r in t.settings){const e=t.settings[r];n[r]=e.defaultValue}const i="__vue-devtools-plugin-settings__"+t.id;let s={...n};try{const t=localStorage.getItem(i),e=JSON.parse(t);Object.assign(s,e)}catch(o){}this.fallbacks={getSettings(){return s},setSettings(t){try{localStorage.setItem(i,JSON.stringify(t))}catch(o){}s=t}},e.on(r["a"],(t,e)=>{t===this.plugin.id&&this.fallbacks.setSettings(e)}),this.proxiedOn=new Proxy({},{get:(t,e)=>this.target?this.target.on[e]:(...t)=>{this.onQueue.push({method:e,args:t})}}),this.proxiedTarget=new Proxy({},{get:(t,e)=>this.target?this.target[e]:"on"===e?this.proxiedOn:Object.keys(this.fallbacks).includes(e)?(...t)=>(this.targetQueue.push({method:e,args:t,resolve:()=>{}}),this.fallbacks[e](...t)):(...t)=>new Promise(n=>{this.targetQueue.push({method:e,args:t,resolve:n})})})}async setRealTarget(t){this.target=t;for(const e of this.onQueue)this.target.on[e.method](...e.args);for(const e of this.targetQueue)e.resolve(await this.target[e.method](...e.args))}}},f6b4:function(t,e,n){"use strict";var r=n("c532");function i(){this.handlers=[]}i.prototype.use=function(t,e,n){return this.handlers.push({fulfilled:t,rejected:e,synchronous:!!n&&n.synchronous,runWhen:n?n.runWhen:null}),this.handlers.length-1},i.prototype.eject=function(t){this.handlers[t]&&(this.handlers[t]=null)},i.prototype.forEach=function(t){r.forEach(this.handlers,(function(e){null!==e&&t(e)}))},t.exports=i},fa1c:function(t,e){Function.define(Function,"event",class{constructor(t){this.event={},t&&"event"in t===!1&&(Function.define(t,"event",this),Function.define(t,"on",(function(e,n){t.on(e,n)})),Function.define(t,"emit",(function(e,...n){t.emit(e,...n)})))}on(t,e){t in this.event===!1&&(this.event[t]=[]),this.event[t].push(e)}emit(t,...e){for(var n in this.event[t])this.event[t][n].call(this.proto,...e)}})}}]);
//# sourceMappingURL=chunk-vendors.66fd2615.js.map